#coding:utf-8

wx_config = {'jd':120.092125,'wd':23.099994,'num':10,'time':1440}


