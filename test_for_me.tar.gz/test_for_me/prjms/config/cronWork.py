# -*- coding: utf-8 -*-
import tornado.web
import database.readdb as rd
import json
import datetime
from config import config
import time
from business_calendar import Calendar,MO, TU, WE, TH, FR, SA, SU
from functools import reduce
import logging
from handlers.pmsManager.projectComment import comment_sub

def str2float(s):
    L = s.split('.')
    return reduce(lambda x,y:y+x*10, map(int,L[0])) + reduce(lambda x,y:y+x*10, map(int,L[1]))/10**len(L[1])


#为了便于日后统计，为免考勤用户自动进行每日的打卡考勤记录
def register_for_exempt_ck_in_user(the_code):
    holidaysDict = config.HOLIDAYS
    holidaysList = []
    for k1 in holidaysDict:
        for k2 in holidaysDict[k1]:
            holidaysList.append(k1 + k2)
    day = str(datetime.date.today())
    time = datetime.datetime.now()
    pms_time = rd.select("select * from pms_time where code = '%s'" %the_code)
    if pms_time:
        pms_time = pms_time[0]
    chi_time = day + ' ' + pms_time['value']
    if the_code == '01' or the_code == '04':
        chi_time = datetime.datetime.strptime(chi_time,'%Y-%m-%d %H:%M') - datetime.timedelta(minutes=5)
    elif the_code == '02' or the_code == '05':
        chi_time = datetime.datetime.strptime(chi_time,'%Y-%m-%d %H:%M') + datetime.timedelta(minutes=5)
    chi_name = pms_time['name'] 
    if day.replace('-','') in holidaysList:   
        logging.info("今日为休假日,无需进行免考勤用户自动%s(%s)打卡操作,时间>%s." %(chi_name,chi_time,time.strftime("%Y-%m-%d %H:%M:%S")))
        return 
    sql1 = "select id, no, name from pms_user where exempt_ck_in = 'true'"
    data = rd.select(sql1)
    user_id_list = []    
    for d in data:
        sql2 = """
                insert into PMS_SIGNRECODE  (id,time,datetime,pms_user_id,latitude,longitude,am_start_time,am_end_time,noon_time,pm_start_time,pm_end_time)  
                    values(seq_PMS_SIGNRECODE.nextval,to_timestamp('%s','syyyy-mm-dd hh24:mi:ss.ff'),
                    '%s','%s','000.000000','00.000000',(select value from pms_time where code = \'01\'),(select value from pms_time where code = \'02\'),(select value from pms_time where code = \'03\'),(select value from pms_time where code = \'04\'),(select value from pms_time where code = \'05\'))
                """ %(chi_time,day,d['id'])

        rd.insert(sql2)
        user_id_list.append({'id':d['id'], 'no':d['no'], 'name':d['name']})
    logging.info("免考勤用户组%s定时自动%s(%s)打卡任务完成,时间>%s." %(user_id_list, chi_name, chi_time, time.strftime("%Y-%m-%d %H:%M:%S")))

#根据人员考勤情况和人员纪律情况, 计算月初至目前的人员评分情况,并修改 其在pms_user_evaluation_score表中的本月数据
def count_user_evaluation_score():
    day = str(datetime.date.today()).replace('-','')
    #查看本月 还未录入人员评价汇总表的人员ID
    data = rd.select("""
                       select id from pms_user pu where id not in (select pms_user_id from pms_user_evaluation_score where year = '%s' and month = '%s')
                       """ %(day[0:4],day[4:6]))
    #为以上人员插入本月评价初始数据
    for d in data:
        rd.insert("""
                    insert into pms_user_evaluation_score (id, year, month, pms_user_id, check_in_deducted, discipline_deducted, residue_score, manual_up)
                        values(seq_pms_user_evaluation_score.nextval, '%s', '%s', '%s', '0', '0', '100', 'false')
                    """ %(day[0:4], day[4:6], d['id']))

    #此处copy了 人员考勤 界面的sql,略微进行对其进行修改,用得出的结果进行计算
    now = time.localtime()
    begin = '%d%02d01' %(now.tm_year, now.tm_mon)#本月初
    end = '%d%02d%02d' %(now.tm_year, now.tm_mon, now.tm_mday) #今天
    time_quantum = begin + '-' + end
    #早于上线时间以上线时间为下限
    if config.ONLINE_DATE > begin:
        begin = config.ONLINE_DATE
    if config.ONLINE_DATE > end:
        end = config.ONLINE_DATE
    # 过滤 双休和节假日
    holidaysDict = config.HOLIDAYS
    holidaysList = []
    for k1 in holidaysDict:
        for k2 in holidaysDict[k1]:
            holidaysList.append(k1 + k2)
    cal = Calendar(workdays=[MO, TU, WE, TH, FR, SA, SU],holidays=holidaysList)
    days = cal.busdaycount(datetime.datetime.strptime(begin, '%Y%m%d') - datetime.timedelta(days=1),datetime.datetime.strptime(end, '%Y%m%d'))
    sql_status = "select * from pms_status where code = 'delete'"
    status_delete = rd.select(sql_status)[0]['id']
    data_check_in = rd.select("""
        select max(pspu.user_id) as user_id, max(pspu.user_no) as user_no, max(pspu.user_name) as user_name , to_char(%s - (count(*) - sum(null_count))/2)  as  no_check_in_days ,
                            sum(pspu.shangban_outtime) as sb_error, sum(pspu.xiaban_outtime) as xb_error, '%s' as time_quantum, 
                            max(pspu.discipline_deducted) as discipline_deducted
                            from 
                                (
                                    select max(pu.id) as user_id, max(pu.no) as user_no,max(pu.name) as user_name, max(pu.org_id) as user_org_id,count(*) as count ,max(datetime) as datetime ,
                                        case when to_char(max(time),'hh24mi')   < replace(max(pm_end_time),':','')   then 1 else 0 end as xiaban_outtime , 
                                        case when to_char(min(time),'hh24mi')  >= replace(min(pm_start_time),':','')   then 1 else 0  end as shangban_outtime,
                                        case when max(datetime) is null then 1 else 0 end as null_count,
                                        max(pue.score) as  discipline_deducted
                                        from pms_user pu
                                        left join (select * from PMS_SIGNRECODE where  replace(datetime,'-','') >= '%s' and  replace(datetime,'-','') <= '%s' and to_char(time,'hh24mi') >= replace(noon_time,':',''))  ps on pu.id = ps.pms_user_id
                                        left join pms_user_evaluate pue on pue.id = pu.pms_user_evaluate_id 
                                        where pu.status_id != '%s'
                                        group by ps.datetime, pu.no 
                                    union all
                                    select max(pu.id) as user_id, max(pu.no) as user_no,max(pu.name) as user_name, max(pu.org_id) as user_org_id,count(*) as count ,max(datetime) as datetime ,
                                        case when to_char(max(time),'hh24mi')   < replace(max(am_end_time),':','')  then 1 else 0 end as xiaban_outtime , 
                                        case when to_char(min(time),'hh24mi')  >= replace(min(am_start_time),':','')  then 1 else 0  end as shangban_outtime,
                                        case when max(datetime) is null then 1 else 0 end as null_count,
                                        max(pue.score) as  discipline_deducted
                                        from pms_user pu
                                        left join (select * from PMS_SIGNRECODE where  replace(datetime,'-','') >= '%s' and  replace(datetime,'-','') <= '%s' and to_char(time,'hh24mi') < replace(noon_time,':',''))  ps on pu.id = ps.pms_user_id
                                        left join pms_user_evaluate pue on pue.id = pu.pms_user_evaluate_id 
                                        where pu.status_id != '%s'
                                        group by ps.datetime, pu.no
                                ) pspu
                             where pspu.user_id  in  (select pms_user_id from pms_user_evaluation_score where year = '%s' and month = '%s' and manual_up = 'false') group by pspu.user_no
            """ % (days, time_quantum, begin, end, status_delete, begin, end, status_delete,day[0:4], day[4:6]))
    
    cki1 = rd.select("select score from  pms_user_evaluate where code = '01'")[0]['score'] #当月迟到或早退一次(应扣分值)
    cki2 = rd.select("select score from  pms_user_evaluate where code = '02'")[0]['score'] #当月迟到或早退两次(应扣分值)
    cki3 = rd.select("select score from  pms_user_evaluate where code = '03'")[0]['score'] #当月迟到或早退三次(应扣分值)
    cki4 = rd.select("select score from  pms_user_evaluate where code = '04'")[0]['score'] #当月迟到或早退三次以上(应扣分值)，或无故旷工
    cki_rate = rd.select("select score from  pms_user_evaluate where code = '10'")[0]['score'] #考勤评价占人员评价权重(比值)
    dpe_rate = rd.select("select score from  pms_user_evaluate where code = '11'")[0]['score'] #纪律评价占人员评价权重(比值)
    for dci in data_check_in:
        pms_user_id = dci['user_id'] #员工id
        check_in_deducted = 0 #考勤扣分
        check_in_outtimes = int(dci['sb_error']) + int(dci['xb_error']) + (int(dci['no_check_in_days'] * 4)) #本月迟到早退总数 =  迟到次数 +  早退次数  +  (未打卡天数 x 4)
        if check_in_outtimes == 1:
            check_in_deducted = cki1
        elif check_in_outtimes == 2:
            check_in_deducted = cki2
        elif check_in_outtimes == 3:
            check_in_deducted = cki3
        elif check_in_outtimes > 3:
            check_in_deducted = cki4
        if dci['discipline_deducted'] and dci['discipline_deducted'] != '':
            discipline_deducted = dci['discipline_deducted'] #纪律扣分
        else:
            discipline_deducted = 0
        residue_score = '%.2f' %((100 - int(check_in_deducted)) * str2float(cki_rate) + (100 - int(discipline_deducted)) * str2float(dpe_rate)) #评价总分 = 考勤分数X权重  + 纪律分数X权重

        sql_must = "and manual_up = 'false'"  #如果不为false,说明本月评分记录被人为修改过,则不进行自动计算。
        rd.update("""
                    update pms_user_evaluation_score set check_in_deducted = '%s', discipline_deducted = '%s', residue_score = '%s'
                                                    where pms_user_id = '%s' and year = '%s' and month = '%s'  %s  
                    """ %(check_in_deducted, discipline_deducted, residue_score, pms_user_id, day[0:4], day[4:6], sql_must))


#每月一号清空用户表的本月纪律情况字段,开始新的一个月
def recover_user_discipline():
    day = str(datetime.date.today()).replace('-','')
    if day[6:] != '01':
        logging.info("非当月一号,不进行 清空pms_user表 pms_user_evaluate_id 字段的操作.>%s" %day)
        return    
    rd.update("""
                update pms_user set pms_user_evaluate_id = null
                """)


#自动计算供应商评价评分
def count_supplier_evaluation_score():
    sql_status = "select * from pms_status where code = 'delete'"
    status_delete = rd.select(sql_status)[0]['id']
    org_list = rd.select("""
                            select pos.* from PMS_ORGANIZATIONS pos
                                join PMS_ORG_TYPE pot on pot.id = pos.TYPE_ID
                                where pot.name = '外包机构' and pos.STATUS_ID != '%s'
                        """ %status_delete)
    for ol in org_list:
        logging.info(ol)
        user_avg_score = 0#外包机构全部人员的评价平均分 
        project_avg_score = 0#外包机构全部项目的评价平均分 
        residue_score = 0 #总评分数
        count_user_avg_score = rd.select("""
                                            select cast(avg(uscore.RESIDUE_SCORE) as decimal(10,2)) as user_avg_score from (
                                                                                   select avg(RESIDUE_SCORE) as RESIDUE_SCORE ,pms_user_id from (
                                                                                                                                    select max(RESIDUE_SCORE) as RESIDUE_SCORE,pms_user_id,year,month from pms_user_evaluation_score group by pms_user_id,year,month
                                                                                                                                    )  group by pms_user_id
                                                                                   ) uscore
                                                                                    join  pms_user pu on pu.id = uscore.pms_user_id
                                                                                    where pu.ORG_ID = '%s' and pu.STATUS_ID != '%s' group by pu.org_id
                                        """%(ol["id"], status_delete))
        if count_user_avg_score and len(count_user_avg_score) > 0:
            user_avg_score = count_user_avg_score[0]["user_avg_score"]
        all_project = rd.select("""
                                select * from pms_project where pms_org_id = '%s' 
                                """%ol["id"])
        for ap in all_project:
            logging.info(ap["id"])
            logging.info("===================")
            project_avg_score += comment_sub(ap["id"])[1]
        if len(all_project) > 0:
            project_avg_score = '%.2f' %(project_avg_score/len(all_project))
        cki_rate = rd.select("select score from  pms_supplier_evaluate where code = '01'")[0]['score'] #人员评价占供应商评价权重(比值)
        dpe_rate = rd.select("select score from  pms_supplier_evaluate where code = '02'")[0]['score'] #项目评价占供应商评价权重(比值)
        residue_score = '%.2f' %(float(user_avg_score) * str2float(cki_rate) + float(project_avg_score) * str2float(dpe_rate)) 
        org_score_obj = rd.select("""
                                    select * from pms_supplier_eva_score where pms_organizations_id = '%s'
                                    """%ol["id"])
        if org_score_obj and len(org_score_obj) > 0:
            rd.updatebyDict("pms_supplier_eva_score",{"id":org_score_obj[0]["id"],"user_avg_score":str(user_avg_score),"project_avg_score":str(project_avg_score),"residue_score":str(residue_score)})
        else:
            rd.insertbyDict("pms_supplier_eva_score",{"user_avg_score":str(user_avg_score),"pms_organizations_id":str(ol["id"]),"project_avg_score":str(project_avg_score),"residue_score":str(residue_score)})


        
