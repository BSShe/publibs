function details_info1(id){
    var data = {'id':id};
    $.ajax({
        url: "/pmsManager/project_plan_index-project_preparation",
        type: "post",
        dataType: "html",
        data: data,
        async: false,
        success: function (response) {
                $('#content').html(response)
        },
        error: function (response) {
                alert("查看详情失败");
        }
    })
}
