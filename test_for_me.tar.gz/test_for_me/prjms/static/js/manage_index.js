$('#upPassWd_form').bootstrapValidator({
    message: 'This value is not valid',
    feedbackIcons: {
        valid: 'glyphicon glyphicon-ok',
        invalid: 'glyphicon glyphicon-remove',
        validating: 'glyphicon glyphicon-refresh'
    },
    fields: {
        old_password: {
            message: '',
            validators: {
                notEmpty: {
                    message: '旧密码不能为空'
                }
            }
        },
        password: {
            message: '',
            validators: {
                notEmpty: {
                    message: '新密码不能为空'
                }
            }
        },
        again_password: {
            message: '',
            validators: {
                notEmpty: {
                    message: '确认密码不能为空'
                }
            }
        }
    }
});

// 表单数据序列化
function objectifyForm(formArray) { //serialize data function

    var returnArray = {};
    for (var i = 0; i < formArray.length; i++) {
        returnArray[formArray[i]['name']] = formArray[i]['value'];
    }
    return returnArray;
}

// 表单验证清空数据和样式
function upPdclearform() {
    $("small").css('display', 'none');
    $("#upPassWd_form")[0].reset();
    $("i").remove(".glyphicon-remove");
    $("i").remove(".glyphicon-ok");
    $("div").removeClass("has-error");
    $("div").removeClass("has-success");
}

// 点击修改密码按钮
function showUpPassWd(user_id,type) {
    $("#modal-normal-upPassWd").modal("show");
    $("#modal-title-upPassWd").text("修改密码");
    if (type == 'init'){
        var login_password = $("#login_password").val();
        $("#old_password").attr("value",login_password);
    }
    upPdclearform();
    $("#upPassWd_btn").unbind();
    $("#upPassWd_btn").on("click", function () {
        to_upPassWd(user_id);
    });
}

// 修改密码
function to_upPassWd(user_id) {
    $("#upPassWd_form").bootstrapValidator('validate');
    var bv = $("#upPassWd_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        //alert("验证失败");
        return false;
    } else {
        var data = $("#upPassWd_form").serializeArray()
        data = objectifyForm(data);
        if(data['password'] == data['old_password']){
            $("#old_password").val("");
            $("#password").val("");
            $("#again_password").val("");
            alert('新密码不能与旧密码相同,请重新输入!');
            return false;
        }
        if (data['password']== ""||data['password'].length < 8) {
            $("#password").val("");
            $("#again_password").val("");
            alert("密码不能为空或小于8位,且密码必须包含数字、字母!");
            return false;
        }
        if(data['password'] != data['again_password']){
            alert('新密码与确认密码不一样,请重新输入!');
            $("#password").val("");
            $("#again_password").val("");
            return false;
        }
        var reg = new RegExp(/^(?![^a-zA-Z]+$)(?!\D+$)/);
        if (!reg.test(data['password'])){
            $("#password").val("");
            $("#again_password").val("");
            alert("密码不能为空或小于8位,且密码必须包含数字、字母!")
            return false;
        }
        data['id'] = user_id
        $.ajax({
            url: "/upPassWd",
            type: "post",
            dataType: "json",
            data: data,
            success: function (response) {
                if (response.result == 'true') {
                    alert(response.msg);
                    $("#modal-normal-upPassWd").modal("hide");
                    window.location.reload();
                }else{
                    alert(response.msg);
                }
            },
            error: function (response) {
                console.log(response);
                alert("修改密码失败!");
            }
        })
    }
}

