function setWrite(obj,id,username){
    $.ajax({
        url: "/pmsManager/manageMessageList",
        type: "post",
        data: data = {"id":id,'username':username},
        async: false,
        success:function(response){
            $("#realMesCount").val(parseInt($("#realMesCount").val())-1);
            if(parseInt($("#realMesCount").val())<=99 && parseInt($("#realMesCount").val())>0){
                $("#mesCount").text($("#realMesCount").val());
            }
            if(parseInt($("#realMesCount").val())<=0){
                $("#mesCount").css("display","none");
                $("#mesCount").text();
            }
            alert("修改成功！");
            obj.parentNode.previousSibling.innerHTML = "<p style='margin-bottom:0px;'>已读</p>";
            obj.parentNode.innerHTML = "无操作";
        },
        error: function (response) {
            alert("查看失败");
        }
    });
}
