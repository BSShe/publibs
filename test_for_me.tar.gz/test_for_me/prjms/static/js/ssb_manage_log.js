function logSubmit(){
    var val = CKEDITOR.instances.logText.getData();
    if (val == null || val == ""){alert("请输入内容！"); return;}
    var title = document.getElementById("logTitle").value;
    if (title == null || title == ""){alert("请输入标题！"); return;}
    var pid = document.getElementById("submitLog").value; 
    var data = {'text':val,'projectId':pid,'title':title};
    $.ajax({
        url: "/pmsManager/manageLogList",
        type: "post",
        data:{"data": JSON.stringify(data)},
        async: false,
        success: function (response) {
        alert("提交成功");
        },
        error: function (response) {
            alert("提交失败");
        }
    })
    $("#logwrite-modal-normal").modal("hide");
}

function click_logPage(page,id){
    $.ajax({
        url: "/pmsManager/getLogDetails",
        type: "get",
        data: data={'pid':id,'page':page},
        async: false,
        success: function (response) {
           $('#content').html(response); 
        },
        error: function (response) {
            alert("查看失败");
        }
    })    
}

function logDetail(id){
    $("#logdetail-modal-normal").modal("show");
    $("#modal-title-logdetail").text("日志详情");
    $.ajax({
        url: "/pmsManager/getLogDetailsForWatch",
        type: "post",
        data: data={'id':id},
        async: false,
        success: function (response) {
            document.getElementById("logTextHead").innerHTML = '<textarea class="form-control" id=logText'+id+' style="height:300px;" disabled></textarea>';
            document.getElementById("logTitle").value = response.data['title'];
            document.getElementById("logDate").value = response.data['wdate'];
            myEditor = CKEDITOR.replace('logText'+id,{
                toolbarCanCollapse:true,toolbarStartupExpanded:false,
                toolbar:[
                    ['RemoveFormat','Form','CheckBox','Radio','TextField','Textarea','Select','Button'],
                    ['Bold','Italic','Underline','Strike','Subscript','Superscript','NumberedList','BulletedList'],
                    '/',
                    [,'Blockquote','CreateDiv','JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock','BidiLtr','BidiRtl'],
                    ['Table','HorizontalRule','Smiley','SpecialChar','PageBreak'],
                    ['Styles','Format','Font','FontSize','TextColor','BGColor','Maximize']],
                height:'250px'
            });
            myEditor.setData(response.data['con']);
        },
        error: function (response) {
            alert("查看失败");
        }
    })
} 

function writeLog(pid){
    $("#logwrite-modal-normal").modal("show");
    $("#modal-title-logwrite").text("日志撰写");
    document.getElementById("submitLog").value = pid;
}

function comeBack(page){
    $.ajax({
        url: "/pmsManager/manageWorkLogList",
        type: "get",
        data: data={'page':page},
        async: false,
        success: function (response) {
           $('#content').html(response);
        },
        error: function (response) {
            alert("查看失败");
        }
    })
}
