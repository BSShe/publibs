function jumpToReport(){
    var data = {'page':1};
    $.ajax({
            url: "/pms/projectManageReport",
            type: "get",
            dataType: "html",
            data: data,
            async: false,
            success: function (response) {
                $("#content").html(response);
            },
            error: function (response) {
                    alert("查看报表失败");
            }
        });
}

function jumpEvent(type,pid){
    var url = "";
    var ajax_type = "get";
    var data = {};
    if (type == "logMain"){
        data = {'page':1}
        url = "/pmsManager/manageWorkLogList";
    }
    else if (type == "logDetails"){
        data = {'page':1,'pid':pid}
        url = "/pmsManager/getLogDetails"
    }
    else if (type == "msgMain"){
        data = {'page':1}
        url = "/pmsManager/manageMessageList"
    }
    else if (type == "proMain-ing"){
        data = {'page':1,'work_id':0}
        url = "/pmsManagerPlan/manageQueryList";
    }
    if (type == "proMain"){
        data = {'page':1,'work_id':1}
        url = "/pmsManagerPlan/manageQueryList";
    }
    else if (type == "proDetails"){
        ajax_type = "post";
        data = {'page':1,'id':pid}
        url = "/pmsManager/projectDetail2Handler"
    }
    $.ajax({
        url: url,
        type: ajax_type,
        dataType: "html",
        data: data,
        async: false,
        success: function (response) {
            $("#content").html(response);
        },
        error: function (response) {
                alert("查看失败");
        }
    });
}
