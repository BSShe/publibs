function project_test(id){
        var data = {'id':id};
        $.ajax({
            url: "/pmsManager/projectPlanTestHandler",
            type: "post",
            dataType: "html",
            data: data,
            async: false,
            success: function (response) {
                    $('#content').html(response)
            },
            error: function (response) {
                    alert("测试进度页进入失败");
            }
        })
}
function add_project(){
    url = '' 
    $.ajax({
         url:url,
         type:'post',
         dataType:'html',
         data:data,
         async:false,
         success: function (response){
             $('#content').html(response)
         },
         error: function (response){
             alert('测试进度功能页面')
                
         }
    });
}

function add_new_plan() {
    $("#modal-normal").modal("show");
    $("#modal-title").text("子项目新增");
    clearform();
    $("#submit_btn_pro").unbind();
    $("#submit_btn_pro").on("click",add_project);
}
