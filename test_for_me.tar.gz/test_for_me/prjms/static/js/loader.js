$(window).on('load', function () { // makes sure the whole site is loaded
    $('#preloader_status').fadeOut(); // will first fade out the loading animation
    $('#preloader').delay(350).fadeOut('slow'); // will fade out the white DIV that covers the website.
    $('body').delay(350).css({'overflow': 'visible'});

});

function by_auth_show_button(){
    $.ajax({
        type:"post",
        url:"/paramManage/byAuthGetButtonList",
        data:{'global_menu_id':$("#global_menu_id").val()},
        cache:false,
        success:function(data){
            no_show_button_id_list= data['no_show_button_id_list']
            for(var a=0;a<no_show_button_id_list.length;a++){
                $("input[id^=\'"+no_show_button_id_list[a]['html_button_id']+"\']").remove();
                $("button[id^=\'"+no_show_button_id_list[a]['html_button_id']+"\']").remove();
            }
        },
        error:function(){
            alert("系统异常,请通知管理员!");
        },
    });
}
