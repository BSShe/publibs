function search_supplier_eva_score() {
    init_supplier_eva_score_DataTables();
    return false;
}

// 点击修改供应商评价汇总分数管理按钮
function click_supplier_eva_score_alter(org_id,id) {
    $("#supplier_eva_score_form")[0].reset();
    clearform();
    $("#modal-title").text("供应商评价汇总分数管理修改");
    //使用disable 属性，将使控件失去焦点，以下数据不仅无法在界面编辑，通过提交表单的方式也不传到后台，如果需要传到后台，请使用 readonly 属性
    $("#code").attr("disabled","disabled");
    $("#name").attr("disabled","disabled");
    $("#user_avg_score").attr("disabled","disabled");
    $("#project_avg_score").attr("disabled","disabled");
    $("#residue_score").attr("disabled","disabled");

    fill_form_supplier_eva_score(org_id);
    $("#modal-normal").modal("show");
    $("#submit_btn").unbind();
    $("#submit_btn").on("click", function () {
        alter_supplier_eva_score(id);
    });
}

// 修改供应商评价汇总分数管理信息
function alter_supplier_eva_score(id) {
    $("#supplier_eva_score_form").bootstrapValidator('validate');
    var bv = $("#supplier_eva_score_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        //alert("验证失败");
        return false;
    } else {
        var data = $("#supplier_eva_score_form").serializeArray();
        data = objectifyForm(data);
        data['id'] = id;
        //data['global_menu_id'] = $("#global_menu_id").val();
        $.ajax({
            url: "/supplierManage/supplierEvaluateToUpdate",
            type: "post",
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
                if (response.result) {
                    $("#modal-normal").modal("hide");
                    search_supplier_eva_score();
                }
            },
            error: function () {
                alert("修改供应商评价管理信息失败");
            }
        });

    }
}

// 填充数据
function fill_form_supplier_eva_score(id) {
    $.ajax({
        url: "/supplierManage/supplierEvaluateBfUpdate",
        type: "post",
        dateType: "json",
        data: {
            'id': id
        },
        success: function (response) {
            for (var key in response) {
                $("#" + key).val(response[key]);
            }
            return false;
        },
        error: function (response) {
            alert("获取数据失败");
        }
    });
}


//供应商评价信息 导出
function exportInfo() {
    window.location.href =  "/supplierManage/supplierEvaluateExportInfo?code=" + $("#search_code").val() + "&name=" + $("#search_name").val(); 
}
// 表单数据序列化
function objectifyForm(formArray) { //serialize data function
    var returnArray = {};
    for (var i = 0; i < formArray.length; i++) {
        returnArray[formArray[i]['name']] = formArray[i]['value'];
    }
    return returnArray;
}

// 表单验证清空数据和样式
function clearform() {
    $("small").css('display', 'none');
    $("#supplier_eva_score_form")[0].reset();
    $("i").remove(".glyphicon-remove");
    $("i").remove(".glyphicon-ok");
    $("div").removeClass("has-error");
    $("div").removeClass("has-success");
}

// 显示人员评分趋势图标 模态框 
function showChart(pms_user_id,year_month) {
    $("#modal-normal-showChart").modal("show");
    console.log(year_month.substr(0,4));
    $("#modal-title-showChart").text(year_month.substr(0,4) + "年评分趋势图表")
    data = Array.apply(null, Array(12)) 
    $.ajax({
        url: "/supplierManage/supplierEvaluateShowChart",
        type: "post",
        dateType: "json",
        data: {
            'pms_user_id': pms_user_id,
            'year_month':year_month
        },
        success: function (response) {
            if(response.result == 'true'){
                sdata = response.data    
                for (var i=0;i<sdata.length;i++){
                    data[sdata[i]['month']-1]= sdata[i]['residue_score']
                } 
            }
        },
        error: function (response) {
            alert("获取数据失败");
        }
    });
    var ctx = $("#myChart");
    var myChart = new Chart(ctx,{
        type: 'line',
        data: {
            labels: ['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'],
            datasets: [{
                label: '月评分折线',
                data: data,
                borderWidth: 3,
                borderColor:'#9370DB',
                fill: false,
                pointBorderWidth:2,
                pointBackgroundColor:'#9370DB',
                pointRadius:7,
            }]
        },
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        min: 0,
                        max: 100,
                        stepSize: 10
                    }
                }]
            }
        }
    });
}
