function search_user_evaluate_score() {
    init_user_evaluate_score_DataTables();
    return false;
}

// 点击修改人员评价汇总分数管理按钮
function click_user_evaluate_score_alter(id,manual_up) {
    $("#user_evaluate_score_form")[0].reset();
    clearform();
    $("#modal-title").text("人员评价汇总分数管理修改");
    //使用disable 属性，将使控件失去焦点，以下数据不仅无法在界面编辑，通过提交表单的方式也不传到后台，如果需要传到后台，请使用 readonly 属性
    $("#no").attr("disabled","disabled");
    $("#name").attr("disabled","disabled");
    $("#org_name").attr("disabled","disabled");
    $("#phone_no").attr("disabled","disabled");
    $("#check_in_score").attr("disabled","disabled");
    $("#discipline_score").attr("disabled","disabled");
    $("#year_residue_score").attr("disabled","disabled");
    $("#year_month").attr("disabled","disabled");


    fill_form_user_evaluate_score(id);
    $("#modal-normal").modal("show");
    $("#submit_btn").unbind();
    $("#submit_btn").on("click", function () {
        alter_user_evaluate_score(id,manual_up);
    });
}

// 修改人员评价汇总分数管理信息
function alter_user_evaluate_score(id,manual_up) {
    var msg = "手工修改后,系统本月将不会再对此评价进行自动计算,\n\n请确认！";
    if (manual_up == 'true'){
        msg = "此人员评价分数,由于之前已手工编辑过,所以本月系统将不会自动计算此人员评价！"
    }
    if (confirm(msg) === false) {
        return false;
    }
    $("#user_evaluate_score_form").bootstrapValidator('validate');
    var bv = $("#user_evaluate_score_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        //alert("验证失败");
        return false;
    } else {
        var data = $("#user_evaluate_score_form").serializeArray();
        data = objectifyForm(data);
        data['id'] = id;
        //data['global_menu_id'] = $("#global_menu_id").val();
        $.ajax({
            url: "/userManage/userEvaluateToUpdate",
            type: "post",
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
                if (response.result) {
                    $("#modal-normal").modal("hide");
                    search_user_evaluate_score();
                }
            },
            error: function () {
                alert("修改人员评价管理信息失败");
            }
        });

    }
}

// 填充数据
function fill_form_user_evaluate_score(id) {
    $.ajax({
        url: "/userManage/userEvaluateBfUpdate",
        type: "post",
        dateType: "json",
        data: {
            'id': id
        },
        success: function (response) {
            for (var key in response) {
                $("#" + key).val(response[key]);
            }
            return false;
        },
        error: function (response) {
            alert("获取数据失败");
        }
    });
}


//人员评价信息 导出
function exportInfo() {
    window.location.href =  "/userManage/userEvaluateExportInfo?year_month=" + $("#search_year_month").val(); 
}
// 表单数据序列化
function objectifyForm(formArray) { //serialize data function
    var returnArray = {};
    for (var i = 0; i < formArray.length; i++) {
        returnArray[formArray[i]['name']] = formArray[i]['value'];
    }
    return returnArray;
}

// 表单验证清空数据和样式
function clearform() {
    $("small").css('display', 'none');
    $("#user_evaluate_score_form")[0].reset();
    $("i").remove(".glyphicon-remove");
    $("i").remove(".glyphicon-ok");
    $("div").removeClass("has-error");
    $("div").removeClass("has-success");
}

// 显示人员评分趋势图标 模态框 
function showChart(pms_user_id,year_month) {
    $("#modal-normal-showChart").modal("show");
    console.log(year_month.substr(0,4));
    $("#modal-title-showChart").text(year_month.substr(0,4) + "年评分趋势图表")
    data = Array.apply(null, Array(12)) 
    $.ajax({
        url: "/userManage/userEvaluateShowChart",
        type: "post",
        dateType: "json",
        data: {
            'pms_user_id': pms_user_id,
            'year_month':year_month
        },
        success: function (response) {
            if(response.result == 'true'){
                sdata = response.data    
                for (var i=0;i<sdata.length;i++){
                    data[sdata[i]['month']-1]= sdata[i]['residue_score']
                } 
            }
        },
        error: function (response) {
            alert("获取数据失败");
        }
    });
    var ctx = $("#myChart");
    var myChart = new Chart(ctx,{
        type: 'line',
        data: {
            labels: ['一月','二月','三月','四月','五月','六月','七月','八月','九月','十月','十一月','十二月'],
            datasets: [{
                label: '月评分折线',
                data: data,
                borderWidth: 3,
                borderColor:'#e7554b',
                fill: false,
                pointBorderWidth:2,
                pointBackgroundColor:'#e7554b',
                pointRadius:7,
            }]
        },
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        min: 0,
                        max: 100,
                        stepSize: 10
                    }
                }]
            }
        }
    });
}
