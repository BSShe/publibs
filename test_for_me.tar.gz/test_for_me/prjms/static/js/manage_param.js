// 查询机构
function search_paramList() {
    init_DataTables();
    $("#divDetail").html("");
    return false;
}

//点击查看详情按钮
function showHtml(map_addr) {
    $("#divDetail").include(map_addr,"divDetail");
}


// 表单数据序列化
function objectifyForm(formArray) { //serialize data function

    var returnArray = {};
    for (var i = 0; i < formArray.length; i++) {
        returnArray[formArray[i]['name']] = formArray[i]['value'];
    }
    return returnArray;
}


// 表单验证清空数据和样式
function clearform() {
    $("small").css('display', 'none');
    $("#user_form")[0].reset();
    $("i").remove(".glyphicon-remove");
    $("i").remove(".glyphicon-ok");
    $("div").removeClass("has-error");
    $("div").removeClass("has-success");
}

$("input:radio[name='search_pro_type']").change(function(){
    search_paramList()
});

document.getElementById('img1').style.border = '1px solid #000000';

function myFun(sId) {
    var oImg = document.getElementsByTagName('img');
    for (var i = 0; i < oImg.length; i++) {
      if (oImg[i].id == sId) {
        $("#"+sId+"spt").prop("checked",true).trigger('change');
        oImg[i].style.border = '1px solid #000000';
      } else {
        oImg[i].style.border = '1px solid #FFFFFF';

      }
    }
}
