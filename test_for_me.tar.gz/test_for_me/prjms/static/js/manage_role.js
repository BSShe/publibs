// 查询角色
function search_role() {
    init_role_DataTables();
    return false;
}

// 点击角色新增按钮
function click_role_add() {
    $("#modal-normal").modal("show");
    $("#modal-title").text("新增角色");
    clearform();
    $("#type").removeAttr("disabled");
    $("#submit_btn").unbind();
    $("#submit_btn").on("click", add_role);
}

// 增加角色
function add_role() {
    $("#role_form").bootstrapValidator('validate');
    var bv = $("#role_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        //alert("验证失败");
        return false;
    } else {
        var data = $("#role_form").serializeArray()
        data = objectifyForm(data);
        data['status_id'] = $("#status_id").val();
        //data['global_menu_id'] = $("#global_menu_id").val();
        $.ajax({
            url: "/paramManage/manageRoleToAdd",
            type: "post",
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
                if (response.result == 'true') {
                    search_role();
                    $("#modal-normal").modal("hide");
                }else{
                    alert(response.msg);
                }
            },
            error: function (response) {
                alert("添加角色失败");
            }
        })
    }
}

// 点击修改角色按钮
function click_role_alter(id) {
    $("#role_form")[0].reset();
    clearform();
    $("#modal-title").text("角色修改");
    $("#type").attr("disabled","disabled");
    fill_form_role(id);
    $("#modal-normal").modal("show");
    $("#submit_btn").unbind();
    $("#submit_btn").on("click", function () {
        alter_role(id);
    });
}

// 修改角色信息
function alter_role(id) {
    $("#role_form").bootstrapValidator('validate');
    var bv = $("#role_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        //alert("验证失败");
        return false;
    } else {
        var data = $("#role_form").serializeArray();
        data = objectifyForm(data);
        data['id'] = id;
        //data['global_menu_id'] = $("#global_menu_id").val();
        $.ajax({
            url: "/paramManage/manageRoleToUpdate",
            type: "post",
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
                if (response.result == 'true') {
                    $("#modal-normal").modal("hide");
                    search_role();
                }else{
                    alert(response.msg);
                }
            },
            error: function () {
                alert("修改角色信息失败");
            }
        });

    }
}

function del_role(id, type) {
    var msg = "您真的确定要删除该角色？\n\n请确认！";
    if (confirm(msg) === false) {
        return false;
    }
    var role_id = id;
    var surl = '/paramManage/manageRoleDel';
    var data = {};
    data['id'] = role_id;
    data['type'] = type
    $.ajax({
        type: 'post',
        url: surl,
        data: data,
        dataType: 'json',
        success: function (data) {
            if (data.result == 'true') {
                init_role_DataTables();
            } else {
                alert(data.msg);
            }
        },
        error: function (error_msg) {
            alert("数据请求失败!");
        }
    });
}

// 填充数据
function fill_form_role(id) {
    $.ajax({
        url: "/paramManage/manageRoleBfUpdate",
        type: "post",
        dateType: "json",
        data: {
            'id': id
        },
        success: function (response) {
            for (var key in response) {
                $("#" + key).val(response[key]);
            }
            return false;
        },
        error: function (response) {
            alert("获取数据失败");
        }
    });
}


// 点击权限按钮
function update_role_auth(role_id) {
    //$("#js_tree").jstree({}).bind("select_node.jstree",function(e,data){
    //        var node = data.rslt.obj, inst = data.inst;
    //        if (node.hasClass('jstree-closed')){return inst.open_node(node);}
    //        if (node.hasClass('jstree-open')){return inst.close_node(node);}
    //});
    $("#modal-title2").text("菜单权限配置");
    fill_form_role_auth(role_id);
    $("#modal-normal2").modal("show");
    $("#submit_btn2").unbind();
    $("#submit_btn2").on("click", function () {
        alter_role_auth(role_id);
    });
}


// 填充权限数据
function fill_form_role_auth(role_id) {
    $.ajax({
        url: "/paramManage/manageRoleGetAuth",
        type: "post",
        dateType: "json",
        data: {
            'role_id': role_id
        },
        success: function (response) {
            tree_id_list = response['tree_id_list']
            $('#js_tree').jstree('check_all');
            $('#js_tree').jstree('close_all');
            for (var i=0; i<tree_id_list.length; i++){
               $('#js_tree').jstree('uncheck_node', tree_id_list[i]['tree_id']);
            }
            return false;
        },
        error: function (response) {
            alert("获取数据失败");
        }
    });
}


// 修改权限信息
function alter_role_auth(id) {
    $("#role_auth_form").bootstrapValidator('validate');
    var bv = $("#role_auth_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        //alert("验证失败");
        return false;
    } else {
        var data = $("#role_auth_form").serializeArray();
        data = objectifyForm(data);
        data['id'] = id;
        var arr = $('#js_tree').jstree('get_all_checked');
        data['id_list'] = arr;
        //data['global_menu_id'] = $("#global_menu_id").val();
        $.ajax({
            url: "/paramManage/manageRoleToUpdateMenu",
            type: "post",
            dataType: "json",
            traditional: true,
            data: data,
            async: false,
            success: function (response) {
                if (response.result) {
                    $("#modal-normal2").modal("hide");
                    search_role();
                }
            },
            error: function () {
                alert("修改角色信息失败");
            }
        });

    }
}

//更新部门权限按钮
function update_role_branch(role_id){
    $("#modal-title3").text("菜单权限配置");
    fill_form_role_branch(role_id);
    $("#modal-normal3").modal("show");
    $("#submit_btn3").unbind();
    $("#submit_btn3").on("click", function () {
        alter_role_branch(role_id);
    });
}

//填充部门权限信息
function fill_form_role_branch(role_id) {
    $.ajax({
        url: "/paramManage/manageRoleGetBranch",
        type: "post",
        dateType: "json",
        data: {
            'role_id': role_id
        },
        success: function (response) {
            tree_id_list = response['tree_id_list']
            $('#js_tree2').jstree('check_all');
            $('#js_tree2').jstree('close_all');
            for (var i=0; i<tree_id_list.length; i++){
               $('#js_tree2').jstree('uncheck_node', tree_id_list[i]['tree_id']);
            }
            return false;
        },
        error: function (response) {
            alert("获取数据失败");
        }
    });
}

//修改部门权限
function alter_role_branch(id) {
    $("#role_branch_form").bootstrapValidator('validate');
    var bv = $("#role_branch_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        //alert("验证失败");
        return false;
    } else {
        var data = $("#role_branch_form").serializeArray();
        data = objectifyForm(data);
        data['id'] = id;
        var arr = $('#js_tree2').jstree('get_all_checked');
        data['id_list'] = arr;
        //data['global_menu_id'] = $("#global_menu_id").val();
        $.ajax({
            url: "/paramManage/manageRoleToUpdateBranch",
            type: "post",
            dataType: "json",
            traditional: true,
            data: data,
            async: false,
            success: function (response) {
                if (response.result) {
                    alert("修改成功");
                    $("#modal-normal3").modal("hide");
                }
            },
            error: function () {
                alert("修改角色信息失败");
            }
        });

    }
}

// 表单数据序列化
function objectifyForm(formArray) { //serialize data function

    var returnArray = {};
    for (var i = 0; i < formArray.length; i++) {
        returnArray[formArray[i]['name']] = formArray[i]['value'];
    }
    return returnArray;
}

// 表单验证清空数据和样式
function clearform() {
    $("small").css('display', 'none');
    $("#role_form")[0].reset();
    $("i").remove(".glyphicon-remove");
    $("i").remove(".glyphicon-ok");
    $("div").removeClass("has-error");
    $("div").removeClass("has-success");
}
