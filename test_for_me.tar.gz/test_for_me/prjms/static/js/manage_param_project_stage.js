// 查询项目阶段
function search_project_stage() {
    init_project_stage_DataTables();
    return false;
}

// 点击项目阶段新增按钮
function click_project_stage_add() {
    $("#modal-normal").modal("show");
    $("#modal-title").text("新增项目阶段");
    clearform();
    $("#id").hide();
    $("#code").attr("disabled",false);
    $("#submit_btn").unbind();
    $("#submit_btn").on("click", add_project_stage);
}

// 增加项目阶段
function add_project_stage() {
    $("#project_stage_form").bootstrapValidator('validate');
    var bv = $("#project_stage_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        //alert("验证失败");
        return false;
    } else {
        var data = $("#project_stage_form").serializeArray()
        data = objectifyForm(data);
        //data['global_menu_id'] = $("#global_menu_id").val();
        $.ajax({
            url: "/paramManage/manageParamList-project_stageToAdd",
            type: "post",
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
                if (response.result) {
                    search_project_stage();
                    $("#modal-normal").modal("hide");
                }
            },
            error: function (response) {
                alert("添加项目阶段失败");
            }
        })
    }
}

// 点击修改项目阶段按钮
function click_project_stage_alter(project_stage_code) {
    $("#project_stage_form")[0].reset();
    clearform();
    $("#modal-title").text("项目阶段修改");
    $("#code").attr("disabled",true);
    fill_form_project_stage(project_stage_code);
    $("#modal-normal").modal("show");
    $("#submit_btn").unbind();
    $("#submit_btn").on("click", function () {
        alter_project_stage(project_stage_code,$("#project_stage_doc_id").val());
    });
}

// 修改项目阶段信息
function alter_project_stage(project_stage_code, project_stage_doc_id) {
    $("#project_stage_form").bootstrapValidator('validate');
    var bv = $("#project_stage_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        //alert("验证失败");
        return false;
    } else {
        var data = new FormData();

        data.append('project_stage_code', project_stage_code);
        data.append('project_stage_doc_id', project_stage_doc_id);
        var files = $("#file_data")[0].files[0];
        data.append('file_data', files);
        $.ajax({
            url: "/paramManage/manageParamList-project_stageToUpdate",
            type: "post",
            dataType: "json",
            cache: false,
            processData: false,
            contentType: false,
            data: data,
            async: false,
            success: function (response) {
                if (response.result) {
                    $("#modal-normal").modal("hide");
                    search_project_stage();
                }
            },
            error: function () {
                alert("修改项目阶段信息失败");
            }
        });

    }
}

function del_project_stage(id) {
    var msg = "您真的确定要删除该项目阶段？\n\n请确认！";
    if (confirm(msg) === false) {
        return false;
    }
    var project_stage_id = id;
    var surl = '/paramManage/manageParamList-project_stageDel';
    var data = {};
    data['id'] = project_stage_id;
    $.ajax({
        type: 'post',
        url: surl,
        data: data,
        dataType: 'json',
        success: function (data) {
            console.log(data)
            if (data.result == 'true') {
                init_project_stage_DataTables();
            } else {
                alert(data.msg);
            }
        },
        error: function (error_msg) {
            alert("数据请求失败!");
        }
    });
}

//点击查看子阶段详情按钮
function childStageShowHtml(p_stage_id) {
    $("#proStageDivDetail").include("/paramManage/manageParamList-project_stage_child?p_stage_id="+p_stage_id,"proStageDivDetail");
    document.getElementById("proStageDivDetail").scrollIntoView();
}

// 填充数据
function fill_form_project_stage(project_stage_code) {
    $.ajax({
        url: "/paramManage/manageParamList-project_stageBfUpdate",
        type: "post",
        dateType: "json",
        data: {
            'project_stage_code': project_stage_code
        },
        success: function (res) {
            response = res.data
            var len  = response.length
            $("#project_stage_doc_id").find("option:selected").text("");
            $("#project_stage_doc_id").empty();
            for (var key in response) {
                    url = response[key]['url']
                    if(url != null && url.length >0){
                        $("#project_stage_doc_id").append("<option value='" + response[key]['id'] + "'>" + response[key]['name'] + "  (已上传模版)" + "</option>")
                    }else{
                        $("#project_stage_doc_id").append("<option value='" + response[key]['id'] + "'>" + response[key]['name'] + "  (未上传模版)" + "</option>")
                    }
            }
            $("#code").val(res.code)
            $("#project_stage_doc_id").trigger("change");
            return false;
        },
        error: function (res) {
            alert("获取数据失败");
        }
    });
}

//下载模版 
function download_stage_doc() {
    window.location.href =  "/paramManage/manageParamList-project_stageDownDoc?project_stage_doc_id=" + $("#project_stage_doc_id").val();
}

$("#project_stage_doc_id").change(function(){
    var downDocText = $(this).find("option:selected").text();
    if(downDocText.indexOf("已上传模版") > -1){
        $("#downDoc").show(); 
    }else{
        $("#downDoc").hide(); 
    }
});

// 表单数据序列化
function objectifyForm(formArray) { //serialize data function

    var returnArray = {};
    for (var i = 0; i < formArray.length; i++) {
        returnArray[formArray[i]['name']] = formArray[i]['value'];
    }
    return returnArray;
}

// 表单验证清空数据和样式
function clearform() {
    $("small").css('display', 'none');
    $("#project_stage_form")[0].reset();
    $("i").remove(".glyphicon-remove");
    $("i").remove(".glyphicon-ok");
    $("div").removeClass("has-error");
    $("div").removeClass("has-success");
}
