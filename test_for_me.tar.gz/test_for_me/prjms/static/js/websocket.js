$(document).ready(function() {
	if (!window.console) window.console = {};
	if (!window.console.log) window.console.log = function() {};
});

zw_id = null;
img_id = null;
id_id = null;

function jl_id() {
    id_id = $(this)[0].id;
	var message = {};
    
    $("#"+id_id).val("id");
    return ;

	message["driverType"] = "idcard"
	message["driverName"] = "readBaseMsg"
	message["prompt"] = ""
	message["salt"] = "value"
} 
 
function wj_image(obj) {
	img_id=$(this)[0].id;

    $("#"+img_id).val("wj_image");
    return ;

	var message = {};
	message["driverType"] = "camera"
        if(img_id=="khz"){
	    message["driverName"] = "back";
        }else{
	    message["driverName"] = "main";
	}
	message["prompt"]=""
	message["salt"]="value"
}

function bm_mb(obj) {
    var objects = obj; 
    zw_id = objects.id;
  
    $("#"+zw_id).val("mb");
    return;

	var message = {};
	message["driverType"] = "fingerprint"
	message["driverName"] = "usbmb"
	message["prompt"] = ""
	message["salt"] = "value"
}

function bm_tz(obj) {
    zw_id=$(this)[0].id;

    $("#"+zw_id).val("tz_1");
    return ;

	var message = {};
	message["driverType"]="fingerprint"
	message["driverName"]="usbtz"
	message["prompt"]=""
	message["salt"]="value"
}

function bm_verification(mb,tz) {
	var message = {};

	message["driverType"]="fingerprint"
	message["driverName"]="usbverification"
	message["MB"]= mb
	message["TZ"]= tz
	message["prompt"]=""
	message["salt"]="value"
}


