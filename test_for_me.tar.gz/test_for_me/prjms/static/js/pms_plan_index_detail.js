function refresh(dev_id,type,itype){
    clearForm();
    if(type == true){
        $("#p_start_date").attr("disabled","disabled");
    }else{
        $("#p_start_date").removeAttr("disabled");
    }
    $.ajax({
        url: '/pmsManagerWork/projectGetDevInfo',
        data: {'dev_id':dev_id},
        type: 'post',
        dataType: 'json',
        success:function(response){
            $("#dev_id").val(response['dev_id']);
            $("#pms_project_stage_id").val(response['stage_name']);
            $("#dev_user_id").val(response['manage_name']);
            $("#p_start_date").val(response.p_start_date);
            $("#p_end_date").val(response.p_end_date);
            if(itype == '项目计划普通变更'){
                $("#refreshParent").css("display","none");   
            }else{
                $("#refreshParent").css("display","block");
            }
            $("#modal-normal").modal("show");
            $("#submit_btn").unbind();
            $("#submit_btn").bind('click',{type:itype},changeDevInfo);
        },error:function(response){
            alert('获取数据失败');
        }
    });
}

function clearForm(){
    //$("#dev_id").val("");
    //$("#p_start_date").val("");
    //$("#p_end_date").val("");
    //$("#pms_project_stage_id").val("");
    //$("#dev_user_id").val("");
    $("input:text").val("");
    $("textArea").val("");
}

function changeDevInfo(e){
    if($.trim($("#p_start_date").val())!=""&&$.trim($("#p_end_date").val())!=""){
        if($("#p_start_date").val()>$("#p_end_date").val() == true){
            alert("预计开始日期大于预计结束日期");
            return;
        }
    }
    if(e.data.type == '项目计划重大变更'){
        if($.trim($("#refreshReason").val()) == ""){
            alert("请填写变更原因");
            return;
        }
    }
    var data={};
    data['dev_id'] = $("#dev_id").val();
    data['p_start_date'] = $("#p_start_date").val();
    data['p_end_date'] = $("#p_end_date").val();
    data['refreshReason'] = $.trim($("#refreshReason").val());
    $.ajax({
        url: '/pmsManagerWork/projectWorkDtUpdate',
        data: data,
        type: 'post',
        dataType: 'json',
        success:function(response){
            if(response.status == 1){
                alert('设置成功');
                reload('modal-normal',e.data.type);
                $("#modal-normal").modal("hide");
            }else{
                alert(response.msg);
            }
        },error:function(ersponse){
            alert('更新失败');
        }
    });
}
function reload(modalName,type){
     $("#"+modalName).on('hidden.bs.modal',function(){
        $.ajax({
            url: '/pmsManagerWork/projectPlanDetailHandler',
            type: 'post',
            data: {'id':$("#project_id").val(),'type':type},
            dataType: 'html',
            success:function(html){
                $("#"+modalName).unbind();
                $("#content").html(html);
            }
        });
    });
}
function addStage(id,type){
    clearForm();
    if(type == '项目计划普通变更'){
        $("#addParent").css("display","none");
    }else{
        $("#addParent").css("display","block");
    }
    $("#stage-add").modal("show");
    $("#submit-add").unbind();
    $("#submit-add").bind('click',{id:id,type:type},submitStage);
}

function submitStage(e){
    if($.trim($("#new_stage_name").val()) == ""){
        alert("没有需要新增的阶段");
        return;
    }
    if($.trim($("#new_p_start_date").val())!=""&&$.trim($("#new_p_end_date").val())!=""){
        if($("#new_p_start_date").val()>$("#new_p_end_date").val() == true){
            alert("预计开始日期大于预计结束日期");
            return;
        }
    }
    if(e.data.type == '项目计划重大变更'){
        if($.trim($("#addReason").val()) == ""){
            alert("请填写变更原因");
            return;
        }
    }
    $.ajax({
        url: '/pmsManagerWorkIMP/projectStageAdd',
        type: 'post',
        data: {'stage_id':$("#new_stage_name").val(),'p_start_date':$("#new_p_start_date").val(),'p_end_date':$("#new_p_end_date").val(),'id':e.data.id,'addReason':$.trim($("#addReason").val())},
        dataType: 'json',
        success:function(response){
            if(response.status == 1){
                alert('新增成功');
                reload('stage-add',e.data.type);
                $("#stage-add").modal("hide");
            }else{
                alert(response.msg);
            }
        },error:function(response){
            alert("新增阶段失败");
        }
    });
}

function deleteStage(dev_id,type,obj){
    if(type == '项目计划重大变更'){
        clearForm();
        $("#delete-modal").modal("show");
        $("#delete_btn").unbind();
        $("#delete_btn").bind("click",{dev_id:dev_id,type:type,obj:obj},deleteBtn);
        return;
    }
    var choose = confirm("确认删除此进度");
    if(choose == true){
        startDelete(dev_id,type,obj);
    }
}
function deleteBtn(e){
    if($.trim($("#deleteReason").val()) == ""){
        alert("请填写删除原因");
        return;
    }
    3
    startDelete(e.data.dev_id,e.data.type,e.data.obj);
}

function startDelete(dev_id,type,obj){
    $.ajax({
        url: '/pmsManagerWorkIMP/projectDelDev',
        data: {'dev_id':dev_id,"deleteReason":$.trim($("#deleteReason").val())},
        type: 'post',
        dataType: 'json',
        success:function(response){
            alert("删除成功");
            $("#delete-modal").modal("hide");
            $(obj.parentElement.parentElement).remove();
        },error:function(response){
            alert('删除失败');
        }
    });
}

function startProject(id,type){
    $.ajax({
        url: '/pmsManagerWorkIMP/projectStChange',
        type: 'post',
        data: {'id':id},
        dataType: 'json',
        success:function(response){
            if(response.status == 1){
                alert("项目启动成功");
                $.ajax({
                    url: '/pmsManagerWork/projectPlanDetailHandler',
                    type: 'post',
                    data: {'id':id,'type':type},
                    dataType: 'html',
                    success:function(html){
                        $("#content").html(html);
                    }
                });
            }else{
                alert(response.msg);
            } 
        },error:function(response){
            alert('启动项目失败');
        }
    });
}


function showChange(id){
    $("#list li:gt(0)").remove();
    $.ajax({
        url: '/pmsManagerWorkIMP/changeInfos',
        type: 'post',
        data: {'id':id},
        dataType: 'json',
        success:function(response){
            if(response.length == 0){
                $("#list li:last").after('<li style="text-align:center;"><span style="line-height:30px;border-radius:3px;padding:0 15px;background-color: #e2e2e2;font-size: 14px;display: inline-block;">无任何变更记录</span></li>');
            }else{
                for(var i=0;i<response.length;i++){
                    $("#list li:last").after('<li class="list-group-item"><h5 class="list-group-item-text" style="word-wrap:break-word;word-break:break-all;">'+response[i]['change']+'</h5><h5 class="list-group-item-text" style="word-wrap:break-word;word-break:break-all;"><span style="color:#5d9cec;">变更原因:</span>'+response[i]['mes']+'</h5><p class="list-group-item-heading text-right">'+response[i]['time']+'&nbsp;&nbsp;'+response[i]['user_name']+'</p></li>');
                }
            }
            $("#showChange-modal").modal("show");
        },error(response){
            alert('查看失败');
        }
    });
}

function exportWork(id){
    var form=document.createElement("form");
    form.action="/pmsManagerWork/workDownload";
    form.method="POST";
    form.style.display="none";
    var input=document.createElement("input");
    input.name="fileName";
    input.value='计划安排';
    form.appendChild(input);
    var input1=document.createElement("input");
    input1.name="id";
    input1.value=id;
    form.appendChild(input1);
    document.body.appendChild(form);
    form.submit();
}

function importWork(){
    $("#workImport").click();
}

function startImport(id,type){
    if($.trim($("#workImport").val()) == ""){
        return;
    }else{
        var file=$("#workImport")[0].files[0];
        var formData=new FormData();
        var fileName = $("#workImport").val().split("\\");
        formData.append("fileName",fileName[fileName.length-1]);
        formData.append("file",file);
        formData.append("id",id);
        $.ajax({
            url: '/pmsManagerWork/workImport',
            type: 'post',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            success:function(response){
                $("#workImport").val("");
                if(response.success == 0){
                    alert("导入失败");
                }else if(response.success == 2){
                    alert(response.msg);
                }else{
                    alert("导入成功");
                    $.ajax({
                        url: '/pmsManagerWork/projectPlanDetailHandler',
                        type: 'post',
                        data: {'id':id,'type':type},
                        dataType: 'html',
                        success:function(html){
                            $("#content").html(html);
                        }
                    });
                }
            },error:function(response){
                alert("导入失败");
            }
        }); 
    }
}
