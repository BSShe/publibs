// 查询机构
function search_orgs() {
    init_DataTables();
    return false;
}

// 点击机构新增按钮
function click_orgs_add() {
    $("#modal-normal").modal("show");
    $("#modal-title").text("机构新增");
    clearform();
    $("#code").attr("disabled",false);
    var nowDate = new Date().Format("yyyyMMdd");
    $("#st_date").val(nowDate);
    $("#submit_btn").unbind();
    $("#submit_btn").on("click", add_orgs);
}

// 点击返回按钮
function backTemplate() {
    $('#ut').css('display','none');
    $('#ot').removeAttr('style');
    $('#backBtn').toggle();
}

// 增加机构
function add_orgs() {
    $("#user_form").bootstrapValidator('validate');
    var bv = $("#user_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        //alert("验证失败");
        return false;
    } else {
        var data = $("#user_form").serializeArray()
        data = objectifyForm(data);
        //data['global_menu_id'] = $("#global_menu_id").val();
        $.ajax({
            url: "/supplierManager/manageEstimateToAdd",
            type: "post",
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
                if (response.result) {
                    search_orgs();
                    $("#modal-normal").modal("hide");
                }
            },
            error: function (response) {
                alert("添加机构失败");
            }
        })
    }
}

// 点击修改机构按钮
function click_orgs_alter(id) {
    $("#user_form")[0].reset();
    clearform();
    $("#modal-title").text("机构修改");
    $("#code").attr("disabled",true);
    fill_form_orgs(id);
    $("#modal-normal").modal("show");
    $("#submit_btn").unbind();
    $("#submit_btn").on("click", function () {
        alter_orgs(id);
    });
}

// 修改机构信息
function alter_orgs(id) {
    $("#user_form").bootstrapValidator('validate');
    var bv = $("#user_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        //alert("验证失败");
        return false;
    } else {
        var data = $("#user_form").serializeArray();
        data = objectifyForm(data);
        data['id'] = id;
        //data['global_menu_id'] = $("#global_menu_id").val();
        $.ajax({
            url: "/supplierManager/manageEstimateToUpdate",
            type: "post",
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
                if (response.result) {
                    $("#modal-normal").modal("hide");
                    search_orgs();
                }
            },
            error: function () {
                alert("修改机构信息失败");
            }
        });

    }
}

function del_orgs(id) {
    var msg = "您真的确定要删除该机构？\n\n请确认！";
    if (confirm(msg) === false) {
        return false;
    }
    var user_id = id;
    var surl = '/supplierManager/manageEstimateDel';
    var data = {};
    data['id'] = user_id;
    data['global_menu_id'] = $("#global_menu_id").val();
    $.ajax({
        type: 'post',
        url: surl,
        data: data,
        dataType: 'json',
        success: function (data) {
            if (data.result) {
                init_DataTables();
            } else {
                alert("删除失败");
            }
        },
        error: function (error_msg) {
            alert("数据请求失败!");
        }
    });
}


// 点击查看人员按钮
function showOrgUser(id) {
    $('#ot').css('display','none');
    $('#ut').removeAttr('style');
    $('#backBtn').toggle();

    $("#modal-normal-userList").modal("show");
    $("#modal-title-userList").text("人员列表");
    //var nowDate = new Date().Format("yyyyMMdd");
    $("#org_userList_org_id").val(id)
    init_org_userList_DataTables();
    //$("#submit_btn").unbind();
    //$("#submit_btn").on("click", add_orgs);
}

//
function xxxxxxx() {
    $("#user_form").bootstrapValidator('validate');
    var bv = $("#user_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        //alert("验证失败");
        return false;
    } else {
        var data = $("#user_form").serializeArray()
        data = objectifyForm(data);
        //data['global_menu_id'] = $("#global_menu_id").val();
        $.ajax({
            url: "/supplierManager/manageEstimateToAdd",
            type: "post",
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
                if (response.result) {
                    search_orgs();
                    $("#modal-normal").modal("hide");
                }
            },
            error: function (response) {
                alert("添加机构失败");
            }
        })
    }
}
// 填充数据
function fill_form_orgs(id) {
    $.ajax({
        url: "/supplierManager/manageEstimateBfUpdate",
        type: "post",
        dateType: "json",
        data: {
            'id': id
        },
        success: function (response) {
            for (var key in response) {
                $("#" + key).val(response[key]);
            }
            return false;
        },
        error: function (response) {
            alert("获取数据失败");
        }
    });
}


// 表单数据序列化
function objectifyForm(formArray) { //serialize data function

    var returnArray = {};
    for (var i = 0; i < formArray.length; i++) {
        returnArray[formArray[i]['name']] = formArray[i]['value'];
    }
    return returnArray;
}

// 表单验证清空数据和样式
function clearform() {
    $("small").css('display', 'none');
    $("#user_form")[0].reset();
    $("i").remove(".glyphicon-remove");
    $("i").remove(".glyphicon-ok");
    $("div").removeClass("has-error");
    $("div").removeClass("has-success");
}
