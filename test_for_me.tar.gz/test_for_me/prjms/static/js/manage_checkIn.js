function search_check_in() {
    init_check_in_DataTables();
    return false;
}

// 人员考勤未打卡详情 
function showNCIDList(user_id) {
   $("#modal-normal-ncidList").modal("show");
   var nowDate = new Date().Format("yyyyMMdd");
   $("#ncidModel_user_id").val(user_id)
   $("#ncidModel_start_date").val($("#search_startdate").val())
   $("#ncidModel_end_date").val($("#search_enddate").val())
   init_user_ncidList_DataTables();
}
// 人员考勤迟到详情
function showSEList(user_id) {
   $("#modal-normal-seList").modal("show");
   var nowDate = new Date().Format("yyyyMMdd");
   $("#seModel_user_id").val(user_id)
   $("#seModel_start_date").val($("#search_startdate").val())
   $("#seModel_end_date").val($("#search_enddate").val())
   init_user_seList_DataTables();
}
// 人员考勤早退详情
function showXEList(user_id) {
   $("#modal-normal-xeList").modal("show");
   var nowDate = new Date().Format("yyyyMMdd");
   $("#xeModel_user_id").val(user_id)
   $("#xeModel_start_date").val($("#search_startdate").val())
   $("#xeModel_end_date").val($("#search_enddate").val())
   init_user_xeList_DataTables();
}
// 人员考勤详情查看按钮 
function showAloneUserList(user_id) {
   $("#modal-normal-aloneList").modal("show");
   var nowDate = new Date().Format("yyyyMMdd");
   $("#aloneModel_user_id").val(user_id)
   $("#aloneModel_start_date").val($("#search_startdate").val())
   $("#aloneModel_end_date").val($("#search_enddate").val())
   init_user_aloneList_DataTables();
}

//人员考勤信息 导出
function exportInfo() {
    window.location.href =  "/userManage/userCheckInExportInfo?start_date=" + $("#search_startdate").val() + "&end_date=" + $("#search_enddate").val(); 
}
