// 查询人员
function search_users() {
    init_DataTables();
    return false;
}

// 点击人员新增按钮
function click_users_add() {
    $("#modal-normal").modal("show");
    $("#modal-title").text("新增人员");
    $("#no").removeAttr("disabled");
    $("#org_id").removeAttr("disabled");
    clearform();
    $('#js_tree').jstree('uncheck_all');
    var nowDate = new Date().Format("yyyyMMdd");
    $("#st_date").val(nowDate);
    $("#submit_btn").unbind();
    $("#submit_btn").on("click", add_users);
}

// 增加人员
function add_users() {
    $("#user_form").bootstrapValidator('validate');
    var bv = $("#user_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        return false;
    } else {
        var data = $("#user_form").serializeArray()
        var arr = $('#js_tree').jstree('get_checked');
        if(arr.length == 0){
            alert('人员必须分配角色!');
            return false;
        }
        data = objectifyForm(data);
        data['role_id_list'] = arr;
        data['no'] = $("#no").val();
        $.ajax({
            url: "/paramManage/manageUserToAdd",
            type: "post",
            traditional: true,
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
                if (response.result == 'true') {
                    search_users();
                    $("#modal-normal").modal("hide");
                }else{
                    alert(response.msg);
                }
            },
            error: function (response) {
                alert("添加人员失败");
            }
        })
    }
}
//重置用户密码为初始密码
function reset_users_passwd(id) {
    var msg = "您确定要重置该人员密码？";
    if (confirm(msg) === false) {
        return false;
    }
    var user_id = id;
    var surl = '/paramManage/manageUserResetPd';
    var data = {};
    data['id'] = user_id;
    data['global_menu_id'] = $("#global_menu_id").val();
    $.ajax({
        type: 'post',
        url: surl,
        data: data,
        dataType: 'json',
        success: function (data) {
            if (data.result == 'true') {
                alert(data.msg);
                //init_DataTables();
            } 
        },
        error: function (error_msg) {
            alert("数据请求失败!");
        }
    });
}

// 点击修改人员按钮
function click_users_alter(id) {
    $("#user_form")[0].reset();
    clearform();
    $("#modal-title").text("人员修改");
    $("#no").attr("disabled","disabled");
    $("#org_id").attr("disabled","disabled");
    fill_form_users(id);
    $("#modal-normal").modal("show");
    $("#submit_btn").unbind();
    $("#submit_btn").on("click", function () {
        alter_users(id);
    });
}

// 修改人员信息
function alter_users(id) {
    $("#user_form").bootstrapValidator('validate');
    var bv = $("#user_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        //alert("验证失败");
        return false;
    } else {
        var data = $("#user_form").serializeArray();
        var arr = $('#js_tree').jstree('get_checked');
        if(arr.length == 0){
            alert('人员必须分配角色!');
            return false;
        }
        data = objectifyForm(data);
        data['id'] = id;
        data['org_id'] = $("#org_id").val();
        data['role_id_list'] = arr;
        $.ajax({
            url: "/paramManage/manageUserToUpdate",
            type: "post",
            traditional: true,
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
                if (response.result == 'true') {
                    $("#modal-normal").modal("hide");
                    search_users();
                }else{
                    alert(response.msg);
                }
            },
            error: function () {
                alert("修改人员信息失败");
            }
        });

    }
}

function del_users(id) {
    var msg = "您真的确定要删除该人员？\n\n请确认！";
    if (confirm(msg) === false) {
        return false;
    }
    var user_id = id;
    var surl = '/paramManage/manageUserDel';
    var data = {};
    data['id'] = user_id;
    data['global_menu_id'] = $("#global_menu_id").val();
    $.ajax({
        type: 'post',
        url: surl,
        data: data,
        dataType: 'json',
        success: function (data) {
            if (data.result) {
                init_DataTables();
            } else {
                alert("删除失败");
            }
        },
        error: function (error_msg) {
            alert("数据请求失败!");
        }
    });
}


// 点击查看人员按钮
function showUserProUser(id) {
    $("#modal-normal-userList").modal("show");
    $("#modal-title-userList").text("人员列表");
    var nowDate = new Date().Format("yyyyMMdd");
    $("#user_proList_user_id").val(id)
    init_user_proList_DataTables();
}

// 填充数据
function fill_form_users(id) {
    $.ajax({
        url: "/paramManage/manageUserBfUpdate",
        type: "post",
        dateType: "json",
        data: {
            'id': id
        },
        success: function (response) {
            for (var key in response['user']) {
                $("#" + key).val(response['user'][key]);
            }
            role_id_list = response['role_id_list']
            $('#js_tree').jstree('uncheck_all');
            for (var i=0; i<role_id_list.length; i++){
               $('#js_tree').jstree('check_node', role_id_list[i]['role_id']); 
            }
            return false;
        },
        error: function (response) {
            alert("获取数据失败");
        }
    });
}

$("#org_id").change(function(){
    var org_id = $(this).val();
    $.ajax({
        url: "/paramManage/manageUserBfAdd-orgId",
        type: "post",
        dateType: "json",
        data: {
            'org_id': org_id
        },
        success: function (response) {
            if(response.result == 'true'){
                $("#no").attr("disabled","disabled");
                $("#no").val(response.user_no);
            }else{
                $("#no").removeAttr("disabled");
                $("#no").val("");
            }
        },
        error: function (response) {
            alert("获取数据失败");
        }
    });
});


//人员管理信息 导出
function exportInfo() {
    window.location.href =  "/paramManage/manageUserExportInfo?no=" + $("#search_no").val() + "&name=" + $("#search_name").val() 
                                                                    + "&role_id=" + $("#search_role_id").val() + "&status_id=" + $("#search_status_id").val() 
                                                                    + "&org_id=" + $("#search_org_id").val();
}

// 表单数据序列化
function objectifyForm(formArray) { //serialize data function

    var returnArray = {};
    for (var i = 0; i < formArray.length; i++) {
        returnArray[formArray[i]['name']] = formArray[i]['value'];
    }
    return returnArray;
}

// 表单验证清空数据和样式
function clearform() {
    $("small").css('display', 'none');
    $("#user_form")[0].reset();
    $("i").remove(".glyphicon-remove");
    $("i").remove(".glyphicon-ok");
    $("div").removeClass("has-error");
    $("div").removeClass("has-success");
}
