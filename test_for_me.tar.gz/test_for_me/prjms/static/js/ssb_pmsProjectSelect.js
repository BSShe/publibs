function getNewInfo(){
    data = {}
    data.supId = $("#supList").val();
    data.userId = $("#userList").val()
    data.contractCode = $("#contractList").val();
    init_ProjectTables();
    $.ajax({
        url: "/pms/refreshTotalInfo",
        type: "post",
        data: data,
        dataType: "json",
        success:function(response){
            alert("111");
        },error(response){
        }
    });
}

