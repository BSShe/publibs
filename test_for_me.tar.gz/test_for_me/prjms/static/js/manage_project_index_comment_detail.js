function click_project_add(comment_type) {
    $("#modal-normal").modal("show");
    $("#modal-title").text("质量评价新增");
    clearform();
    var html = "<select class='form-control' id='type' name='type'>";
    for (var i in comment_type){
        html += "<option value="+comment_type[i]+">"+comment_type[i]+"</option>" 
    }
    html += "</select>"
    document.getElementById("select_type").innerHTML = html; 
    $("#submit_btn_pro").unbind();
    $("#submit_btn_pro").on("click",add_project);
}
function add_project(){
    $("#user_form").bootstrapValidator('validate');
    var bv = $("#user_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        alert("验证失败");
        return false;
    } else {
        var data = $("#user_form").serializeArray()
        data = objectifyForm(data);
        console.info(data);
        $.ajax({
            url: "/pmsComment/manageQueryToAdd",
            type: "post",
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
               // console.info(response);
               // var body="";
               // for (var i in response){
               // body += '<tr><td>'+response[i]["name2"]+'</td>'+
               //         '<td>'+response[i]["discu"]+'</td>'+
               //         '<td>'+response[i]["code"]+'</td>'+
               //         '<td>'+response[i]["username"]+'</td>'+
               //         '<td><button class="btn w-sm btn-primary waves-effect waves-light" type="button" onclick="click_project_update()">'+
               //         '项目质量修改</button></tr>';
               // }
               // $('#comment_list').html(body);
                $("#modal-normal").on('hide.bs.modal',function(){
                    $.ajax({
                        url: "/pmsComment/projectCommentHandler",
                        type: "post",
                        dataType: "html",
                        data: data={'id':document.getElementById('pms_project_id').value,'type':1},
                        async: false,
                        success: function (response) {
                                $('#content').html(response)
                        },
                        error: function (response) {
                                alert("查看详情失败");
                        }
                    })
                });
                $("#modal-normal").modal("hide");
            
            },
            error: function (response) {
                alert("项目评价失败");
            }
        })
    }
}






function details_users(id){
        var data = {'id':id};
        $.ajax({
            url: "/pmsManager/projectDetail2Handler",
            type: "post",
            dataType: "html",
            data: data,
            async: false,
            success: function (response) {
                    $('#content').html(response)
            },
            error: function (response) {
                    alert("查看详情失败");
            }
        })

}

function click_project_update(type,name){
    $("#modal-normal").modal("show");
    $("#modal-title").text("手动修改");
    clearform();
    document.getElementById("select_type").innerHTML = "<select class='form-control' id='type' name='type'>"+
        "<option value="+type+"-"+name+">"+name+"</option></select>"
    $("#submit_btn_pro").unbind();
    $("#submit_btn_pro").on("click",add_project);
}

function update(pcid){
    $("#modal-normal").modal("show");
    $("#modal-title").text("项目修改");
    document.getElementById("code").name = pcid;
    clearform();
    $("#submit_btn_pro").unbind();
    $("#submit_btn_pro").on("click",add_code);    
}

function add_code(){
    code = document.getElementById("code").value;
    pcid = document.getElementById("code").name;
    $.ajax({
        url: "/pmsComment/projectCommentToUpdateHandler",
        type: "post",
        dataType: "json",
        data: data={'pcid':pcid,'code':code},
        async: false,
        success: function (response) {
                $("#modal-normal").on('hide.bs.modal',function(){
                    $.ajax({
                        url: "/pmsComment/projectCommentHandler",
                        type: "post",
                        dataType: "html",
                        data: data={'id':document.getElementById('pms_project_id').value,'type':2},
                        async: false,
                        success: function (response) {
                                $('#content').html(response)
                        },
                        error: function (response) {
                                alert("查看详情失败");
                        }
                    })
                });
                $("#modal-normal").modal("hide");
        },
        error: function (response) {
                alert("查看详情失败");
        }
    })
}

function search_users(){

}
function clearform() {
}

function moreDiscu(con){
    $("#modal-normal2").modal("show");
    $("#modal-title2").text("项目修改");
    $("#moreDiscu").html("<textarea class='form-control' type='text' >"+con+"</textarea>");
}

function comeBackCom(page){
    $.ajax({
        url: "/pmsComment/manageQueryList",
        type: "get",
        dataType: "html",
        data: data={'page':page},
        async: false,
        success: function (response) {
                $('#content').html(response)
        },
        error: function (response) {
                alert("查看详情失败");
        }
    })
}
function objectifyForm(formArray) { //serialize data function
    var returnArray = {};
    for (var i = 0; i < formArray.length; i++) {
        returnArray[formArray[i]['name']] = formArray[i]['value'];
    }
    return returnArray;
}

