
var stage = {};
var cstage = {};
var name1 = {};
var projectId = 0;
var devCUserList = new Array();//格式：stageID-stageChildId-userId_statu
setProjectPreData();
//主页查看详情模态框
function moreDevInfo(id,childStage){
    $("#modal-normal-manDetail").modal("show");
    $("#modal-title-manDetail").text("子任务人员安排");
    node = document.getElementById("addManDetail");
    //列表标题
    head = "<table class='table text-nowrap text-center table-bordered table-header-bg'>"+
           "<thead><tr><th class='col-md-4'>子任务名</th><th class='col-md-8'>人员安排</th></tr></thead>";
    //列表内容
    body = "<tbody>";
    for (var i in childStage){
        if (childStage[i]['sid'] == id){
            body += "<tr><th style='text-align:center;'>"+childStage[i]['cname']+"</th><th>";
            var htmlname = "";
            for (var j in devCUserList){
                if (devCUserList[j].split("-")[0] == id && devCUserList[j].split("-")[1] == childStage[i]['id']){
                    for (var k in name1){
                        if (name1[k]['id'] == (devCUserList[j].split("-")[2]).split("_")[0]){
                            if (htmlname == ""){
                                htmlname += (name1[k]['name']);
                            }else{
                                htmlname += ("/"+name1[k]['name']);
                            }
                        }
                    }
                }
            }
            body += (htmlname+"</th></tr>");
        }
    }
    body += "</tbody></table>"
    node.innerHTML = (head + body);
}

//时间分配清空
function project_pre_re(){
    Nodes=document.querySelectorAll("[data-commit-id = 'stageres']");
    for (var i in Nodes){
        Nodes[i].value = "";
    }
}
//时间分配数据提交与主页回显
function project_pre(){
    $("#stage_res_form").bootstrapValidator('validate');
    var bv = $("#stage_res_form").data("bootstrapValidator").isValid();
    var dataJson = {};
    if (bv === false) {
        alert("验证失败");
        return false;
    } else {
        var data1 = $("#stage_res_form").serializeArray()
        for(var i in data1){
            if (data1[i]["value"] != ""){
                document.getElementById(data1[i]["name"]+"pre").innerText = (data1[i]["value"]);
            }
            document.getElementById(data1[i]["name"]+"devMa").innerText = document.getElementById(data1[i]["name"]+"devManagerId").value;
            dataJson[data1[i]["name"]+'time'] = data1[i]["value"];
            dataJson[data1[i]["name"]+'devM'] = document.getElementById(data1[i]["name"]+"devManagerId").name;
        }
        dataJson['projectId'] = projectId;
        $.ajax({
            url: "/pmsManager/timeAndDevMCommit",
            type: "post",
            data:{"data": JSON.stringify(dataJson)},
            async: false,
            success: function (response) {
                alert("提交成功！");
                document.getElementById("mainPageId").click();
            },
            error: function (response) {
                alert("提交失败");
            }
        })
    }
}
// statu 1表添加，0表初始化数据库提取
//人员添加操作
function getLiMan(uid,sid,id,statu){
    var flag = 1;
    for (var i in devCUserList){

        if (devCUserList[i].split("_")[0] == (sid+"-"+id+"-"+uid)){
            for (var i in cstage){
                //当机构id等于供应商id时，管理人可为同一人，不弹出已分配
                if ( cstage[i]['sid']==sid){
                    if (cstage[i]['sname'] == '项目准备'){
                    }else{
                        alert("用户已分配！");
                    }
                }
            }
            flag = 0;
            break;
        }
    }
    if (flag == 1){
        devCUserList.push(sid+"-"+id+"-"+uid+"_"+statu);
        refreshData(sid,id,uid);
    }
}
//删除人员操作
function delLiMan(sid,id,uid){
    for (var i in devCUserList){
        if (devCUserList[i].split("_")[0] == (sid+"-"+id+"-"+uid)){
            devCUserList.splice(i,1);
            break;
        }
    }
    refreshData(sid,id,uid);
}
//人员数据及时刷新
function refreshData(sid,id,uid){
    html = "";
    document.getElementById(sid+"id"+id).value = "";
    document.getElementById(sid+"id"+id).name = "";
    for (var i in devCUserList){
        if (devCUserList[i].split("-")[0] == sid && devCUserList[i].split("-")[1] == id){
            for (var j in name1){
                if (name1[j]['id'] == (devCUserList[i].split("-")[2]).split("_")[0]){
                    html += ("<li><a onclick='delLiMan("+sid+","+id+","+name1[j]['id']+")'>"+name1[j]['name']+"</a></li>");
                    //界面数据
                    var uvalue = document.getElementById(sid+"id"+id);
                    if (uvalue.value == "" || uvalue.value == null){
                        document.getElementById(sid+"id"+id).value += name1[j]['name'];          
                    }else{
                        document.getElementById(sid+"id"+id).value += ("/"+name1[j]['name']);
                    }
                }
            }
        }
    }
    for (var i in cstage){
        if ( cstage[i]['sid']==sid && cstage[i]['id']==id){
            if (cstage[i]['cname'] != '项目立项' && cstage[i]['cname'] != '项目启动' && document.getElementById(sid+"parentDevUser"+id)){
                document.getElementById(sid+"parentDevUser"+id).innerHTML = html;
            }
        }
    }    
}

//人员分配数据提交
function project_child(sid){
    var data = {};
    var len = 0;
    for (var i in devCUserList){
        if (devCUserList[i].split("-")[0] == sid){
            var is_same = 0;
            for (var n = 0 ;n < i;n++ ){
                console.info(n,i,"  ",devCUserList[n])
                if(devCUserList[i].split("-")[0] == devCUserList[n].split("-")[0] && (devCUserList[i].split("-")[2]).split("_")[0] == (devCUserList[n].split("-")[2]).split("_")[0]){
                    is_same = 1;
                    break;
                }
            }
            if(is_same == 0){
                len++;    
            }
            data[sid+"-"+i+"-"+devCUserList[i].split("_")[1]] = devCUserList[i].split("-")[1]+"-"+(devCUserList[i].split("-")[2]).split("_")[0];
        }
    }
    if (document.getElementById(sid+"cou")){
        document.getElementById(sid+"cou").innerText = len;
    }
    data['projectId'] = projectId+"-"+sid;
    $.ajax({
        url: "/pmsManager/devChildUserCommit",
        type: "post",
        data:{"data": JSON.stringify(data)},
        async: false,
        success: function (response) {
            alert("提交成功！");
        },
        error: function (response) {
            alert("提交失败");
        }
    })
}

//资源操作与提交，回显
function project_res(){
    Nodes=document.querySelectorAll("#Lia");
    var flag = 0;
    //检查是否有空白
    for (var i in Nodes){
        if (Nodes[i].value=="" || Nodes[i].value){
            if (Nodes[i].value == "" || Nodes[i].nextSibling.value == ""){
                flag = 1;
                break;
            }
        }
    }
    if (flag == 0){
        document.getElementById("fin_project_res").innerHTML = document.getElementById("fin_project_res_head").outerHTML;
        var data=new Array();
        var dataJson = {};
        for (var i in Nodes){
            if (Nodes[i].value=="" || Nodes[i].value){
                data[i]={};
                data[i]["id"]=i;
                data[i]["value1"]=Nodes[i].value;
                data[i]["value2"]=Nodes[i].nextSibling.value;
                if (data[i]["value1"] == "" && data[i]["value2"] == ""){
                    flag = 1;
                }else{
                    dataJson[i+"res"+Nodes[i].value] = Nodes[i].nextSibling.value;
                    setResourceData(data[i]["id"],data[i]["value1"],data[i]["value2"],"fin_project_res");
                }
            }
        }
        dataJson['projectId'] = projectId;
        $.ajax({
            url: "/pmsManager/resAndDevCommit",
            type: "post",
            data:{"data": JSON.stringify(dataJson)},
            async: false,
            success: function (response) {
                alert("修改成功!")
                document.getElementById("mainPageId").click();
            },
            error: function (response) {
                alert("提交失败");
            }
        })
    }else {
        alert("存在空白输入，请检查！")
    }
}

function project_dev(){
    Nodes=document.querySelectorAll("#Lib");
    var flag = 0;
    for (var i in Nodes){
        if (Nodes[i].value=="" || Nodes[i].value){
            if (Nodes[i].value == "" || Nodes[i].nextSibling.value == ""){
                flag = 1;
                break;
            }
        }
    }
    if (flag == 0){
        document.getElementById("fin_project_dev").innerHTML = document.getElementById("fin_project_dev_head").outerHTML;
        var data=new Array();
        var dataJson = {};
        for (var i in Nodes){
            if (Nodes[i].value=="" || Nodes[i].value){
                data[i]={};
                data[i]["id"]=i;
                data[i]["value1"]=Nodes[i].value;
                data[i]["value2"]=Nodes[i].nextSibling.value;
                if (data[i]["value1"] == "" && data[i]["value2"] == ""){
                    flag = 1;
                }else{
                    dataJson[i+"dev"+Nodes[i].value] = Nodes[i].nextSibling.value;
                    setResourceData(data[i]["id"],data[i]["value1"],data[i]["value2"],"fin_project_dev");
                }
            }
        }
        dataJson['projectId'] = projectId;
        $.ajax({
            url: "/pmsManager/resAndDevCommit",
            type: "post",
            data:{"data": JSON.stringify(dataJson)},
            async: false,
            success: function (response) {
                alert("修改成功!")
                document.getElementById("mainPageId").click();
            },
            error: function (response) {
                alert("提交失败");
            }
        })
    }else {
        alert("存在空白输入，请检查！")
    }
}

function setResourceData(name,value1,value2,hid){
    var getId = "";
    if (hid == "fin_project_res"){
        getId = "LiaD";
    }
    else if (hid == "fin_project_dev"){
        getId = "LibD";
    }
    html='<div class="col-md-4" id='+getId+'><input type="text" class=" form-control" name="'+name+'1" value="'+value1+'" disabled ></input></div><div class="col-md-8"><input type="text" class="col-lg-4 form-control" name="'+name+'2" value="'+value2+'" disabled></input></div>';
    var parentNode = document.getElementById(hid);
    var div=document.createElement("div");
    div.setAttribute("class","row");
    div.innerHTML=html;
    parentNode.appendChild(div);
}
function getMoreData(id,allstage,allchildstage){
    stage = allstage;
    cstage = allchildstage;
}

//界面初始化数据显示
function setProjectPreData(){
    document.getElementById("getProId").click();
    proId = document.getElementById("getProId").value;
    dev_id = document.getElementById("dev_id").value;
    projectId = proId;

    //子任务人员分配界面完善
    $.ajax({
        url: "/pmsManager/getChildBranchPerson",
        type: "post",
        dataType: "json",
        data:{'pid':projectId},
        async: false,
        success: function (response) {
            name1 = response.name1;
            var cstageUser = response.cstage_userList; 
            for (var i in cstageUser){
                if (cstageUser[i]['cname'] == '项目立项' || cstageUser[i]['cname'] == '项目启动'){
                    continue;
                }
                var html = "";
                for (var j in cstageUser[i]['userList']){
                    html += "<li><a onclick=getLiMan(" + cstageUser[i]['userList'][j]['id'] + "," + cstageUser[i]['sid'] + 
                            "," + cstageUser[i]['id'] + ",'1') >" + cstageUser[i]['userList'][j]['name'] + "</a></li>";
                }   
                if (document.getElementById(cstageUser[i]['sid']+'parent'+cstageUser[i]['id'])){
                    document.getElementById(cstageUser[i]['sid']+'parent'+cstageUser[i]['id']).innerHTML = html;
                }
            }
        },
        error: function (response) {
            alert("提交失败");
        }
    });

    data = {"id":proId,"dev_id":dev_id};
    $.ajax({
        url: "/pmsManager/getProjectPreData",
        type: "post",
        dataType: "json",
        data:data,
        async: false,
        success: function (response) {
            for (var i in response) {
                if (response[i]['type'] == 1) {
                    setResourceData(i,response[i]["name"],response[i]["con"],"fin_project_res");
                    if (response[i]['write'] == 1){
                        addSaltIpGrp(document.getElementById("addLia"),'Lia',response[i]["name"],response[i]["con"]);
                    }else{
                        addSaltIpGrp2(document.getElementById("addLia"),'Lia',response[i]["name"],response[i]["con"]);
                    }
                }
                else if (response[i]['type'] == 2){
                    setResourceData(i,response[i]["name"],response[i]["con"],"fin_project_dev");
                    if (response[i]['write'] == 1){
                        addSaltIpGrp(document.getElementById("addLib"),'Lib',response[i]["name"],response[i]["con"]);
                    }else{
                        addSaltIpGrp2(document.getElementById("addLib"),'Lib',response[i]["name"],response[i]["con"]);
                    }
                }
                else if (response[i]['type'] == 3){
                    if (document.getElementById(response[i]['sid']+"pre")){
                        document.getElementById(response[i]['sid']+"pre").innerText = response[i]['worksday'];
                    }
                }
                else if (response[i]['type'] == 4){
                    if (document.getElementById(response[i]['sid']+"devMa")){
                        document.getElementById(response[i]['sid']+"devMa").innerText = response[i]['name'];
                    }
                    if (document.getElementById(response[i]['sid']+"devManagerId")){
                        document.getElementById(response[i]['sid']+"devManagerId").value = response[i]['name'];
                    }
                }
                else if (response[i]['type'] == 5){
                    if (document.getElementById(response[i]['sid']+"cou")){
                        if (response[i]['cou'] == 0){
                            document.getElementById(response[i]['sid']+"cou").innerText = "";
                        }else{
                            document.getElementById(response[i]['sid']+"cou").innerText = response[i]['cou'];
                        }
                    }
                }
                else if (response[i]['type'] == 6){
                    if (response[i]['name'] != null){
                        getLiMan(response[i]['userid'],response[i]['sid'],response[i]['cid'],0)
                    }
                }
            }
            //update_cou(stage);
        },
        error: function (response) {
            alert("数据初始化失败");
        }
    })
}

function clearform(){
}
//进度确认提交
function project_preparation_data(){
    $.ajax({
        url: '/pmsManager/checkPlanTime',
        type: 'post',
        data: {'dev_id':$("#dev_id").val()},
        dataType: 'json',
        success:function(response){
            var len = response.length;
            if(len != 0){
                if(len == 1){
                    if(response[0] == 'p_start_date'){
                        alert('未安排阶段预计开始时间，请前往综合管理安排具体时间再完成此进度');
                        return;
                    }else{
                        alert('未安排阶段预计结束时间，请前往综合管理安排具体时间再完成此进度');
                        return;
                    }
                }else{
                    alert('未安排阶段预计时间，请前往综合管理安排具体时间再完成此进度');
                    return;
                }
            }else{
                makeFinishStage(response);
            }
        },error:function(response){
            alert('检测计划安排时间失败');
        }
    });
}
function makeFinishStage(checkTime){
    $.ajax({
        url: "/pmsManager/project_plan_index-project_submit",
        data: {'projectId':$("#getProId").val(),"checkTime":JSON.stringify(checkTime),'dev_id':$("#dev_id").val()},
        type: "POST",
        dataType: "json",
        success:function(response){
            if(response.status == 1){
                alert("状态改变成功!");
                $.ajax({
                    url: "/pmsManagerPlan/manageQueryList",
                    type: "get",
                    dataType: "html",
                    async: false,
                    success: function (response) {
                        $('#content').html(response);
                    },
                    error: function (response) {
                        alert("刷新失败！");
                    }
                })
            }else if(response.status == 0){
                alert("无权限做出此操作");
            }else{
                alert("状态改变失败!");
            }
        },error:function(response){
            alert("状态改变失败!");
        }
    });
}
function onError(){
    alert("该功能需要授权！");
}

function objectifyForm(formArray) { //serialize data function
    var returnArray = {};
    for (var i = 0; i < formArray.length; i++) {
        returnArray[formArray[i]['name']] = formArray[i]['value'];
    }
    return returnArray;
}
