function search_supplier_qualify() {
    init_supplier_qualify_DataTables();
    return false;
}

// 点击新增供应商按钮
function click_supplier_qualify_add() {
        $("#org_form")[0].reset();
        $("#supplier_qualify_form")[0].reset();
        clearform();
        $("#modal-title").text("新增供应商");
        $("#modal-normal").modal("show");
        $("#code").removeAttr("readonly");
        $("#name").removeAttr("readonly");
        $("#submit_btn").unbind();
        $("#submit_btn").on("click", function () {
        add_supplier_qualify();
    });
}
  
// 新增供应商信息
function add_supplier_qualify() {
    $("#supplier_qualify_form").bootstrapValidator('validate');
    var bv = $("#supplier_qualify_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        //alert("验证失败");
        return false;
    } else {
        var data1 = $("#org_form").serializeArray();
        data1 = objectifyForm(data1);
        var data2 = $("#supplier_qualify_form").serializeArray();
        data2 = objectifyForm(data2);
        var arr = $('#js_tree').jstree('get_checked');
        if(arr.length == 0){
            alert('机构必须分配角色!');
            return false;
        }
        data1['role_id_list'] = arr;
        data1['type_id'] = $("#type_id").val();
        $.ajax({ 
            url: "/paramManage/manageOrgToAdd", 
            type: "post", 
            dataType: "json", 
            traditional: true, 
            data: data1, 
            async: false, 
            success: function (response) { 
                if (response.result == 'true') { 
                    data2['id'] = response.org_id
                    data2['code'] = "code";
                    data2['name'] = "name";
                    $.ajax({
                        url: "/supplierManage/manageQualifyToUpdate",
                        type: "post",
                        dataType: "json",
                        data: data2,
                        async: false,
                        success: function (response) {
                            if (response.result) {
                                $("#modal-normal").modal("hide");
                                search_supplier_qualify();
                            }
                        },
                        error: function () {
                            alert("新增供应商失败");
                        }
                    });
                }else{ 
                    alert(response.msg); 
                } 
            }, 
            error: function (response) { 
                alert("新增供应商失败"); 
            } 
        });
    }
}

// 点击修改供应商资质管理按钮
function click_supplier_qualify_alter(id) {
    $("#org_form")[0].reset();
    $("#supplier_qualify_form")[0].reset();
    clearform();
    $("#modal-title").text("供应商资质管理修改");
    $("#code").attr("readonly","readonly");
    $("#name").attr("readonly","readonly");
    $("#contact_way").attr("readonly","readonly");
    fill_form_supplier_qualify(id);
    $("#modal-normal").modal("show");
    $("#submit_btn").unbind();
    $("#submit_btn").on("click", function () {
        alter_supplier_qualify(id);
    });
}


//根据主要联系人员 修改 联系方式 的内容
$("#link_man").change(function(){
    var user = $(this).val();
    $.ajax({
        url: "/supplierManage/manageQualifyGetUserPhone",
        type: "post",
        dateType: "json",
        async: false,
        data: {
            'user': user
        },
        success: function (response) {
            if(response.result == 'true'){
                $("#contact_way").val(response['data']['phone_no']);
            }
        },
        error: function (response) {
            alert("获取数据失败");
        }
    });
});

// 修改供应商资质管理信息
function alter_supplier_qualify(id) {
    $("#supplier_qualify_form").bootstrapValidator('validate');
    var bv = $("#supplier_qualify_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        //alert("验证失败");
        return false;
    } else {
        var data1 = $("#org_form").serializeArray();
        data1 = objectifyForm(data1);
        data1['id'] = id;
        var arr = $('#js_tree').jstree('get_checked');
        if(arr.length == 0){
            alert('机构必须分配角色!');
            return false;
        }
        data1['role_id_list'] = arr;
        data1['type_id'] = $("#type_id").val();
        $.ajax({
            url: "/paramManage/manageOrgToUpdate",
            type: "post",
            dataType: "json",
            traditional: true,
            data: data1,
            async: false,
            success: function (response) {
                if (response.result == 'true') {
                    var data2 = $("#supplier_qualify_form").serializeArray();
                    data2 = objectifyForm(data2);
                    data2['id'] = id;
                    data2['code'] = "code";
                    data2['name'] = "name";
                    //data['global_menu_id'] = $("#global_menu_id").val();
                    $.ajax({
                        url: "/supplierManage/manageQualifyToUpdate",
                        type: "post",
                        dataType: "json",
                        data: data2,
                        async: false,
                        success: function (response) {
                            if (response.result) {
                                $("#modal-normal").modal("hide");
                                search_supplier_qualify();
                            }
                        },
                        error: function () {
                            alert("修改供应商信息失败");
                        }
                    });
                }else{
                    alert(response.msg);
                }
            },
            error: function () {
                alert("修改供应商信息失败");
            }
        });
    }
}

// 供应商资质文件详情查看按钮 
function showFileList(org_id) {
   $("#modal-normal-fileList").modal("show");
   var nowDate = new Date().Format("yyyyMMdd");
   $("#fileModel_org_id").val(org_id)
   init_qualify_fileList_DataTables();
}

// 展示上传供应商资质文件界面
function showAddFile(org_id) {
    $("#modal-normal-add-file").modal("show");
    clearform();
    $("#addFileModel_org_id").val(org_id);
    var nowDate = new Date().Format("yyyyMMdd");
    $("#file_data").bind("change",function(){
        var str = $(this).val();
        var arr = str.split("\\");
        var file_name = arr[arr.length-1].split(".")[0];
        $("#file_name").val(file_name);
    });
}

// 增加资质文件
function toAddFile(org_id) {
        var data = new FormData();
        data.append('pms_org_id',$("#addFileModel_org_id").val());
        data.append('file_name',$("#file_name").val());
        data.append('file_data',$("#file_data")[0].files[0]);
        $.ajax({
            url: "/supplierManage/manageQualifyAddFile",
            type: "post",
            dataType: "json",
            cache: false,
            processData: false,
            contentType: false,
            data: data,
            async: false,
            success: function (response) {
                if (response.result == 'true') {
                    $("#modal-normal-add-file").modal("hide");
                }else{
                    alert(response.msg);
                }
            },
            error: function (response) {
                alert("添加资质文件");
            }
        })
}

//下载合同文件 
function downFile(pms_supplier_file_id) {
    window.location.href =  "/supplierManage/manageQualifydownFile?pms_supplier_file_id=" + pms_supplier_file_id;
        }

//供应商资质信息 导出
function exportInfo() {
    window.location.href =  "/supplierManage/manageQualifyExportInfo?code=" + $("#search_code").val() + "&name=" + $("#search_name").val();
        }

// 填充数据
function fill_form_supplier_qualify(id) {
    $.ajax({
        url: "/supplierManage/manageQualifyBfUpdate",
        type: "post",
        dateType: "json",
        async: false,
        data: {
            'id': id
        },
        success: function (response) {
            options = response['option']        
            //$("#link_man").empty();
            //$("#link_man").append("<option value=\"\">请选择</option>");
            //for(var i=0;i<options.length;i++){
            //    var option = "<option value='" + options[i]['link_man'] + "'>" + options[i]['link_man'] + "</option>"
            //    $("#link_man").append(option);
            //}
            for (var key in response['data']) {
                $("#" + key).val(response['data'][key]);
            }
            role_id_list = response['role_id_list']
            $('#js_tree').jstree('uncheck_all');
            for (var i=0; i<role_id_list.length; i++){
               $('#js_tree').jstree('check_node', role_id_list[i]['role_id']);
            }
            return false;
        },
        error: function (response) {
            alert("获取数据失败");
        }
    });
}

// 表单数据序列化
function objectifyForm(formArray) { //serialize data function
    var returnArray = {};
    for (var i = 0; i < formArray.length; i++) {
        returnArray[formArray[i]['name']] = formArray[i]['value'];
    }
    return returnArray;
}

// 表单验证清空数据和样式
function clearform() {
    $("small").css('display', 'none');
    $("#supplier_qualify_form")[0].reset();
    $("i").remove(".glyphicon-remove");
    $("i").remove(".glyphicon-ok");
    $("div").removeClass("has-error");
    $("div").removeClass("has-success");
}
