/**
* Theme: Ubold Admin Template
* Author: Coderthemes
* Module/App: Main Js
*/


!function($) {
    "use strict";

    var Sidemenu = function() {
        this.$body = $("body"),
        this.$openLeftBtn = $(".open-left"),
        this.$menuItem = $("#sidebar-menu .nav-submenu"),
        this.$menuLink = $("#sidebar-menu ul ul li a")
    };
    Sidemenu.prototype.openLeftBar = function() {
      $("#wrapper").toggleClass("enlarged");
      $("#wrapper").addClass("forced");

      if($("#wrapper").hasClass("enlarged")) {
        $(".left ul").removeAttr("style");
      } else {
        $(".subdrop").siblings("ul:first").show();
      }

      toggle_slimscroll(".slimscrollleft");
      $("body").trigger("resize");
    },
    //menu item click
    Sidemenu.prototype.menuItemClick = function(e) {
      var $li = $(this).parent();
      var $subMenu = $(this).next();
      var $open = $li.siblings(".open");

      if(!$("#wrapper").hasClass("enlarged")){
        if ($open) {
          $open.find('> ul:visible').slideUp( 200);
          $open.toggleClass('open');
        }
        if( $li.hasClass('open') ){
          $subMenu.slideUp( 200);
          $li.toggleClass('open');
        }else{
          $subMenu.slideDown( 200);
          $li.toggleClass('open');
        }
        if( $(this).next().is('ul') ){
          e.preventDefault();
        } else{
          $li.addClass("menudrop").siblings().removeClass("menudrop").find("> ul > li").removeClass("active");
        }
      }
    },
    //menu link click
    Sidemenu.prototype.menuLinkClick = function(e) {
      $('.active').removeClass('active');
      $(this).addClass('active').parents('.parent').addClass('menudrop').siblings().removeClass("menudrop");
    },

    //init sidemenu
    Sidemenu.prototype.init = function() {
      var $this  = this;

      var ua = navigator.userAgent,
        event = (ua.match(/iP/i)) ? "touchstart" : "click";

      //bind on click
      this.$openLeftBtn.on(event, function(e) {
        e.stopPropagation();
        $this.openLeftBar();
      });

      // LEFT SIDE MAIN NAVIGATION
      $this.$menuItem.on(event, $this.menuItemClick);
      $this.$menuLink.on(event, $this.menuLinkClick);

    },

    //init Sidemenu
    $.Sidemenu = new Sidemenu, $.Sidemenu.Constructor = Sidemenu

}(window.jQuery),


function($) {
    "use strict";

    var FullScreen = function() {
        this.$body = $("body"),
        this.$fullscreenBtn = $("#btn-fullscreen")
    };

    //turn on full screen
    // Thanks to http://davidwalsh.name/fullscreen
    FullScreen.prototype.launchFullscreen  = function(element) {
      if(element.requestFullscreen) {
        element.requestFullscreen();
      } else if(element.mozRequestFullScreen) {
        element.mozRequestFullScreen();
      } else if(element.webkitRequestFullscreen) {
        element.webkitRequestFullscreen();
      } else if(element.msRequestFullscreen) {
        element.msRequestFullscreen();
      }
    },
    FullScreen.prototype.exitFullscreen = function() {
      if(document.exitFullscreen) {
        document.exitFullscreen();
      } else if(document.mozCancelFullScreen) {
        document.mozCancelFullScreen();
      } else if(document.webkitExitFullscreen) {
        document.webkitExitFullscreen();
      }
    },
    //toggle screen
    FullScreen.prototype.toggle_fullscreen  = function() {
      var $this = this;
      var fullscreenEnabled = document.fullscreenEnabled || document.mozFullScreenEnabled || document.webkitFullscreenEnabled;
      if(fullscreenEnabled) {
        if(!document.fullscreenElement && !document.mozFullScreenElement && !document.webkitFullscreenElement && !document.msFullscreenElement) {
          $this.launchFullscreen(document.documentElement);
        } else{
          $this.exitFullscreen();
        }
      }
    },
    //init sidemenu
    FullScreen.prototype.init = function() {
      var $this  = this;
      //bind
      $this.$fullscreenBtn.on('click', function() {
        $this.toggle_fullscreen();
      });
    },
     //init FullScreen
    $.FullScreen = new FullScreen, $.FullScreen.Constructor = FullScreen

}(window.jQuery),



//main app module
 function($) {
    "use strict";

    var App = function() {
        this.$body = $("body")
    };

     //on doc load
    App.prototype.onDocReady = function(e) {
      FastClick.attach(document.body);
      resizefunc.push("initscrolls");
      resizefunc.push("changeptype");

      $('.animate-number').each(function(){
        $(this).animateNumbers($(this).attr("data-value"), true, parseInt($(this).attr("data-duration")));
      });

      //RUN RESIZE ITEMS
      $(window).resize(debounce(resizeitems,100));
      $("body").trigger("resize");

      // right side-bar toggle
      $('.right-bar-toggle').on('click', function(e){

          $('#wrapper').toggleClass('right-bar-enabled');
      });


    },
    //initilizing
    App.prototype.init = function() {
        var $this = this;
        //document load initialization
        $(document).ready($this.onDocReady);
        //init side bar - left
        $.Sidemenu.init();
        //init fullscreen
        $.FullScreen.init();
    },

    $.App = new App, $.App.Constructor = App

}(window.jQuery),

//initializing main application module
function($) {
    "use strict";
    $.App.init();
}(window.jQuery);



/* ------------ some utility functions ----------------------- */
//this full screen
var toggle_fullscreen = function () {

}

function executeFunctionByName(functionName, context /*, args */) {
  var args = [].slice.call(arguments).splice(2);
  var namespaces = functionName.split(".");
  var func = namespaces.pop();
  for(var i = 0; i < namespaces.length; i++) {
    context = context[namespaces[i]];
  }
  return context[func].apply(this, args);
}
var w,h,dw,dh;
var changeptype = function(){
    w = $(window).width();
    h = $(window).height();
    dw = $(document).width();
    dh = $(document).height();

    if(jQuery.browser.mobile === true){
        $("body").addClass("mobile").removeClass("fixed-left");
    }

    if(!$("#wrapper").hasClass("forced")){
      if(w > 990){
        $("body").removeClass("smallscreen").addClass("widescreen");
          $("#wrapper").removeClass("enlarged");
      }else{
        $("body").removeClass("widescreen").addClass("smallscreen");
        $("#wrapper").addClass("enlarged");
        $(".left ul").removeAttr("style");
      }

  }
  toggle_slimscroll(".slimscrollleft");
}


var debounce = function(func, wait, immediate) {
  var timeout, result;
  return function() {
    var context = this, args = arguments;
    var later = function() {
      timeout = null;
      if (!immediate) result = func.apply(context, args);
    };
    var callNow = immediate && !timeout;
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
    if (callNow) result = func.apply(context, args);
    return result;
  };
}

function resizeitems(){
  if($.isArray(resizefunc)){
    for (i = 0; i < resizefunc.length; i++) {
        window[resizefunc[i]]();
    }
  }
}

function initscrolls(){
    if(jQuery.browser.mobile !== true){
      //SLIM SCROLL
      $('.slimscroller').slimscroll({
        height: 'auto',
        size: "5px"
      });

      $('.slimscrollleft').slimScroll({
          height: 'auto',
          position: 'right',
          size: "5px",
          color: '#98a6ad',
          wheelStep: 5
      });
  }
}
function toggle_slimscroll(item){
    if($("#wrapper").hasClass("enlarged")){
      $(item).css("overflow","inherit").parent().css("overflow","inherit");
      $(item). siblings(".slimScrollBar").css("visibility","hidden");
    }else{
      $(item).css("overflow","hidden").parent().css("overflow","hidden");
      $(item). siblings(".slimScrollBar").css("visibility","visible");
    }
}



// Blocks options functionality
var uiBlocks = function() {
    // Init default icons fullscreen and content toggle buttons
    uiBlocksApi(false, 'init');

    // Call blocks API on option button click
    jQuery('[data-toggle="block-option"]').on('click', function(){
        uiBlocksApi(jQuery(this).closest('.block'), jQuery(this).data('action'));
    });
};
var uiBlocksApi = function($block, $mode) {
    // Set default icons for fullscreen and content toggle buttons
    var $iconFullscreen         = 'icon-size-fullscreen';
    var $iconFullscreenActive   = 'icon-size-actual';
    var $iconContent            = 'si si-arrow-up';
    var $iconContentActive      = 'si si-arrow-down';

    if ($mode === 'init') {
        // Auto add the default toggle icons to fullscreen and content toggle buttons
        jQuery('[data-toggle="block-option"][data-action="fullscreen_toggle"]').each(function(){
            var $this = jQuery(this);

            $this.html('<i class="' + (jQuery(this).closest('.block').hasClass('block-opt-fullscreen') ? $iconFullscreenActive : $iconFullscreen) + '"></i>');
        });

        jQuery('[data-toggle="block-option"][data-action="content_toggle"]').each(function(){
            var $this = jQuery(this);

            $this.html('<i class="' + ($this.closest('.block').hasClass('block-opt-hidden') ? $iconContentActive : $iconContent) + '"></i>');
        });
    } else {
        // Get block element
        var $elBlock = ($block instanceof jQuery) ? $block : jQuery($block);

        // If element exists, procceed with blocks functionality
        if ($elBlock.length) {
            // Get block option buttons if exist (need them to update their icons)
            var $btnFullscreen  = jQuery('[data-toggle="block-option"][data-action="fullscreen_toggle"]', $elBlock);
            var $btnToggle      = jQuery('[data-toggle="block-option"][data-action="content_toggle"]', $elBlock);

            // Mode selection
            switch($mode) {
                case 'fullscreen_toggle':
                    $elBlock.toggleClass('block-opt-fullscreen');

                    // Enable/disable scroll lock to block
                    if ($elBlock.hasClass('block-opt-fullscreen')) {
                        jQuery($elBlock).scrollLock('enable');
                    } else {
                        jQuery($elBlock).scrollLock('disable');
                    }

                    // Update block option icon
                    if ($btnFullscreen.length) {
                        if ($elBlock.hasClass('block-opt-fullscreen')) {
                            jQuery('i', $btnFullscreen)
                                .removeClass($iconFullscreen)
                                .addClass($iconFullscreenActive);
                        } else {
                            jQuery('i', $btnFullscreen)
                                .removeClass($iconFullscreenActive)
                                .addClass($iconFullscreen);
                        }
                    }
                    break;
                case 'fullscreen_on':
                    $elBlock.addClass('block-opt-fullscreen');

                    // Enable scroll lock to block
                    jQuery($elBlock).scrollLock('enable');

                    // Update block option icon
                    if ($btnFullscreen.length) {
                        jQuery('i', $btnFullscreen)
                            .removeClass($iconFullscreen)
                            .addClass($iconFullscreenActive);
                    }
                    break;
                case 'fullscreen_off':
                    $elBlock.removeClass('block-opt-fullscreen');

                    // Disable scroll lock to block
                    jQuery($elBlock).scrollLock('disable');

                    // Update block option icon
                    if ($btnFullscreen.length) {
                        jQuery('i', $btnFullscreen)
                            .removeClass($iconFullscreenActive)
                            .addClass($iconFullscreen);
                    }
                    break;
                case 'content_toggle':
                    $elBlock.toggleClass('block-opt-hidden');

                    // Update block option icon
                    if ($btnToggle.length) {
                        if ($elBlock.hasClass('block-opt-hidden')) {
                            jQuery('i', $btnToggle)
                                .removeClass($iconContent)
                                .addClass($iconContentActive);
                        } else {
                            jQuery('i', $btnToggle)
                                .removeClass($iconContentActive)
                                .addClass($iconContent);
                        }
                    }
                    break;
                case 'content_hide':
                    $elBlock.addClass('block-opt-hidden');

                    // Update block option icon
                    if ($btnToggle.length) {
                        jQuery('i', $btnToggle)
                            .removeClass($iconContent)
                            .addClass($iconContentActive);
                    }
                    break;
                case 'content_show':
                    $elBlock.removeClass('block-opt-hidden');

                    // Update block option icon
                    if ($btnToggle.length) {
                        jQuery('i', $btnToggle)
                            .removeClass($iconContentActive)
                            .addClass($iconContent);
                    }
                    break;
                case 'refresh_toggle':
                    $elBlock.toggleClass('block-opt-refresh');

                    // Return block to normal state if the demostration mode is on in the refresh option button - data-action-mode="demo"
                    if (jQuery('[data-toggle="block-option"][data-action="refresh_toggle"][data-action-mode="demo"]', $elBlock).length) {
                        setTimeout(function(){
                            $elBlock.removeClass('block-opt-refresh');
                        }, 2000);
                    }
                    break;
                case 'state_loading':
                    $elBlock.addClass('block-opt-refresh');
                    break;
                case 'state_normal':
                    $elBlock.removeClass('block-opt-refresh');
                    break;
                case 'close':
                    $elBlock.hide();
                    break;
                case 'open':
                    $elBlock.show();
                    break;
                default:
                    return false;
            }
        }
    }
};
uiBlocks();


