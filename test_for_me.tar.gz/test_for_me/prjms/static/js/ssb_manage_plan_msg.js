//消息留言
function proComment(pid,uid,is_send){
    if ($(".chatbar").is(":visible")&&is_send) {
       outCommesList(pid); 
    }
    else {
        $(".chatbar").css({display:"block"});
        $(".inner-con"+pid).css({background:"#DDDDDD"});
        $(".inner-box"+pid).addClass('bb');
        $("#inner-img"+pid).addClass('aa');
        $("#blockId").animate({width:"76%"});
        $("#manage_msg_datatable").animate({width:"100%"});
        $("#chatbarId").animate({width:"20%"});
        $(".icon-box").addClass('shadow');
        document.getElementById("comsend").innerHTML="<input class='message-btn' type='button' value='发送' id='message-btn' onclick='sendCommes("+pid+","+uid+")'>";
        document.getElementById("meg-title").innerHTML += "<i class='iconfont return-icon' onclick='outCommesList("+pid+")'>&#xe61a;</i>";
        var data = {'pid': pid};
        var messages_text = document.getElementById("messagestext");
        messages_text.innerHTML = "";
        document.getElementById("messageContent").value = "";
        $.ajax({
            url: "/pmsManager/getProjectCommes",
            type: "post",
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
                if (response.length != 0){
                    document.getElementById("comproname").innerHTML = '<span>'+response[0]['proname']+'</span>';
                }
                else{
                    document.getElementById("comproname").innerHTML = '';
                    messages_text.innerHTML = '<h3 style="text-align:center;margin-top:50%;">暂无数据</h3>';
                }
                for (var i in response){
                    messages_text.innerHTML = messages_text.innerHTML + "<ul id="+ i +"ul class='messages-text-uls'><li class='messages-text-lis'>"
                        + "<h4><span>" + response[i]['username'] + "</span><span class='time'>"
                        + response[i]['workdate'] + "</span></h4>" + "<p>" + response[i]['con'] + "</p>"
                        + "</ul></li>";
                }
            },
            error: function (response) {
                alert("查看详情失败");
            }
        })
    }
}

function outCommesList(pid){
    $("#blockId").animate({width:"100%"});
    $("#manage_msg_datatable").animate({width:"100%"});
    $("#chatbarId").animate({width:"0%"});
    $(".icon-box").removeClass('shadow');
    $(".inner-con"+pid).css({background:""});
    $(".inner-box"+pid).removeClass('bb');
    $("#inner-img"+pid).removeClass('aa');
    setTimeout('$(".chatbar").css({display:"none"})','1000');
}

function sendCommes(pid,uid){
    var message = $('.messages-content').val();
    var messages_text = document.getElementById("messagestext");
    var data = {};
    if (message != "undefined" && message != '') {
        messages_text.innerHTML = "";
        data['pid'] = pid;
        data['uid'] = uid;
        data['con'] = message;
        $.ajax({
            url: "/pmsManager/saveProjectCommes",
            type: "post",
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
                proComment(pid,uid,false);
            },
            error: function (response) {
                alert("发送失败！");
            }
       })
    } else {
        var messageTooltip = "<div class='message-tooltip'>不能发送空白信息</div>";
        $(".chatbar").append(messageTooltip);
        setTimeout(function() {
            $(".message-tooltip").hide();
        }, 2000);
    }
}

