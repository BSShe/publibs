// 查询项目阶段
function search_project_stage_child() {
    init_project_stage_child_DataTables();
        return false;
        }
//点击子阶段新增按钮
function click_project_stage_child_add() {
    $("#modal-normal-child").modal("show");
    $("#modal-title-child").text("新增子阶段");
    clearform_child();
    $("#id").hide();
    $("#child_code").attr("disabled",false);
    $("#submit_btn_child").unbind();
    $("#submit_btn_child").on("click", add_project_stage_child);
}

// 增加子阶段
function add_project_stage_child() {
    $("#project_stage_child_form").bootstrapValidator('validate');
    var bv = $("#project_stage_child_form").data("bootstrapValidator").isValid();
    if (bv == false) {
        //alert("验证失败");
        return false;
    } else {
        var data = $("#project_stage_child_form").serializeArray()
        data = objectifyForm(data);
        data['pms_project_stage_id'] = $("#p_stage_id").val();
        $.ajax({
            url: "/paramManage/manageParamList-project_stage_childToAdd",
            type: "post",
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
                if (response.result) {
                    search_project_stage_child();
                    $("#modal-normal-child").modal("hide");
                }
            },
            error: function (response) {
                alert("添加子阶段失败");
            }
        })
    }
}

// 点击修改子阶段按钮
function click_project_stage_child_alter(project_stage_child_id) {
    $("#project_stage_child_form")[0].reset();
    clearform_child();
    $("#modal-title-child").text("修改子阶段修改");
    $("#child_code").attr("disabled",true);
    fill_form_project_stage_child(project_stage_child_id);
    $("#modal-normal-child").modal("show");
    $("#submit_btn-child").unbind();
    $("#submit_btn_child").on("click", function () {
        alter_project_stage_child(project_stage_child_id);
    });
}

// 修改子阶段信息
function alter_project_stage_child(project_stage_child_id) {
    $("#project_stage_child_form").bootstrapValidator('validate');
    var bv = $("#project_stage_child_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        //alert("验证失败");
        return false;
    } else {
        var data = $("#project_stage_child_form").serializeArray();
        data = objectifyForm(data);
        data['id'] = project_stage_child_id
        $.ajax({
            url: "/paramManage/manageParamList-project_stage_childToUpdate",
            type: "post",
            traditional: true,
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
                if (response.result) {
                    $("#modal-normal-child").modal("hide");
                    search_project_stage_child();
                }
            },
            error: function () {
                alert("修改项目阶段信息失败");
            }
        });

    }
}

function del_project_stage_child(project_stage_child_id) {
    var msg = "您真的确定要删除该子阶段？\n\n请确认！";
    if (confirm(msg) === false) {
        return false;
    }
    var surl = '/paramManage/manageParamList-project_stage_childToDel';
    var data = {};
    data['id'] = project_stage_child_id;
    $.ajax({
        type: 'post',
        url: surl,
        data: data,
        dataType: 'json',
        success: function (data) {
            if (data.result == 'true') {
                init_project_stage_child_DataTables();
                alert(data.msg);
            } else {
                alert(data.msg);
            }
        },
        error: function (error_msg) {
            alert("数据请求失败!");
        }
    });
}

// 填充数据
function fill_form_project_stage_child(project_stage_child_id) {
    $.ajax({
        url: "/paramManage/manageParamList-project_stage_childBfUpdate",
        type: "post",
        dateType: "json",
        data: {
            'project_stage_child_id': project_stage_child_id
        },
        success: function (response) {
            for (var key in response) {
                $("#child_" + key).val(response[key]);
            }
            return false;
        },
        error: function (response) {
            alert("获取数据失败");
        }
    });
}


// 表单数据序列化
function objectifyForm(formArray) { //serialize data function

    var returnArray = {};
    for (var i = 0; i < formArray.length; i++) {
        returnArray[formArray[i]['name']] = formArray[i]['value'];
    }
    return returnArray;
}

// 表单验证清空数据和样式
function clearform_child() {
    $("small").css('display', 'none');
    $("#project_stage_child_form")[0].reset();
    $("i").remove(".glyphicon-remove");
    $("i").remove(".glyphicon-ok");
    $("div").removeClass("has-error");
    $("div").removeClass("has-success");
}
