// 查询合同
function search_contracts() {
    init_DataTables();
    return false;
}

// 点击合同新增按钮
function click_contracts_add() {
    $("#modal-normal").modal("show");
    $("#modal-title").text("新增合同");
    $("#code").removeAttr("readonly");
    $("#org_id").removeAttr("disabled");
    clearform();
    var nowDate = new Date().Format("yyyyMMdd");
    $("#st_date").val(nowDate);
    $("#submit_btn").unbind();
    $("#submit_btn").on("click", add_contracts);
}

// 增加合同
function add_contracts() {
    $("#contract_form").bootstrapValidator('validate');
    var bv = $("#contract_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        //alert("验证失败");
        return false;
    } else {
        var data = $("#contract_form").serializeArray()
        data = objectifyForm(data);
        console.log(data);
        $.ajax({
            url: "/contractManage/manageContractToAdd",
            type: "post",
            traditional: true,
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
                if (response.result == 'true') {
                    search_contracts();
                    $("#modal-normal").modal("hide");
                }else{
                    alert(response.msg);
                }
            },
            error: function (response) {
                alert("添加合同失败");
            }
        })
    }
}

// 点击修改合同按钮
function click_contracts_alter(id) {
    $("#contract_form")[0].reset();
    clearform();
    $("#modal-title").text("合同修改");
    $("#code").attr("readonly","readonly");
    fill_form_contracts(id);
    $("#modal-normal").modal("show");
    $("#submit_btn").unbind();
    $("#submit_btn").on("click", function () {
        alter_contracts(id);
    });
}

// 修改合同信息
function alter_contracts(id) {
    $("#contract_form").bootstrapValidator('validate');
    var bv = $("#contract_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        //alert("验证失败");
        return false;
    } else {
        var data = $("#contract_form").serializeArray();
        data = objectifyForm(data);
        data['id'] = id;
        //data['global_menu_id'] = $("#global_menu_id").val();
        $.ajax({
            url: "/contractManage/manageContractToUpdate",
            type: "post",
            traditional: true,
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
                if (response.result) {
                    $("#modal-normal").modal("hide");
                    search_contracts();
                }
            },
            error: function () {
                alert("修改合同信息失败");
            }
        });

    }
}

function del_contracts(id) {
    var msg = "您真的确定要删除该合同？\n\n请确认！";
    if (confirm(msg) === false) {
        return false;
    }
    var surl = '/contractManage/manageContractDel';
    var data = {};
    data['pms_contract_exe_condtn_id'] = id;
    data['global_menu_id'] = $("#global_menu_id").val();
    $.ajax({
        type: 'post',
        url: surl,
        data: data,
        dataType: 'json',
        success: function (data) {
            if (data.result) {
                init_DataTables();
            } else {
                alert("删除失败");
            }
        },
        error: function (error_msg) {
            alert("数据请求失败!");
        }
    });
}

//根据供应商改变 人员 select的 option
$("#supplier_name").change(function(){
    var org = $(this).val();
    $.ajax({
        url: "/contractManage/manageContractGetSupplierUser",
        type: "post",
        dateType: "json",
        async: false,
        data: {
            'org': org
        },
        success: function (response) {
            if(response.result == 'true'){
                $("#supplier_linkman").empty();
                data = response.data
                for(var i=0;i<data.length;i++){
                    var option = "<option value='" + data[i]['supplier_linkman'] + "'>" + data[i]['supplier_linkman'] + "</option>"
                    $("#supplier_linkman").append(option); 
                }
            }
        },
        error: function (response) {
            alert("获取数据失败");
        }
    });
});


// 点击查看阶段按钮
function showStageList(contract_id) {
    $("#modal-normal-stageList").modal("show");
    var nowDate = new Date().Format("yyyyMMdd");
    $("#stageModel_contract_id").val(contract_id)
    init_contract_stageList_DataTables();
}

// 点击查看特殊约定事项按钮
function showItemList(contract_id) {
    $("#modal-normal-itemList").modal("show");
    var nowDate = new Date().Format("yyyyMMdd");
    $("#itemModel_contract_id").val(contract_id)
    init_contract_itemList_DataTables();
}

// 付款详情查看按钮 
function showPayCondtnList(contract_id) {
    $("#modal-normal-payCondtnList").modal("show");
    var nowDate = new Date().Format("yyyyMMdd");
    $("#payCondtnModel_contract_id").val(contract_id)
    init_contract_payCondtnList_DataTables();
}

// 合同文件详情查看按钮 
function showFileList(contract_id) {
    $("#modal-normal-fileList").modal("show");
    var nowDate = new Date().Format("yyyyMMdd");
    $("#fileModel_contract_id").val(contract_id)
    init_contract_fileList_DataTables();
}
//下载合同文件 
function downContractFile(pms_contract_file_id) {
    window.location.href =  "/contractManage/manage-contract-downContractFile?pms_contract_file_id=" + pms_contract_file_id;
    }

// 展示增加阶段界面
function showAddStage(contract_id) {
    $("#modal-normal-add-stage").modal("show");
    clearform();
    $("#addStageModel_contract_id").val(contract_id);
    var nowDate = new Date().Format("yyyyMMdd");
}

// 增加阶段
function toAddStage(contract_id) {
        $.ajax({
            url: "/contractManage/manage-contract-AddStage",
            type: "post",
            traditional: true,
            dataType: "json",
            data: {'pms_contract_id':$("#addStageModel_contract_id").val(),
                   'name':$("#stage_name").val(),
                    'start_date':$("#stage_start_date").val(),
                    'end_date':$("#stage_end_date").val()         
                  },
            async: false,
            success: function (response) {
                if (response.result == 'true') {
                    $("#modal-normal-add-stage").modal("hide");
                }else{
                    alert(response.msg);
                }
            },
            error: function (response) {
                alert("添加阶段失败");
            }
        })
}

// 展示增加特殊约定事项界面
function showAddItem(contract_id) {
    $("#modal-normal-add-item").modal("show");
    clearform();
    $("#addItemModel_contract_id").val(contract_id);
    var nowDate = new Date().Format("yyyyMMdd");
}

// 增加特殊约定事项
function toAddItem(contract_id) {
        $.ajax({
            url: "/contractManage/manage-contract-AddItem",
            type: "post",
            traditional: true,
            dataType: "json",
            data: {'pms_contract_id':$("#addItemModel_contract_id").val(),
                   'remark':$("#remark").val(),
                  },
            async: false,
            success: function (response) {
                if (response.result == 'true') {
                    $("#modal-normal-add-item").modal("hide");
                }else{
                    alert(response.msg);
                }
            },
            error: function (response) {
                alert("添加特殊约定事项失败");
            }
        })
}

// 展示增加付款情况界面
function showAddPayCondtn(contract_id) {
    $("#modal-normal-add-payCondtn").modal("show");
    clearform();
    $.ajax({
        url: "/contractManage/manage-contract-AddPayCondtn?contract_id="+contract_id+"&type=1",
        type: "get",
        dateType: "json",
        success: function (response) {
            payTypeList = response['payTypeList']
            $("#payCondtn_pay_type").empty();
            $("#payCondtn_pay_type").append($("<option>").val("").text("请选择"));
        
            for(var i=0;i<payTypeList.length;i++){
                var option = $("<option>").val(payTypeList[i]).text(payTypeList[i]);
                $("#payCondtn_pay_type").append(option);
            }
            
            return false;
        },
        error: function (response) {
            alert("获取数据失败");
        }
    });
    $("#addPayCondtnModel_contract_id").val(contract_id);
    var nowDate = new Date().Format("yyyyMMdd");
    $("#payCondtn_amount").bind("input propertychange",function(){
        payCondtn_amount = $("#payCondtn_amount").val();
        if (payCondtn_amount == ""){
            return false;
        }
        $.ajax({
        url: "/contractManage/manageContractBfAddPayCondtn",
        type: "post",
        dateType: "json",
        data: {
            'amount': payCondtn_amount,
            'contract_id':$("#addPayCondtnModel_contract_id").val()
        },
        success: function (response) {
            for (var key in response) {
                $("#" + key).val(response[key]);
            }
            return false;
        },
        error: function (response) {
            alert("请输入整数!");
            $("#payCondtn_amount").val("");
            $("#payCondtn_paid").val("");
            $("#payCondtn_unpaid").val("");
            $("#payCondtn_paid_ratio").val("");
        }
        }); 
    });
}

function alert_null(check_list){
    for(var i =0; i< check_list.length; i++){
        if($("#"+check_list[i][0]).val() == null || $("#"+check_list[i][0]).val() == ""){
            alert(check_list[i][1] + "不能为空！");
            return false;
            break;
        }
    }
}
// 增加付款情况
function toAddPayCondtn(contract_id) {
        flag = true;
        check_list = [["payCondtn_pay_date",'付款时间'],["payCondtn_amount",'金额'],["payCondtn_pay_type",'付款性质'],["payCondtn_remark",'备注说明'],["payCondtn_paid",'已付合同金额总计'],["payCondtn_unpaid",'未付金额总计'],["payCondtn_paid_ratio",'已付款比例']]
        flag = alert_null(check_list);
        if(flag == false){
            return false;
        }
        $.ajax({
            url: "/contractManage/manage-contract-AddPayCondtn",
            type: "post",
            traditional: true,
            dataType: "json",
            data: {'pms_contract_id':$("#addPayCondtnModel_contract_id").val(),
                   'pay_date':$("#payCondtn_pay_date").val(),
                    'amount':$("#payCondtn_amount").val(),
                    'pay_type':$("#payCondtn_pay_type").val(),
                    'remark':$("#payCondtn_remark").val(),
                    'paid':$("#payCondtn_paid").val(),
                    'unpaid':$("#payCondtn_unpaid").val(),
                    'paid_ratio':$("#payCondtn_paid_ratio").val()
                  },
            async: false,
            success: function (response) {
                if (response.result == 'true') {
                    $("#modal-normal-add-payCondtn").modal("hide");
                }else{
                    alert(response.msg);
                }
            },
            error: function (response) {
                alert("添加失败");
            }
        })
}


// 展示增加合同文件界面
function showAddFile(contract_id) {
    $("#modal-normal-add-file").modal("show");
    clearform();
    $("#addFileModel_contract_id").val(contract_id);
    var nowDate = new Date().Format("yyyyMMdd");
    $("#file_data").bind("change",function(){
        var str = $(this).val();
        var arr = str.split("\\");
        var file_name = arr[arr.length-1].split(".")[0];
        $("#file_name").val(file_name);
    });
}

// 增加合同文件
function toAddFile(contract_id) {
        var data = new FormData();
        data.append('pms_contract_id',$("#addFileModel_contract_id").val());
        data.append('file_name',$("#file_name").val());
        data.append('file_data',$("#file_data")[0].files[0]);
        $.ajax({
            url: "/contractManage/manage-contract-AddFile",
            type: "post",
            dataType: "json",
            cache: false,
            processData: false,
            contentType: false,
            data: data,
            async: false,
            success: function (response) {
                if (response.result == 'true') {
                    $("#modal-normal-add-file").modal("hide");
                }else{
                    alert(response.msg);
                }
            },
            error: function (response) {
                alert("请选择合同文件");
            }
        })
}

// 填充数据
function fill_form_contracts(contract_id) {
    $.ajax({
        url: "/contractManage/manageContractBfUpdate",
        type: "post",
        dateType: "json",
        data: {
            'contract_id': contract_id
        },
        success: function (response) {
            for (var key in response['contract']) {
                $("#" + key).val(response['contract'][key]);
                if(key == 'supplier_name'){
                    $("#supplier_name").trigger("change");
                    $("#supplier_linkman").val(response['contract']['supplier_linkman']);
                }
            }
            return false;
        },
        error: function (response) {
            alert("获取数据失败");
        }
    });
}

// 表单数据序列化
function objectifyForm(formArray) { //serialize data function

    var returnArray = {};
    for (var i = 0; i < formArray.length; i++) {
        returnArray[formArray[i]['name']] = formArray[i]['value'];
    }
    return returnArray;
}

// 表单验证清空数据和样式
function clearform() {
    $("small").css('display', 'none');
    $("#contract_form")[0].reset();
    $("i").remove(".glyphicon-remove");
    $("i").remove(".glyphicon-ok");
    $("div").removeClass("has-error");
    $("div").removeClass("has-success");
}
