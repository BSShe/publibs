function comeBack(page){
    var data = {'page':page};
    $.ajax({
        url: "/pmsManager/manageQueryList",
        type: "get",
        dataType: "html",
        data: data,
        async: false,
        success: function (response) {
              $("#content").html(response);
        },
        error: function (response) {
                alert("返回失败");
        }
    });
}
