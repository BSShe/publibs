// 查询状态
function search_status() {
    init_status_DataTables();
    return false;
}

// 点击状态新增按钮
function click_status_add() {
    $("#modal-normal").modal("show");
    $("#modal-title").text("新增状态");
    clearform();
    $("#code").attr("disabled",false);
    $("#submit_btn").unbind();
    $("#submit_btn").on("click", add_status);
}

// 增加状态
function add_status() {
    $("#status_form").bootstrapValidator('validate');
    var bv = $("#status_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        //alert("验证失败");
        return false;
    } else {
        var data = $("#status_form").serializeArray()
        data = objectifyForm(data);
        //data['global_menu_id'] = $("#global_menu_id").val();
        $.ajax({
            url: "/paramManage/manageParamList-statusToAdd",
            type: "post",
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
                if (response.result) {
                    search_status();
                    $("#modal-normal").modal("hide");
                }
            },
            error: function (response) {
                alert("添加状态失败");
            }
        })
    }
}

// 点击修改状态按钮
function click_status_alter(id) {
    $("#status_form")[0].reset();
    clearform();
    $("#modal-title").text("状态修改");
    $("#code").attr("disabled",true);
    fill_form_status(id);
    $("#modal-normal").modal("show");
    $("#submit_btn").unbind();
    $("#submit_btn").on("click", function () {
        alter_status(id);
    });
}

// 修改状态信息
function alter_status(id) {
    $("#status_form").bootstrapValidator('validate');
    var bv = $("#status_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        //alert("验证失败");
        return false;
    } else {
        var data = $("#status_form").serializeArray();
        data = objectifyForm(data);
        data['id'] = id;
        //data['global_menu_id'] = $("#global_menu_id").val();
        $.ajax({
            url: "/paramManage/manageParamList-statusToUpdate",
            type: "post",
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
                if (response.result) {
                    $("#modal-normal").modal("hide");
                    search_status();
                }
            },
            error: function () {
                alert("修改状态信息失败");
            }
        });

    }
}

function del_status(id) {
    var msg = "您真的确定要删除该状态？\n\n请确认！";
    if (confirm(msg) === false) {
        return false;
    }
    var status_id = id;
    var surl = '/paramManage/manageParamList-statusDel';
    var data = {};
    data['id'] = status_id;
    $.ajax({
        type: 'post',
        url: surl,
        data: data,
        dataType: 'json',
        success: function (data) {
            console.log(data)
            if (data.result == 'true') {
                init_status_DataTables();
            } else {
                alert(data.msg);
            }
        },
        error: function (error_msg) {
            alert("数据请求失败!");
        }
    });
}

// 填充数据
function fill_form_status(id) {
    $.ajax({
        url: "/paramManage/manageParamList-statusBfUpdate",
        type: "post",
        dateType: "json",
        data: {
            'id': id
        },
        success: function (response) {
            for (var key in response) {
                $("#" + key).val(response[key]);
            }
            return false;
        },
        error: function (response) {
            alert("获取数据失败");
        }
    });
}


// 表单数据序列化
function objectifyForm(formArray) { //serialize data function

    var returnArray = {};
    for (var i = 0; i < formArray.length; i++) {
        returnArray[formArray[i]['name']] = formArray[i]['value'];
    }
    return returnArray;
}

// 表单验证清空数据和样式
function clearform() {
    $("small").css('display', 'none');
    $("#status_form")[0].reset();
    $("i").remove(".glyphicon-remove");
    $("i").remove(".glyphicon-ok");
    $("div").removeClass("has-error");
    $("div").removeClass("has-success");
}
