// 查询项目类型
function search_project_type() {
    init_project_type_DataTables();
    return false;
}

// 点击项目类型新增按钮
function click_project_type_add() {
    $("#modal-normal").modal("show");
    $("#modal-title").text("新增项目类型");
    clearform();
    $("#id").hide();
    $("#code").attr("disabled",false);
    $("#submit_btn").unbind();
    $("#submit_btn").on("click", add_project_type);
}

// 增加项目类型
function add_project_type() {
    $("#project_type_form").bootstrapValidator('validate');
    var bv = $("#project_type_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        //alert("验证失败");
        return false;
    } else {
        var data = $("#project_type_form").serializeArray()
        data = objectifyForm(data);
        $.ajax({
            url: "/paramManage/manageParamList-project_typeToAdd",
            type: "post",
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
                if (response.result) {
                    search_project_type();
                    $("#modal-normal").modal("hide");
                }
            },
            error: function (response) {
                alert("添加项目类型失败");
            }
        })
    }
}

// 点击修改项目类型按钮
function click_project_type_alter(id) {
    $("#project_type_form")[0].reset();
    clearform();
    $("#modal-title").text("项目类型修改");
    $("#code").attr("disabled",true);
    fill_form_project_type(id);
    $("#modal-normal").modal("show");
    $("#submit_btn").unbind();
    $("#submit_btn").on("click", function () {
        alter_project_type(id);
    });
}

// 修改项目类型信息
function alter_project_type(id) {
    $("#project_type_form").bootstrapValidator('validate');
    var bv = $("#project_type_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        //alert("验证失败");
        return false;
    } else {
        var data = $("#project_type_form").serializeArray();
        data = objectifyForm(data);
        data['id'] = id;
        //data['global_menu_id'] = $("#global_menu_id").val();
        $.ajax({
            url: "/paramManage/manageParamList-project_typeToUpdate",
            type: "post",
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
                if (response.result) {
                    $("#modal-normal").modal("hide");
                    search_project_type();
                }
            },
            error: function () {
                alert("修改项目类型信息失败");
            }
        });

    }
}

function del_project_type(id) {
    var msg = "您真的确定要删除该项目类型？\n\n请确认！";
    if (confirm(msg) === false) {
        return false;
    }
    var project_type_id = id;
    var surl = '/paramManage/manageParamList-project_typeDel';
    var data = {};
    data['id'] = project_type_id;
    $.ajax({
        type: 'post',
        url: surl,
        data: data,
        dataType: 'json',
        success: function (data) {
            console.log(data)
            if (data.result == 'true') {
                init_project_type_DataTables();
            } else {
                alert(data.msg);
            }
        },
        error: function (error_msg) {
            alert("数据请求失败!");
        }
    });
}

//
function xxxxxxx() {
    $("#project_type_form").bootstrapValidator('validate');
    var bv = $("#project_type_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        //alert("验证失败");
        return false;
    } else {
        var data = $("#project_type_form").serializeArray()
        data = objectifyForm(data);
        //data['global_menu_id'] = $("#global_menu_id").val();
        $.ajax({
            url: "/paramManage/manageOrgToAdd",
            type: "post",
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
                if (response.result) {
                    search_orgs();
                    $("#modal-normal").modal("hide");
                }
            },
            error: function (response) {
                alert("添加项目类型失败");
            }
        })
    }
}
// 填充数据
function fill_form_project_type(id) {
    $.ajax({
        url: "/paramManage/manageParamList-project_typeBfUpdate",
        type: "post",
        dateType: "json",
        data: {
            'id': id
        },
        success: function (response) {
            for (var key in response) {
                $("#" + key).val(response[key]);
            }
            return false;
        },
        error: function (response) {
            alert("获取数据失败");
        }
    });
}


// 表单数据序列化
function objectifyForm(formArray) { //serialize data function

    var returnArray = {};
    for (var i = 0; i < formArray.length; i++) {
        returnArray[formArray[i]['name']] = formArray[i]['value'];
    }
    return returnArray;
}

// 表单验证清空数据和样式
function clearform() {
    $("small").css('display', 'none');
    $("#project_type_form")[0].reset();
    $("i").remove(".glyphicon-remove");
    $("i").remove(".glyphicon-ok");
    $("div").removeClass("has-error");
    $("div").removeClass("has-success");
}
