jQuery.fn.extend({
    include:    function (path, id) {
        var _this = $(this);
        
        $.get(path, function (html){
            _this.replaceWith("<div id =\""+ id +"\">" + html + "</div>");
        });

        return 0;
    }
});
