function click_project_add() {
    if($("#father").length != 0){
        $($("#father").get(0).parentElement.parentElement).remove();
    }
    modalChangeToProject();
    $("#modal-normal").modal("show");
    $("#modal-title").text("项目新增");
    clearform();
    $("#submit_btn_pro").unbind();
    $("#submit_btn_pro").on("click",add_project);
}

function add_project(){
    $("#user_form").bootstrapValidator('validate');
    var bv = $("#user_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        alert("验证失败");
        return false;
    } else {
        var data = $("#user_form").serializeArray()
        data = objectifyForm(data);
        var arr = $('#js_tree').jstree('get_all_checked');
        data['pro_id'] = arr;
        
        data['status'] = 2;
        $.ajax({
            url: "/pmsManager/manageQueryToAdd",
            type: "post",
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
                if (response.result =='true') {
                    alert("创建成功，请前往计划制定以开始相关项目!");
                    $("#modal-normal").modal("hide");
                }else{
                    alert(response.msg);
                }
            },
            error: function (response) {
                alert("添加失败");
            }
        })
    }
}

function del_users(obj,id){
    $("#stopReason").val("");
    $("#stopReason-modal").modal("show");
    $("#stop_btn").unbind();
    $("#stop_btn").bind('click',{id:id,obj:obj},stopProject);
}

function stopProject(e){
    if($.trim($("#stopReason").val()) == ""){
        alert("请填写停止原因");
        return;
    }
    var data = {'pid':e.data.id,'stopReason':$.trim($("#stopReason").val())};
    $.ajax({
        url: "/pmsManager/stopTheProject",
        type: "post",
        dataType: "html",
        data: data,
        async: false,
        success: function (response) {
            alert("修改成功");
            $("#stopReason-modal").modal("hide");
            var obj = e.data.obj;
            var next = obj.parentElement.nextElementSibling;
            obj.parentElement.previousElementSibling.innerText = '已关闭';
            var pre = obj.previousElementSibling;
            if(next.length != 0 && next.children[0].innerText == "创建子项目"){
                $(next.children[0]).remove();
            }
            if(pre.innerText == '计划制定' || pre.innerText == '计划变更'){
                $(pre).remove();
            }
            $(obj).before('<button class="btn btn-info btn-xs" onclick=showStopInfo(' + e.data.id + ')> 关闭原因 </button>');
            $(obj).remove();
        },
        error: function (response) {
            alert("修改失败");
        }
    });
}

function details_users(id,page){
        var data = {'id':id,'page':page};
        $.ajax({
            url: "/pmsManager/projectDetail2Handler",
            type: "post",
            dataType: "html",
            data: data,
            async: false,
            success: function (response) {
                  $("#content").html(response);
            },
            error: function (response) {
                    alert("查看详情失败");
            }
        });

}

function details_img_users(id,page){
    var data = {"id":id,'page':page};
    $.ajax({
            url: "/pms/projectDetail",
            type: "post",
            dataType: "html",
            data: data,
            async: false,
            success: function (response) {
                $("#content").html(response);
            },
            error: function (response) {
                    alert("查看工作进度图失败");
            }
        });
}

function search_users(){

}
function clearform() {
}


function objectifyForm(formArray) { //serialize data function
    var returnArray = {};
    for (var i = 0; i < formArray.length; i++) {
        returnArray[formArray[i]['name']] = formArray[i]['value'];
    }
    return returnArray;
}

function child_manage(page){
    $.ajax({
        url: "/pms/projectChildManageIndex",
        type: "get",
        data: {"page":page,"type":"all"},
        dataType: "html",
        success:function(response){
            $("#content").html(response);
        },error:function(response){
            alert("查看失败");
        }
    });
}

function child_detail(page){
    $.ajax({
        url: "/pms/projectChildDetailIndex",
        type: "get",
        data: {"page":page,"type":"all"},
        dataType: "html",
        success:function(response){
            $("#content").html(response);
        },error:function(response){
            alert("查看失败");
        }
    });
}

function childAlone_manage(id,code,page){
    $.ajax({
        url: "/pms/projectChildManageIndex",
        type: "get",
        data: {"page":page,"type":"alone","fCode":code},
        dataType: "html",
        success:function(response){
            $("#content").html(response);
        },error:function(response){
            alert("查看失败");
        }
    });
}

function childAlone_detail(id,code,page){
    $.ajax({
        url: "/pms/projectChildDetailIndex",
        type: "get",
        data: {"page":page,"type":"alone","fCode":code},
        dataType: "html",
        success:function(response){
            $("#content").html(response);
        },error:function(response){
            alert("查看失败");
        }
    });
}
function comeBack(){
    $.ajax({
        url: "/pmsManager/manageQueryList",
        type: "get",
        dataType: "html",
        success:function(response){
            $("#content").html(response);
        },error:function(response){
            alert("查看失败");
        }
    });
}

function createChild(id,fCode){
    if($("#father").length != 0){
        $($("#father").get(0).parentElement.parentElement).remove();
    }
    var top = $("#code").get(0).parentElement.parentElement;
    $(top).before(' <div class="form-group"><label class="col-sm-2 control-label"> 父项目编号:</label><div class="col-md-3"><input type="hidden" id="father" name="father" value="'+id+'"><input class="form-control" type="text" disabled value="'+fCode+'"></div></div>');
    modalChangeToChild();
    $("#modal-title").text("子项目新增");
    clearform();
    $("#modal-normal").modal("show");
    $("#submit_btn_pro").unbind();
    $("#submit_btn_pro").on("click",add_project);
}

function modalChangeToChild(){
    $("#projectCode").text("子项目编号:");
    $("#code").attr("placeholder","请输入子项目编号..");
    $("#projectName").text("子项目名");
    $("#name").attr("placeholder","请输入子项目名..");
    $("#peizhi").text("子项目进度配置");
    $("#projectType").text("子项目类型:");
    $("#projectRisk").text("子项目风险等级:");
    $("#pms_dangous_level").attr("placeholder","请输入子项目风险等级..");
    $("#pms_level").attr("placeholder","请输入子项目优先级..");
    $("#projectProperty").text("子项目性质:");
    $("#projectHManager").text("子项目行方管理员:");
    $("#projectManager").text("子项目管理员:");
    for(var i=0;i<$("#pms_pro_type_id option").length;i++){
        if($("#pms_pro_type_id option")[i].innerText == "混合型项目"){
            $($("#pms_pro_type_id option")[i]).css("display","none");
            break;
        }
    }
    for(var i=0;i<$("#pms_project_property_id option").length;i++){
        if($("#pms_project_property_id option")[i].innerText == "混合项目"){
            $($("#pms_project_property_id option")[i]).css("display","none");
            break;
        }
    }
}
function modalChangeToProject(){
    $("#projectCode").text("项目编号:");
    $("#code").attr("placeholder","请输入项目编号..");
    $("#projectName").text("项目名");
    $("#name").attr("placeholder","请输入项目名..");
    $("#peizhi").text("项目进度配置");
    $("#projectType").text("项目类型:");
    $("#projectRisk").text("项目风险等级:");
    $("#pms_dangous_level").attr("placeholder","请输入项目风险等级..");
    $("#pms_level").attr("placeholder","请输入项目优先级..");
    $("#projectProperty").text("项目性质:");
    $("#projectHManager").text("项目行方管理员:");
    $("#projectManager").text("项目管理员:");
    for(var i=0;i<$("#pms_pro_type_id option").length;i++){
        if($("#pms_pro_type_id option")[i].innerText == "混合型项目"){
            $($("#pms_pro_type_id option")[i]).css("display","block");
            break;
        }
    }
    for(var i=0;i<$("#pms_project_property_id option").length;i++){
        if($("#pms_project_property_id option")[i].innerText == "混合项目"){
            $($("#pms_project_property_id option")[i]).css("display","block");
            break;
        }
    }
}


function details_plan(obj,page,id,type){
     var data = {'id':id,'type':type,'page':page};
     $.ajax({
         url: "/pmsManagerWork/projectPlanDetailHandler",
         type: "post",
         dataType: "html",
         data: data,
         async: false,
         success: function (response) {
            $('#content').html(response);
         },
         error: function (response) {
            alert("操作失败");
         }
     });
}

function showNextInfo(org_name_id,user_select_name_id){
    $("#"+user_select_name_id).val();
    $("#"+user_select_name_id+" option:gt(0)").remove();
    if($.trim($("#"+org_name_id).val()) == ""){
        $("#"+user_select_name_id).attr("disabled","disabled");
    }else{
        $("#"+user_select_name_id).removeAttr("disabled");
        $.ajax({
            url: '/pmsManager/showNextInfo',
            type: 'post',
            data: {'org_id':$("#"+org_name_id).val()},
            dataType: 'json',
            success:function(response){
                var users = response.users;
                for(var i=0;i<users.length;i++){
                    $("#"+user_select_name_id+" option:eq(0)").after('<option value="'+users[i]['id']+'">'+users[i]['name']+'</option>');
                }
            },error:function(response){
                alert("获取行方管理人信息失败");
            }
        }); 
    }
}

function showStopInfo(id){
    $("#list").empty();
    $.ajax({
        url: '/pmsManager/stopProjectInfo',
        type: 'post',
        data: {"id":id},
        dataType: 'json',
        success:function(response){
            if(response.length == 0){
                $("#list").html('<li style="text-align:center;"><span style="line-height:30px;border-radius:3px;padding:0 15px;background-color: #e2e2e2;font-size: 14px;display: inline-block;">无关闭原因</span></li>');
            }else{
                $("#list").html('<li class="list-group-item"><h5 class="list-group-item-text" style="word-wrap:break-word;word-break:break-all;"><span style="color:#5d9cec;">关闭原因:</span></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+response[0]['mes']+'</h5><p class="list-group-item-heading text-right">'+response[0]['time']+'&nbsp;&nbsp;'+response[0]['user_name']+'</p></li>');
            }
            $("#showChange-modal").modal("show");
        },error:function(response){
            alert("查看失败");
        }
    });
}
