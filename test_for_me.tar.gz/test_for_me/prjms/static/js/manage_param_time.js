// 查询时间
function search_time() {
    init_time_DataTables();
    return false;
}

// 点击修改时间按钮
function click_time_alter(id) {
    $("#time_form")[0].reset();
    clearform();
    $("#modal-title").text("时间修改");
    $("#code").attr("disabled",true);
    $("#name").attr("disabled",true);
    fill_form_time(id);
    $("#modal-normal").modal("show");
    $("#submit_btn").unbind();
    $("#submit_btn").on("click", function () {
        alter_time(id);
    });
}

// 修改时间信息
function alter_time(id) {
    $("#time_form").bootstrapValidator('validate');
    var bv = $("#time_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        //alert("验证失败");
        return false;
    } else {
        var data = $("#time_form").serializeArray();
        data = objectifyForm(data);
        data['id'] = id;
        //data['global_menu_id'] = $("#global_menu_id").val();
        $.ajax({
            url: "/paramManage/manageParamList-timeToUpdate",
            type: "post",
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
                if (response.result) {
                    $("#modal-normal").modal("hide");
                    search_time();
                }
            },
            error: function () {
                alert("修改时间信息失败");
            }
        });

    }
}

// 填充数据
function fill_form_time(id) {
    $.ajax({
        url: "/paramManage/manageParamList-timeBfUpdate",
        type: "post",
        dateType: "json",
        data: {
            'id': id
        },
        success: function (response) {
            for (var key in response) {
                $("#" + key).val(response[key]);
            }
            return false;
        },
        error: function (response) {
            alert("获取数据失败");
        }
    });
}


// 表单数据序列化
function objectifyForm(formArray) { //serialize data function

    var returnArray = {};
    for (var i = 0; i < formArray.length; i++) {
        returnArray[formArray[i]['name']] = formArray[i]['value'];
    }
    return returnArray;
}

// 表单验证清空数据和样式
function clearform() {
    $("small").css('display', 'none');
    $("#time_form")[0].reset();
    $("i").remove(".glyphicon-remove");
    $("i").remove(".glyphicon-ok");
    $("div").removeClass("has-error");
    $("div").removeClass("has-success");
}
