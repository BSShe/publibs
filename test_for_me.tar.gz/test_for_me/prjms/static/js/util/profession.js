function winprint(){
    simpleheader.style.display = "none";
    explain.style.display = "block";
    explainheader.style.display = "block";
    window.print();
}


function GetQueryString(name)
{
     var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
     var r = window.location.search.substr(1).match(reg);
     if(r!=null)return  unescape(r[2]); return null;
}

function AddSearchInfo(url) {
    return url + '&search_info_id=' + GetQueryString("id");
}

// 查看担保-贷款
function showLoanAssureeInfo(loancardno,financecode,loancontractcode){
    var url="/zxqz/company_report_detail/reportInfoWindows.do?reqFlag=2&loancardno="+loancardno+"&blockcode=ASSUREEINFO_00&loankind=1&financecode="+financecode+"&loancontractcode="+loancontractcode;
    url = AddSearchInfo(url);
//    window.open(url,"","dialogWidth=800px;dialogHeight=600px");
    window.open(url,"","top=100,left=100,width=700,height=400,scrollbars=yes,toolbar=no,location=no,menubar=no,status=no,resizable=yes,directories=no");
}

// 查看担保-贸易融资
function showFinancingAssureeInfo(loancardno,financecode,loancontractcode){
    var url="/zxqz/company_report_detail/reportInfoWindows.do?reqFlag=2&loancardno="+loancardno+"&blockcode=ASSUREEINFO_00&loankind=4&financecode="+financecode+"&loancontractcode="+loancontractcode;
    url = AddSearchInfo(url);
//    window.open(url,"","dialogWidth=800px;dialogHeight=600px");
    window.open(url,"","top=100,left=100,width=700,height=400,scrollbars=yes,toolbar=no,location=no,menubar=no,status=no,resizable=yes,directories=no");
}

// 查看担保-保理
function showAssureeAssureeInfo(loancardno,financecode,loancontractcode){
    var url="/zxqz/company_report_detail/reportInfoWindows.do?reqFlag=2&loancardno="+loancardno+"&blockcode=ASSUREEINFO_00&loankind=2&financecode="+financecode+"&loancontractcode="+loancontractcode;
    url = AddSearchInfo(url);
//    window.open(url,"","dialogWidth=800px;dialogHeight=600px");
    window.open(url,"","top=100,left=100,width=700,height=400,scrollbars=yes,toolbar=no,location=no,menubar=no,status=no,resizable=yes,directories=no");
}

// 查看担保-信用证
    function showLetterAssureeInfo(loancardno,financecode,loancontractcode){
    var url="/zxqz/company_report_detail/reportInfoWindows.do?reqFlag=2&loancardno="+loancardno+"&blockcode=ASSUREEINFO_00&loankind=5&financecode="+financecode+"&loancontractcode="+loancontractcode;
    url = AddSearchInfo(url);
//    window.open(url,"","dialogWidth=800px;dialogHeight=600px");
    window.open(url,"","top=100,left=100,width=700,height=400,scrollbars=yes,toolbar=no,location=no,menubar=no,status=no,resizable=yes,directories=no");
}
    
// 查看担保-银行承兑汇票
function showPostalAssureeInfo(loancardno,financecode,loancontractcode){
    var url="/zxqz/company_report_detail/reportInfoWindows.do?reqFlag=2&loancardno="+loancardno+"&blockcode=ASSUREEINFO_00&loankind=7&financecode="+financecode+"&loancontractcode="+loancontractcode;
    url = AddSearchInfo(url);
//    window.open(url,"","dialogWidth=800px;dialogHeight=600px");
    window.open(url,"","top=100,left=100,width=700,height=400,scrollbars=yes,toolbar=no,location=no,menubar=no,status=no,resizable=yes,directories=no");
}

// 查看担保-保函
function showGuaranteeletterAssureeInfo(loancardno,financecode,loancontractcode){
    var url="/zxqz/company_report_detail/reportInfoWindows.do?reqFlag=2&loancardno="+loancardno+"&blockcode=ASSUREEINFO_00&loankind=6&financecode="+financecode+"&loancontractcode="+loancontractcode;
    url = AddSearchInfo(url);
//    window.open(url,"","dialogWidth=800px;dialogHeight=600px");
    window.open(url,"","top=100,left=100,width=700,height=400,scrollbars=yes,toolbar=no,location=no,menubar=no,status=no,resizable=yes,directories=no");
}
//查看贷款明细
function showLoanNor(){
    var obj = new Object();
    obj.name = document.getElementById("loanpaid").innerHTML;
    window.open('simplequery/profession/creditdetail.jsp',obj,"dialogWidth=800px;dialogHeight=600px");
    return;
}
//查看贸易融资明细
function showFinancingNor(){
    var obj = new Object();
    obj.name = document.getElementById("financingpaid").innerHTML;
    window.open('simplequery/profession/creditdetail.jsp',obj,"dialogWidth=800px;dialogHeight=600px");
    return;
}
//查看保理明细
function showAssureeNor(){
    var obj = new Object();
    obj.name = document.getElementById("assureepaid").innerHTML;
    window.open('simplequery/profession/creditdetail.jsp',obj,"dialogWidth=800px;dialogHeight=600px");
    return;
}
//查看承兑汇票明细
function showPostalNor(){
    var obj = new Object();
    obj.name = document.getElementById("postalpaid").innerHTML;
    window.open('simplequery/profession/creditdetail.jsp',obj,"dialogWidth=800px;dialogHeight=600px");
    return;
}
//查看信用证明细
function showLetterNor(){
    var obj = new Object();
    obj.name = document.getElementById("letterpaid").innerHTML;
    window.open('simplequery/profession/creditdetail.jsp',obj,"dialogWidth=800px;dialogHeight=600px");
    return;
}
//查看票据贴现明细
function showBillNor(){
    var obj = new Object();
    obj.name = document.getElementById("billpaid").innerHTML;
    window.open('simplequery/profession/creditdetail.jsp',obj,"dialogWidth=800px;dialogHeight=600px");
    return;
}

//查看保函明细
function showGuaranteeletterNor(){
    var obj = new Object();
    obj.name = document.getElementById("guaranteeletterpaid").innerHTML;
    window.open('simplequery/profession/creditdetail.jsp',obj,"dialogWidth=800px;dialogHeight=600px");
    return;
}
////////////////////////////////////查看展期弹出窗口///////////////////////////////////////////////////////////
//查看贷款展期
function showLoanExtensionInfo(loancardno,financecode,operid){
    var url="/zxqz/company_report_detail/reportInfoWindows.do?reqFlag=3&loancardno="+loancardno+"&blockcode=EXTENSION_01&financecode="+financecode+"&operid="+operid;
    url = AddSearchInfo(url);
    window.open(url,"","dialogWidth=800px;dialogHeight=600px");
//    window.open(url,"","top=100,left=100,width=700,height=400,scrollbars=yes,toolbar=no,location=no,menubar=no,status=no,resizable=yes,directories=no");
}
//查看贸易融资展期
function showFinancingExtensionInfo(loancardno,financecode,operid){
    var url="/zxqz/company_report_detail/reportInfoWindows.do?reqFlag=3&loancardno="+loancardno+"&blockcode=EXTENSION_02&financecode="+financecode+"&operid="+operid;
    url = AddSearchInfo(url);
//    window.open(url,"","dialogWidth=800px;dialogHeight=600px");
    window.open(url,"","top=100,left=100,width=700,height=400,scrollbars=yes,toolbar=no,location=no,menubar=no,status=no,resizable=yes,directories=no");
}
////////////////////////////////////弹出窗口查看公共信息历史24/////////////////////////////////////////////////////////
//社会
function showEntaccountPublicHistory(loancardcode,sistype,occureddate){
    var url="/zxqz/company_report_detail/showAllHistory.do?loancardno="+loancardcode+"&sistype="+sistype+"&occureddate="+occureddate+"&type=last24month&last24MonthType=entaccount";
    url = AddSearchInfo(url);
//    window.open(url,"","dialogWidth=800px;dialogHeight=600px");
    window.open(url,"","Width=800px;Height=600px,top=100px,left=200px,scrollbars=yes,toolbar=no,location=no,menubar=no,status=no,resizable=no,directories=no");
}
//住房
function showAccfundPublicHistory(loancardcode,occureddate){
    var url="/zxqz/company_report_detail/showAllHistory.do?loancardno="+loancardcode+"&occureddate="+occureddate+"&type=last24month&last24MonthType=accfund";
    url = AddSearchInfo(url);
//    window.open(url,"","dialogWidth=800px;dialogHeight=600px");
    window.open(url,"","Width=800px;Height=600px,top=100px,left=200px,scrollbars=yes,toolbar=no,location=no,menubar=no,status=no,resizable=no,directories=no");
}
//缴费
function showPublicPublicHistory(areacode,entaccountname,businessmancode,sistype, payinfotype,censusDate){
    var url="/zxqz/company_report_detail/showAllHistory.do?areacode="+areacode+"&sistype="+sistype+"&entaccountname="+entaccountname+"&type=last24month&last24MonthType=public&businessmancode="+businessmancode+ "&payinfotype="+payinfotype+"&censusDate="+censusDate;
    url = AddSearchInfo(url);
//    window.open(url,"","dialogWidth=800px;dialogHeight=600px");
    window.open(url,"","Width=800px;Height=600px,top=100px,left=200px,scrollbars=yes,toolbar=no,location=no,menubar=no,status=no,resizable=no,directories=no");
}


//未结清正常票据贴现明细
function showBillDetail(arg){
    var searchreason = document.getElementById("searchReason").value;
    var searchreasoncode = document.getElementById("searchReasonCode").value;
    var editiontype = document.getElementById("reportcode").value;
    var creditcode = document.getElementById("creditcode").value;
    var reportCode = document.getElementById("reportcode").value;
    var loancardcode= document.getElementById("loancardcode").value;
    var obj = new Object();
    var url = "/zxqz/company_report_detail/includeNormal.do?loancardcode="+loancardcode+"&reportcode="+reportCode+"&kindType=3"+"&source=1"+"&toporg="+arg;
    url = AddSearchInfo(url);
    window.open(url,"","dialogWidth=800px;dialogHeight=600px");
}
//未结清正常承兑汇票明细
function showPostalDetail(arg){
    var searchreason = document.getElementById("searchReason").value;
    var searchreasoncode = document.getElementById("searchReasonCode").value;
    var editiontype = document.getElementById("reportcode").value;
    var creditcode = document.getElementById("creditcode").value;
    var reportCode = document.getElementById("reportcode").value;
    var loancardcode= document.getElementById("loancardcode").value;
    var obj = new Object();
    var url = "/zxqz/company_report_detail/includeNormal.do?loancardcode="+loancardcode+"&reportcode="+reportCode+"&kindType=7"+"&source=1"+"&toporg="+arg;
    url = AddSearchInfo(url);
    window.open(url,"","dialogWidth=800px;dialogHeight=600px");
}
//未结清正常信用证明细
function showLetterDetail(arg){
    var searchreason = document.getElementById("searchReason").value;
    var searchreasoncode = document.getElementById("searchReasonCode").value;
    var editiontype = document.getElementById("reportcode").value;
    var creditcode = document.getElementById("creditcode").value;
    var reportCode = document.getElementById("reportcode").value;
    var loancardcode= document.getElementById("loancardcode").value;
    // window.open("/zxqz/company_report_detail/includeNormal.do?loancardcode="+loancardcode+"&reportcode="+reportCode+"&kindType=5"+"&source=1"+"&toporg="+arg,obj,"dialogWidth=800px;dialogHeight=600px");
    var url = "/zxqz/company_report_detail/includeNormal.do?loancardcode="+loancardcode+"&reportcode="+reportCode+"&kindType=5"+"&source=1"+"&toporg="+arg;
    url = AddSearchInfo(url);
    window.open(url,"","dialogWidth=800px;dialogHeight=600px");
}
//未结清正常保函明细
function showGuaranteeletterDetail(arg){
    var searchreason = document.getElementById("searchReason").value;
    var searchreasoncode = document.getElementById("searchReasonCode").value;
    var editiontype = document.getElementById("reportcode").value;
    var creditcode = document.getElementById("creditcode").value;
    var reportCode = document.getElementById("reportcode").value;
    var loancardcode= document.getElementById("loancardcode").value;
    var url = "/zxqz/company_report_detail/includeNormal.do?loancardcode="+loancardcode+"&reportcode="+reportCode+"&kindType=6"+"&source=1"+"&toporg="+arg;
    url = AddSearchInfo(url);
    window.open(url,"","dialogWidth=800px;dialogHeight=600px");
}
//查看垫款
function showPackInfoWindow(loancardno,type,operationcode,loankindcode,financecode){
    var url="/zxqz/company_report_detail/showAllHistory.do?loancardno="+loancardno+"&type="+type+"&id="+operationcode+"&loankindcode="+loankindcode+"&financecode="+financecode;
    url = AddSearchInfo(url);
//    window.open(url,"","dialogWidth=800px;dialogHeight=600px");
    window.open(url,"","Width=800px;Height=600px,top=100px,left=200px,scrollbars=yes,toolbar=no,location=no,menubar=no,status=no,resizable=no,directories=no");
}

//查看历史信息
function showHis(loancardno,financecode,loancontractcode,type,id,loankindcode){
    var searchreason = document.getElementById("searchReason").value;
    var searchreasoncode = document.getElementById("searchReasonCode").value;
    var editiontype = document.getElementById("reportcode").value;
    var creditcode = document.getElementById("creditcode").value;
    var reportCode = document.getElementById("reportcode").value;
    var loancardcode= document.getElementById("loancardcode").value;
    var url="/zxqz/company_report_detail/showAllHistory.do?loancardno="+loancardno+"&blockcode=ASSUREEINFO_00&loankindcode="+loankindcode+"&financecode="+financecode+"&loancontractcode="+loancontractcode+"&type="+type+"&id="+id+"&searchreason="+searchreason+"&searchreasoncode="+searchreasoncode+"&editiontype="+editiontype+"&creditcode="+creditcode;
    url = AddSearchInfo(url);
    window.open(url,"","Width=800px;Height=600px,top=100px,left=200px,scrollbars=yes,toolbar=no,location=no,menubar=no,status=no,resizable=no,directories=no");
}
function showWindows(loancardno,financecode,loancontractcode,type,id,loankindcode){
    var url="/zxqz/company_report_detail/showAllHistory.do?loancardno="+loancardno+"&blockcode=ASSUREEINFO_00&loankind="+loankindcode+"&financecode="+financecode+"&loancontractcode="+loancontractcode+"&type="+type+"&id="+id+"&loankindcode="+loankindcode;
    url = AddSearchInfo(url);
//    window.open(url,"","dialogWidth=800px;dialogHeight=600px");
    window.open(url,"","Width=800px;Height=600px,top=100px,left=200px,scrollbars=yes,toolbar=no,location=no,menubar=no,status=no,resizable=no,directories=no");
}
function showGuaWindow(loancardno,type,loancontractcode,toporg,kind){
    var url="/zxqz/company_report_detail/showAllHistory.do?loancardno="+loancardno+"&type="+type+"&id="+loancontractcode+"&toporg="+toporg+"&kind="+kind;
    url = AddSearchInfo(url);
//    window.open(url,"","dialogWidth=800px;dialogHeight=600px");
    window.open(url,"","Width=800px;Height=600px,top=100px,left=200px,scrollbars=yes,toolbar=no,location=no,menubar=no,status=no,resizable=no,directories=no");
}
function showReport(type,code,codeType){
    return;
}



// 查看信贷正常类明细
function showNormal(loancard,editiontyp,kindcode){
    var obj = new Object();
    window.open("includeNormal.do?loancardcode="+loancard+"&reportcode="+editiontyp+"&kindType="+kindcode+"&source=3","","dialogWidth=800px;dialogHeight=600px");
}
