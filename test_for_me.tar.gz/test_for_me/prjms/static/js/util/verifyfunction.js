function fileChange(target){
    //检测文件上传类型
    var imgName = document.all.file_data.value;
    var ext,idx;
    if (imgName == ''){
        document.all.submit_upload.disabled=true;
        alert('请选择需要上传的文件!');
        return;
    }else{
        idx = imgName.lastIndexOf(".");
        if (idx != -1){
            ext = imgName.substr(idx+1).toUpperCase();
            ext = ext.toLowerCase();
            if (ext != 'jpg' && ext != 'png' && ext != 'jpeg' && ext != 'gif' && ext != 'doc' && ext != 'docx' && ext != 'xls' && ext != 'xlsx' && ext != 'pdf'){
                document.all.submit_upload.disabled = true;
                alert("只能上传( .jpg | .png | .jpeg | .gif | .doc | .docx | .xls | .xlsx | .pdf )类型的文件!");
                return;
            }
        }else{
            document.all.submit_upload.disabled = true;
            alert("只能上传( .jpg | .png | .jpeg | .gif | .doc | .docx | .xls | .xlsx | .pdf )类型的文件!");
            return;
        }
    }
    document.all.submit_upload.disabled=false;

    ////检测上传文件大小
    //var isIE = /msie/i.test(navigator.userAgent) && !window.opera;
    //var fileSize = 0;
    //if (isIE && !target.files){
    //    var filePath = target.value;
    //    var fileSystem = new ActiveXObject("Scripting.FileSystemObject");
    //    var file = fileSystem.GetFile(filePath);
    //    fileSize = file.Size;
    //}else{
    //    fileSize = target.files[0].size;
    //}
    //var size = fileSize / 1024*1024;
    //var max_size = 200;
    //if (size>(1024*max_size)){
    //    document.all.submit_upload.disabled=true;
    //    alert("文件大小不能超过" + max_size + "KB");
    //}else{
    //    document.all.submit_upload.disabled=false;
    //}
}
