function search_supplier_evaluate() {
    init_supplier_evaluate_DataTables();
    return false;
}

// 点击修改供应商评价参数按钮
function click_supplier_evaluate_alter(id) {
    $("#supplier_evaluate_form")[0].reset();
    clearform();
    $("#modal-title").text("供应商评价参数修改");
    $("#code").attr("readonly","readonly");
    $("#name").attr("readonly","readonly");
    fill_form_supplier_evaluate(id);
    $("#modal-normal").modal("show");
    $("#submit_btn").unbind();
    $("#submit_btn").on("click", function () {
        alter_supplier_evaluate(id);
    });
}

// 修改供应商评价参数信息
function alter_supplier_evaluate(id) {
    $("#supplier_evaluate_form").bootstrapValidator('validate');
    var bv = $("#supplier_evaluate_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        //alert("验证失败");
        return false;
    } else {
        var data = $("#supplier_evaluate_form").serializeArray();
        data = objectifyForm(data);
        data['id'] = id;
        //data['global_menu_id'] = $("#global_menu_id").val();
        $.ajax({
            url: "/paramManage/manageParamList-supplier_evaluateToUpdate",
            type: "post",
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
                if (response.result) {
                    $("#modal-normal").modal("hide");
                    search_supplier_evaluate();
                }
            },
            error: function () {
                alert("修改供应商评价参数信息失败");
            }
        });

    }
}

// 填充数据
function fill_form_supplier_evaluate(id) {
    $.ajax({
        url: "/paramManage/manageParamList-supplier_evaluateBfUpdate",
        type: "post",
        dateType: "json",
        data: {
            'id': id
        },
        success: function (response) {
            for (var key in response) {
                $("#" + key).val(response[key]);
            }
            return false;
        },
        error: function (response) {
            alert("获取数据失败");
        }
    });
}

// 表单数据序列化
function objectifyForm(formArray) { //serialize data function
    var returnArray = {};
    for (var i = 0; i < formArray.length; i++) {
        returnArray[formArray[i]['name']] = formArray[i]['value'];
    }
    return returnArray;
}

// 表单验证清空数据和样式
function clearform() {
    $("small").css('display', 'none');
    $("#supplier_evaluate_form")[0].reset();
    $("i").remove(".glyphicon-remove");
    $("i").remove(".glyphicon-ok");
    $("div").removeClass("has-error");
    $("div").removeClass("has-success");
}
