function comeBackProPlan(page,type){
    if (type == "father"){
        url = "/pmsManagerPlan/manageQueryList";
    }
    else if (type == "child"){
        url = "/pms/projectChildDetailIndex";
    }
    $.ajax({
        url: url,
        type: "get",
        data: data = {"page":page},
        dataType: "html",
        async: false,
        success:function(response){
            $("#content").html(response);
        },
        error: function (response) {
            alert("查看失败");
        }
    });
}
