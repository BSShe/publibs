iJump();
function iJump(){
   var data = {"id":141};
   $.ajax({
        url: "/jumpToIndex",
        type: "get",
        dataType: "html",
        data: data,
        async: false,
        success: function (response) {
            $('#content').html(response);
        },
        error: function (response) {
            alert("获取主页失败！");
        }
   })
}
