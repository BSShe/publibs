// 查询人员
function search_users() {
    init_DataTables();
    return false;
}

// 点击人员新增按钮
function click_users_add() {
    $("#modal-normal").modal("show");
    $("#modal-title").text("人员新增");
    clearform();
    $("#no").attr("disabled",false);
    var nowDate = new Date().Format("yyyyMMdd");
    $("#st_date").val(nowDate);
    $("#submit_btn").unbind();
    $("#submit_btn").on("click", add_users);
}

// 增加人员
function add_users() {
    $("#user_form").bootstrapValidator('validate');
    var bv = $("#user_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        //alert("验证失败");
        return false;
    } else {
        var data = $("#user_form").serializeArray()
        data = objectifyForm(data);
        //data['global_menu_id'] = $("#global_menu_id").val();
        $.ajax({
            url: "/queryAndForms/manageFormsToAdd",
            type: "post",
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
                if (response.result) {
                    search_users();
                    $("#modal-normal").modal("hide");
                }
            },
            error: function (response) {
                alert("添加人员失败");
            }
        })
    }
}

// 点击修改人员按钮
function click_users_alter(id) {
    $("#user_form")[0].reset();
    clearform();
    $("#modal-title").text("人员修改");
    $("#no").attr("disabled",true);
    fill_form_users(id);
    $("#modal-normal").modal("show");
    $("#submit_btn").unbind();
    $("#submit_btn").on("click", function () {
        alter_users(id);
    });
}

// 修改人员信息
function alter_users(id) {
    $("#user_form").bootstrapValidator('validate');
    var bv = $("#user_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        //alert("验证失败");
        return false;
    } else {
        var data = $("#user_form").serializeArray();
        data = objectifyForm(data);
        data['id'] = id;
        //data['global_menu_id'] = $("#global_menu_id").val();
        $.ajax({
            url: "/queryAndForms/manageFormsToUpdate",
            type: "post",
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
                if (response.result) {
                    $("#modal-normal").modal("hide");
                    search_users();
                }
            },
            error: function () {
                alert("修改人员信息失败");
            }
        });

    }
}

function del_users(id) {
    var msg = "您真的确定要删除该人员？\n\n请确认！";
    if (confirm(msg) === false) {
        return false;
    }
    var user_id = id;
    var surl = '/queryAndForms/manageFormsDel';
    var data = {};
    data['id'] = user_id;
    data['global_menu_id'] = $("#global_menu_id").val();
    $.ajax({
        type: 'post',
        url: surl,
        data: data,
        dataType: 'json',
        success: function (data) {
            if (data.result) {
                init_DataTables();
            } else {
                alert("删除失败");
            }
        },
        error: function (error_msg) {
            alert("数据请求失败!");
        }
    });
}


// 点击查看人员按钮
function showUserProUser(id) {
    $("#modal-normal-userList").modal("show");
    $("#modal-title-userList").text("人员列表");
    var nowDate = new Date().Format("yyyyMMdd");
    $("#user_proList_user_id").val(id)
    init_user_proList_DataTables();
    //$("#submit_btn").unbind();
    //$("#submit_btn").on("click", add_orgs);
}

//
function xxxxxxx() {
    $("#user_form").bootstrapValidator('validate');
    var bv = $("#user_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        //alert("验证失败");
        return false;
    } else {
        var data = $("#user_form").serializeArray()
        data = objectifyForm(data);
        //data['global_menu_id'] = $("#global_menu_id").val();
        $.ajax({
            url: "/queryAndForms/manageOrgToAdd",
            type: "post",
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
                if (response.result) {
                    search_orgs();
                    $("#modal-normal").modal("hide");
                }
            },
            error: function (response) {
                alert("添加人员失败");
            }
        })
    }
}
// 填充数据
function fill_form_users(id) {
    $.ajax({
        url: "/queryAndForms/manageFormsBfUpdate",
        type: "post",
        dateType: "json",
        data: {
            'id': id
        },
        success: function (response) {
            for (var key in response) {
                $("#" + key).val(response[key]);
            }
            return false;
        },
        error: function (response) {
            alert("获取数据失败");
        }
    });
}


// 表单数据序列化
function objectifyForm(formArray) { //serialize data function

    var returnArray = {};
    for (var i = 0; i < formArray.length; i++) {
        returnArray[formArray[i]['name']] = formArray[i]['value'];
    }
    return returnArray;
}

// 表单验证清空数据和样式
function clearform() {
    $("small").css('display', 'none');
    $("#user_form")[0].reset();
    $("i").remove(".glyphicon-remove");
    $("i").remove(".glyphicon-ok");
    $("div").removeClass("has-error");
    $("div").removeClass("has-success");
}
