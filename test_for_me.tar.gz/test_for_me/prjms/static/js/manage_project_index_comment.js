function click_project_add() {
    $("#modal-normal").modal("show");
    $("#modal-title").text("项目新增");
    clearform();
    $("#submit_btn_pro").unbind();
    $("#submit_btn_pro").on("click",add_project);
}

function add_project(){
    $("#user_form").bootstrapValidator('validate');
    var bv = $("#user_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        alert("验证失败");
        return false;
    } else {
        var data = $("#user_form").serializeArray()
        data = objectifyForm(data);
        data['status'] = 0;
        $.ajax({
            url: "/pmsComment/manageQueryToAdd",
            type: "post",
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
                alert (response.result);
                if (response.result == 'true'){
                var body = '';
                for (i=0;i<=response.data.length;i++){
                    body = body +'<tr>';
                    for ( key in response.data[i]){
                         body = body + '<td>';
                         body = body + response.data[i][key];
                         body = body + '</td>'
                    }
                    body = body +'</tr>';
                    $('#comment_list').html(body);
                }
                }
            },
            error: function (response) {
                alert("项目评价失败");
            }
        })
    }
}


function showCommentDetail(page,id,type){
        var data = {'page':page,'id':id,'type':type};
        $.ajax({
            url: "/pmsComment/projectCommentHandler",
            type: "post",
            dataType: "html",
            data: data,
            async: false,
            success: function (response) {
                    $('#content').html(response)
            },
            error: function (response) {
                    alert("查看详情失败");
            }
        })

}


function search_users(){

}
function clearform() {
}


function objectifyForm(formArray) { //serialize data function
    var returnArray = {};
    for (var i = 0; i < formArray.length; i++) {
        returnArray[formArray[i]['name']] = formArray[i]['value'];
    }
    return returnArray;
}

