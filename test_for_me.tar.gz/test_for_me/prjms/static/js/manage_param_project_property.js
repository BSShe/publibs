// 查询项目性质
function search_project_property() {
    init_project_property_DataTables();
    return false;
}

// 点击项目性质新增按钮
function click_project_property_add() {
    $("#modal-normal").modal("show");
    $("#modal-title").text("新增项目性质");
    clearform();
    $("#id").hide();
    $("#code").attr("disabled",false);
    $("#submit_btn").unbind();
    $("#submit_btn").on("click", add_project_property);
}

// 增加项目性质
function add_project_property() {
    $("#project_property_form").bootstrapValidator('validate');
    var bv = $("#project_property_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        //alert("验证失败");
        return false;
    } else {
        var data = $("#project_property_form").serializeArray()
        data = objectifyForm(data);
        //data['global_menu_id'] = $("#global_menu_id").val();
        $.ajax({
            url: "/paramManage/manageParamList-project_propertyToAdd",
            type: "post",
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
                if (response.result) {
                    search_project_property();
                    $("#modal-normal").modal("hide");
                }
            },
            error: function (response) {
                alert("添加项目性质失败");
            }
        })
    }
}

// 点击修改项目性质按钮
function click_project_property_alter(id) {
    $("#project_property_form")[0].reset();
    clearform();
    $("#modal-title").text("项目性质修改");
    $("#code").attr("disabled",true);
    fill_form_project_property(id);
    $("#modal-normal").modal("show");
    $("#submit_btn").unbind();
    $("#submit_btn").on("click", function () {
        alter_project_property(id);
    });
}

// 修改项目性质信息
function alter_project_property(id) {
    $("#project_property_form").bootstrapValidator('validate');
    var bv = $("#project_property_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        //alert("验证失败");
        return false;
    } else {
        var data = $("#project_property_form").serializeArray();
        data = objectifyForm(data);
        data['id'] = id;
        //data['global_menu_id'] = $("#global_menu_id").val();
        $.ajax({
            url: "/paramManage/manageParamList-project_propertyToUpdate",
            type: "post",
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
                if (response.result) {
                    $("#modal-normal").modal("hide");
                    search_project_property();
                }
            },
            error: function () {
                alert("修改项目性质信息失败");
            }
        });

    }
}

function del_project_property(id) {
    var msg = "您真的确定要删除该项目性质？\n\n请确认！";
    if (confirm(msg) === false) {
        return false;
    }
    var project_property_id = id;
    var surl = '/paramManage/manageParamList-project_propertyDel';
    var data = {};
    data['id'] = project_property_id;
    $.ajax({
        type: 'post',
        url: surl,
        data: data,
        dataType: 'json',
        success: function (data) {
            console.log(data)
            if (data.result == 'true') {
                init_project_property_DataTables();
            } else {
                alert(data.msg);
            }
        },
        error: function (error_msg) {
            alert("数据请求失败!");
        }
    });
}

//
function xxxxxxx() {
    $("#project_property_form").bootstrapValidator('validate');
    var bv = $("#project_property_form").data("bootstrapValidator").isValid();
    if (bv === false) {
        //alert("验证失败");
        return false;
    } else {
        var data = $("#project_property_form").serializeArray()
        data = objectifyForm(data);
        //data['global_menu_id'] = $("#global_menu_id").val();
        $.ajax({
            url: "/paramManage/manageOrgToAdd",
            type: "post",
            dataType: "json",
            data: data,
            async: false,
            success: function (response) {
                if (response.result) {
                    search_orgs();
                    $("#modal-normal").modal("hide");
                }
            },
            error: function (response) {
                alert("添加项目性质失败");
            }
        })
    }
}
// 填充数据
function fill_form_project_property(id) {
    $.ajax({
        url: "/paramManage/manageParamList-project_propertyBfUpdate",
        type: "post",
        dateType: "json",
        data: {
            'id': id
        },
        success: function (response) {
            for (var key in response) {
                $("#" + key).val(response[key]);
            }
            return false;
        },
        error: function (response) {
            alert("获取数据失败");
        }
    });
}


// 表单数据序列化
function objectifyForm(formArray) { //serialize data function

    var returnArray = {};
    for (var i = 0; i < formArray.length; i++) {
        returnArray[formArray[i]['name']] = formArray[i]['value'];
    }
    return returnArray;
}

// 表单验证清空数据和样式
function clearform() {
    $("small").css('display', 'none');
    $("#project_property_form")[0].reset();
    $("i").remove(".glyphicon-remove");
    $("i").remove(".glyphicon-ok");
    $("div").removeClass("has-error");
    $("div").removeClass("has-success");
}
