$(function(){
    $('[data-toggle="tooltip"]').tooltip();
    $("[data-toggle='popover']").popover();
});
var childChart = $("#childChart").get(0).getContext("2d");
var tChildChart=new Chart(childChart,{
    type:"doughnut",
    data:{
        labels:["已完成阶段数","未完成阶段数"],
        datasets:[{
            data:[],
            backgroundColor:["#00FF00","#FF0000"],
        }],
    },
    options:{
        tooltips:{
            enabled:true,
        },
        legend:{
            display:true,
            position:"right",
            labels:{
                boxWidth:10,
            },
        },
    },
});
$(".wrapper").ready(function(){
    $.ajax({
        url:"/pms/singleProChartInfo",
        type:"post",
        data:{"id":$("#id").val()},
        dataType:"json",
        success:function(response){
            $("#jihua").attr("data-original-title",response["jihua"]+"%");
            $("#jihua div").animate({width:response["jihua"]+"%"});
            $("#shiji").attr("data-original-title",response["shiji"]+"%");
            $("#shiji div").animate({width:response["shiji"]+"%"});
            $("#total").attr("data-original-title",response["totalWorkLoad"]+"人天");
            $("#total div").animate({width:"100%"});
            $("#milestone").attr("data-original-title",response["milestoneWorkLoad"]+"人天");
            $("#milestone div").animate({width:response["milestoneWorkLoad"]/response["totalWorkLoad"]*100+"%"});
            $("#real").attr("data-original-title",response["realWorkLoad"]+"人天");
            $("#real div").animate({width:response["realWorkLoad"]/response["totalWorkLoad"]*100+"%"});
            tChildChart.data.datasets[0].data.push(response['finish_dev']);
            tChildChart.data.datasets[0].data.push(response['undo_dev']);
            tChildChart.update();
        },error:function(response){
            alert("初始化数据失败");
        }
    });
});
