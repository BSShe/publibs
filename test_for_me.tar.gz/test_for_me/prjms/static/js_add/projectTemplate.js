function finishStage(dev_id,obj){
    $.ajax({
        url: '/pmsManager/checkPlanTime',
        type: 'post',
        data: {'dev_id':dev_id},
        dataType: 'json',
        success:function(response){
            var len = response.length;
            if(len != 0){
                if(len == 1){
                    if(response[0] == 'p_start_date'){
                        alert('未安排阶段预计开始时间，请前往综合管理安排具体时间再完成此进度');
                        return;
                    }else{
                        alert('未安排阶段预计结束时间，请前往综合管理安排具体时间再完成此进度');
                        return;
                    }
                }else{
                    alert('未安排阶段预计时间，请前往综合管理安排具体时间再完成此进度');
                    return;
                }
            }else{
                makeFinishStage(dev_id,obj,response);
            }
        },error:function(response){
            alert('检测计划安排时间失败');
        }
    });
}

function makeFinishStage(dev_id,obj,checkTime){
    $.ajax({
        url: "/pmsManager/projectFinishStage",
        data: {'id':$("#id").val(),"dev_id":dev_id,"checkTime":JSON.stringify(checkTime)},
        type: "POST",
        dataType: "json",
        success:function(response){
            if(response.status == 1){
                alert("状态改变成功!");
                $(obj).remove();
            }else if(response.status == 0){
                alert("无权限做出此操作");
            }else{
                alert("状态改变失败!");
            }
        },error:function(response){
            alert("状态改变失败!");
        }
    });
}
//下载模版
function downloadTemplate(dev_id){
    $.ajax({
        url: "/pmsManager/projectTemplateCheck",
        type: "POST",
        data: {"dev_id":dev_id},
        dataType: "json",
        success:function(response){
            if(response.status == 1){
                html = '';
                var result = response.result;
                for(var i=0;i<result.length;i++){
                    if(i==0){
                        html = html + '<label><input type="radio" name="template" checked value="'+result[i]["url"]+'"></input>'+result[i]['name']+'</label>';
                    }else{
                        html = html + '<br><label><input type="radio" name="template" value="'+result[i]["url"]+'"></input>'+result[i]['name']+'</label>';
                    }
                }
                $("#templateChoose").html(html);
                $("#myModal").modal("show");
            }else{
                alert("暂未上传模板！");
            }
        },error:function(response){
            alert("模板下载失败");
        }
    });
}
//编辑按钮
function projectTextChangeBtn(dev_id,dev_child_id,code){
     var page_text = $('#'+code+'Area');
     page_text.removeAttr('disabled');
}
//提交
function projectTextAddBtn(dev_id,dev_child_id,code){
     var page_text = $('#'+code+'Area');
     url = '/pmsManager/ProjectChildFaildSubmitHandler';
     data = {'dev_id':dev_id,'dev_child_id':dev_child_id,'data':page_text.val(),'type':code}
     $.ajax({
        url:url,
        type:'POST',
        dataType:'Json',
        data:data,
        async:false,
        success:function(response){
             page_text.attr('disabled','true');
             alert('提交成功!');
        },
        error:function(response){
             alert('提交失败！');
        }          
     });     
     
}
function downloadFile(url,fileName){
    var form=document.createElement("form");
    form.action="/pmsManager/projectFileDownload";
    form.method="POST";
    form.style.display="none";
    var input=document.createElement("input");
    input.name="url";
    input.value=url;
    form.appendChild(input);
    var input1=document.createElement("input");
    input1.name="fileName";
    input1.value=fileName;
    form.appendChild(input1);
    document.body.appendChild(form);
    form.submit();
}

function deleteFile(id,url,event){
    $.ajax({
        url: "/pmsManager/projectFileDelete",
        type: "post",
        data: {"id":id,"url":url},
        dataType: "json",
        success:function(response){
            if(response.status == 1){
                $(event.parentNode).prev().remove();
                $(event.parentNode).remove();
                alert("删除成功");
            }else{
                alert("删除失败");
            }
        },error:function(response){
            alert("删除失败");
        }
    });
}

function previewFile(url){
    $.ajax({
        url: "/pmsManager/projectFilePreview",
        type: "post",
        data: {"url":url},
        dataType: "html",
        success:function(response){
            $('#content').html(response);
        },error:function(response){
            alert("预览失败");
        }
    }); 
}

function previewT(){
    var url = $("#templateChoose :radio:checked").val();
    url = "./static" + url.split('/static')[1]    
    $.ajax({
        url: "/pmsManager/projectFilePreview",
        type: "post",
        data: {"url":url},
        dataType: "html",
        success:function(response){
            $("#myModal").on('hidden.bs.modal',function(){
                $('#content').html(response);
            });
            $("#myModal").modal("hide");
        },error:function(response){
            alert("预览失败");
        }
    });
}

function sendFile(dev_id,stage_code,code,event){
    console.log(event);
    var fileChoose = event.parentNode.parentNode.children[0];
    var value = $(fileChoose).val();
    if($.trim(value) == ""){
        alert("请选择文件");
        return;
    }else{
        var file=$(fileChoose)[0].files[0];
        var showName = event.parentNode.parentNode.children[2];
        var progress = event.parentNode.parentNode.children[3];
        var mainProgress = progress.children[0];
        $(showName).css("display","none");
        $(progress).css("display","block");
        $(mainProgress).text("0%");
        startToUpload(file,1,showName,progress,mainProgress,dev_id,stage_code,code,$(showName).val(),'');
    }
}

function openFileChoose(event){
    var fileChoose = event.parentNode.parentNode.children[0];
    $(fileChoose).bind('change',showFileName);
    fileChoose.click();
}
function showFileName(event){
    var fileName = $(event.target).val().split("\\");
    $(event.target.nextElementSibling.nextElementSibling).val(fileName[fileName.length-1]);
    $(event.target).unbind('change',showFileName);
}

function startToUpload(file,num,showName,progress,mainProgress,dev_id,stage_code,code,fileName,fileId){
    var formData=new FormData();
    var blockSize= 1024*1024*2;
    var blockNum=Math.ceil(file.size / blockSize);
    var nextSize= Math.min(num * blockSize,file.size);
    var fileData= file.slice((num-1)*blockSize,nextSize);
    formData.append("file",fileData);
    formData.append("fileName",fileName);
    formData.append("num",num);
    formData.append("dev_id",dev_id);
    formData.append("stage_code",stage_code);
    formData.append("code",code);
    formData.append("fileId",fileId);
    $.ajax({
        url: "/pmsManager/projectFileUpload",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function(response){
            $(mainProgress).css("width",(num*100)/blockNum +"%");
            $(mainProgress).text(((num*100)/blockNum).toFixed(2) +"%");
            if(nextSize>=file.size){
                alert("上传成功");
                $(showName).css("display","block");
                $(progress).css("display","none");
                $(mainProgress).css("width","0%");
                $(showName.parentNode).after('<hr /><div style="overflow:hidden;"><p style="float:left;">'+fileName+'</p><br><button type="button" class="btn btn-danger" onclick=downloadFile("'+response.url+'","'+fileName+'") style="float:right">文档下载</button><button type="button" class="btn btn-danger" onclick=deleteFile("'+response.id+'","'+response.url+'",this) style="float:right;margin-right:10px;">删除</button><button type="button" class="btn btn-danger" onclick=previewFile("'+response.url+'") style="float:right;margin-right:10px;">文件预览</button></div>');
                return;
            }
            alert(response.id);
            startToUpload(file,num+1,showName,progress,mainProgress,dev_id,stage_code,code,fileName,response.id);
        },error:function(response){
            alert("上传失败");
            $(showName).css("display","block");
            $(progress).css("display","none");
            $(mainProgress).css("width","0%");
        }
    });
}

function downloadT(){
    var url = $("#templateChoose :radio:checked").val();
    if(url == ""){
        alert("请选择");
        return;
    }
    var form=document.createElement("form");
    form.action="/pmsManager/projectTemplateDownload";
    form.method="POST";
    form.style.display="none";
    var input=document.createElement("input");
    input.name="url";
    input.value=url;
    form.appendChild(input);
    document.body.appendChild(form);
    form.submit();
    $("#myModal").modal("hide");
}
