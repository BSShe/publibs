$(function(){
    $('[data-toggle="tooltip"]').tooltip();
    $("[data-toggle='popover']").popover();
});
var singleStage  = $("#singleStage").get(0).getContext("2d");
var personFrom  = $("#personFrom").get(0).getContext("2d");
var tSingleStage=new Chart(singleStage,{
    type:"doughnut",
    data:{
        labels:["已完成阶段","未完成阶段"],
        datasets:[{
            data:[],
            backgroundColor:["#e7554b","#f4a259"],
        }],
    },
    options:{
        tooltips:{
            enabled:true,
        },
        legend:{
            display:true,
            position:"right",
            labels:{
                boxWidth:10,
            },
        },
    },
});
var tpersonFrom=new Chart(personFrom,{
    type:"doughnut",
    data:{
        labels:["外包机构","管理部门","需求部门","研发部门","测试部门","技术支持部门"],
        datasets:[{
            data:[],
            backgroundColor:["#e7554b","#f4a259","#8cb369","#f4e285","#5b8e7d","#d7f9f1"],
        }],
    },
    options:{
        tooltips:{
            enabled:true,
        },
        legend:{
            display:true,
            position:"right",
            labels:{
                boxWidth:10,
            },
        },
    },
});
$(".wrapper").ready(function(){
    $.ajax({
        url:"/pms/singleProChartInfo",
        type:"post",
        data:{"id":$("#id").val()},
        dataType:"json",
        success:function(response){
            $("#totalman").attr("data-original-title",(response['total'])+"人");
            $("#totalman div").animate({width:"100%"});
            $("#zihang").attr("data-original-title",(response['own'])+"人");
            $("#zihang div").animate({width:(response['own']/response['total']*100)+"%"});
            $("#waibao").attr("data-original-title",(response['total'] - response['own'])+"人");
            $("#waibao div").animate({width:((response['total'] - response['own'])/response['total']*100)+"%"});
            $("#jihua").attr("data-original-title",response["jihua"]+"%");
            $("#jihua div").animate({width:response["jihua"]+"%"});
            $("#shiji").attr("data-original-title",response["shiji"]+"%");
            $("#shiji div").animate({width:response["shiji"]+"%"});
            $("#total").attr("data-original-title",response["totalWorkLoad"]+"人天");
            $("#total div").animate({width:"100%"});
            $("#milestone").attr("data-original-title",response["milestoneWorkLoad"]+"人天");
            $("#milestone div").animate({width:response["milestoneWorkLoad"]/response["totalWorkLoad"]*100+"%"});
            $("#real").attr("data-original-title",response["realWorkLoad"]+"人天");
            $("#real div").animate({width:response["realWorkLoad"]/response["totalWorkLoad"]*100+"%"});
            tSingleStage.data.datasets[0].data.push(response['finish_dev']);
            tSingleStage.data.datasets[0].data.push(response['undo_dev']);
            tSingleStage.update();
            for (var i = 0;i < 6;i++){
                tpersonFrom.data.datasets[0].data.push(response[i+'']);
            }
            tpersonFrom.update();
        },error:function(response){
            alert("初始化数据失败");
        }
    });
});
function comeBackProReport(page){
    var data = {'page':page};
    $.ajax({
        url: "/pms/projectManageReport",
        type: "get",
        dataType: "html",
        data: data,
        async: false,
        success: function (response) {
              $("#content").html(response);
        },
        error: function (response) {
                alert("返回失败");
        }
    });
}
