function details_info(type,page,arg,dev_id,code){
    var data={"id":arg,'dev_id':dev_id,'page':page,"type":type};
    if (code == '01'){
        url = '/pmsManager/project_plan_index-project_preparation';
    }else{
        url = '/pmsManager/projectChildFaildHandler'
    }
    console.info(type,page,arg,dev_id,code);
    $.ajax({
        url: url,
        type: "post",
        data: data,
        dataType: "html",
        async: false,
        success:function(response){
            $("#content").html(response);
        },
        error: function (response) {
            alert("查看失败");
        }
    });
} 

