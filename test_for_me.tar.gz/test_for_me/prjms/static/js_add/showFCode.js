function mouseover(event){
    $(event.target).css("background-color","rgb(84, 149, 231)");
    $(event.target).css("color","rgb(255, 255, 255)");
}

function mouseout(event){
    $(event.target).css("background-color","#fff");
    $(event.target).css("color","rgb(121, 121, 121)");
}

function click(event){
    $("#fCode").val(event.target.innerText);
    $("#list").css("display","none");
}

$("#fCode").keyup(function(){
    if($.trim($("#fCode").val())!=""){
        $.ajax({
            url:"/pms/projectGetFCodes",
            type:"post",
            data:{"data":$("#fCode").val()},
            dataType:"json",
            success:function(response){
                var data = response.data;
                var html = '';
                for(var i=0;i<data.length;i++){
                    html = html+'<li style="cursor:default;padding-left:10px;height:25px;line-height:25px;">'+data[i]["pf_code"]+'</li>'
                    $("#list").html(html);
                }
                if(data.length!=0){
                    $("#list li").bind({"mouseover":mouseover,"mouseout":mouseout,"click":click});
                    $("#list").css("display","block");
                }
                else{
                    $("#list").css("display","none");
                }
            },error:function(response){
            }
        });
    }
});
$("#list").mouseover(function(){
    $("#fCode").unbind("blur",hide);
});
$("#list").mouseout(function(){
    $("#fCode").bind("blur",hide);
});
function hide(){
     $("#list").css("display","none");
}

