var staticFileName = '';
function designChange(ct){
    if(ct == "projectOutlineDesignArea"){
        $("#projectOutlineDesignArea").removeAttr("readOnly");
        $("#projectOutlineDesignArea").focus();
    }else if(ct == "systemArchDesignArea"){
        $("#systemArchDesignArea").removeAttr("readOnly");
        $("#systemArchDesignArea").focus();
    }else if(ct == "interfacePlanArea"){
        $("#interfacePlanArea").removeAttr("readOnly");
        $("#interfacePlanArea").focus();
    }else{
        $("#databaseDesignArea").removeAttr("readOnly");
        $("#databaseDesignArea").focus();
    }
}

function designSubmit(ct){
    var data;
    if(ct == "projectOutlineDesignArea"){
        if($("#projectOutlineDesignArea").val() == ""){
            alert("没有可提交的数据");
            return;
        }
        data={"type":"projectOutlineDesignArea","data":$("#projectOutlineDesignArea").val(),"textId":$("#outLineDesignAreaId").val()};
        $("#projectOutlineDesignArea").attr("readOnly","readOnly");
    }else if(ct == "systemArchDesignArea"){
        if($("#systemArchDesignArea").val() == ""){
            alert("没有可提交的数据");
            return;
        }
        data={"type":"systemArchDesignArea","data":$("#systemArchDesignArea").val(),"textId":$("#systemArchAreaId").val()};
        $("#systemArchDesignArea").attr("readOnly","readOnly");
    }else if(ct == "interfacePlanArea"){
        if($("#interfacePlanArea").val() == ""){
            alert("没有可提交的数据");
            return;
        }
        data={"type":"interfacePlanArea","data":$("#interfacePlanArea").val(),"textId":$("#interfaceAreaId").val()};
        $("#interfacePlanArea").attr("readOnly","readOnly");
    }else{
        if($("#databaseDesignArea").val() == ""){
            alert("没有可提交的数据");
            return;
        }
        data={"type":"databaseDesignArea","data":$("#databaseDesignArea").val(),"textId":$("#databaseDesignAreaId").val()};
        $("#databaseDesignArea").attr("readOnly","readOnly");
    }
    data["id"] = $("#id").val();
    $.ajax({
        url: "/pms/projectDesignSubmit",
        type: "POST",
        data: data,
        dataType: "json",
        success: function(response){
            if(response.status == 1){
                if(data.type == "projectOutlineDesignArea"){
                    $("#outLineDesignAreaId").val(response.textId);   
                }else if(data.type == "systemArchDesignArea"){
                    $("#systemArchAreaId").val(response.textId);
                }else if(data.type == "interfacePlanArea"){
                    $("#interfaceProDesign").val(response.textId);
                }else{
                    $("#databaseDesignAreaId").val(response.textId);
                }
                alert("提交成功");
            }
            else
                alert("提交失败");
        },error: function(response){
            alert("提交失败");
        }
    });
}

function openProjectDesignFileChoose(){
    $("#projectDesignFileChoose").click();
}

function getProjectDesignFileName(){
    var fileName=$("#projectDesignFileChoose").val();
    if(fileName != ""){
        var name=fileName.split("\\");
        $("#projectDesignFileName").val(name[name.length-1]);
    }else{
        $("#projectDesignFileName").val("");
    }
}

function sendProjectDesignFile(){
    if($("#projectDesignFileChoose").val()==""){
        alert("请选择文件！");
    }else{
        var file=$("#projectDesignFileChoose")[0].files[0];
        startToSendProjectDesignFile(file,1);
        $("#projectDesignFileName").css("display","none");
        $("#projectDesignProgressParent").css("display","block");
        $("#projectDesignUploadBtn").attr("disabled","disabled");
    }
}


function startToSendProjectDesignFile(file,num){
    var formData=new FormData();
    var blockSize= 1024*1024*2;
    var blockNum=Math.ceil(file.size / blockSize);
    var nextSize= Math.min(num * blockSize,file.size);
    var fileData= file.slice((num-1)*blockSize,nextSize);
    formData.append("file",fileData);
    formData.append("fileName",$("#projectDesignFileName").val());
    formData.append("id",$("#id").val());
    formData.append("num",num);
    formData.append("filePath",staticFileName);
    $.ajax({
        url: "/pms/projectDesignFileUpload",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function(response){
            staticFileName = response.fileName;
            $("#projectDesignProgress").css("width",(num*100)/blockNum +"%");
            $("#projectDesignProgress").text(((num*100)/blockNum).toFixed(2) +"%");
            if(nextSize>=file.size){
                checkProjectDesignFileUploadSuccess($("#id").val(),staticFileName,file.size,1);
                return;
            }
            startToSendProjectDesignFile(file,num+1);
        },error:function(response){
            alert("上传失败");
            $("#projectDesignFileName").css("display","block");
            $("#projectDesignProgressParent").css("display","none");
            $("#projectDesignProgress").css("width","0%");
            checkProjectDesignFileUploadSuccess($("#id").val(),staticFileName,file.size,0);
        }
    });
}

function checkProjectDesignFileUploadSuccess(id,fileName,fileSize,isWarn){
    var data={"id":id,"fileName":fileName,"fileSize":fileSize};
    $.ajax({
        url: "/pms/projectDesignFileCheckSuccess",
        type: "POST",
        data: data,
        dataType: "json",
        success:function(response){
            $("#projectDesignUploadBtn").removeAttr("disabled");
            if(isWarn == 1){
                if(response.status == 1){
                    deleteDesignFileName(fileName);
                    $("#downloadDiv").after('<hr /><div style="overflow:hidden;"> <p style="float:left;">'+fileName+'</p><button type="button" class="btn btn-danger" onclick=downloadDesign("'+fileName+'") style="float:right">文档下载</button> </div>');
                    $("#projectDesignFileName").css("display","block");
                    $("#projectDesignProgressParent").css("display","none");
                    $("#projectDesignProgress").css("width","0%");
                    $("#projectDesignFileName").val("");
                    $("#projectDesignFileChoose").val("");
                    alert("上传成功");
                }else{
                    alert("文件完整性校验失败");
                    $("#projectDesignFileName").css("display","block");
                    $("#projectDesignProgressParent").css("display","none");
                    $("#projectDesignProgress").css("width","0%");
                }
            }
            staticFileName = "";
        }
    });
}

function downloadDesign(fileName){
    id=$("#id").val();
    var form=document.createElement("form");
    form.action="/pms/projectDesignFileDownload";
    form.method="POST";
    form.style.display="none";
    var input1=document.createElement("input");
    input1.name="fileName";
    input1.value=fileName;
    var input2=document.createElement("input");
    input2.name="id";
    input2.value=id;
    form.appendChild(input1);
    form.appendChild(input2);
    document.body.appendChild(form);
    form.submit();
}

function deleteDesignFileName(fileName){
    var fileNode=document.getElementsByTagName("hr");
    for(var i=0;i<fileNode.length;i++){
        var nextNode=fileNode[i].nextElementSibling;
        var firstChild=nextNode.firstChild;
        if(firstChild.nextElementSibling.innerText == fileName){
            nextNode.remove();
            fileNode[i].remove();
            return;
        }
    }
}


function downloadDesignTemplate(){
    $.ajax({
        url: "/pms/projectDesign/checkTemplate",
        type: "POST",
        dataType: "json",
        success:function(response){
            console.log(response);
            if(response.status == 1){
                var form=document.createElement("form");
                form.action="/pms/projectDesign/downloadTemplate";
                form.method="POST";
                form.style.display="none";
                document.body.appendChild(form);
                form.submit();
            }else{
                alert("暂未上传模板！");
            }
        },error:function(response){
        }
    });
}

function finishDesign(){
    $.ajax({
        url: "/pms/projectDesign/finish",
        data: {'id':$("#id").val()},
        type: "POST",
        dataType: "json",
        success:function(response){
            if(response.status == 1){
                alert("状态改变成功!");
            }else{
                alert("状态改变失败!");
            }
        },error:function(response){
            alert("状态改变失败!");
        }
    });
}
