var ws;
$(document).ready(wsInit);
function wsInit(){
    ws = new WebSocket("ws://192.168.100.64:8000/pms/projectWSChat");
    var myChat = layui.use('layim',function(layim){
        layim.config({
            title: '我的聊天',
            min: true,
            maxLength: 500,
            isAudio: false,
            isVideo: false,
            notice: false,
            copyright: true,
            init:{
                url: '/pms/projectInitChat',
                type: 'post',
                data: {},
            },
            members:{
                url: '/pms/projectGetMembers',
                type: 'post',
                data: {},
            },
            chatLog: layui.cache.dir + "css/modules/layim/html/chatlog.html",
        });
        layim.on("ready",function(options){
            var cache = layim.cache();
            var local = layui.data('layim')[cache.mine.id];
            if(typeof(local) != "undefined"){
                delete local.chatlog;
                delete local.history;
            }
            layui.data("layim",{
                key:cache.mine.id,
                value: local,
            });
            $(".layim-list-history").html('<li class="layim-null">暂无历史会话</li>');
            ws.send(JSON.stringify({"type":"getOfflineMessage"}));
            //监听发送消息
            layim.on("sendMessage",function(res){
                ws.send(JSON.stringify({"type":"chatMessage",data:res}));
            });
            //监听修改签名
            layim.on("sign",function(value){
                $.ajax({
                    url: "/pms/projectChangeSign",
                    data: {"value":value},
                    type: "post",
                    dataType: "json",
                    success:function(response){
                    },error:function(response){
                    }
                });
            });
            ws.onmessage = function(e){
                var data = JSON.parse(e.data);
                if(data.type == "systemMessage"){
                    //$("#info").text("有新的"+data.mes);
                    //$("#info").css("display","block");
                    //$("#info").animate({top:'20%'});
                    //setTimeout(hideInfo,3000);
                    var ct = parseInt($("#mesCount").text());
                    if(isNaN(ct)){
                        $("#mesCount").text(1);
                        $("#mesCount").css("display","block");
                        $("#realMesCount").val(1);
                    }
                    else{
                        if(ct < 99){
                            $("#mesCount").text(ct+1);
                        }
                        $("#realMesCount").val(parseInt($("#realMesCount").val())+1);
                    }
                }else if(data.type == "userOnline"){
                    layim.setFriendStatus(data.id,"online");
                    //对在线离线人员进行排序
                    var sortUsers = sortOnlineUser($(".layim-list-friend .layui-layim-list").get(0));
                    $($(".layim-list-friend .layui-layim-list").get(0)).html(sortUsers);
                }else if(data.type == "userOffline"){
                    layim.setFriendStatus(data.id,"offline");
                    //对在线离线人员进行排序
                    var sortUsers = sortOnlineUser($(".layim-list-friend .layui-layim-list").get(0));
                    $($(".layim-list-friend .layui-layim-list").get(0)).html(sortUsers);
                    layim.getMessage({
                        system:true,
                        id: data.id,
                        type: "friend",
                        content: "对方已下线",
                    });
                }else{
                    layim.getMessage(data.data);
                }
            }
        });
    });
}
function hideInfo(){
    $("#info").animate({top:"0%"},function(){
        $("#info").css("display","none");
    });
}

function jumpToMessage(){
    $.ajax({
        url: "/pmsManager/manageMessageList",
        type: "get",
        dataType: "html",
        success:function(response){
            $("#content").html(response);
        },error:function(response){
            alert("查看消息失败");
        }
    });
}

function onSubmit(id,sendId,pid,sid,getUserName){
    var input = document.getElementById("inputLi");
    var data = {};
    if (!input.value || input.value==""){
        alert("输入不能为空！");
    }else{
        data['id'] = id;
        data['sid'] = sendId;
        data['mes'] = input.value;
        data['projectid'] = pid;
        data['stageid'] = sid;
        data['type'] = 'returnMessage';
        data['getUserName'] = getUserName;
        data = JSON.stringify(data);
        ws.send(data);
        output("已回复:" + input.value);
        input.value = "";
        input.focus();
    }
}

//对在线离线人员进行排序
function sortOnlineUser(userList){
    var users = userList.children;
    var onlineUser = '';
    var offlineUser = '';
    for(var i=0;i<users.length;i++){
        if(users[i].classList.length == 1){
            onlineUser = onlineUser + users[i].outerHTML;
        }else{
            offlineUser = offlineUser + users[i].outerHTML;
        }
    }
    return onlineUser + offlineUser;
}
