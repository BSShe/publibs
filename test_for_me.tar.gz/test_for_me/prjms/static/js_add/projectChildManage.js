function stopChild(id,obj){
    $("#stopChildReason").val("");
    $("#stopChildReason-modal").modal("show");
    $("#stopChild_btn").unbind();
    $("#stopChild_btn").bind('click',{id:id,obj:obj},stopChildProject);
}

function stopChildProject(e){
    if($.trim($("#stopChildReason").val()) == ""){
        alert("请填写停止原因");
        return;
    }
    var data = {'pid':e.data.id,'stopReason':$.trim($("#stopChildReason").val())};
    $.ajax({
        url: "/pmsManager/stopTheProject",
        type: "post",
        dataType: "html",
        data: data,
        async: false,
        success: function (response) {
            alert("修改成功");
            $("#stopChildReason-modal").modal("hide");
            var obj = e.data.obj;
            obj.parentNode.previousElementSibling.innerText = '已关闭';
            var pre = obj.previousElementSibling;
            if(pre.innerText == '计划制定' || pre.innerText == '计划变更'){
                $(pre).remove();
            }
            $(obj).before('<button class="btn btn-info btn-xs" onclick=showChildStopInfo(' + e.data.id + ')> 关闭原因 </button>');
            $(obj).remove();
        },
        error: function (response) {
            alert("修改失败");
        }
    });
}

function watchMore(name,id,page){
    $.ajax({
        url: "/pms/projectWatchMore",
        type: "post",
        data: {"id":id,"page":page},
        dataType: "html",
        success:function(response){
            $("#content").html(response);
        },error:function(response){
            alert("查看失败");
        }
    });
}

function watchChart(name,id,page){
    $.ajax({
        url: "/pms/projectWatchChart",
        type: "post",
        data: {"id":id,"page":page},
        dataType: "html",
        success:function(response){
            $("#content").html(response);
        },error:function(response){
            alert("查看失败");
        }
    });
}

function details_plan(event,id,type){
        var data = {'id':id,'type':type};
        $.ajax({
            url: "/pmsManagerWork/projectPlanDetailHandler",
            type: "post",
            dataType: "html",
            data: data,
            async: false,
            success: function (response) {
                    $('#content').html(response)
            },
            error: function (response) {
                    alert("测试进度页进入失败");
            }
        })
}

function showChildStopInfo(id){
    $("#childList").empty();
    $.ajax({
        url: '/pmsManager/stopProjectInfo',
        type: 'post',
        data: {"id":id},
        dataType: 'json',
        success:function(response){
            if(response.length == 0){
                $("#childList").html('<li style="text-align:center;"><span style="line-height:30px;border-radius:3px;padding:0 15px;background-color: #e2e2e2;font-size: 14px;display: inline-block;">无关闭原因</span></li>');
            }else{
                $("#childList").html('<li class="list-group-item"><h5 class="list-group-item-text" style="word-wrap:break-word;word-break:break-all;"><span style="color:#5d9cec;">关闭原因:</span></br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'+response[0]['mes']+'</h5><p class="list-group-item-heading text-right">'+response[0]['time']+'&nbsp;&nbsp;'+response[0]['user_name']+'</p></li>');
            }
            $("#showChildChange-modal").modal("show");
        },error:function(response){
            alert("查看失败");
        }
    });
}
