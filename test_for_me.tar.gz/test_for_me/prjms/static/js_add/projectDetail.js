var myProgress=$("#progress").get(0).getContext("2d");
var myTotal=$("#total").get(0).getContext("2d");
var myChart1=$("#chart1").get(0).getContext("2d");
var chart1=new Chart(myChart1,{
    type:"doughnut",
    data:{
        labels:["已完成阶段数","未完成阶段数"],
        datasets:[{
            data:[],
            backgroundColor:["#00FF00","#FF0000"],
        }],
    },
    options:{
        tooltips:{
            enabled:true,
        },
        legend:{
            display:true,
            position:"right",
            labels:{
                boxWidth:10,
            },
        },
    },
});
var progress=new Chart(myProgress,{
    type:"bar",
    data:{
        datasets:[{
            label:"计划",
            data:[],
            backgroundColor:["#FFD700"],
        },{
            label:"实际",
            data:[],
            backgroundColor:['#00FF00'],
        }],
    },
    options:{
        scales:{
            yAxes:[{
                ticks:{
                    beginAtZero:true,
                },
                scaleLabel:{
                    display:true,
                    labelString:"百分比(%)",
                },
            }],
        },
         legend:{
            display:true,
            position:"right",
        },
    }
});
var total=new Chart(myTotal,{
    type:"bar",
    data:{
        datasets:[{
            label:"总工作量",
            data:[],
            backgroundColor:["#FFD700"],
        },{
            label:"至本里程碑",
            data:[],
            backgroundColor:["#00FF00"],
        },{
            label:"实际",
            data:[],
            backgroundColor:["#FF0000"],
        }],
    },
    options:{
        scales:{
            yAxes:[{
                ticks:{
                    beginAtZero:true,
                },
                scaleLabel:{
                    display:true,
                    labelString:"人天",
                },
            }],
        },
        legend:{
            display:true,
            position:"right",
            labels:{
                boxWidth:10,
            },
        },
    }
});
$(function(){
    $("[data-toggle='popover']").popover();
});
$(".wrapper").ready(function(){
     $.ajax({
        url: "/pms/projectDetailChartInfo",
        type: "POST",
        data: {"id":$("#id").val()},
        dataType: "json",
        success: function(response){
            progress.data.datasets[0].data.push(response['jihua']);
            progress.data.datasets[1].data.push(response['shiji']);
            progress.update();
            total.data.datasets[0].data.push(response['totalWorkLoad']);
            total.data.datasets[1].data.push(response['milestoneWorkLoad']);
            total.data.datasets[2].data.push(response['realWorkLoad']);
            total.update();
            chart1.data.datasets[0].data.push(response['finish_dev']);
            chart1.data.datasets[0].data.push(response['undo_dev']);
            chart1.update();
        },error: function(response){
        }
    });
});

function comeBack(page){
    var data = {'page':page};
    $.ajax({
        url: "/pmsManager/manageQueryList",
        type: "get",
        dataType: "html",
        data: data,
        async: false,
        success: function (response) {
              $("#content").html(response);
        },
        error: function (response) {
                alert("返回失败");
        }
    });
}
