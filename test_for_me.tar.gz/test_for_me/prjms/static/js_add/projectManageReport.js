$(function(){
    $('[data-toggle="tooltip"]').tooltip();
});
var colors = ["#e7554b","#f4a259","#8cb369","#f4e285","#5b8e7d"];
var totalProjectNature = $("#totalProjectNature").get(0).getContext("2d");
var totalProgress = $("#totalProgress").get(0).getContext("2d");
var tProjectNature=new Chart(totalProjectNature,{
    type:"doughnut",
    data:{
        labels:[],
        datasets:[{
            data:[],
            backgroundColor:[],
        }],
    },
    options:{
        tooltips:{
            enabled:true,
        },
        legend:{
            display:true,
            position:"right",
            labels:{
                boxWidth:10,
            },
        },
        title:{
            display: true,
            position: "bottom",
            text:"项目性质分布",
        },
    },
});
var tProgress=new Chart(totalProgress,{
    type:"doughnut",
    data:{
        labels:["已完成项目","未完成项目"],
        datasets:[{
            data:[],
            backgroundColor:["#e7554b","#f4a259"],
        }],
    },
    options:{
        tooltips:{
            enabled:true,
        },
        legend:{
            display:true,
            position:"right",
            labels:{
                boxWidth:10,
            },
        },
        title:{
            display: true,
            position: "bottom",
            text:"总体项目进度",
        },
    },
});
$("#manageReport").ready(function(){
    $.ajax({
        url: "/pms/projectManageReport",
        type: "post",
        dataType: "json",
        success:function(response){
            for(var i=0;i<response["nature"].length;i++){
                tProjectNature.data.labels.push(response["nature"][i]["name"]);
                tProjectNature.data.datasets[0].data.push(response["nature"][i]["ct"]);
                tProjectNature.data.datasets[0].backgroundColor.push(colors[i]);
            }
            tProjectNature.update();
            tProgress.data.datasets[0].data.push(response["progress"][0]["ct"]);
            tProgress.data.datasets[0].data.push($("#totalProjects").text()-response["progress"][0]["ct"]);
            tProgress.update();
        },error:function(response){
            alert("获取数据失败");
        }
    });
});

function getNewInfo(){
    data = {}
    data.startTime = $("#startTime").val();
    data.endTime = $("#endTime").val()
    data.minMoney = $("#minMoney").val();
    data.maxMoney = $("#maxMoney").val();
    data.outsourcer = $("#outsourcer").val();
    data.organizationNature = $("#organizationNature").val();
    data.projectType = $("#projectType").val();
    data.projectNature = $("#projectNature").val();
    init_ProjectTables();
    $.ajax({
        url: "/pms/refreshTotalInfo",
        type: "post",
        data: data,
        dataType: "json",
        success:function(response){
            $("#totalProjects").text(response["pro_count"]);
            $("#totalMoney").text(response["money_count"]);
            tProjectNature.data.labels = [];
            tProjectNature.data.datasets[0].data = [];
            tProjectNature.data.datasets[0].backgroundColor = [];
            for(var i=0;i<response["nature"].length;i++){
                tProjectNature.data.labels.push(response["nature"][i]["name"]);
                tProjectNature.data.datasets[0].data.push(response["nature"][i]["ct"]);
                tProjectNature.data.datasets[0].backgroundColor.push(colors[i]);
            }
            tProjectNature.update();
            tProgress.data.datasets[0].data = [];
            tProgress.data.datasets[0].data.push(response["progress"][0]["ct"]);
            tProgress.data.datasets[0].data.push(response["pro_count"]-response["progress"][0]["ct"]);
            tProgress.update();
        },error(response){
        }
    });
}

function showProjectProgress(event,arg,page){
    $.ajax({
        url: "/pms/singleProjectReport",
        type: "post",
        data: {"projectName":event.innerText,"id":arg,"page":page},
        dataType: "html",
        success:function(response){
            $("#content").html(response);
        },error:function(response){
            alert("查看失败");
        }
    });
}

function userEvaluate(page){
    console.info("123");
    $.ajax({
        url: "/pms/showUserEvaluate",
        type: "post",
        dataType: "html",
        data: {'page':page},
        success:function(response){
            $("#content").html(response);
        },error:function(response){
            alert("查看失败");
        }
    });
}

function supplierEvaluate(){
    $.ajax({
        url: "/supplierManage/supplierEvaluateList",
        type: "get",
        dataType: "html",
        success:function(response){
            $("#content").html(response);
        },error:function(response){
            alert("查看失败");
        }
    });
}

function projectEvaluate(){
    $.ajax({
        url: "/pmsComment/manageQueryList",
        type: "get",
        dataType: "html",
        success:function(response){
            $("#content").html(response);
        },error:function(response){
            alert("查看失败");
        }
    });
}

function riskWarn(){
    $.ajax({
        url: "/pmsManager/manageMessageList",
        type: "get",
        dataType: "html",
        success:function(response){
            $("#content").html(response);
        },error:function(response){
            alert("查看失败");
        }
    });
}
