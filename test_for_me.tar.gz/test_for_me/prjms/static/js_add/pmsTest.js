function designChange(ct){
    if(ct == "projectOutlineDesignArea"){
        $("#projectOutlineDesignArea").removeAttr("readOnly");
        $("#projectOutlineDesignArea").focus();
    }else if(ct == "systemArchDesignArea"){
        $("#systemArchDesignArea").removeAttr("readOnly");
        $("#systemArchDesignArea").focus();
    }else if(ct == "interfacePlanArea"){
        $("#interfacePlanArea").removeAttr("readOnly");
        $("#interfacePlanArea").focus();
    }else{
        $("#databaseDesignArea").removeAttr("readOnly");
        $("#databaseDesignArea").focus();
    }
}

function designSubmit(ct,stage_id){
    var data;
    if(ct == "projectOutlineDesignArea"){
        if($("#projectOutlineDesignArea").val() == ""){
            alert("没有可提交的数据");
            return;
        }
        data={"type":"projectOutlineDesignArea","data":$("#projectOutlineDesignArea").val()};
        $("#projectOutlineDesignArea").attr("readOnly","readOnly");
    }else if(ct == "systemArchDesignArea"){
        if($("#systemArchDesignArea").val() == ""){
            alert("没有可提交的数据");
            return;
        }
        data={"type":"systemArchDesignArea","data":$("#systemArchDesignArea").val()};
        $("#systemArchDesignArea").attr("readOnly","readOnly");
    }
    data['stage_id'] = stage_id ;
    $.ajax({
        url: "/pms/projectTestSubmit",
        type: "POST",
        data: data,
        dataType: "json",
        success: function(response){
            if(response.status == 1)
                alert("提交成功");
            else
                alert("提交失败");
        },error: function(response){
            alert("提交失败");
        }
    });
}

function openProjectDesignFileChoose(){
    $("#projectDesignFileChoose").click();
}

function getProjectDesignFileName(){
    var fileName=$("#projectDesignFileChoose").val();
    if(fileName != ""){
        var name=fileName.split("\\");
        $("#projectDesignFileName").val(name[name.length-1]);
    }else{
        $("#projectDesignFileName").val("");
    }
}

function sendProjectDesignFile(){
    if($("#projectDesignFileChoose").val()==""){
        alert("请选择文件！");
    }else{
        var file=$("#projectDesignFileChoose")[0].files[0];
        startToSendProjectDesignFile(file,1);
        $("#projectDesignFileName").css("display","none");
        $("#projectDesignProgressParent").css("display","block");
        $("#projectDesignUploadBtn").attr("disabled","disabled");
    }
}


function startToSendProjectDesignFile(file,num){
    var formData=new FormData();
    var blockSize= 1024*1024*2;
    var blockNum=Math.ceil(file.size / blockSize);
    var nextSize= Math.min(num * blockSize,file.size);
    var fileData= file.slice((num-1)*blockSize,nextSize);
    formData.append("file",fileData);
    formData.append("fileName",$("#projectDesignFileName").val());
    formData.append("id",$("#id").val());
    formData.append("num",num);
    $.ajax({
        url: "/pms/projectTestFileUpload",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function(response){
            $("#projectDesignProgress").css("width",(num*100)/blockNum +"%");
            $("#projectDesignProgress").text(((num*100)/blockNum).toFixed(2) +"%");
            if(nextSize>=file.size){
                checkProjectDesignFileUploadSuccess($("#id").val(),$("#projectDesignFileName").val(),file.size,1);
                return;
            }
            startToSendProjectDesignFile(file,num+1);
        },error:function(response){
            alert("上传失败");
            $("#projectDesignFileName").css("display","block");
            $("#projectDesignProgressParent").css("display","none");
            $("#projectDesignProgress").css("width","0%");
            checkProjectDesignFileUploadSuccess($("#id").val(),$("#projectDesignFileName").val(),file.size,0);
        }
    });
}

function checkProjectDesignFileUploadSuccess(id,fileName,fileSize,isWarn){
    var data={"id":id,"fileName":fileName,"fileSize":fileSize};
    $.ajax({
        url: "/pms/projectTestFileCheckSuccess",
        type: "POST",
        data: data,
        dataType: "json",
        success:function(response){
            $("#projectDesignUploadBtn").removeAttr("disabled");
            if(isWarn == 1){
                if(response.status == 1){
                    deleteDesignFileName($("#projectDesignFileName").val());
                    $("#downloadDiv").after('<hr /><div style="overflow:hidden;"> <p style="float:left;">'+$("#projectDesignFileName").val()+'</p><button type="button" class="btn btn-danger" onclick=downloadDesign("'+$("#projectDesignFileName").val()+'") style="float:right">文档下载</button> </div>');
                    $("#projectDesignFileName").css("display","block");
                    $("#projectDesignProgressParent").css("display","none");
                    $("#projectDesignProgress").css("width","0%");
                    $("#projectDesignFileName").val("");
                    $("#projectDesignFileChoose").val("");
                    alert("上传成功");
                }else{
                    alert("文件完整性校验失败");
                    $("#projectDesignFileName").css("display","block");
                    $("#projectDesignProgressParent").css("display","none");
                    $("#projectDesignProgress").css("width","0%");
                }
            }
        }
    });
}

function downloadDesign(fileName){
    id=$("#id").val();
    var form=document.createElement("form");
    form.action="/pms/projectTestFileDownload";
    form.method="POST";
    form.style.display="none";
    var input1=document.createElement("input");
    input1.name="fileName";
    input1.value=fileName;
    var input2=document.createElement("input");
    input2.name="id";
    input2.value=id;
    form.appendChild(input1);
    form.appendChild(input2);
    document.body.appendChild(form);
    form.submit();
}

function deleteDesignFileName(fileName){
    var fileNode=document.getElementsByTagName("hr");
    for(var i=0;i<fileNode.length;i++){
        var nextNode=fileNode[i].nextElementSibling;
        var firstChild=nextNode.firstChild;
        if(firstChild.nextElementSibling.innerText == fileName){
            nextNode.remove();
            fileNode[i].remove();
            return;
        }
    }
}
