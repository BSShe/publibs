var staticFileName = '';

function openEditor(){
    CKEDITOR.replace('myEditor',{
        language:'zh-cn',
        height: 400,
        resize_enabled: false,
        startupFocus: true,
        htmlEncodeOutput : true,
        skin : 'bootstrapck',
        tabSpaces : 4,
        removePlugins : 'elementspath',
        dialog_backgroundCoverColor : 'black',
        customCnfig : './config.js',
    });
    console.log(CKEDITOR.instances['myEditor'].getData());
}

function chooseFile(){
    $("#getFilePath").click();
}

function getFilePath(){
    var fileName=$("#getFilePath").val();
    if(fileName != ""){
        var name=fileName.split("\\");
        $("#fileName").val(name[name.length-1]);
    }else{
        $("#fileName").val("");
    }
}

function startToUpload(){
     if($("#getFilePath").val()==""){
        alert("请选择文件！");
    }else{
        var file=$("#getFilePath")[0].files[0];
        startToSendProjectFile(file,1);
        $("#fileName").css("display","none");
        $("#parentFileUploadPeogress").css("display","block");
        $("#startToUpload").attr("disabled","disabled");
    }
}

function startToSendProjectFile(file,num){
    var formData=new FormData();
    var blockSize= 1024*1024*2;
    var blockNum=Math.ceil(file.size / blockSize);
    var nextSize= Math.min(num * blockSize,file.size);
    var fileData= file.slice((num-1)*blockSize,nextSize);
    formData.append("file",fileData);
    formData.append("fileName",$("#fileName").val());
    formData.append("id",$("#id").val());
    formData.append("num",num);
    formData.append("filePath",staticFileName);
    $.ajax({
        url: "/pms/projectMaintenance/upload",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function(response){
            staticFileName = response.fileName;
            $("#fileUploadProgress").css("width",(num*100)/blockNum +"%");
            $("#fileUploadProgress").text(((num*100)/blockNum).toFixed(2) +"%");
            if(nextSize>=file.size){
                checkProjectFileUploadSuccess($("#id").val(),staticFileName,file.size,1);
                return;
            }
            startToSendProjectFile(file,num+1);
        },error:function(response){
            alert("上传失败");
            $("#fileName").css("display","block");
            $("#parentFileUploadPeogress").css("display","none");
            $("#fileUploadProgress").css("width","0%");
            checkProjectFileUploadSuccess($("#id").val(),staticFileName,file.size,0);
        }
    });
}

function checkProjectFileUploadSuccess(id,fileName,fileSize,isWarn){
    var data={"id":id,"fileName":staticFileName,"fileSize":fileSize};
    $.ajax({
        url: "/pms/projectMaintenance/check",
        type: "POST",
        data: data,
        dataType: "json",
        success:function(response){
            $("#startToUpload").removeAttr("disabled");
            if(isWarn == 1){
                if(response.status == 1){
                    $("#fileIndex").after('<hr /><div style="overflow:hidden;"> <p style="float:left;">'+staticFileName+'</p><button type="button" class="btn btn-danger" onclick=download("'+staticFileName+'") style="float:right">文档下载</button> </div>');
                    $("#fileName").css("display","block");
                    $("#parentFileUploadPeogress").css("display","none");
                    $("#fileUploadProgress").css("width","0%");
                    $("#fileName").val("");
                    alert("上传成功");
                }else{
                    alert("文件完整性校验失败");
                    $("#fileName").css("display","block");
                    $("#parentFileUploadPeogress").css("display","none");
                    $("#fileUploadProgress").css("width","0%");
                }
            }
            staticFileName = '';
        }
    });
}

function download(fileName){
    id=$("#id").val();
    var form=document.createElement("form");
    form.action="/pms/projectMaintenance/download";
    form.method="POST";
    form.style.display="none";
    var input1=document.createElement("input");
    input1.name="fileName";
    input1.value=fileName;
    var input2=document.createElement("input");
    input2.name="id";
    input2.value=id;
    form.appendChild(input1);
    form.appendChild(input2);
    document.body.appendChild(form);
    form.submit();
}

function submit(){
    var data = {"id":$("#id").val(),"text":CKEDITOR.instances.myEditor.getData()};
    $.ajax({
        url: "/pms/projectMaintenance/submitText",
        type: "POST",
        data: data,
        dataType: "json",
        success:function(response){
        },error:function(response){
        }
    });
}


function downloadTemplate(){
    $.ajax({
        url: "/pms/projectMaintenance/checkTemplate",
        type: "POST",
        dataType: "json",
        success:function(response){
            if(response.status == 1){
                var form=document.createElement("form");
                form.action="/pms/projectMaintenance/downloadTemplate";
                form.method="POST";
                form.style.display="none";
                document.body.appendChild(form);
                form.submit();
            }else{
                alert("暂未上传模板！");
            }
        },error:function(response){
        }
    });
}

function finishMaintenance(){
    $.ajax({
        url: "/pms/projectMaintenance/finish",
        data: {'id':$("#id").val()},
        type: "POST",
        dataType: "json",
        success:function(response){
            if(response.status == 1){
                alert("状态改变成功!");
            }else{
                alert("状态改变失败!");
            }
        },error:function(response){
            alert("状态改变失败!");
        }
    });
}
