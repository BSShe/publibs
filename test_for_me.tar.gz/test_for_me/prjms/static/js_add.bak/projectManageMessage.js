function openInfo(event,data){
    var html='';
    var rd=[];
    for(var i=0;i<data.length;i++){
        console.log(data[i]['pms_mes_recode_type']);
        if(data[i]['pms_mes_recode_type'] == 0){
            html=html+'<li><div class="row" style="font-size:16px;"><label class="pull-left"><span class="glyphicon glyphicon-user"></span> '+data[i]['pms_user_name']+'</label><p class="pull-left" style="margin-left:10px;">'+data[i]['pms_mes_recode_senddate']+'</p><span class="badge" style="margin-left:10px;background-color:red;">new</span></div><p>'+data[i]['pms_mes_recode_mes']+'</p></li>';
            rd.push(data[i]['pms_mes_recode_id']);
        }else{
            html=html+'<li><div class="row" style="font-size:16px;"><label class="pull-left"><span class="glyphicon glyphicon-user"></span> '+data[i]['pms_user_name']+'</label><p class="pull-left" style="margin-left:10px;">'+data[i]['pms_mes_recode_senddate']+'</p></div><p>'+data[i]['pms_mes_recode_mes']+'</p></li>';
        }
    }
    $("#infoBody").html(html);
    $("#infoWindow").modal("show");
    event.children[0].innerText="";
    var pa=event.parentNode.parentNode.children;
    for(var i=0;i<pa.length;i++){
        if(pa[i].children[0].children[0].innerText!="")
            break;
        if(i==pa.length-1){
            event.parentNode.parentNode.previousElementSibling.children[0].innerText="";
        }
    }
    if(rd.length>0){
        $.ajax({
            url: "/pms/projectChangeType",
            type:"POST",
            data:{"id":JSON.stringify(rd)},
            dataType:"json",
            success: function(response){

            },error: function(response){}
        });
    }
}
