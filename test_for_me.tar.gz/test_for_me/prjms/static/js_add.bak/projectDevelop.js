function projectTextChangeBtn(type){
    if(type == "programModal"){
        $("#programParent").html('<button class="btn btn-info" id="programTextAddBtn" type="button" data-toggle="tooltip" title="新增" onclick="addProgramArea(this)"><span class="glyphicon glyphicon-plus"></span></button>');
        var data={"id":$("#id").val(),"type":"projectProgramText"};
        $.ajax({
            url: "/pms/projectDevelopGetText",
            type: "POST",
            data: data,
            dataType: "json",
            success:function(response){
                for(var i=0;i<response.length;i++){
                    $("#programTextAddBtn").before('<div class="input-group"><label class="input-group-addon">程序设计阶段名:</label><input class="form-control" type="text" value="'+response[i]["title"]+'"></input><span class="input-group-btn"><button class="btn btn-info" type="button" data-toggle="tooltip" title="删除" onclick="removeProgramArea(this)"><span class="glyphicon glyphicon-minus"></span></button></span></div><textArea class="form-control" wrap="hard" rows="10">'+response[i]["text"]+'</textArea>');
                }
                $("#programModal").modal("show");
            },error:function(response){
                alert("数据初始化失败");
            }
        });
    }else{
        $("#unitTestParent").html('<button class="btn btn-info" id="unitTestTextAddBtn" type="button" data-toggle="tooltip" title="新增" onclick="addUnitTestArea(this)"><span class="glyphicon glyphicon-plus"></span></button>');
        var data={"id":$("#id").val(),"type":"projectUnitTestText"};
        $.ajax({
            url: "/pms/projectDevelopGetText",
            type: "POST",
            data: data,
            dataType: "json",
            success:function(response){
                for(var i=0;i<response.length;i++){
                    $("#unitTestTextAddBtn").before('<div class="input-group"><label class="input-group-addon">单元测试名:</label><input class="form-control" type="text" value="'+response[i]["title"]+'"></input><span class="input-group-btn"><button class="btn btn-info" type="button" data-toggle="tooltip" title="删除" onclick="removeProgramArea(this)"><span class="glyphicon glyphicon-minus"></span></button></span></div><textArea class="form-control" wrap="hard" rows="10">'+response[i]["text"]+'</textArea>');
                }
                $("#unitTestModal").modal("show");
            },error:function(response){
                alert("数据初始化失败");
            }
        });
    }
}

function addProgramArea(event){
    $(event).before('<div class="input-group"><label class="input-group-addon">程序设计阶段名:</label><input class="form-control" type="text"></input><span class="input-group-btn"><button class="btn btn-info" type="button" data-toggle="tooltip" title="删除" onclick="removeProgramArea(this)"><span class="glyphicon glyphicon-minus"></span></button></span></div><textArea class="form-control" wrap="hard" rows="10"></textArea>');
     $("#programParent").scrollTop($("#programParent")[0].scrollHeight);
}

function removeProgramArea(event){
    var now=event.parentNode.parentNode;
    var textArea=now.nextSibling;
    textArea.remove();
    now.remove();
}

function addUnitTestArea(event){
    $(event).before('<div class="input-group"><label class="input-group-addon">单元测试名:</label><input class="form-control" type="text"></input><span class="input-group-btn"><button class="btn btn-info" type="button" data-toggle="tooltip" title="删除" onclick="removeUnitTestArea(this)"><span class="glyphicon glyphicon-minus"></span></button></span></div><textArea class="form-control" wrap="hard" rows="10"></textArea>');
     $("#unitTestParent").scrollTop($("#unitTestParent")[0].scrollHeight);
}

function removeUnitTestArea(event){
    var now=event.parentNode.parentNode;
    var textArea=now.nextSibling;
    textArea.remove();
    now.remove();
}

//文件上传与下载

function openProjectDevelopFileChoose(){
    $("#projectDevelopFileChoose").click();
}

function getProjectDevelopFileName(){
    var fileName=$("#projectDevelopFileChoose").val();
    if(fileName != ""){
        var name=fileName.split("\\");
        $("#projectDevelopFileName").val(name[name.length-1]);
    }else{
        $("#projectDevelopFileName").val("");
    }
}

function sendProjectDevelopFile(){
    if($("#projectDevelopFileChoose").val()==""){
        alert("请选择文件！");
    }else{
        var file=$("#projectDevelopFileChoose")[0].files[0];
        startToSendProjectDevelopFile(file,1);
        $("#projectDevelopFileName").css("display","none");
        $("#projectDevelopProgressParent").css("display","block");
        $("#projectDevelopFileUploadBtn").attr("disabled","disabled");
    }
}

function startToSendProjectDevelopFile(file,num){
    var formData=new FormData();
    var blockSize= 1024*1024*2;
    var blockNum=Math.ceil(file.size / blockSize);
    var nextSize= Math.min(num * blockSize,file.size);
    var fileData= file.slice((num-1)*blockSize,nextSize);
    formData.append("file",fileData);
    formData.append("fileName",$("#projectDevelopFileName").val());
    formData.append("id",$("#id").val());
    formData.append("num",num);
    $.ajax({
        url: "/pms/projectDevelopFileUpload",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function(response){
            $("#projectDevelopProgress").css("width",(num*100)/blockNum +"%");
            $("#projectDevelopProgress").text(((num*100)/blockNum).toFixed(2) +"%");
            if(nextSize>=file.size){
                checkProjectDevelopFileUploadSuccess($("#id").val(),$("#projectDevelopFileName").val(),file.size,1);
                return;
            }
            startToSendProjectDevelopFile(file,num+1);
        },error:function(response){
            alert("上传失败");
            $("#projectDevelopFileName").css("display","block");
            $("#projectDevelopProgressParent").css("display","none");
            $("#projectDevelopProgress").css("width","0%");
            checkProjectDevelopFileUploadSuccess($("#id").val(),$("#projectDevelopFileName").val(),file.size,0);
        }
    });
}

function checkProjectDevelopFileUploadSuccess(id,fileName,fileSize,isWarn){
    var data={"id":id,"fileName":fileName,"fileSize":fileSize};
    $.ajax({
        url: "/pms/projectDevelopFileCheckSuccess",
        type: "POST",
        data: data,
        dataType: "json",
        success:function(response){
            $("#projectDevelopFileUploadBtn").removeAttr("disabled");
            if(isWarn == 1){
                if(response.status == 1){
                    deleteDevelopFileName($("#projectDevelopFileName").val());
                    $("#downloadDiv").after('<hr /><div style="overflow:hidden;"> <p style="float:left;">'+$("#projectDevelopFileName").val()+'</p><button type="button" class="btn btn-danger" onclick=downloadDevelopFile("'+$("#projectDevelopFileName").val()+'") style="float:right">文档下载</button> </div>');
                    $("#projectDevelopFileName").css("display","block");
                    $("#projectDevelopProgressParent").css("display","none");
                    $("#projectDevelopProgress").css("width","0%");
                    $("#projectDevelopFileName").val("");
                    $("#projectDevelopFileChoose").val("");
                    alert("上传成功");
                }else{
                    alert("文件完整性校验失败");
                    $("#projectDevelopFileName").css("display","block");
                    $("#projectDevelopProgressParent").css("display","none");
                    $("#projectDevelopProgress").css("width","0%");
                }
            }
        }
    });
}

function downloadDevelopFile(fileName){
    id=$("#id").val();
    var form=document.createElement("form");
    form.action="/pms/projectDevelopFileDownload";
    form.method="POST";
    form.style.display="none";
    var input1=document.createElement("input");
    input1.name="fileName";
    input1.value=fileName;
    var input2=document.createElement("input");
    input2.name="id";
    input2.value=id;
    form.appendChild(input1);
    form.appendChild(input2);
    document.body.appendChild(form);
    form.submit();
}

function deleteDevelopFileName(fileName){
    var fileNode=document.getElementsByTagName("hr");
    for(var i=0;i<fileNode.length;i++){
        var nextNode=fileNode[i].nextElementSibling;
        var firstChild=nextNode.firstChild;
        if(firstChild.nextElementSibling.innerText == fileName){
            nextNode.remove();
            fileNode[i].remove();
            return;
        }
    }
}

function saveDevelopText(type){
    var data=[];
    if(type == "programText"){
        data.push({"type":"programText"});
        var all=document.querySelectorAll("#programParent div.input-group");
        console.log(all);
        for(var i=0;i<all.length;i++){
            var title=all[i].children[1].value;
            var text=all[i].nextElementSibling.value;
            if((title==""&&text!="")||(title!=""&&text=="")){
                alert("填写不完整，存在标题内容只填写了其中之一");
                return;
            }else{
                if(title!=""&&text!=""){
                    data.push({"title":title,"text":text});
                }
            }
        }
    }else{
        data.push({"type":"unitTestText"});
        var all=document.querySelectorAll("#unitTestParent div.input-group");
        for(var i=0;i<all.length;i++){
            var title=all[i].children[1].value;
            var text=all[i].nextElementSibling.value;
            if((title==""&&text!="")||(title!=""&&text=="")){
                alert("填写不完整，存在标题内容只填写了其中之一");
                return;
            }else{
                if(title!=""&&text!=""){
                    data.push({"title":title,"text":text});
                }
            }
        }
    }
    $.ajax({
        url: "/pms/projectDevelopTextSubmit",
        type: "POST",
        data: {"data":JSON.stringify(data)},
        dataType: "json",
        success:function(response){
            if(response.status == "1"){
                for(var i=1;i<data.length;i++){
                    if(data[0]["type"]=="programText"){
                        if(i==1)
                            $("#projectProgramArea").val("");
                        $("#projectProgramArea").val($("#projectProgramArea").val()+data[i]["title"]+"\r\n"+data[i]["text"]+"\r\n\r\n");
                    }else{
                        if(i==1)
                            $("#projectUnitTestArea").val("");
                        $("#projectUnitTestArea").val($("#projectUnitTestArea").val()+data[i]["title"]+"\r\n"+data[i]["text"]+"\r\n\r\n");
                    }
                }
                if(type == "programText")
                    $("#programModal").modal("hide");
                else
                    $("#unitTestModal").modal("hide");
            }
        },error:function(response){
            alert("保存数据失败");
        }
    });
}
