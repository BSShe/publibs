function openFile(){
    $("#file").click();
}

function getFilePath(){
    if($("#file").val()!=""){
        var name=$("#file").val().split("\\");
        $("#filePath").text(name[name.length-1]);
    }
}

function fileUploadBtn(){
    $("#fileChoose #modal-title").text("需求文档上传");
    $("#fileChoose").modal("show");
}

function fileDownloadBtn(){
    fileName=$("#fileNames").val();
    id=$("#id").val();
    var form=document.createElement("form");
    form.action="/pms/projectAnalysisDownload";
    form.method="POST";
    form.style.display="none";
    var input1=document.createElement("input");
    input1.name="fileName";
    input1.value=fileName;
    var input2=document.createElement("input");
    input2.name="id";
    input2.value=id;
    form.appendChild(input1);
    form.appendChild(input2);
    document.body.appendChild(form);
    form.submit();
}

function anaylsisChangeBtn(){
    getAnalysisText($("#radioBox :radio:checked").val());
    $("#anaylsisSubmit").modal("show");
}

function anaylsisSubmitBtn(){
    if($("#analysisText").val()==""){
        alert("没有内容需要提交");
        return;
    }else{
        var data={"analysisText":$("#analysisText").val(),"type":$("#radioBox :radio:checked").val()};
        $.ajax({
            url: "/pms/projectAnalysisUpdate",
            type: "POST",
            data: data,
            dataType:"json",
            success:function(response){
                if(response.status==1){
                    if($("#radioBox :radio:checked").val()== "4"){
                        $("#confirm").val($("#analysisText").val());
                    }else{
                        changeAnalysisAreaValue();
                    }
                    alert("需求提交成功");
                    $("#anaylsisSubmit").modal("hide");
                }else{
                    alert("需求提交失败");
                }
            },
            error:function(response){
                alert("需求提交失败");
            }
        });
    }

}

function changeAnalysisAreaValue(){
    var data={"type":"5"};
    $.ajax({
        url: "/pms/projectAnalysisTextGet",
        type: "POST",
        data: data,
        dataType:"json",
        success:function(response){
            $("#analysis").val(response.text);
        },error:function(){
            
        }
    });
}

function getAnalysisText(type){
    var data={"type":type};
    $.ajax({
        url: "/pms/projectAnalysisTextGet",
        type: "POST",
        data: data,
        dataType: "json",
        success: function(response){
           $("#analysisText").val(response.text);
        },error: function(response){
            alert("获取数据失败");
        }
    });
}

function sendFile(){
    if($("#file").val()==""){
        alert("请选择文件！");
    }else{
        var file=$("#file")[0].files[0];
        startToSend(file,1);
        $("#fileChoose").modal("hide");
        $("#fileNames").css("display","none");
        $("#progressParent").css("display","block");
        $("#upload").attr("disabled","disabled");
    }
}

function startToSend(file,num){
    var formData=new FormData();
    var blockSize= 1024*1024*2;
    var blockNum=Math.ceil(file.size / blockSize);
    var nextSize= Math.min(num * blockSize,file.size);
    var fileData= file.slice((num-1)*blockSize,nextSize);
    formData.append("file",fileData);
    formData.append("fileName",$("#filePath").text());
    formData.append("id",$("#id").val());
    formData.append("num",num);
    $.ajax({
        url: "/pms/projectAnalysisUpload",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function(response){
            $("#progress").css("width",(num*100)/blockNum +"%");
            $("#progress").text(((num*100)/blockNum).toFixed(2) +"%");
            if(nextSize>=file.size){
                checkFileUploadSuccess($("#id").val(),$("#filePath").text(),file.size,1);
                return;
            }
            startToSend(file,num+1);
        },error:function(response){
            alert("上传失败");
            $("#fileNames").css("display","block");
            $("#progressParent").css("display","none");
            $("#progress").css("width","0%");
            checkFileUploadSuccess($("#id").val(),$("#filePath").text(),file.size,0);
        }
    });
}

function checkFileUploadSuccess(id,fileName,fileSize,isWarn){
    var data={"id":id,"fileName":fileName,"fileSize":fileSize};
    $.ajax({
        url: "/pms/projectAnalysisCheckFile",
        type: "POST",
        data: data,
        dataType: "json",
        success:function(response){
            $("#upload").removeAttr("disabled");
            if(isWarn == 1){
                if(response.status == 1){
                    deleteAnalysisFile(fileName);
                    $("#fileNames").html("<option>"+fileName+"</option>"+$("#fileNames").html())
                    $("#fileNames").css("display","block");
                    $("#progressParent").css("display","none");
                    $("#download").removeAttr("disabled");
                    $("#progress").css("width","0%");
                    alert("上传成功");
                }else{
                    alert("文件完整性校验失败");
                    $("#fileNames").css("display","block");
                    $("#progressParent").css("display","none");
                    $("#progress").css("width","0%");
                }
            }
        }
    });
}

function deleteAnalysisFile(fileName){
    var fileNodes=document.getElementsByTagName("option");
    for(var i=0;i<fileNodes.length;i++){
        if(fileNodes[i].innerText == fileName){
            fileNodes[i].remove();
            return;
        }
    }
}
