function details_info1(arg){
    alert("test")
}
 
function details_info2(arg){
    var data={"id":arg};
    $.ajax({
        url: "/pms/projectAnalysis",
        type: "post",
        data: data,
        dataType: "html",
        async: false,
        success:function(response){
            $("#content").html(response);
        },
        error: function (response) {
            alert("查看需求确认失败");
        }
    });
} 

function details_info3(arg){
    var data={"id":arg};
    $.ajax({
        url: "/pms/projectJumpToDesign",
        type: "post",
        data: data,
        dataType: "html",
        async: false,
        success:function(response){
            $("#content").html(response);
        },
        error: function (response) {
            alert("查看方案设计失败");
        }
    });
} 

function details_info4(arg){
    var data={"id":arg};
    $.ajax({
        url: "/pms/projectDevelop",
        type: "post",
        data: data,
        dataType: "html",
        async: false,
        success:function(response){
            $("#content").html(response);
        },
        error: function (response) {
            alert("查看开发实现失败");
        }
    });
} 

function details_info5(arg){
    alert("test5")
} 

function details_info6(arg){
    alert("test6")
} 

function details_info7(arg){
    alert("test7")
} 

function details_info8(arg){
    alert("test8")
} 

function details_info9(arg){
    alert("test9")
} 

function details_info10(arg){
    var data={"id":arg};
    $.ajax({
        url: "/pms/projectMaintenance",
        type: "post",
        data: data,
        dataType: "html",
        async: false,
        success:function(response){
            $("#content").html(response);
        },
        error: function (response) {
            alert("查看项目维护失败");
        }
    });
}  
