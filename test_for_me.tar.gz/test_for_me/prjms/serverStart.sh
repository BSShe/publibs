#日志文件在 当前目录 log/ 文件夹下面
nohup python ownServer.py  > /dev/null 2>&1 &
tail -f log/main.log

