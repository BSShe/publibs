# -*- coding: utf-8 -*-
"""
the url define for web
"""
from handlers.pmsManager.projectManager import ShowNextInfoHandler


from handlers.index import LoginHandler ,LoginOutHandler, IndexHandler,UpPassWdHandler , PageNotFoundHandler 
from handlers.paramManage.orgManage import OrgListHandler, OrgDelHandler, OrgBfUpdateHandler, OrgToUpdateHandler, OrgToAddHandler, OrgUserListHandler, OrgExportInfoHandler
from handlers.paramManage.userManage import UserListHandler, UserDelHandler, UserResetPassWdHandler ,UserBfUpdateHandler, UserToUpdateHandler, UserToAddHandler, UserBfAddOrgIdHandler, UserExportInfoHandler
from handlers.queryAndForms.queryManger import queryListHandler, queryDelHandler, queryBfUpdateHandler, queryToUpdateHandler, queryToAddHandler, queryUserListHandler
from handlers.queryAndForms.formsManager import formsListHandler, formsDelHandler, formsBfUpdateHandler, formsToUpdateHandler, formsToAddHandler 
from handlers.supplierManage.srEvaluateManage import SrEvaluateListHandler, SrEvaluateBfUpdateHandler, SrEvaluateToUpdateHandler, SrEvaluateExportInfoHandler
from handlers.supplierManage.qualifyManage import QualifyListHandler , QualifyBfUpdateHandler, QualifyToUpdateHandler, QualifyAddFileHandler, QualifyFileListHandler, QualifyDownFileHandler, QualifyExportInfoHandler, QualifyGetUserPhoneHandler 
from handlers.userManage.urEvaluateManage import UrEvaluateListHandler,UrEvaluateBfUpdateHandler, UrEvaluateToUpdateHandler, UrEvaluateExportInfoHandler,UrEvaluateShowChartHandler 
from handlers.userManage.checkInManage import CheckInListHandler, CheckInAloneListHandler,NCIDListHandler,SEListHandler,XEListHandler,CheckInExportInfoHandler 
from handlers.paramManage.sysParam.sysParamManage  import ParamListHandler
from handlers.paramManage.roleManage import RoleListHandler, RoleToAddHandler,RoleBfUpdateHandler,RoleToUpdateHandler,RoleDelHandler, RoleGetAuthHandler,RoleGetBranchHandler, RoleToUpdateMenuHandler,RoleToUpdateBranchHandler, RolebyAuthGetButtonListHandler
from handlers.paramManage.sysParam.sysParamManageOrgType  import OrgTypeListHandler, OrgTypeToAddHandler,OrgTypeBfUpdateHandler,OrgTypeToUpdateHandler
from handlers.paramManage.sysParam.sysParamManageStatus  import StatusListHandler, StatusToAddHandler,StatusBfUpdateHandler,StatusToUpdateHandler
from handlers.paramManage.sysParam.sysParamManageTime  import TimeListHandler, TimeBfUpdateHandler, TimeToUpdateHandler
from handlers.paramManage.sysParam.sysParamManageProjectType  import ProjectTypeListHandler, ProjectTypeToAddHandler,ProjectTypeBfUpdateHandler,ProjectTypeToUpdateHandler
from handlers.paramManage.sysParam.sysParamManageProjectProperty  import ProjectPropertyListHandler, ProjectPropertyToAddHandler,ProjectPropertyBfUpdateHandler,ProjectPropertyToUpdateHandler
from handlers.paramManage.sysParam.sysParamManageProjectStage  import ProjectStageListHandler, ProjectStageBfUpdateHandler,ProjectStageToUpdateHandler, ProjectStageDownDocHandler,ProjectStageChildHandler,ProjectStageChildToAddHandler,ProjectStageChildToUpdateHandler,\
                                                                      ProjectStageChildBfUpdateHandler,ProjectStageChildToDelHandler 
from handlers.paramManage.sysParam.sysParamManageUserEvaluate import UserEvaluateListHandler, UserEvaluateBfUpdateHandler, UserEvaluateToUpdateHandler 
from handlers.paramManage.sysParam.sysParamManageProjectEvaluate import ProjectEvaluateListHandler, ProjectEvaluateBfUpdateHandler, ProjectEvaluateToUpdateHandler 
from handlers.paramManage.sysParam.sysParamManageSupplierEvaluate import SupplierEvaluateListHandler, SupplierEvaluateBfUpdateHandler, SupplierEvaluateToUpdateHandler 
from handlers.paramManage.sysParam.sysParamManageRiskWarnValue import RiskWarnValueListHandler, RiskWarnValueBfUpdateHandler, RiskWarnValueToUpdateHandler ,RiskWarnRemindUserHandler, RiskWarnRecordRemindHandler

from handlers.py_add.pmsTest import pmsTestHandler,pmsTestFileUploadHandler,pmsTestFileCheckSuccessHandler,pmsTestFileDownloadHandler,pmsTestGetTextHandler,pmsTestTextSubmitHandler

from handlers.pmsManager.projectManager import projectListHandler,projectDelHandler,projectBfUpdateHandler,projectToUpdateHandler,projectToAddHandler,projectProListHandler,ShowNextInfoHandler
from handlers.pmsManager.projectPlan import projectPlanListHandler,projectPlanDelHandler,projectPlanUpdateHandler,projectPlanToUpdateHandler,projectPlanToAddHandler,projectPlanProListHandler
from handlers.pmsManager.projectWork import projectWorkListHandler
from handlers.pmsManager.projectComment import projectCommentListHandler,projectCommentBfUpdateHandler,projectCommentToAddHandler,projectCommentProListHandler,projectCommentHandler,projectCommentToUpdateHandler

from handlers.pmsManager.projectManager_detail import projectDetail2Handler
from handlers.wx_handlers.wx_sign import signlogin,signcode,sign
from handlers.py_add.pmsSPre import *
from handlers.py_add.projectManageMessage import projectJumpToManageMessageHandler,projectManageChangeTypeHandler
from handlers.py_add.ws_Message import WSMessageHandler
from handlers.py_add.projectChat import GetInitInfoHandler,GetMembersHandler,GetMessageCountHandler,GetChatMessageHandler,SetSelfSignHandler
from handlers.py_add.projectDetail import projectJumpToDetailHandler,projectDetailChartInfoHandler
from handlers.py_add.projectManageReport import ManageReportIndexHandler,GetProjectListHandler,RefreshTotalInfoHandler,ShowUserEvaluateHandler
from handlers.py_add.projectSingleReport import SingleProjectReportHandler,SingleProChartInfoHandler
from handlers.py_add.userEvaluation import GetUserEvInfoHandler
from handlers.py_add.projectChildManage import ChildManageIndexHandler,ChildWatchMoreHandler,ChildWatchChartHandler,GetFCodeInfoHandler
from handlers.py_add.projectChildDetail import ChildDetailIndexHandler
from handlers.py_add.projectChildPlan import ChildPlanIndexHandler
#ssb
from handlers.pmsManager.ssb_project_plan import projectPreparationHandler,projectPreDataHandler,getProjectPreDataHandler,timeAndDevMCommitHandler,devChildUserCommitHandler,resAndDevCommitHandler,getAllManHandler,getChildBranchPersonHandler
from handlers.pmsManager.ssb_project_msg import getUserIdHandler
from handlers.pmsManager.ssb_project_msg_detail import manageMessageListHandler,projectMsgProListHandler,setManyMsgStatusHandler
from handlers.pmsManager.ssb_project_log import manageLogHandler,logPageHandler,getmanageWorkLogListHandler,getLogDetailsHandler,getLogDetailsForWatchHandler
from handlers.pmsManager.ssb_project_commes import projectCommesHandler,saveProjectCommesHandler
from handlers.pmsManager.ssb_manage_index import getIndexHandler
from handlers.pmsManager.ssb_project_status_change import stopTheProjectHandler,getStopProjectInfo
from handlers.pmsManager.projectChild import *
from handlers.pmsManager.ssb_pmsProjectSelect import getPmsProjectSelectHandler 



from handlers.contractManage.contractManage import ContractListHandler, ContractDelHandler, ContractBfUpdateHandler, ContractToUpdateHandler, \
                                                    ContractToAddHandler,ContractStageListHandler,ContractItemListHandler, ContractAddStageHandler, ContractAddItemHandler, ContractAddPayCondtnHandler, ContractBfAddPayCondtnHandler, ContractAddFileHandler, \
                                                    ContractPayCondtnListHandler, ContractFileListHandler , ContractDownFileHandler, ContractGetSupplierUserHandler
from handlers.pmsManager.xlj_projectWork_detail import ProjectWorkDtIndexHandler,ProjectWorkDtUpdate,ProjectWorkDtInfoHandler,ProjectWorkImport,ProjectWorkDownload
from handlers.pmsManager.xlj_projectWork_detail import ProjectWorkDtAddStage,ProjectWorkDtDelDev,ProjectStatusChange,GetChangeInfosHandler

url = [
    (r'/', IndexHandler),
    (r'/login', LoginHandler),
    (r'/upPassWd', UpPassWdHandler),
    (r'/signlogin',signlogin),
    (r'/signcode',signcode),
    (r'/signnow',sign),
    (r'/loginOut', LoginOutHandler),

    #参数管理-机构管理
    (r'/paramManage/manageOrgList', OrgListHandler),
    (r'/paramManage/manageOrgDel', OrgDelHandler),
    (r'/paramManage/manageOrgBfUpdate', OrgBfUpdateHandler),
    (r'/paramManage/manageOrgToUpdate', OrgToUpdateHandler),
    (r'/paramManage/manageOrgToAdd', OrgToAddHandler),
    (r'/paramManage/manageOrgList-userList', OrgUserListHandler),
    (r'/paramManage/manageOrgExportInfo', OrgExportInfoHandler),

    #参数管理-人员管理
    (r'/paramManage/manageUserList', UserListHandler),
    (r'/paramManage/manageUserDel', UserDelHandler),
    (r'/paramManage/manageUserResetPd', UserResetPassWdHandler),
    (r'/paramManage/manageUserBfAdd-orgId', UserBfAddOrgIdHandler),
    (r'/paramManage/manageUserBfUpdate', UserBfUpdateHandler),
    (r'/paramManage/manageUserToUpdate', UserToUpdateHandler),
    (r'/paramManage/manageUserToAdd', UserToAddHandler),
    (r'/paramManage/manageUserExportInfo', UserExportInfoHandler),

    #参数管理-角色权限管理
    (r'/paramManage/manageRoleList', RoleListHandler),
    (r'/paramManage/manageRoleToAdd', RoleToAddHandler),
    (r'/paramManage/manageRoleBfUpdate', RoleBfUpdateHandler),
    (r'/paramManage/manageRoleToUpdate', RoleToUpdateHandler),
    (r'/paramManage/manageRoleDel', RoleDelHandler),
    (r'/paramManage/manageRoleGetAuth', RoleGetAuthHandler),
    (r'/paramManage/manageRoleGetBranch', RoleGetBranchHandler),
    (r'/paramManage/manageRoleToUpdateMenu', RoleToUpdateMenuHandler),
    (r'/paramManage/manageRoleToUpdateBranch', RoleToUpdateBranchHandler),
    (r'/paramManage/byAuthGetButtonList', RolebyAuthGetButtonListHandler),

    #系统查询
    (r'/queryAndForms/manageQueryList', queryListHandler),
    (r'/queryAndForms/manageQueryDel', queryDelHandler),
    (r'/queryAndForms/manageQueryBfUpdate', queryBfUpdateHandler),
    (r'/queryAndForms/manageQueryToUpdate', queryToUpdateHandler),
    (r'/queryAndForms/manageQueryToAdd', queryToAddHandler),
    (r'/queryAndForms/manageQueryList-userList', queryUserListHandler),

    #管理报表
    (r'/queryAndForms/manageFormsList', formsListHandler),
    (r'/queryAndForms/manageFormsDel', formsDelHandler),
    (r'/queryAndForms/manageFormsBfUpdate', formsBfUpdateHandler),
    (r'/queryAndForms/manageFormsToUpdate', formsToUpdateHandler),
    (r'/queryAndForms/manageFormsToAdd', formsToAddHandler),

    #项目管理
    (r'/pmsManager/manageQueryList',projectListHandler),
    (r'/pmsManager/manageQueryDel',projectDelHandler),
    (r'/pmsManager/manageQueryBfUpdate',projectBfUpdateHandler),
    (r'/pmsManager/manageQueryToUpdate',projectToUpdateHandler),
    (r'/pmsManager/manageQueryToAdd',projectToAddHandler),
    (r'/pmsManager/manageQueryList-userList',projectProListHandler),
    (r'/pmsManager/projectDetail2Handler',projectDetail2Handler),
    (r'/pmsManager/showNextInfo',ShowNextInfoHandler),
    
    #ssb
    (r'/pmsManager/project_plan_index-project_preparation', projectPreparationHandler),
    (r'/pmsManager/project_plan_index-project_submit', projectPreDataHandler),
    (r'/pmsManager/getProjectPreData', getProjectPreDataHandler),
    (r'/pmsManager/getChildBranchPerson', getChildBranchPersonHandler),
    (r'/pmsManager/manageMessageList', manageMessageListHandler),
    (r'/pmsManager/setManyMsgStatus', setManyMsgStatusHandler),
    (r'/pmsManager/manageLogList',manageLogHandler),
    (r'/pmsManager/project_plan_logPage',logPageHandler),
    (r'/pmsManager/getLogDetails',getLogDetailsHandler),
    (r'/pmsManager/getLogDetailsForWatch',getLogDetailsForWatchHandler),
    (r'/pmsManager/get_userId',getUserIdHandler),
    (r'/pmsManager/getProjectCommes',projectCommesHandler),
    (r'/pmsManager/saveProjectCommes',saveProjectCommesHandler),
    (r'/jumpToIndex',getIndexHandler),
    (r'/pmsManager/timeAndDevMCommit',timeAndDevMCommitHandler),
    (r'/pmsManager/devChildUserCommit',devChildUserCommitHandler),
    (r'/pmsManager/resAndDevCommit',resAndDevCommitHandler),
    (r'/pmsManager/stopTheProject',stopTheProjectHandler),
    (r'/pmsManager/stopProjectInfo',getStopProjectInfo),
    (r'/pmsMsg/projectMsgProList',projectMsgProListHandler),
    (r'/pmsManager/getPmsProjectSelect',getPmsProjectSelectHandler),
    (r'/pmsManager/manageWorkLogList',getmanageWorkLogListHandler),
    (r'/pmsManager/checkPlanTime',CheckPlanTimeHandler),
    (r'/pmsManager/getAllMan',getAllManHandler),

    #子任务阶段
    (r'/pmsManager/projectChildFaildHandler',projectChildFaildHandler),
    (r'/pmsManager/ProjectChildFaildSubmitHandler',ProjectChildFaildSubmitHandler),
    (r'/pmsManager/projectFileUpload',projectChildFieldFileUploadHandler),
    (r'/pmsManager/projectFileDownload',projectChildFieldFileDownloadHandler),
    (r'/pmsManager/projectFileDelete',ProjectDeleteFileHandler),
    (r'/pmsManager/projectFilePreview',ProjectPreviewFileHandler),
    (r'/pmsManager/projectFinishStage',ProjectFinishDevelopHandler),
    (r'/pmsManager/projectTemplateCheck',ProjectChildCheckTemplateHandler),
    (r'/pmsManager/projectTemplateDownload',ProjectChildTemplateDownloadHandler),
    #项目测试
    (r'/pms/projectTest',pmsTestHandler),
    (r'/pms/projectTestFileUpload',pmsTestFileUploadHandler),
    (r'/pms/projectTestFileCheckSuccess',pmsTestFileCheckSuccessHandler),
    (r'/pms/projectTestFileDownload',pmsTestFileDownloadHandler),
    (r'/pms/projectTestGetText',pmsTestGetTextHandler),
    (r'/pms/projectTestSubmit',pmsTestTextSubmitHandler),
    #项目计划安排
    (r'/pmsManagerWork/projectPlanDetailHandler',ProjectWorkDtIndexHandler),
    (r'/pmsManagerWork/projectWorkDtUpdate',ProjectWorkDtUpdate),
    (r'/pmsManagerWork/projectGetDevInfo',ProjectWorkDtInfoHandler),
    (r'/pmsManagerWorkIMP/projectStageAdd',ProjectWorkDtAddStage),
    (r'/pmsManagerWorkIMP/projectDelDev',ProjectWorkDtDelDev),
    (r'/pmsManagerWorkIMP/projectStChange',ProjectStatusChange),
    (r'/pmsManagerWorkIMP/changeInfos',GetChangeInfosHandler),
    (r'/pmsManagerWork/workDownload',ProjectWorkDownload),
    (r'/pmsManagerWork/workImport',ProjectWorkImport),
    #项目计划
    (r'/pmsManagerPlan/manageQueryList',projectPlanListHandler),
    (r'/pmsManagerPlan/manageQueryDel',projectPlanDelHandler),
    (r'/pmsManagerPlan/manageQueryUpdate',projectPlanUpdateHandler),
    (r'/pmsManagerPlan/manageQueryToUpdate',projectPlanToUpdateHandler),
    (r'/pmsManagerPlan/manageQueryToAdd',projectPlanToAddHandler),
    (r'/pmsManagerPlan/manageQueryList-userList',projectPlanProListHandler),
    #项目报告
    (r'/pmsManagerWork/projectWorkListHandler',projectWorkListHandler),
    #项目评价
    (r'/pmsComment/manageQueryList',projectCommentListHandler),
    (r'/pmsComment/manageQueryBfUpdate',projectCommentBfUpdateHandler),
    (r'/pmsComment/manageQueryToAdd',projectCommentToAddHandler),
    (r'/pmsComment/manageQueryList-userList',projectCommentProListHandler),
    (r'/pmsComment/projectCommentHandler',projectCommentHandler),
    (r'/pmsComment/projectCommentToUpdateHandler',projectCommentToUpdateHandler),
    #供应商资质管理
    (r'/supplierManage/manageQualifyList', QualifyListHandler),
    (r'/supplierManage/manageQualifyBfUpdate', QualifyBfUpdateHandler),
    (r'/supplierManage/manageQualifyToUpdate', QualifyToUpdateHandler),
    (r'/supplierManage/manageQualifyAddFile', QualifyAddFileHandler),
    (r'/supplierManage/manageQualifyFileList', QualifyFileListHandler),
    (r'/supplierManage/manageQualifydownFile', QualifyDownFileHandler),
    (r'/supplierManage/manageQualifyExportInfo', QualifyExportInfoHandler),
    (r'/supplierManage/manageQualifyGetUserPhone', QualifyGetUserPhoneHandler),

    #供应商评价管理
    (r'/supplierManage/supplierEvaluateList', SrEvaluateListHandler),
    (r'/supplierManage/supplierEvaluateBfUpdate', SrEvaluateBfUpdateHandler),
    (r'/supplierManage/supplierEvaluateToUpdate', SrEvaluateToUpdateHandler),
    (r'/supplierManage/supplierEvaluateExportInfo', SrEvaluateExportInfoHandler),

    #参数管理-系统参数管理列表
    (r'/paramManage/manageParamList', ParamListHandler),

    #参数管理-系统参数管理-基础参数类-机构类型信息
    (r'/paramManage/manageParamList-org_typeList', OrgTypeListHandler),
    (r'/paramManage/manageParamList-org_typeToAdd', OrgTypeToAddHandler),
    (r'/paramManage/manageParamList-org_typeBfUpdate', OrgTypeBfUpdateHandler),
    (r'/paramManage/manageParamList-org_typeToUpdate', OrgTypeToUpdateHandler),

    #参数管理-系统参数管理-基础参数类-状态信息
    (r'/paramManage/manageParamList-statusList', StatusListHandler),
    (r'/paramManage/manageParamList-statusToAdd', StatusToAddHandler),
    (r'/paramManage/manageParamList-statusBfUpdate', StatusBfUpdateHandler),
    (r'/paramManage/manageParamList-statusToUpdate', StatusToUpdateHandler),

    #参数管理-系统参数管理-基础参数类-状态信息
    (r'/paramManage/manageParamList-timeList', TimeListHandler),
    (r'/paramManage/manageParamList-timeBfUpdate', TimeBfUpdateHandler),
    (r'/paramManage/manageParamList-timeToUpdate', TimeToUpdateHandler),

    #参数管理-系统参数管理-项目管理类-项目类型
    (r'/paramManage/manageParamList-project_typeList', ProjectTypeListHandler),
    (r'/paramManage/manageParamList-project_typeToAdd', ProjectTypeToAddHandler),
    (r'/paramManage/manageParamList-project_typeBfUpdate', ProjectTypeBfUpdateHandler),
    (r'/paramManage/manageParamList-project_typeToUpdate', ProjectTypeToUpdateHandler),

    #参数管理-系统参数管理-项目管理类-项目性质
    (r'/paramManage/manageParamList-project_propertyList', ProjectPropertyListHandler),
    (r'/paramManage/manageParamList-project_propertyToAdd', ProjectPropertyToAddHandler),
    (r'/paramManage/manageParamList-project_propertyBfUpdate', ProjectPropertyBfUpdateHandler),
    (r'/paramManage/manageParamList-project_propertyToUpdate', ProjectPropertyToUpdateHandler),

    #参数管理-系统参数管理-项目管理类-项目阶段
    (r'/paramManage/manageParamList-project_stageList', ProjectStageListHandler),
    (r'/paramManage/manageParamList-project_stageBfUpdate', ProjectStageBfUpdateHandler),
    (r'/paramManage/manageParamList-project_stageToUpdate', ProjectStageToUpdateHandler),
    (r'/paramManage/manageParamList-project_stageDownDoc', ProjectStageDownDocHandler),
    (r'/paramManage/manageParamList-project_stage_child', ProjectStageChildHandler),
    (r'/paramManage/manageParamList-project_stage_childToAdd', ProjectStageChildToAddHandler),
    (r'/paramManage/manageParamList-project_stage_childToUpdate', ProjectStageChildToUpdateHandler),
    (r'/paramManage/manageParamList-project_stage_childBfUpdate', ProjectStageChildBfUpdateHandler),
    (r'/paramManage/manageParamList-project_stage_childToDel', ProjectStageChildToDelHandler),

    #参数管理-系统参数管理-评价模型类-人员评价参数设定
    (r'/paramManage/manageParamList-user_evaluateList', UserEvaluateListHandler),
    (r'/paramManage/manageParamList-user_evaluateBfUpdate', UserEvaluateBfUpdateHandler),
    (r'/paramManage/manageParamList-user_evaluateToUpdate', UserEvaluateToUpdateHandler),

    #参数管理-系统参数管理-评价模型类-项目评价参数设定
    (r'/paramManage/manageParamList-project_evaluateList', ProjectEvaluateListHandler),
    (r'/paramManage/manageParamList-project_evaluateBfUpdate', ProjectEvaluateBfUpdateHandler),
    (r'/paramManage/manageParamList-project_evaluateToUpdate', ProjectEvaluateToUpdateHandler),

    #参数管理-系统参数管理-评价模型类-供应商评价参数设定
    (r'/paramManage/manageParamList-supplier_evaluateList', SupplierEvaluateListHandler),
    (r'/paramManage/manageParamList-supplier_evaluateBfUpdate', SupplierEvaluateBfUpdateHandler),
    (r'/paramManage/manageParamList-supplier_evaluateToUpdate', SupplierEvaluateToUpdateHandler),

    #参数管理-系统参数管理-评价模型类-风险预警值设定
    (r'/paramManage/manageParamList-riskWarnValueList', RiskWarnValueListHandler),
    (r'/paramManage/manageParamList-riskWarnValueBfUpdate', RiskWarnValueBfUpdateHandler),
    (r'/paramManage/manageParamList-riskWarnValueToUpdate', RiskWarnValueToUpdateHandler),
    (r'/paramManage/manageParamList-riskWarnRemindUser', RiskWarnRemindUserHandler),
    (r'/paramManage/manageParamList-riskWarnRecordRemind', RiskWarnRecordRemindHandler),

    #合同管理-一般项目合同管理
    (r'/contractManage/manageContractList', ContractListHandler),
    (r'/contractManage/manageContractDel', ContractDelHandler),
    (r'/contractManage/manageContractBfUpdate', ContractBfUpdateHandler),
    (r'/contractManage/manageContractToUpdate', ContractToUpdateHandler),
    (r'/contractManage/manageContractToAdd', ContractToAddHandler),
    (r'/contractManage/manageContractGetSupplierUser', ContractGetSupplierUserHandler),

    #合同管理-一般项目合同管理-阶段、详特别约定事项、付款、文档详情信息
    (r'/contractManage/manage-contract-StageList', ContractStageListHandler),
    (r'/contractManage/manage-contract-ItemList', ContractItemListHandler),
    (r'/contractManage/manage-contract-PayCondtnList', ContractPayCondtnListHandler),
    (r'/contractManage/manage-contract-FileList', ContractFileListHandler),
    (r'/contractManage/manage-contract-downContractFile', ContractDownFileHandler),

    #合同管理-一般项目合同管理-添加 阶段、详特别约定事项、付款、文档信息
    (r'/contractManage/manage-contract-AddStage', ContractAddStageHandler),
    (r'/contractManage/manage-contract-AddItem', ContractAddItemHandler),
    (r'/contractManage/manage-contract-AddPayCondtn', ContractAddPayCondtnHandler),
    (r'/contractManage/manageContractBfAddPayCondtn', ContractBfAddPayCondtnHandler),
    (r'/contractManage/manage-contract-AddFile', ContractAddFileHandler),

    #人员管理-人员评价管理
    (r'/userManage/userEvaluateList', UrEvaluateListHandler),
    (r'/userManage/userEvaluateBfUpdate', UrEvaluateBfUpdateHandler),
    (r'/userManage/userEvaluateToUpdate', UrEvaluateToUpdateHandler),
    (r'/userManage/userEvaluateExportInfo', UrEvaluateExportInfoHandler),
    (r'/userManage/userEvaluateShowChart', UrEvaluateShowChartHandler),

    
    #人员管理-人员考勤管理
    (r'/userManage/userCheckInList', CheckInListHandler),
    (r'/userManage/userCheckInAloneList', CheckInAloneListHandler),
    (r'/userManage/userNCIDList', NCIDListHandler),
    (r'/userManage/userSEList', SEListHandler),
    (r'/userManage/userXEList', XEListHandler),
    (r'/userManage/userCheckInExportInfo', CheckInExportInfoHandler),

    (r'/paramManage/', ParamListHandler),
    #项目上线准备
    (r'/pms/pmsSPre',pmsSPreHandler),
    (r'/pms/pmsSPreFileUpload',pmsSPreFileUploadHandler),
    (r'/pms/pmsSPreFileCheckSuccess',pmsSPreFileCheckSuccessHandler),
    (r'/pms/pmsSPreFileDownload',pmsSPreFileDownloadHandler),
    (r'/pms/pmsSPreGetText',pmsSPreGetTextHandler),
    (r'/pms/pmsSPreTextSubmit',pmsSPreTextSubmitHandler),
    (r'/pms/pmsSPre/check',pmsSPreCheckTemplateHandler),
    (r'/pms/pmsSPre/downloadTemplate',pmsSPreTemplateDownloadHandler),
    (r'/pms/pmsSPre/finish',pmsSPrefinshHandler),    
    #项目消息
    (r'/pms/projectWSChat',WSMessageHandler),
    (r'/pms/projectChangeType',projectManageChangeTypeHandler),
    #layim start
    (r'/pms/projectInitChat',GetInitInfoHandler),
    (r'/pms/projectGetMembers',GetMembersHandler),
    (r'/pms/projectGetMessageCount',GetMessageCountHandler),
    (r'/pms/projectChatMessage',GetChatMessageHandler),
    (r'/pms/projectChangeSign',SetSelfSignHandler),
    #工作进度图
    (r'/pms/projectDetail',projectJumpToDetailHandler),
    (r'/pms/projectDetailChartInfo',projectDetailChartInfoHandler),
    #子项目
    (r'/pms/projectChildManageIndex',ChildManageIndexHandler),
    (r'/pms/projectChildDetailIndex',ChildDetailIndexHandler),
    (r'/pms/projectChildPlan',ChildPlanIndexHandler),
    (r'/pms/projectWatchMore',ChildWatchMoreHandler),
    (r'/pms/projectWatchChart',ChildWatchChartHandler),
    (r'/pms/projectGetFCodes',GetFCodeInfoHandler),
    #报表管理-xlj
    (r'/pms/projectManageReport',ManageReportIndexHandler),
    (r'/pms/projectGetProject',GetProjectListHandler),
    (r'/pms/refreshTotalInfo',RefreshTotalInfoHandler),
    (r'/pms/showUserEvaluate',ShowUserEvaluateHandler),
    (r'/pms/getUserEvInfo',GetUserEvInfoHandler),
    (r'/pms/singleProjectReport',SingleProjectReportHandler),
    (r'/pms/singleProChartInfo',SingleProChartInfoHandler),
    (r'.*', PageNotFoundHandler),




]
