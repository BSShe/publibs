# -*- coding: utf-8 -*-

import os
import tornado.ioloop
import tornado.options
import tornado.httpserver
import tornado.web
from tornado.options import define, options
from url import url
from config import config

define("port", default = 8001, help = "run on the given port", type = int)

def main():
    settings = dict(
        template_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),"templates"),
        static_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),"static"),
        xsrf_cookies=False,
        cookie_secret=config.SECRET
    )
    
    application = tornado.web.Application(
        handlers = url,
        **settings,
        debug = True, #调试模式 上线注释-------
        login_url = '/login'
    )
    tornado.options.parse_command_line()
    http_server = tornado.httpserver.HTTPServer(application)
    http_server.listen(options.port)
    print ("PMS Server run on http://127.0.0.1:%s" %options.port)
    print ("you can close it with Control-C")
    tornado.ioloop.IOLoop.instance().start()

if __name__ == "__main__":
    main()
    
