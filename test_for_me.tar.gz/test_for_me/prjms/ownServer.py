# -*- coding: utf-8 -*-

import os
import tornado.ioloop
import tornado.options
import tornado.httpserver
import tornado.web
import tornado.log
import logging
from tornado.options import define, options
from url import url
from config import config, cronWork
from apscheduler.schedulers.tornado import TornadoScheduler

define("port", default = 8030, help = "run on the given port", type = int)

class LogFormatter(tornado.log.LogFormatter):
    def __init__(self):
        super(LogFormatter, self).__init__(
            fmt='%(color)s[%(asctime)s %(levelname)s]%(end_color)s %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )

def main():
    settings = dict(
        template_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),"templates"),
        static_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),"static"),
        xsrf_cookies = False,
        cookie_secret = config.SECRET
    )
    
    application = tornado.web.Application(
        handlers = url,
        **settings,
        debug = True, #调试模式 上线注释-------
        login_url = '/login'
    )
    #----------日志存储至文件并按天分割-----------
    tornado.options.define("log_file_prefix",default="./log/main.log")
    tornado.options.define("log_rotate_mode",default='time')
    tornado.options.define("log_rotate_when",default='D')
    tornado.options.define("log_rotate_interval",default=7)

    tornado.options.parse_command_line()
    [i.setFormatter(LogFormatter()) for i in logging.getLogger().handlers]
    http_server = tornado.httpserver.HTTPServer(application)
    http_server.listen(options.port)

    scheduler = TornadoScheduler()
    scheduler.add_job(cronWork.recover_user_discipline, 'cron', day='1', hour='02', minute='00', second='05' )# 每月一号凌晨两点,清空用户表的本月纪律情况字段,开始新的一个月
    scheduler.add_job(cronWork.count_user_evaluation_score, 'cron', day_of_week='0-6', hour='23', minute='30', second='05' )# 每天23点半 自动计算并更新人员评价汇总表数据
    scheduler.add_job(cronWork.count_supplier_evaluation_score, 'cron', day_of_week='0-6', hour='23', minute='50', second='05' )# 每天23点50分 自动计算并更新供应商评价汇总表数据
    scheduler.add_job(cronWork.register_for_exempt_ck_in_user, 'cron', day_of_week='0-4', hour='07', minute='00', second='05', args=['01'])# 免考勤用户 周一至周五定时自动上午上班打卡
    scheduler.add_job(cronWork.register_for_exempt_ck_in_user, 'cron', day_of_week='0-4', hour='07', minute='00', second='15', args=['02'])# 免考勤用户 周一至周五定时自动上午下班打卡
    scheduler.add_job(cronWork.register_for_exempt_ck_in_user, 'cron', day_of_week='0-4', hour='07', minute='00', second='25', args=['04'])# 免考勤用户 周一至周五定时自动下午下班打卡
    scheduler.add_job(cronWork.register_for_exempt_ck_in_user, 'cron', day_of_week='0-4', hour='07', minute='00', second='35', args=['05'])# 免考勤用户 周一至周五定时自动下午下班打卡
    #scheduler.add_job(cronWork.count_supplier_evaluation_score, 'interval', seconds=2)
    scheduler.start()
    logging.info("PMS Server run on http://127.0.0.1:%s" %options.port)
    tornado.ioloop.IOLoop.instance().start()

if __name__ == "__main__":
    main()
    
