# -*- coding: utf-8 -*-

import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts
import os

class pmsChildHandler(BaseHandler):
    #打开子项目功能界面
    @tornado.web.authenticated
    def post(self):
        id=self.get_argument("id")
        sql = "select * from pms_child_project where pro_id = %s"%id
        data = rd.select(sql)
        self.render("pmsManager/html_add/pmsTest.html",id=id,data1=message1,data2=None,data3=None,data4=None,files=files)



class pmsChildTextSubmitHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        data=self.get_argument("data")
        project_id = self.get_argument('project_id')
        stage_id =self.get_argument('project_stage_id')
        user_id = self.session['id']
        data=json.loads(data)
        print (data)
         
        #此处将数据填入后台内容
        #此处查询对应的项目阶段并将阶段的项目进度报告值录入
        #添加表，表对应5个content参数，分别根据对应的阶段输入,绑定对应的阶段id
        sql = 'select * from pms_project_dev_report where dev_id = stage_id'%stage_id
        stage = rd.select(sql)
        if len(stage)>0:
            sql2 = 'update pms_project_dev_report (message1) to (%s) where dev_id = %s'%(stage_id,data)
        else:
            sql2 = 'insert pms_project_dev_report (id,message1) values(seq_pms_project_dev_report.nextval,%s) where id = %s'%(data,stage_id)
        rd.insert(sql2)
        self.write({"status":"1"})
