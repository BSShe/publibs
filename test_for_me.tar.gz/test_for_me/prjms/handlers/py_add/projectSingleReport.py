import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts
import os
from handlers.py_add.projectDetail import getProjectDevInfo,getProgress,getRealWorkLoad,getProjectDevStatus,getAllPersonInProject,getAllPersonInBranch
from handlers.pmsManager.projectComment import comment_sub

class SingleProjectReportHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument("id")
        projectName = self.get_argument("projectName")
        projectDevInfo = getProjectDevInfo(id)
        page = self.get_argument("page")
        sql = """
             select pms_contract.contract_amount,pms_project_property.name pro_name,pms_project_type.name type_name from pms_project
left join pms_contract on pms_contract.code = pms_project.HT_CODE
left join pms_project_property on pms_project_property.ID = pms_project.pms_project_property_id
left join pms_project_type on pms_project_type.id = pms_project.pms_pro_type_id
where pms_project.id =
                """
        sql = sql + id
        result = rd.select(sql)
        (code,pro_code,pro_mes_code) = comment_sub(id)
        self.render("html_add/pmsSingleProjectReport.html",id=id,projectName=projectName,projectInfo=result[0],projectDevInfo=projectDevInfo,page=page,code = code,pro_code = pro_code,pro_mes_code = pro_mes_code)


class SingleProChartInfoHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument("id")
        chartInfo = getProgress(id)
        realWorkLoad = getRealWorkLoad(id)
        chartInfo['realWorkLoad'] = realWorkLoad[0]['real_work_time']
        devStatus = getProjectDevStatus(id)
        chartInfo['finish_dev'] = devStatus['ok']
        chartInfo['undo_dev'] = devStatus['undo']
        personCount = getAllPersonInProject(id)
        chartInfo['total'] = personCount['total']
        chartInfo['own'] = personCount['own']
        for i in range(6):
            chartInfo[str(i)] = getAllPersonInBranch(id)[i]
        
        self.write(chartInfo)
