import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts


def checkToRisk(user_id,handler):
    projctDevRisk(user_id,handler)
    projctQualityRisk(user_id,handler)
    projectRisk(user_id,handler)


def projectRisk(user_id,handler):
    
    sql = """
            select pj.id from pms_project pj
            left join pms_pro_status pps on pps.ID = pj.status
            where (pj.MANAGER_USER_ID = %s or pj.org_manager_user_id = %s) and sysdate > to_date(pj.p_end_date,'yyyy-mm-dd HH:mi:ss') and 
            (pps.name != '已完成' and pps.name != '已关闭' or pps.name is null) ORDER BY pj.id
            """ % (user_id,user_id)
    result = rd.select(sql)
    for i in range(len(result)):
        canSend = checkRiskMesCanSend(result[i]['id'],None,'项目预计完成时间已过',user_id)
        if canSend is True:
            sql = "insert into pms_risk_mes values(seq_pms_risk_mes.nextval,%s,null,'%s',sysdate,0,%s,null)"\
            %(result[i]['id'],'项目预计完成时间已过',user_id)
            rd.insert(sql)
            handler.write_message({"type":"systemMessage","mes":"预警消息"})

def projctDevRisk(user_id,handler):
    sql = """
            select distinct ppd.id dev_id,pj.id pj_id,pps.name status_name from pms_project_dev_child_user ppdcu
            left join pms_project_dev_child ppdc on ppdc.id = ppdcu.DEV_CHILD_ID
            left join pms_project_dev ppd on ppd.id = ppdc.PMS_PROJECT_DEV_ID
            left join pms_project pj on pj.id = ppd.pms_project_id
            left join pms_project_stage pps on pps.ID = ppd.PMS_PROJECT_STAGE_ID
            left join pms_pro_status pps2 on pps2.id = pj.status
            where (pj.manager_user_id = %s or ppd.dev_user_id = %s or ppdcu.USER_ID = %s or pj.org_manager_user_id = %s) and (pps2.name != '已完成' and pps2.name != '已关闭' or pps2.name is null) and ppd.is_comp = 0 and sysdate > ppd.p_end_date order by pj.id
            """ % (user_id,user_id,user_id,user_id)
    result = rd.select(sql)
    for i in range(len(result)):
        canSend = checkRiskMesCanSend(result[i]['pj_id'],result[i]['dev_id'],result[i]['status_name']+'阶段预计完成时间已过',user_id)
        if canSend is True:
            sql = "insert into pms_risk_mes values(seq_pms_risk_mes.nextval,%s,%s,'%s',sysdate,0,%s,null)"\
            %(result[i]['pj_id'],result[i]['dev_id'],result[i]['status_name']+'阶段预计完成时间已过',user_id)
            rd.insert(sql)
            handler.write_message({"type":"systemMessage","mes":"预警消息"}) 


def projctQualityRisk(user_id,handler):
    #项目质量预警
    sql = """
            select distinct ppd.id dev_id,pj.id pj_id,prwv.NAME from pms_project_dev_child_user ppdcu
            left join pms_project_dev_child ppdc on ppdc.id = ppdcu.DEV_CHILD_ID
            left join pms_project_dev ppd on ppd.id = ppdc.PMS_PROJECT_DEV_ID
            left join pms_project pj on pj.id = ppd.pms_project_id
            left join pms_project_dev_comment ppdc2 on ppdc2.PMS_PROJECT_DEV_ID = ppd.id
            left join pms_risk_warn_value prwv on prwv.code = ppdc2.type
            left join pms_pro_status pps on pps.ID = pj.STATUS
            where (pj.manager_user_id = %s or ppd.dev_user_id = %s or ppdcu.USER_ID = %s or pj.org_manager_user_id = %s)             and ppdc2.CODE < prwv.SCORE and 
            (pps.name != '已完成' and pps.name != '已关闭' or pps.name is null) ORDER BY pj.id
            """ % (user_id,user_id,user_id,user_id)
    result = rd.select(sql)
    for i in range(len(result)):
        canSend = checkRiskMesCanSend(result[i]['pj_id'],result[i]['dev_id'],result[i]['name'][:len(result[i]['name'])-1],user_id)
        if canSend is True:
            sql = "insert into pms_risk_mes values(seq_pms_risk_mes.nextval,%s,%s,'%s',sysdate,0,%s,null)"\
            %(result[i]['pj_id'],result[i]['dev_id'],result[i]['name'][:len(result[i]['name'])-1],user_id)
            rd.insert(sql)
            handler.write_message({"type":"systemMessage","mes":"预警消息"})



def checkRiskMesCanSend(project_id,dev_id,mes,user_id):
    if dev_id is not None and dev_id != "":  #此为阶段预警和质量预警
        sql = """
            select count(id) ct from pms_risk_mes
            where (status = 0 or (status = 1 and (to_char(sysdate,'yyyy-mm-dd') = to_char(time,'yyyy-mm-dd') or to_char(sysdate,'yyyy-mm-dd') = to_char(read_time,'yyyy-mm-dd')))) 
            and project_id = %s and dev_id = %s and mes = '%s' and GET_MES_USER_ID = %s
                """ % (project_id,dev_id,mes,user_id)
    else:     #此为项目总体预警
        sql = """
            select count(id) ct from pms_risk_mes
            where (status = 0 or (status = 1 and (to_char(sysdate,'yyyy-mm-dd') = to_char(time,'yyyy-mm-dd') or to_char(sysdate,'yyyy-mm-dd') = to_char(read_time,'yyyy-mm-dd')))) 
            and project_id = %s and dev_id is null and mes = '%s' and GET_MES_USER_ID = %s
                """ % (project_id,mes,user_id)
    result = rd.select(sql)
    if result[0]['ct'] == 0:
        return True    #需要发送
    else:
        return False   #不需要发送
