import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts
import os
from handlers.py_add.onlineUser import userList

#初始化用户信息（自己及好友），获取所有未完成的项目作为群组
class GetInitInfoHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        user_id = self.session['user_id']
        sql = 'select name,id,no,self_sign from pms_user'
        result = rd.select(sql)
        response = {}
        response["code"] = 0
        response["msg"] = ""
        response["data"] = {}
        response["data"]["friend"] = []
        response["data"]["friend"].append({"groupname":"所有成员","id": 0,"list":[]})
        response["data"]["group"] = []
        for i in range(len(result)):
            sign = ""
            if result[i]["self_sign"] is not None:
                sign = result[i]["self_sign"]
            if result[i]['id'] == user_id:
                status = "online"
                response["data"]["mine"] = {"username":result[i]["name"],"id":result[i]["id"],\
                    "status":status,"sign":sign,"avatar":"static/plugins/layui/css/modules/layim/skin/logo.jpg"}
            else:
                status = "offline"
                if userList.get(result[i]["id"],None) is not None:
                    status = "online"
                response["data"]["friend"][0]["list"].append({"username":result[i]["name"],"id":result[i]["id"],\
                    "avatar":"static/plugins/layui/css/modules/layim/skin/logo.jpg","sign":sign,"status":status})
        response["data"]["friend"][0]["list"] = sortUsers(response["data"]["friend"][0]["list"])
        sql = """
                select distinct pj.id,pj.name from pms_project_dev_child_user ppdcu
            left join pms_project_dev_child ppdc on ppdc.id = ppdcu.DEV_CHILD_ID
            left join pms_project_dev ppd on ppd.id = ppdc.PMS_PROJECT_DEV_ID
            left join pms_project pj on pj.id = ppd.pms_project_id
            left join pms_pro_status pps2 on pps2.id = pj.status
            where (pj.manager_user_id = %s or ppd.dev_user_id = %s or ppdcu.USER_ID = %s or pj.org_manager_user_id = %s) and 
            (pps2.name != '已完成' and pps2.name != '已关闭' or pps2.name is null)
                """ % (user_id,user_id,user_id,user_id)
        groupInfo = rd.select(sql)
        for i in range(len(groupInfo)):
            response["data"]["group"].append({"groupname":groupInfo[i]["name"],"id":groupInfo[i]["id"],"avatar":\
                "static/plugins/layui/css/modules/layim/skin/touxiang.png"})
        self.write(json.dumps(response))


#获取项目成员，以作为该群组成员
class GetMembersHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument("id")
        user_id = self.session['user_id']
        response = {}
        response["code"] = 0
        response["msg"] = ""
        response["data"] = {}
        response["data"]["list"] = []
        sql = """
                select distinct pu.id,pu.no,pu.name,pu.self_sign 
            from pms_project_dev_child_user ppdcu
            left join pms_user pu on pu.id = ppdcu.USER_ID
            left join pms_project_dev_child ppdc on ppdc.id = ppdcu.DEV_CHILD_ID
            left join pms_project_dev ppd on ppd.id = ppdc.PMS_PROJECT_DEV_ID
            left join pms_project pj on pj.id = ppd.pms_project_id
            where pj.id = %s UNION
select distinct pu.id,pu.no,pu.name,pu.self_sign 
            from pms_project_dev ppd
            left join pms_user pu on ppd.dev_user_id = pu.id
            where ppd.pms_project_id = %s union
select distinct pu.id,pu.no,pu.name,pu.self_sign 
            from pms_project pj
            left join pms_user pu on pu.id = pj.manager_user_id
            where pj.id = %s union
select distinct pu.id,pu.no,pu.name,pu.self_sign 
            from pms_project pj
            left join pms_user pu on pu.id = pj.org_manager_user_id
            where pj.id = %s
                """ % (id,id,id,id)
        users = rd.select(sql)
        for i in range(len(users)):
            if users[i]['id'] != user_id:
                sign = ""
                if users[i]["self_sign"] is not None:
                    sign = users[i]["self_sign"]
                #if userList.get(users[i]['no'],None) is not None:
                response["data"]["list"].append({"username":users[i]["name"],"id":users[i]["id"],"avatar":\
                        "static/plugins/layui/css/modules/layim/skin/logo.jpg","sign":sign})
        self.write(json.dumps(response))


class GetMessageCountHandler(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        id = self.get_argument("id")
        type = self.get_argument("type")
        user_id = self.session['user_id']
        if type == "friend":
            sql = "select count(id) messageCount from pms_private_chat where (SEND_MES_USER_ID = "+id+" and GET_MES_USER_ID = "+str(user_id)+") or (SEND_MES_USER_ID = "+str(user_id)+" and GET_MES_USER_ID = "+id+")"
            result = rd.select(sql)
            self.write(json.dumps({"messageCount":result[0]["messagecount"]}))
        else:
            sql = "select count(id) messageCount from pms_group_chat where pms_project_id = "+id
            result = rd.select(sql)
            self.write(json.dumps({"messageCount":result[0]["messagecount"]}))



class GetChatMessageHandler(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        id = self.get_argument("id")
        type = self.get_argument("type")
        curr = int(self.get_argument("curr"))
        limit = int(self.get_argument("limit"))
        user_id = self.session['user_id']
        data = {}
        data["code"] = 0
        data["msg"] = ""
        data["data"] = []
        if type == "friend":
            sql = "select * from (select p.*,rownum rn from (select pms_user.name,pms_private_chat.SEND_MES_USER_ID,pms_private_chat.TIMESTAMP,pms_private_chat.MES from pms_private_chat join pms_user on pms_user.id = pms_private_chat.SEND_MES_USER_ID where ((SEND_MES_USER_ID = "+id+" and GET_MES_USER_ID = "+str(user_id)+") or (SEND_MES_USER_ID = "+str(user_id)+" and GET_MES_USER_ID = "+id+")) order by pms_private_chat.TIMESTAMP desc) p where rownum <="+str(curr * limit)+") q where q.rn >" + str(curr * limit - limit)
            result = rd.select(sql)
            length = len(result)
            for i in range(length-1,-1,-1):
                data["data"].append({"username":result[i]["name"],"id":result[i]["send_mes_user_id"],"avatar":\
                    "../skin/logo.jpg","timestamp":result[i]["timestamp"],"content"\
                    :result[i]["mes"]})
            self.write(json.dumps({"data":data}))
        else:
            sql = "select * from (select p.*,rownum rn from (select pms_user.name,pms_group_chat.SEND_MES_USER_ID,pms_group_chat.TIMESTAMP,pms_group_chat.MES from pms_group_chat join pms_user on pms_user.id = pms_group_chat.SEND_MES_USER_ID where pms_group_chat.pms_project_id = "+id+" order by pms_group_chat.TIMESTAMP desc) p where rownum <="+str(curr * limit)+") q where q.rn > " + str(curr * limit - limit)
            result = rd.select(sql)
            length = len(result)
            for i in range(length-1,-1,-1):
                data["data"].append({"username":result[i]["name"],"id":result[i]["send_mes_user_id"],"avatar":\
                    "../skin/logo.jpg","timestamp":result[i]["timestamp"],"content"\
                    :result[i]["mes"]})
            self.write(json.dumps({"data":data}))


class SetSelfSignHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        user_id = self.session['user_id']
        value = self.get_argument("value")
        sql = "update pms_user set self_sign = '"+value+"' where id = "+str(user_id)
        rd.update(sql)
        self.write({"status":1})

def sortUsers(allUsers):
    onlineUsers = []
    offlineUsers = []
    for i in range(len(allUsers)):
        if allUsers[i]['status'] == 'offline':
            offlineUsers.append(allUsers[i])
        else:
            onlineUsers.append(allUsers[i])
    return onlineUsers + offlineUsers
