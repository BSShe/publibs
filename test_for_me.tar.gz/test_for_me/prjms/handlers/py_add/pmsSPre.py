# -*- coding: utf-8 -*-

import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts
import os
import time
from handlers.py_add.onlineUser import userList
from handlers.py_add.projectStageFinish import finishProjectStage

class pmsSPreHandler(BaseHandler):
    #打开开发实现界面
    @tornado.web.authenticated
    def post(self):
        id=self.get_argument("id")
        self.render("pmsManager/html_add/pmsSPre.html",id=id,data1=None,data2=None,files=['test1.txt','test2.txt','test3.txt',])


class pmsSPreFileUploadHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        num=self.get_argument("num")
        fileName=self.get_argument("fileName")
        #项目id
        id=self.get_argument("id")
        #文件保存路径及名字
        filePath='./static/files/'+fileName;
        inner=self.request.files.get("file",None)
        if num == '1':
            with open(filePath,"wb") as g:
                for meta in inner:
                    g.write(meta["body"])
        else:
            with open(filePath,"ab") as g:
                for meta in inner:
                    g.write(meta["body"])


class pmsSPreFileCheckSuccessHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        fileName=self.get_argument("fileName")
        id=self.get_argument("id")
        fileSize=self.get_argument("fileSize")
        filePath='./static/files/'+fileName
        nowFileSize=os.path.getsize(filePath)
        status={"status":1}
        if nowFileSize < int(fileSize):
            status["status"]=0
            os.remove(filePath)
        self.write(status)


class pmsSPreFileDownloadHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        id=self.get_argument("id")
        fileName=self.get_argument("fileName")
        self.set_header("Content-Type","application/octet-stream")
        downloadName='attachment;filename='+fileName
        downloadName=downloadName.encode()
        self.set_header("Content-Disposition",downloadName)
        filePath='./static/files/'+fileName
        buff=1024*1024*2
        with open(filePath,"rb") as f:
            while 1:
                block=f.read(buff)
                if not block:
                    break
                self.write(block)
        self.finish()


class pmsSPreGetTextHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        id=self.get_argument("id")
        iType=self.get_argument("type")
        #回填内容
        if iType == 'projectProgramText':
            text=[{'title':'test1','text':'  12345\r\n123'},{'title':'test2','text':'  yuws\r\nsdas'}]
            self.write(json.dumps(text))
        else:
            text=[{'title':'test3','text':'  12345\r\n123'},{'title':'test4','text':'  yuws\r\nsdas'}]
            self.write(json.dumps(text))


class pmsSPreTextSubmitHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        data=self.get_argument("data")
        data=json.loads(data)
        if data[0]["type"] == 'programText':
            pass
        else:
            pass
        self.write({"status":"1"})


class pmsSPreCheckTemplateHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        sql = "select url from pms_project_stage_doc join pms_project_stage on pms_project_stage_doc.PROJECT_STAGE_CODE = pms_project_stage.code where pms_project_stage.name= '开发实现' and pms_project_stage_doc.CODE = 1"
        result = rd.select(sql)
        if result[0]['url'] is None:
            self.write({'status':0})
        else:
            self.write({'status':1})


class pmsSPreTemplateDownloadHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        sql = "select url from pms_project_stage_doc join pms_project_stage on pms_project_stage_doc.PROJECT_STAGE_CODE = pms_project_stage.code where pms_project_stage.name= '开发实现' and pms_project_stage_doc.CODE = 1"
        result = rd.select(sql)
        self.set_header("Content-Type","application/octet-stream")
        downloadName='attachment;filename='+result[0]['url'][result[0]['url'].rindex('/')+1:]
        downloadName=downloadName.encode()
        self.set_header("Content-Disposition",downloadName)
        buff=1024*1024*2
        with open(result[0]['url'],"rb") as f:
            while 1:
                block=f.read(buff)
                if not block:
                    break
                self.write(block)
        self.finish()


class pmsSPrefinshHandler(BaseHandler):
    def get_current_user(self):
        return self.get_secure_cookie('username')


    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        userNo = tornado.escape.xhtml_escape(self.current_user)
        finishProjectStage(id,'开发实现',userNo)
        self.write({'status':1})
