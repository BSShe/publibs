import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts
import os
from handlers.pmsManager.ssb_project_plan import getAllProPersonInfo

class projectJumpToDetailHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        page = self.get_argument('page')
        projectDevInfo = getProjectDevInfo(id)
        self.render("html_add/pmsProjectDetail.html",page=page,id=id,projectDevInfo=projectDevInfo)



class projectDetailChartInfoHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument("id")
        chartInfo = getProgress(id)
        realWorkLoad = getRealWorkLoad(id)
        chartInfo['realWorkLoad'] = realWorkLoad[0]['real_work_time']
        devStatus = getProjectDevStatus(id)
        chartInfo['finish_dev'] = devStatus['ok']
        chartInfo['undo_dev'] = devStatus['undo']
        self.write(json.dumps(chartInfo))


def getProgress(id):
    getProjectInfoSql= "select pms_project.pms_number,pms_project_stage.name,floor(to_date(pms_project.p_end_date,'yyyy-mm-dd')-to_date(pms_project.p_start_date,'yyyy-mm-dd')) total_day,floor(sysdate-to_date(pms_project.p_start_date,'yyyy-mm-dd')) now_day from PMS_PROJECT left join pms_project_dev on PMS_PROJECT.pms_dev_id = pms_project_dev.id left join pms_project_stage on pms_project_dev.pms_project_stage_id = pms_project_stage.ID where PMS_PROJECT.id ="+id
    projectResult = rd.select(getProjectInfoSql)
    progress = {}
    if projectResult[0]['now_day'] > projectResult[0]['total_day']:
        progress['jihua'] = 100
    elif projectResult[0]['now_day'] < 0:
        progress['jihua'] = 0
    else:
        progress['jihua'] = round(projectResult[0]['now_day'] / projectResult[0]['total_day'] * 100,2)
    sql = """
            select distinct ppd.id,null use_dates,round((ppd.p_end_date - ppd.p_start_date),2) worksday,ppd.is_comp 
            from pms_project_dev ppd
            where ppd.PMS_PROJECT_ID = %s
            and ppd.is_comp !=1 or ppd.is_comp is null
            union
            select distinct ppd.id,use_dates,
            round((ppd.p_end_date - ppd.p_start_date),2) worksday,ppd.is_comp from pms_project_dev ppd
            where ppd.PMS_PROJECT_ID = %s
            and ppd.is_comp =1
            """ % (id,id)
    projectDevResult = rd.select(sql)
    
    totalTime = 0
    okTime = 0
    for i in range(len(projectDevResult)):
        if projectDevResult[i]['worksday'] is not None:
            if projectDevResult[i]['is_comp'] == 0 or projectDevResult[i]['is_comp'] is None:
                totalTime = totalTime + projectDevResult[i]['worksday']
            else:
                if projectDevResult[i]['use_dates'] is None:
                    totalTime = totalTime + projectDevResult[i]['worksday']
                    okTime = okTime + projectDevResult[i]['worksday']
                else:
                    totalTime = totalTime + projectDevResult[i]['use_dates']
                    okTime = okTime + projectDevResult[i]['use_dates']
    if totalTime != 0:
        progress['shiji'] = str(round(okTime / totalTime * 100,2))
    else:
        progress['shiji'] = 0
    print('total',totalTime,'okTime',okTime)
    print(progress)
    milestoneWorkLoad=getMilestoneWorkLoad(id,projectResult[0]['name'])
    progress['totalWorkLoad']=projectResult[0]['pms_number']
    progress['milestoneWorkLoad']=milestoneWorkLoad
    progress['nowProgress'] = projectResult[0]['name']
    return progress

def getAllPersonInProject(id):
    (count,allPersonList) = getAllProPersonInfo(id)
    count_own = 0 
    for i in allPersonList:
        if i['org_type'] != '外包机构':
            count_own = count_own + 1
    progress = {}
    progress['total'] = count
    progress['own'] = count_own
    return progress

def getAllPersonInBranch(id):
    allPersonList = getAllProPersonInfo(id)[1]
    waibao = 0
    guanli = 0
    xuqiu = 0
    kaifa = 0
    ceshi = 0
    zhichi = 0
    for i in allPersonList:
        if i['branch_name'] == None:
            waibao += 1
        elif i['branch_name'] == "管理部门":
            guanli += 1
        elif i['branch_name'] == "需求部门":
            xuqiu += 1
        elif i['branch_name'] == "研发部门":
            kaifa += 1
        elif i['branch_name'] == "测试部门":
            ceshi += 1
        elif i['branch_name'] == "技术支持部门":
            zhichi += 1
    return (waibao,guanli,xuqiu,kaifa,ceshi,zhichi)


def getMilestoneWorkLoad(id,name):
    sql = """
            select nvl(round(sum(ppd.p_end_date - ppd.p_start_date),2),0) ct from pms_project_dev ppd
        left join pms_project pj on pj.pms_dev_id = ppd.id
        where ppd.PMS_PROJECT_ID = %s
        and (ppd.is_comp =1 or (ppd.id = pj.pms_dev_id and sysdate >= ppd.start_date))
            """ % id
    result = rd.select(sql)
    total = str(result[0]['ct'])
    return total


def getRealWorkLoad(id):
    sql = """
           select nvl(sum(decode(is_comp,1,use_dates,round((sysdate-start_date),2))),0) real_work_time from pms_project_dev ppd
left join pms_project pj on pj.pms_dev_id = ppd.id
where ppd.PMS_PROJECT_ID = %s
and (ppd.is_comp =1 or (ppd.id = pj.pms_dev_id and sysdate >= ppd.start_date))
            """ % id
    result = rd.select(sql)
    result[0]['real_work_time'] = str(result[0]['real_work_time'])
    return result


def getProjectDevInfo(id):
    sql= 'select pms_project_stage.name from pms_project join pms_project_dev on pms_project.pms_dev_id = pms_project_dev.id join pms_project_stage on pms_project_stage.id = pms_project_dev.pms_project_stage_id where pms_project.id = '+id
    now = None
    result = rd.select(sql)
    if len(result) > 0:
        now = result[0]['name']
    sql = "select pms_project_stage.name,to_char(pms_project_dev.p_end_date,'yyyy-mm-dd') p_end_date,to_char(pms_project_dev.end_date,'yyyy-mm-dd') end_date,pms_project_dev.dev_number,pms_project_dev.is_comp from pms_project_dev join pms_project_stage on pms_project_stage.ID = pms_project_dev.pms_project_stage_id where pms_project_dev.pms_project_id = "+id+" order by pms_project_stage.code"
    result = rd.select(sql)
    length = len(result)
    for i in range(length):
        p_end_date = "未设置"
        end_date = "未设置"
        if result[i]['p_end_date'] is not None:
            p_end_date = result[i]['p_end_date']
        if result[i]['end_date'] is not None:
            end_date = result[i]['end_date']
        if result[i]['is_comp'] == 1:   #已经完成的进度
            dev_number = '未评价'
            if result[i]['dev_number'] is not None:
                dev_number = str(result[i]['dev_number'])
            result[i]['lineColor'] = 'background-color:#00FF00;'
            result[i]['backgroundColor'] = 'background-color:#00FF00;'
            result[i]['content'] = '<h5 class="row">计划完成日期：'+p_end_date+'</h5><h5 class="row">实际完成时间：'+end_date+'</h5><h5 class="row">该阶段评价：'+dev_number+'</h5>'
        elif result[i]['is_comp'] == 0 and result[i]['name'] == now and now is not None:    #当前正在进行的进度
            result[i]['lineColor'] = 'background-color:#FF0000;'
            result[i]['backgroundColor'] = 'background-color:#FF0000;'
            result[i]['content'] = '<h5 class="row">计划完成日期：'+p_end_date+'</h5>'
        else:        #未进行的进度
            result[i]['lineColor'] = 'background-color:lightgray;'
            result[i]['backgroundColor'] = 'background-color:lightgray;'
            result[i]['content'] = '<h5 class="row">计划完成日期：'+p_end_date+'</h5>'
    return result



def getProjectDevStatus(id):
    sql = 'select distinct pms_project_stage_id,IS_COMP from pms_project_dev where pms_project_dev.pms_project_id = '+id
    result = rd.select(sql)
    ok = 0
    undo = 0
    for i in range(len(result)):
        if result[i]['is_comp'] == 1:
            ok = ok+1
        else:
            undo = undo+1
    return {"ok":ok,"undo":undo}
