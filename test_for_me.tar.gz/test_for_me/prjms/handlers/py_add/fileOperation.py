import time
import os
import database.readdb as rd

def upload(handler):
    num = handler.get_argument("num")
    fileName = handler.get_argument("fileName")
    dev_id = handler.get_argument("dev_id")
    stage_code = handler.get_argument("stage_code")
    code = handler.get_argument("code")
    fileId = handler.get_argument("fileId")
    inner=handler.request.files.get("file",None)
    filePath = ''
    if num == '1':
        path = './static/files/'+dev_id
        if not os.path.exists(path):
            os.mkdir(path)
        filePath= path +'/'+time.strftime("%Y%m%d%H%M%S",time.localtime(time.time()))+'.'+fileName[fileName.rindex('.')+1:]
        sql = "insert into pms_file_upload values(seq_pms_file_upload.nextval,%s,%s,'%s',%s,'%s')"%(stage_code,code,filePath,dev_id,fileName)
        rd.insert(sql)
        sql = "select id from pms_file_upload where PMS_PROJECT_STAGE_CODE = %s and code = %s and dev_id = %s and url = '%s'"%(stage_code,code,dev_id,filePath)
        fileId = rd.select(sql)[0]['id']
        with open(filePath,"wb") as g:
            for meta in inner:
                g.write(meta["body"])
    else:
        sql = "select url from pms_file_upload where id = %s"%fileId
        filePath = rd.select(sql)[0]['url']
        with open(filePath,"ab") as g:
            for meta in inner:
                g.write(meta["body"])
    return {"id":fileId,"url":filePath}


def downlaodFile(handler):
    fileName = handler.get_argument("fileName")
    handler.set_header("Content-Type","application/octet-stream")
    downloadName='attachment;filename='+fileName
    downloadName=downloadName.encode()
    handler.set_header("Content-Disposition",downloadName)
    filePath = handler.get_argument("url")
    buff=1024*1024*2
    with open(filePath,"rb") as f:
        while 1:
            block=f.read(buff)
            if not block:
                break
            handler.write(block)
    handler.finish()


def checkTemplate(handler):
    dev_id = handler.get_argument("dev_id")
    sql = """
            select ppsd.name,ppsd.url from pms_project_dev ppd
            join pms_project_stage pps on pps.id = ppd.pms_project_stage_id
            join pms_project_stage_doc ppsd on ppsd.project_stage_code = pps.code
            where ppd.id =%s and ppsd.url is not null
            """ % dev_id
    result = rd.select(sql)
    if len(result) == 0:
        handler.write({'status':0})
    else:
        handler.write({'status':1,"result":result})


def downloadTemplate(handler):
    url = handler.get_argument("url")
    handler.set_header("Content-Type","application/octet-stream")
    downloadName='attachment;filename='+url[url.rindex('/')+1:]
    downloadName=downloadName.encode()
    handler.set_header("Content-Disposition",downloadName)
    buff=1024*1024*2
    with open(url,"rb") as f:
        while 1:
            block=f.read(buff)
            if not block:
                break
            handler.write(block)
    handler.finish()


def deleteFile(handler):
    id = handler.get_argument("id")
    url = handler.get_argument("url")
    os.remove(url)
    sql = "delete from pms_file_upload where id = %s"%id
    rd.own_excute(sql)
    handler.write({"status":1})
