# -*- coding: utf-8 -*-

import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts
import os

class projectDevelopHandler(BaseHandler):
    #打开开发实现界面
    @tornado.web.authenticated
    def post(self):
        id=self.get_argument("id")
        self.render("pmsManager/html_add/pmsTest.html",id=id,data1=None,data2=None,files=['test1.txt','test2.txt','test3.txt',])


class projectDevelopFileUploadHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        num=self.get_argument("num")
        fileName=self.get_argument("fileName")
        #项目id
        id=self.get_argument("id")
        #文件保存路径及名字
        filePath='./static/files/'+fileName
        
         
        inner=self.request.files.get("file",None)
        if num == '1':
            with open(filePath,"wb") as g:
                for meta in inner:
                    g.write(meta["body"])
        else:
            with open(filePath,"ab") as g:
                for meta in inner:
                    g.write(meta["body"])


class projectDevelopFileCheckSuccessHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        fileName=self.get_argument("fileName")
        id=self.get_argument("id")
        fileSize=self.get_argument("fileSize")
        filePath='./static/files/'+fileName
        nowFileSize=os.path.getsize(filePath)
        status={"status":1}
        if nowFileSize < int(fileSize):
            status["status"]=0
            os.remove(filePath)
        self.write(status)


class projectDevelopFileDownloadHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        id=self.get_argument("id")
        fileName=self.get_argument("fileName")
        self.set_header("Content-Type","application/octet-stream")
        downloadName='attachment;filename='+fileName
        downloadName=downloadName.encode()
        self.set_header("Content-Disposition",downloadName)
        filePath='./static/files/'+fileName
        buff=1024*1024*2
        with open(filePath,"rb") as f:
            while 1:
                block=f.read(buff)
                if not block:
                    break
                self.write(block)
        self.finish()


class projectDevelopGetTextHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        id=self.get_argument("id")
        iType=self.get_argument("type")
        #回填内容
        if iType == 'projectProgramText':
            text=[{'title':'test1','text':'  12345\r\n123'},{'title':'test2','text':'  yuws\r\nsdas'}]
            self.write(json.dumps(text))
        else:
            text=[{'title':'test3','text':'  12345\r\n123'},{'title':'test4','text':'  yuws\r\nsdas'}]
            self.write(json.dumps(text))


class projectDevelopTextSubmitHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        data=self.get_argument("data")
        data=json.loads(data)
        print (data) 
        if data[0]["type"] == 'programText':
            pass
        else:
            pass
        self.write({"status":"1"})
