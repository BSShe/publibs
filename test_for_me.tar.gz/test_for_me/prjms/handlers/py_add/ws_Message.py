import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts
import os
import time
#from tornado.websocket import WebSocketHandler
from handlers.py_add.onlineUser import userList
from handlers.py_add.projectRiskMes import checkToRisk
from handlers.py_add.webSocketHandler import BaseWebSocketHandler

class WSMessageHandler(BaseWebSocketHandler):
    def open(self):
        user_id = self.session['user_id']
        user=userList.get(user_id,None)
        if user is None:
            for key in userList:
                userList[key].write_message(json.dumps({"type":"userOnline","id":user_id}))
            checkToRisk(user_id,self)
            userList[user_id]=self

    #可用于转发消息
    def on_message(self,mes):
        user_id = self.session['user_id']
        mes = json.loads(mes)
        if mes["type"] == "chatMessage":
            data = {} 
            data["username"] = mes["data"]["mine"]["username"]
            data["avatar"] = mes["data"]["mine"]["avatar"]
            data["type"] = mes["data"]["to"]["type"]
            data["content"] = mes["data"]["mine"]["content"]
            data["mine"] = False    
            data["fromid"] = mes["data"]["mine"]["id"]   
            data["timestamp"] = int(round(time.time()*1000)) 
            if mes["data"]["to"]["type"] == "friend":
                data["id"] = mes["data"]["mine"]["id"]
                user = userList.get(mes["data"]["to"]["id"],None)
                if user is not None: #用户在线
                    sql = "insert into pms_private_chat values(seq_pms_private_chat.nextval,\
                        '%s',1,%d,%d,%d)"%(data["content"],data["timestamp"],data["id"],mes["data"]["to"]["id"])
                    rd.insert(sql)
                    user.write_message(json.dumps({"type":"chatMessage","data":data}))
                else: #用户不在线
                    sql = "insert into pms_private_chat values(seq_pms_private_chat.nextval,\
                        '%s',0,%d,%d,%d)"%(data["content"],data["timestamp"],data["id"],mes["data"]["to"]["id"])
                    rd.insert(sql)
            else:           
                data["id"] = mes["data"]["to"]["id"]
                sql = """
                        select distinct pu.id,pu.no 
            from pms_project_dev_child_user ppdcu
            left join pms_user pu on pu.id = ppdcu.USER_ID
            left join pms_project_dev_child ppdc on ppdc.id = ppdcu.DEV_CHILD_ID
            left join pms_project_dev ppd on ppd.id = ppdc.PMS_PROJECT_DEV_ID
            left join pms_project pj on pj.id = ppd.pms_project_id
            where pj.id = %s UNION
select distinct pu.id,pu.no
            from pms_project_dev ppd
            left join pms_user pu on ppd.dev_user_id = pu.id
            where ppd.pms_project_id = %s union
select distinct pu.id,pu.no
            from pms_project pj
            left join pms_user pu on pu.id = pj.manager_user_id
            where pj.id = %s union
select distinct pu.id,pu.no
            from pms_project pj
            left join pms_user pu on pu.id = pj.org_manager_user_id
            where pj.id = %s
                        """ % (str(mes["data"]["to"]["id"]),str(mes["data"]["to"]["id"]),str(mes["data"]["to"]["id"]),str(mes["data"]["to"]["id"]))
                users = rd.select(sql)
                for i in range(len(users)):
                    if users[i]['id'] != user_id:
                        user = userList.get(users[i]['id'],None)
                        if user is not None:
                            user.write_message(json.dumps({"type":"chatMessage","data":data}))
                sql = "insert into pms_group_chat values(seq_pms_group_chat.nextval,\
                    '%s',%d,%d,%d)"%(data["content"],data["timestamp"],mes["data"]["mine"]["id"],data["id"])
                rd.insert(sql)
        else:
            sql = "select pms_private_chat.id,pms_user.name,pms_private_chat.MES,pms_private_chat.SEND_MES_USER_ID,pms_private_chat.TIMESTAMP from pms_private_chat join pms_user on pms_user.id = pms_private_chat.SEND_MES_USER_ID where pms_private_chat.get_mes_user_id = "+str(user_id)+" and pms_private_chat.type = 0 order by pms_private_chat.TIMESTAMP"
            result = rd.select(sql)
            body = userList[user_id]
            idList = ''
            for i in range(len(result)):
                data = {"username":result[i]['name'],"avatar":"static/plugins/layui/css/modules/layim/skin/logo.jpg",\
                    "type":"friend","content":result[i]["mes"],"mine":False,"fromid":result[i]['send_mes_user_id'],\
                    "timestamp":result[i]['timestamp'],"id":result[i]["send_mes_user_id"]}
                body.write_message(json.dumps({"type":"chatMessage","data":data}))
                if i <len(result)-1:
                    idList = idList + str(result[i]['id'])+','
                else:
                    idList = idList + str(result[i]['id'])
                    sql = "update pms_private_chat set type=1 where id in ("+idList+")"
                    rd.update(sql)


    def on_close(self):
        user_id = self.session['user_id']
        userList.pop(user_id)
        for key in userList:
            userList[key].write_message(json.dumps({"type":"userOffline","id":user_id}))
