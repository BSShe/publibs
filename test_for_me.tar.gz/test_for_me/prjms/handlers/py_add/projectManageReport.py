# -*- coding: utf-8 -*-

import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts
import os
import time


def makeSQL(sql,startTime,endTime,minMoney,maxMoney,outsourcer,organizationNature,projectType,projectNature):
    if startTime is not None and startTime != "":
        sql = sql + "and to_date(pms_project.p_start_date,'yyyy-mm-dd') >= to_date('"+startTime+"','yyyy-mm-dd')"
    if endTime is not None and endTime != "":
        sql = sql + "and to_date(pms_project.p_end_date,'yyyy-mm-dd') <= to_date('"+endTime+"','yyyy-mm-dd')"
    if minMoney is not None and minMoney != "":
        sql = sql + "and to_number(pms_contract.contract_amount) >= to_number('"+minMoney+"')"
    if maxMoney is not None and maxMoney != "":
        sql = sql + "and to_number(pms_contract.contract_amount) <= to_number('"+maxMoney+"')"
    if outsourcer is not None and outsourcer != "":
        sql = sql + "and PMS_ORGANIZATIONS.name = '"+outsourcer+"'"
    if organizationNature is not None and organizationNature != "":
        sql = sql + "and pms_org_type.name = '"+organizationNature+"'"
    if projectType is not None and projectType != "":
        sql = sql + "and pms_project_type.name = '"+projectType+"'"
    if projectNature is not None and projectNature != "":
        sql = sql + "and pms_project_property.name ='"+projectNature+"'"
    return sql


class ManageReportIndexHandler(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        total = {}
        page = self.get_argument("page",1)
        sql = 'select count(pms_project.id) pro_count,sum(pms_contract.CONTRACT_AMOUNT) money_count from pms_project left join pms_contract on pms_contract.code = pms_project.HT_CODE where (pms_project.is_child != 1 or pms_project.is_child is null)'
        result = rd.select(sql)
        total["pro_count"] = result[0]["pro_count"]
        total["money_count"] = result[0]["money_count"]
        sql = "select po.name from pms_organizations po left join pms_org_type pot on pot.id = po.type_id where pot.name = '外包机构'"
        result = rd.select(sql)
        total["outsourcer"] = result
        sql = "select name from pms_org_type"
        result = rd.select(sql)
        total["organizationNature"] = result
        sql = "select name from pms_project_type"
        result = rd.select(sql)
        total["projectType"] = result
        sql = "select name from pms_project_property"
        result = rd.select(sql)
        total["projectNature"] = result
        self.render("html_add/pmsProjectManageReport.html",info=total,page=page)

    def post(self):
        data = {}
        sql = "select pms_project_property.NAME,count(pms_project.id) ct from pms_project join pms_project_property on pms_project_property.ID = pms_project.pms_project_property_id where (pms_project.is_child != 1 or pms_project.is_child is null) group by (pms_project_property.id,pms_project_property.name)"
        result = rd.select(sql)
        data["nature"] = result
        sql = "select count(pms_project.id) ct from pms_project left join pms_pro_status on pms_pro_status.id = pms_project.STATUS where pms_pro_status.NAME = '已完成' and pms_pro_status.TYPE = 1 and (pms_project.is_child != 1 or pms_project.is_child is null)"
        result = rd.select(sql)
        data["progress"] = result
        self.write(json.dumps(data))


class GetProjectListHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        startTime = self.get_argument('startTime')
        endTime = self.get_argument('endTime')
        minMoney = self.get_argument('minMoney')
        maxMoney = self.get_argument('maxMoney')
        outsourcer = self.get_argument('outsourcer')
        organizationNature = self.get_argument('organizationNature')
        projectType = self.get_argument('projectType')
        projectNature = self.get_argument('projectNature')
        
        sql = """
        select pms_project.id,pms_project.code,pms_project.name pj_name,pms_project.p_start_date,pms_project.p_end_date,prp2.name pms_level,prp.name pms_dangous_level,pms_user.name user_name from pms_project left join pms_contract on pms_contract.code = pms_project.HT_CODE left join PMS_ORGANIZATIONS on pms_organizations.id = pms_project.pms_org_id left join pms_org_type on pms_org_type.id = PMS_ORGANIZATIONS.TYPE_ID left join pms_project_type on pms_project_type.id = pms_project.pms_pro_type_id left join pms_project_property on pms_project_property.ID = pms_project.pms_project_property_id left join pms_user on pms_user.id = pms_project.manager_user_id left join pms_risk_param prp on pms_project.pms_dangous_level = prp.id left join pms_risk_param prp2 on prp2.id = pms_project.pms_level where (pms_project.is_child != 1 or pms_project.is_child is null)
              """

        sql = makeSQL(sql,startTime,endTime,minMoney,maxMoney,outsourcer,organizationNature,projectType,projectNature)
        sql += " order by pms_project.id desc "
        pms_pro,pms_pro_count = rd.select_limit_with_count(sql, pageSize, curPage)
        self.write({'total': pms_pro_count, 'data': pms_pro})


class RefreshTotalInfoHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        startTime = self.get_argument('startTime')
        endTime = self.get_argument('endTime')
        minMoney = self.get_argument('minMoney')
        maxMoney = self.get_argument('maxMoney')
        outsourcer = self.get_argument('outsourcer')
        organizationNature = self.get_argument('organizationNature')
        projectType = self.get_argument('projectType')
        projectNature = self.get_argument('projectNature')
        total = {}
        sql = """
        select count(pms_project.id) pro_count,sum(pms_contract.CONTRACT_AMOUNT) money_count from pms_project left join pms_contract on pms_contract.code = pms_project.HT_CODE left join PMS_ORGANIZATIONS on pms_organizations.id = pms_project.pms_org_id left join pms_org_type on pms_org_type.id = PMS_ORGANIZATIONS.TYPE_ID left join pms_project_type on pms_project_type.id = pms_project.pms_pro_type_id left join pms_project_property on pms_project_property.ID = pms_project.pms_project_property_id where (pms_project.is_child != 1 or pms_project.is_child is null)
              """ 
        sql = makeSQL(sql,startTime,endTime,minMoney,maxMoney,outsourcer,organizationNature,projectType,projectNature)
        result = rd.select(sql)
        total["pro_count"] = result[0]["pro_count"]
        total["money_count"] = result[0]["money_count"]
        sql = """
        select pms_project_property.NAME,count(pms_project.id) ct from pms_project left join pms_contract on pms_contract.code = pms_project.HT_CODE left join PMS_ORGANIZATIONS on pms_organizations.id = pms_project.pms_org_id left join pms_org_type on pms_org_type.id = PMS_ORGANIZATIONS.TYPE_ID left join pms_project_type on pms_project_type.id = pms_project.pms_pro_type_id left join pms_project_property on pms_project_property.ID = pms_project.pms_project_property_id where (pms_project.is_child != 1 or pms_project.is_child is null)
              """
        sql = makeSQL(sql,startTime,endTime,minMoney,maxMoney,outsourcer,organizationNature,projectType,projectNature)
        sql = sql + "group by (pms_project_property.id,pms_project_property.name)"
        result = rd.select(sql)
        total["nature"] = result
        sql = "select count(pms_project.id) ct from pms_project left join pms_contract on pms_contract.code = pms_project.HT_CODE left join PMS_ORGANIZATIONS on pms_organizations.id = pms_project.pms_org_id left join pms_org_type on pms_org_type.id = PMS_ORGANIZATIONS.TYPE_ID left join pms_project_type on pms_project_type.id = pms_project.pms_pro_type_id left join pms_project_property on pms_project_property.ID = pms_project.pms_project_property_id left join pms_pro_status on pms_pro_status.id = pms_project.status where pms_pro_status.NAME = '已完成' and pms_pro_status.TYPE = 1 and (pms_project.is_child != 1 or pms_project.is_child is null)"
        sql = makeSQL(sql,startTime,endTime,minMoney,maxMoney,outsourcer,organizationNature,projectType,projectNature)
        result = rd.select(sql)
        total["progress"] = result
        self.write(json.dumps(total))


class ShowUserEvaluateHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        page = self.get_argument('page',1)
        self.render("html_add/userEvaluate.html",page = page)
