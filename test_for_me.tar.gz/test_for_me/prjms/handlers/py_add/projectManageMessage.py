import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts
import os


class projectJumpToManageMessageHandler(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        userNo = tornado.escape.xhtml_escape(self.current_user)
        userIdSql = "select id from pms_user where no = '"+userNo+"'"
        userId = rd.select(userIdSql)
        sql = "select distinct PMS_PROJECT.id,PMS_PROJECT.code,PMS_PROJECT.name pms_project_name,pms_organizations.NAME pms_organization_name,PMS_PROJECT.P_END_DATE,PMS_PROJECT.T_END_DATE,nvl2(PMS_PROJECT.T_END_DATE,floor(to_date(PMS_PROJECT.T_END_DATE,'yyyy-mm-dd')-to_date(PMS_PROJECT.P_END_DATE,'yyyy-mm-dd')),floor(sysdate-to_date(PMS_PROJECT.P_END_DATE,'yyyy-mm-dd'))) lateTime from pms_project left join pms_project_dev on pms_project.id = pms_project_dev.pms_project_id left join pms_project_dev_user on pms_project_dev.id = pms_project_dev_user.dev_id left join pms_user on pms_project_dev_user.user_id = pms_user.id left join pms_organizations on pms_organizations.id = pms_project.pms_org_id where pms_user.no = '"+userNo+"' or pms_project.manager_user_id = "+str(userId[0]['id'])
        result = rd.select(sql)
        infos = {}
        for i in range(len(result)):
            infoSql = "select PMS_MES_RECODE.id PMS_MES_RECODE_ID,PMS_PROJECT_STAGE.name PMS_PROJECT_STAGE_NAME,PMS_MES_RECODE.type PMS_MES_RECODE_TYPE,PMS_MES_RECODE.MES PMS_MES_RECODE_MES,to_char(PMS_MES_RECODE.SEND_DATE,'yyyy-mm-dd hh:mi:ss') PMS_MES_RECODE_SENDDATE,PMS_USER.name PMS_USER_NAME from PMS_MES_RECODE join PMS_USER on PMS_USER.id = PMS_MES_RECODE.SEND_DATA_USER_ID join PMS_PROJECT_STAGE on PMS_MES_RECODE.PROJECT_PRO_ID = PMS_PROJECT_STAGE.ID where (select id from PMS_USER where PMS_USER.NO ='"+userNo+"') = PMS_MES_RECODE.GET_DATA_USER_ID and PMS_MES_RECODE.PROJECT_ID="+str(result[i]['id'])+"order by PMS_MES_RECODE.send_date desc"
            info = rd.select(infoSql)
            infos[str(result[i]['id'])]=info
        infoClasses={}
        for i in infos:
            infoClass={}
            for j in range(len(infos[i])):
                if infoClass.get(infos[i][j]['pms_project_stage_name'],1) == 1:
                    infoClass[infos[i][j]['pms_project_stage_name']]=infos[i][j]['pms_mes_recode_type']
            infoClasses[str(i)]=infoClass
        self.render("html_add/pmsProjectManageMessage.html",data=result,infos=infos,infoClasses=infoClasses)


    def get_current_user(self):
        return self.get_secure_cookie('username')


class projectManageChangeTypeHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        idlist = json.loads(self.get_argument('id'))
        param=''
        for i in idlist:
            param=param+str(i)+','
        sql = 'update PMS_MES_RECODE set type=1 where id in ('+param.strip(',')+')'
        rd.update(sql)

