import database.readdb as rd
from handlers.py_add.onlineUser import userList
from handlers.py_add.finishButtonSH import getFinishRole
from handlers.pmsManager.projectComment import comment_audit


def finishProjectStage(projectId,stageName,user_id,checkTime,dev_id):
    #提交进度前先验证权限
    projectId = str(projectId)
    isFinishRole = getFinishRole(projectId,user_id,stageName)
    if isFinishRole is False:
        return {'status':0}
    sql = "select id,code from pms_project_stage where name ='"+stageName+"'"
    pro_stage_info = rd.select(sql)
    finishThisStage(projectId,pro_stage_info[0]['id'],stageName,checkTime)
    sendStageMessage(projectId,pro_stage_info[0]['id'],stageName,user_id,dev_id)
    startNextOrFinish(projectId)
    return {'status':1}


def finishThisStage(projectId,stageId,stageName,checkTime):
    sql = ''
    if len(checkTime) == 0:
        sql = 'update pms_project_dev set end_date = sysdate,use_dates=round(sysdate-start_date,1),is_comp = 1 where pms_project_dev.pms_project_id = '+projectId+' and pms_project_dev.pms_project_stage_id = '+str(stageId)
    elif len(checkTime) == 1:
        if checkTime[0] == 'p_start_date':
            sql = 'update pms_project_dev set p_start_date = start_date,end_date = sysdate,use_dates=round(sysdate-start_date,1),is_comp = 1 where pms_project_dev.pms_project_id = '+projectId+' and pms_project_dev.pms_project_stage_id = '+str(stageId)
        else:
            sql = 'update pms_project_dev set p_end_date = sysdate,end_date = sysdate,use_dates=round(sysdate-start_date,1),is_comp = 1 where pms_project_dev.pms_project_id = '+projectId+' and pms_project_dev.pms_project_stage_id = '+str(stageId)
    else:
        sql = 'update pms_project_dev set p_start_date = start_date,p_end_date = sysdate,end_date = sysdate,use_dates=round(sysdate-start_date,1),is_comp = 1 where pms_project_dev.pms_project_id = '+projectId+' and pms_project_dev.pms_project_stage_id = '+str(stageId)
    rd.update(sql)
    #如果是项目准备阶段完成，将项目状态置为进行中
    if stageName == '项目准备':
        rd.update("update pms_project set status = (select id from pms_pro_status where name = '进行中' and type = 1) where id = %s" % projectId)
    

def sendStageMessage(projectId,stageId,stageName,user_id,dev_id):
    #接收消息人员为：此阶段的所有开发者，此阶段的负责人，项目负责人，行方负责人
    sql = """
            select distinct pu.id,pu.no 
            from pms_project_dev_child_user ppdcu
            left join pms_user pu on pu.id = ppdcu.USER_ID
            left join pms_project_dev_child ppdc on ppdc.id = ppdcu.DEV_CHILD_ID
            left join pms_project_dev ppd on ppd.id = ppdc.PMS_PROJECT_DEV_ID
            where ppd.id = %s UNION
select distinct pu.id,pu.no
            from pms_project_dev ppd
            left join pms_user pu on ppd.dev_user_id = pu.id
            where ppd.id = %s union
select distinct pu.id,pu.no
            from pms_project pj
            left join pms_user pu on pu.id = pj.manager_user_id
            where pj.id = %s union
select distinct pu.id,pu.no
            from pms_project pj
            left join pms_user pu on pu.id = pj.org_manager_user_id
            where pj.id = %s
            """ %(dev_id,dev_id,projectId,projectId)
    result = rd.select(sql)
    for i in range(len(result)):
        if result[i]['id'] != user_id:
            sql = "insert into pms_mes_recode values(seq_pms_mes_recode.nextval,%d,%s,sysdate,%d,%d,%d,%d)"%(int(projectId),"'"+stageName+"阶段已完成'",result[i]['id'],user_id,stageId,0)
            rd.insert(sql)
            if userList.get(result[i]['id'],None) is not None:
                userList.get(result[i]['id']).write_message({"type":"systemMessage","mes":"进度消息"})


def startNextOrFinish(projectId):
    #考虑到项目的阶段为自选，可能没有那么多阶段
    sql = "select pms_project_dev.id from pms_project_dev join pms_project_stage on pms_project_stage.id = pms_project_dev.pms_project_stage_id where pms_project_id = "+projectId+" and pms_project_dev.is_comp = 0 order by pms_project_stage.code"
    nextProDev = rd.select(sql)
    if len(nextProDev) != 0:
        #添加下一个阶段的开始时间
        sql = "update pms_project_dev set start_date = sysdate where pms_project_dev.id =" + str(nextProDev[0]["id"])
        rd.update(sql)
        #更新项目的进度情况
        sql = "update pms_project set pms_dev_id = " + str(nextProDev[0]["id"]) + "where id =" + projectId
        rd.update(sql)
    else:
        #添加项目完成时间
        sql = """select ppt.name,pj.father,pj.is_child from pms_project pj left join pms_project_type ppt on ppt.id = pj.pms_pro_type_id where pj.id = %s""" % projectId
        pro_type = rd.select(sql)
        if pro_type[0]['name'] != '混合型项目':
            makeComment(projectId)
            sql = "update pms_project set t_end_date = to_char(sysdate,'yyyy-mm-dd HH:mi:ss'),status = (select id from pms_pro_status where name = '已完成' and type = 1) where pms_project.id = " + projectId
            rd.update(sql)
            if pro_type[0]['is_child'] == 1: #为子项目时
                sql = """select count(pj.id) ct from pms_project pj left join pms_pro_status pps on pps.id = pj.status where (pps.name != '已完成' and pps.name != '已关闭' or pps.name is null) and pj.father = %s""" % (pro_type[0]['father'])
                unfinish_child = rd.select(sql)
                if unfinish_child[0]['ct'] == 0: #其余子项目全为已完成或已停止状态
                    sql = """select count(ppd.id) ct from pms_project_dev ppd where ppd.pms_project_id = %s and ppd.is_comp = 0""" % pro_type[0]['father']
                    father_dev = rd.select(sql)
                    if father_dev[0]['ct'] == 0: #父项目的阶段全部完成
                        makeComment(pro_type[0]['father'])
                        sql = """update pms_project set t_end_date = to_char(sysdate,'yyyy-mm-dd HH:mi:ss'),status = (select id from pms_pro_status where name = '已完成' and type = 1) where pms_project.id = %s""" % pro_type[0]['father']
                        rd.update(sql)
        else:
            sql = """select count(pj.id) ct from pms_project pj left join pms_pro_status pps on pps.ID = pj.status where (pps.name != '已完成' and pps.name != '已关闭' or pps.name is null) and pj.father = %s""" % projectId
            unfinish_child_ct = rd.select(sql)
            if unfinish_child_ct[0]['ct'] == 0:
                makeComment(projectId)
                sql = """update pms_project set t_end_date = to_char(sysdate,'yyyy-mm-dd HH:mi:ss'),status = (select id from pms_pro_status where name = '已完成' and type = 1) where pms_project.id = %s""" % projectId
                rd.update(sql)


def makeComment(project_id):
    sql = """
        select ppd.id from pms_project pj
        left join pms_project_dev ppd on ppd.pms_project_id = pj.id
        left join pms_project_stage pps on pps.id = ppd.PMS_PROJECT_STAGE_ID
        where pj.id = %s order by pps.code
            """ % project_id
    dev_ids = rd.select(sql)
    for i in range(len(dev_ids)):
        comment_audit(dev_ids[i]['id'])
