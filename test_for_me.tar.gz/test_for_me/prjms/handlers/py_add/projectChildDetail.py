import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts


class ChildDetailIndexHandler(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        page = self.get_argument("page")
        showType = self.get_argument("type")
        sql = "select id,name from pms_pro_status where type = 1 order by code"
        pro_status = rd.select(sql)
        sql = "select id,code,name from pms_organizations"
        org = rd.select(sql)
        pms_pmsPro = rd.select('select * from pms_project_stage')
        url = 'html_add/pmsProChildDetail.html'
        user_id = self.session['user_id']
        user_sql = '''select * from pms_role where id in (select role_id from pms_user_role where user_id = %s)'''%user_id
        data = rd.select(user_sql)
        #权限配置返回值(1：系统管理者权限 2：项目总监权限  3：项目经理权限 4：普通人员权限)
        for i in data:
            if i['name'] == '机构管理员' or i['name']=='项目总监' or i['name']=='系统管理员' or i['name'] =='项目经理':
                url = 'html_add/pmsProChildDetail2.html'
        if showType == 'all':
            self.render(url,page=page,showType=showType,pro_status=pro_status,org=org,pms_pmsPro = pms_pmsPro)
        else:
            fCode = self.get_argument("fCode")
            self.render(url,page=page,showType=showType,fCode=fCode,pro_status=pro_status,org=org,pms_pmsPro = pms_pmsPro)
    
    @tornado.web.authenticated
    def post(self):
        cProjectName = self.get_argument("cProjectName")
        manageUserN = self.get_argument("manageUserN")
        cCode = self.get_argument("cCode")
        fCode = self.get_argument("fCode")
        cProjectStatus = self.get_argument("cProjectStatus")
        org_id = self.get_argument("organization")
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        user_id = self.session['user_id']
        role_sql = """select pr.name name,pu.name pu_name from pms_role pr left join pms_user_role pur on pr.id = pur.role_id left join pms_user pu on pu.id = pur.user_id where pu.id = %s """%user_id
        user_roles = rd.select(role_sql)
        sql_s = 'or (ppd.id in (select ppdc.pms_project_dev_id dev_id from pms_project_dev_child_user ppdcu left join pms_project_dev_child ppdc on ppdc.id = ppdcu.dev_child_id  where ppdcu.user_id = %s) or ppd.dev_user_id = %s) '%(user_id,user_id)
        for i in user_roles:
            if i['name'] == "项目经理":
                sql_s += 'or (pj.org_manager_user_id = %s or pj.manager_user_id = %s) '%(user_id,user_id)
                break
        for i in user_roles:
            if i['name'] == '项目总监' or i['name'] == '机构管理员':
                sql_s = 'or (pj.pms_org_id =(select org_id from pms_user where id = %s) or pj.pms_supp_id = (select org_id from pms_user where id = %s)) '%(user_id,user_id)
                break
        for i in user_roles:
            if i['name'] == "系统管理员" :
                sql_s = ''
                break
        #sql = """select pf.code pf_code,pj.id,pj.code,pj.name,pj.p_start_date,pj.p_end_date,pj.pms_level,pj.pms_dangous_level,pu.name as pms_project_dev_user,pps.name as pms_project_stage_name, pj.status as status        from pms_project pj        left join pms_project_dev ppd on ppd.id = pj.pms_dev_id        left join pms_user pu on pu.id = ppd.dev_user_id        left join pms_project_stage pps on pps.id = ppd.pms_project_stage_id left join pms_project pf on pf.id = pj.father where pj.IS_CHILD = 1 """
        sql = """
            select pf.code pf_code,pj.pms_dev_id,pj.id,pj.code,pj.name,pj.p_start_date,pj.p_end_date,pj.pms_dangous_level,pu.name as pms_project_dev_user,pps.name as pms_project_stage_name,pps.code as pms_project_stage_code , pj.status as status        from pms_project pj        left join pms_project_dev ppd on ppd.id = pj.pms_dev_id        left join pms_user pu on pu.id = ppd.dev_user_id  left join pms_project pp on pp.id = ppd.pms_project_id      left join pms_project_stage pps on pps.id = ppd.pms_project_stage_id left join pms_project pf on pf.id = pj.father where (pj.IS_CHILD = 1) and (pj.status !=5 and pj.status !=14)
                """
        sql_s = sql_s.strip('or')
        if sql_s != "":
            sql += ' and ('+sql_s+')'
        if cProjectName is not None  and  cProjectName != "":
            sql += " and pj.name like '%" + cProjectName + "%'"
        if manageUserN is not None  and  manageUserN != "":
            sql += " and pu.name like '%" + manageUserN + "%'"
        if cCode is not None and cCode != '':
            sql += " and pj.code = %s"%cCode
        if cProjectStatus is not None and cProjectStatus !='':
            sql += " and pj.status = '%s'"%cProjectStatus
        if org_id is not None and org_id !='':
            sql += " and pj.pms_org_id = '%s'"%org_id
        if fCode is not None and fCode != '':
            sql += "and pf.code = '%s'"%fCode
        sql = sql + " order by pj.id desc"
        pms_user,pms_user_count = rd.select_limit_with_count(sql, pageSize, curPage)
        #sql_x = """select pps.code,pp.id,ppd.id dev_id from pms_project_stage pps left join pms_project_dev ppd on ppd.PMS_PROJECT_STAGE_ID = pps.id left join pms_project pp on pp.id = ppd.pms_project_id where pp.is_child = 1"""
        sql_x = """select pps.code,pp.id,ppd.id dev_id from pms_project_stage pps left join pms_project_dev ppd on ppd.PMS_PROJECT_STAGE_ID = pps.id left join pms_project pp on pp.id = ppd.pms_project_id where pp.is_child = 1 order by pps.code"""
        all_dev = rd.select(sql_x)
        for i in pms_user:
            i['stages'] = []
            i['dev_id'] = []
            for j in all_dev:
                if j['id'] == i['id']:
                    i['stages'].append(j['code'])
                    i['dev_id'].append(j['dev_id'])
                if j['dev_id'] == i['pms_dev_id']:
                    break
        self.write({'total': pms_user_count, 'data': pms_user})
