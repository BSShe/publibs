# -*- coding: utf-8 -*-

import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts
import os

class pmsTestHandler(BaseHandler):
    #打开项目测试功能界面
    @tornado.web.authenticated
    def post(self):
        project_id=self.get_argument("id")
         
        id = rd.select("select ppd.id from pms_project_dev  ppd left join pms_project_stage pps on ppd.pms_project_stage_id = pps.id where pms_project_id = %s  and pps.code= '05' "%project_id)[0]['id']
        sql = 'select * from pms_project_dev_report where dev_id = %s'%id
        data = rd.select(sql)
        stage =rd.select('select * from pms_project_dev_child ppdc left join pms_project_stage pps on ppdc.pms_project_stage_id = pps.id  where pms_project_dev_id = %s '%id)
        print (stage)
        if len(data) > 0:
            message1 = data[0].message1
            message2 = data[0].message2
            message3 = data[0].message3
            message4 = data[0].message4
        else :
            message1 = None
            message2 = None
            message3 = None
            message4 = None
        files = 'select files from pms_project_dev where id = %s'%id
        files = rd.select(files)
        
        if len(files) > 0 :
            print (files)
            if files !=None and files !='':
                files = []
            else:
                files = files[0]['files'].split(';')
        self.render("pmsManager/html_add/pmsTest.html",id=id,data1=message1,data2=None,data3=None,data4=None,files=files,stage_id=id,stage = stage)


class pmsTestFileUploadHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        num=self.get_argument("num")
        fileName=self.get_argument("fileName")
        #项目id
        id=self.get_argument("id")        
        #文件保存路径及名字
        filePath='./static/files/'+fileName
        sql = 'select files from pms_project_dev where id = %s'%id
        files = rd.select(sql)
        if len(files)>0:
            files = files[0] +';' + filePath
        else:
            files = filePath
        sql2 = "update pms_project_dev set files ='%s' where id = %s"%(files,id)
        rd.update(sql2)
        print (sql2)
        inner=self.request.files.get("file",None)
        if num == '1':
            with open(filePath,"wb") as g:
                for meta in inner:
                    g.write(meta["body"])
        else:
            with open(filePath,"ab") as g:
                for meta in inner:
                    g.write(meta["body"])


class pmsTestFileCheckSuccessHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        fileName=self.get_argument("fileName")
        id=self.get_argument("id")
        fileSize=self.get_argument("fileSize")
        filePath='./static/files/'+fileName
        sql = 'select * from pms_project_dev where pms_project_id = %s'%id
        nowFileSize=os.path.getsize(filePath)
        status={"status":1}
        if nowFileSize < int(fileSize):
            status["status"]=0
            os.remove(filePath)
        self.write(status)


class pmsTestFileDownloadHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        id=self.get_argument("id")
        fileName=self.get_argument("fileName")
        self.set_header("Content-Type","application/octet-stream")
        downloadName='attachment;filename='+fileName
        downloadName=downloadName.encode()
        self.set_header("Content-Disposition",downloadName)
        filePath='./static/files/'+fileName
        buff=1024*1024*2
        with open(filePath,"rb") as f:
            while 1:
                block=f.read(buff)
                if not block:
                    break
                self.write(block)
        self.finish()


class pmsTestGetTextHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        id=self.get_argument("id")
        iType=self.get_argument("type")
        #回填内容
        #查询对应的数据回填到界面上
        sql = 'select * from pms_project_dev where pms_project_id = %s'%id
        data = rd.select(sql)
        if len(data)>0:
            data_tmp = []
            for i in data:
                pass
        if iType == 'projectProgramText':
            
            text=[{'title':'test1','text':'  12345\r\n123'},{'title':'test2','text':'  yuws\r\nsdas'}]
            self.write(json.dumps(text))
        else:
            text=[{'title':'test3','text':'  12345\r\n123'},{'title':'test4','text':'  yuws\r\nsdas'}]
            self.write(json.dumps(text))


class pmsTestTextSubmitHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        data=self.get_argument("data")
        stage_id =self.get_argument('stage_id')
        type = self.get_argument('type')
        user_id = self.session['id']
        print (data)
        #此处将数据填入后台内容
        #此处查询对应的项目阶段并将阶段的项目进度报告值录入
        #添加表，表对应5个content参数，分别根据对应的阶段输入,绑定对应的阶段id
        
        if type =="projectOutlineDesignArea":
            message1 = '环境准备'
        elif type =="systemArchDesignArea":
            message1 = '业务测试'
        sql = "select * from pms_project_dev_report where dev_id = %s and message1='%s'"%(stage_id,message1)
        stage = rd.select(sql)
        if len(stage)>0:
            sql2 = "update pms_project_dev_report (message2) to (%s) where dev_id = %s and message1='%s'"%(data,stage_id,message1)
        else:
            sql2 = "insert pms_project_dev_report (id,message1,message2,dev_id) values(seq_pms_project_dev_report.nextval,'%s',%s,%s)"%(message1,data,stage_id)
        rd.insert(sql2)
        self.write({"status":"1"})
