#维护加入WS通信的在线列表

userList={}

