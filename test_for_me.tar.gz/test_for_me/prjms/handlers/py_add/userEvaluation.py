# -*- coding: utf-8 -*-

import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts
import os
import time

def makeSQL(sql,selectMinDate,selectMaxDate,searchName):
    if selectMinDate is not None and selectMinDate != "":
        sql = sql + " and pms_user_evaluation_score.year >= '%s' and pms_user_evaluation_score.month >= '%s'" %(selectMinDate[0:4], selectMinDate[4:])
    if selectMaxDate is not None and selectMaxDate != "":
        sql = sql + " and pms_user_evaluation_score.year <= '%s' and pms_user_evaluation_score.month <= '%s'" %(selectMaxDate[0:4], selectMaxDate[4:])
    if searchName is not None and searchName != "":
        sql = sql + "and pms_user.name like '%s'"%("%"+searchName+"%")
    return sql


class GetUserEvInfoHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        selectMinDate = self.get_argument('selectMinDate')
        selectMaxDate = self.get_argument('selectMaxDate')
        searchName = self.get_argument('searchName')
        sql = """
            select pms_user.no,pms_user.name user_name,pms_organizations.name org_name,pms_user.PHONE_NO,(100 - pms_user_evaluation_score.check_in_deducted) check_in_score,(100 - pms_user_evaluation_score.DISCIPLINE_DEDUCTED) discipline_score,pms_user_evaluation_score.RESIDUE_SCORE,(pms_user_evaluation_score.year||pms_user_evaluation_score.month) as year_month
from pms_user_evaluation_score 
join pms_user on pms_user.id = pms_user_evaluation_score.PMS_USER_ID 
join PMS_ORGANIZATIONS on PMS_ORGANIZATIONS.id = pms_user.org_id where 1=1
                """
        sql = makeSQL(sql,selectMinDate,selectMaxDate,searchName)
        sql = sql + "order by year_month desc"
        userEv,userEv_count = rd.select_limit_with_count(sql, pageSize, curPage)
        self.write({'total': userEv_count, 'data': userEv})
