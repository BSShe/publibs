from handlers.handler import BaseHandler
from tornado.websocket import WebSocketHandler

class BaseWebSocketHandler(BaseHandler,WebSocketHandler):
    pass
