import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts
from handlers.py_add.projectDetail import getProjectDevInfo,getProgress,getRealWorkLoad,getProjectDevStatus
from handlers.pmsManager.projectManager import checkCreateRole


class ChildManageIndexHandler(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        user_id = self.session['user_id']
        page = self.get_argument("page",1)
        showType = self.get_argument("type")
        sql = "select id,name from pms_pro_status where type = 1 order by code"
        pro_status = rd.select(sql)
        sql = "select id,code,name from pms_organizations"
        org = rd.select(sql)
        close_child_project_role = checkCreateRole(user_id,'项目综合管理','关闭子项目(按钮)')
        child_work_plan_role = checkCreateRole(user_id,'项目综合管理','子项目计划制定(按钮)')
        child_work_plan_imp_role = checkCreateRole(user_id,'项目综合管理','子项目计划变更(按钮)')
        if showType == 'all':
            self.render("html_add/pmsProChildManage.html",pro_status=pro_status,showType=showType,org=org,page = page,close_child_project_role = close_child_project_role,child_work_plan_role = child_work_plan_role,child_work_plan_imp_role = child_work_plan_imp_role)
        else:
            fCode = self.get_argument("fCode")
            self.render("html_add/pmsProChildManage.html",pro_status=pro_status,showType=showType,org=org,page = page,close_child_project_role = close_child_project_role,child_work_plan_role = child_work_plan_role,child_work_plan_imp_role = child_work_plan_imp_role,fCode=fCode)
    
    @tornado.web.authenticated
    def post(self):
        cProjectName = self.get_argument("cProjectName")
        manageUserN = self.get_argument("manageUserN")
        cCode = self.get_argument("cCode")
        fCode = self.get_argument("fCode")
        cProjectStatus = self.get_argument("cProjectStatus")
        org_id = self.get_argument("organization")
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        user_id = self.session['user_id']
        role_sql = """select pr.name name,pu.name pu_name from pms_role pr left join pms_user_role pur on pr.id = pur.role_id left join pms_user pu on pu.id = pur.user_id where pu.id = %s """%user_id
        user_roles = rd.select(role_sql)
        sql_s = 'or ppd.id in (select ppdc.pms_project_dev_id dev_id from pms_project_dev_child_user ppdcu left join pms_project_dev_child ppdc on ppdc.id = ppdcu.dev_child_id  where ppdcu.user_id = %s) '%user_id
        for i in user_roles:
            if i['name'] == "项目经理":
                sql_s = 'or (pp.org_manager_user_id = %s or pp.manager_user_id = %s) '%(user_id,user_id)
                break
        for i in user_roles:
            if i['name'] == '项目总监' or i['name'] == '机构管理员':
                sql_s = 'or (pj.pms_org_id = (select org_id from pms_user where id = %s) or pj.pms_supp_id = (select org_id from pms_user where id = %s) ) '%(user_id,user_id)
                break
        for i in user_roles:
            if i['name'] == "系统管理员" :
                sql_s = ''
                break
        sql = """select pf.code pf_code,pj.id,pj.code,pj.name,pj.p_start_date,pj.p_end_date,prp2.name pms_level,prp.name pms_dangous_level,pu.name as pms_project_dev_user,pps.name as pms_project_stage_name, pps2.name as status        from pms_project pj        left join pms_project_dev ppd on ppd.id = pj.pms_dev_id        left join pms_user pu on pu.id = ppd.dev_user_id    left join pms_project pp on pp.id = ppd.pms_project_id    left join pms_project_stage pps on pps.id = ppd.pms_project_stage_id left join pms_project pf on pf.id = pj.father left join pms_pro_status pps2 on pps2.id = pj.status left join pms_risk_param prp on pj.pms_dangous_level = prp.id left join pms_risk_param prp2 on prp2.id = pj.pms_level where pj.IS_CHILD = 1 """
        sql_s = sql_s.strip('or')
        if sql_s != "":
            sql += ' and ('+sql_s+')'
        if cProjectName is not None  and  cProjectName != "":
            sql += " and pj.name like '%" + cProjectName + "%'"
        if manageUserN is not None  and  manageUserN != "":
            sql += " and pu.name like '%" + manageUserN + "%'"
        if cCode is not None and cCode != '':
            sql += " and pj.code = %s"%cCode
        if cProjectStatus is not None and cProjectStatus !='':
            sql += " and pj.status = '%s'"%cProjectStatus
        if org_id is not None and org_id !='':
            sql += " and pj.pms_org_id = '%s'"%org_id
        if fCode is not None and fCode != '':
            sql += "and pf.code = '%s'"%fCode
        sql = sql + " order by pj.id desc"
        child_info,child_count = rd.select_limit_with_count(sql, pageSize, curPage)
        self.write({'total': child_count, 'data': child_info})


class ChildWatchMoreHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument("id")
        page = self.get_argument("page")
        sql = """
                select pj.code,pj.name pj_name,pc.name pc_name,pps.name pps_name,pj.pms_number,pj.p_start_date,pj.p_end_date,pj.t_start_date,
                pj.t_end_date,prp.name pms_dangous_level,ppp.name ppp_name,ppt.name ppt_name,pj.pms_supp_id,po2.name po2_name,prp2.name pms_level,
                pu.name pu_name,ps.name ps_name,po.name po_name,pot.name pot_name,pps2.name pps2_name
                from pms_project pj
                left join pms_contract pc on pc.code = pj.HT_CODE
                left join pms_project_dev ppd on ppd.id = pj.pms_dev_id
                left join pms_project_stage pps on pps.id = ppd.pms_project_stage_id
                left join pms_project_property ppp on ppp.id = pj.pms_project_property_id
                left join pms_project_type ppt on ppt.id = pj.pms_pro_type_id
                left join pms_pro_status pps2 on pps2.id = pj.STATUS
                left join pms_user pu on pu.id = pj.MANAGER_USER_ID
                left join pms_status ps on ps.id = pu.STATUS_ID
                left join pms_organizations po on po.id = pu.ORG_ID
                left join pms_organizations po2 on po2.id = pj.pms_org_id
                left join pms_org_type pot on pot.id = po.type_id
                left join pms_risk_param prp on pj.pms_dangous_level = prp.id 
                left join pms_risk_param prp2 on prp2.id = pj.pms_level
                where pj.id = %s
                """ % id
        allInfo = rd.select(sql)    
        sql = """
                select pu.name pu_name,pps.name pps_name,ppd.p_start_date,ppd.p_end_date,ppd.start_date,
                ppd.end_date,ppd.dev_number,ppd.use_dates,decode(is_comp,1,'已完成','未完成') is_comp
                from (select * from pms_project_dev where pms_project_id = %s) ppd
                left join pms_user pu on pu.id = ppd.dev_user_id
                left join pms_project_stage pps on pps.id = ppd.pms_project_stage_id
                order by pps.code
                """ % id
        stageInfo = rd.select(sql)
        self.render("html_add/pmsProCMWatchMore.html",allInfo = allInfo[0],stageInfo = stageInfo,page = page)

class GetFCodeInfoHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        data = self.get_argument("data")
        user_id = self.session['user_id']
        role_sql = """select pr.name name,pu.name pu_name from pms_role pr left join pms_user_role pur on pr.id = pur.role_id left join pms_user pu on pu.id = pur.user_id where pu.id = %s """%user_id
        user_roles = rd.select(role_sql)
        sql_s = ' and ppd.id in (select ppdc.pms_project_dev_id dev_id from pms_project_dev_child_user ppdcu left join pms_project_dev_child ppdc on ppdc.id = ppdcu.dev_child_id  where ppdcu.user_id = %s)'%user_id
        for i in user_roles:
            if i['name'] == "项目经理":
                sql_s = 'and (pp.org_manager_user_id = %s or pp.manager_user_id = %s)'%(user_id,user_id)
                break
        for i in user_roles:
            if i['name'] == '项目总监' or i['name'] == '机构管理员':
                sql_s = 'and (pj.pms_org_id = (select org_id from pms_user where id = %s) or pj.pms_supp_id = (select org_id from pms_user where id = %s) )'%(user_id,user_id)
                break
        for i in user_roles:
            if i['name'] == "系统管理员" :
                sql_s = ''
                break
        sql = "select distinct pf.code pf_code from pms_project pj        left join pms_project_dev ppd on ppd.id = pj.pms_dev_id left join pms_project pf on pf.id = pj.father left join pms_project pp on pp.id = ppd.pms_project_id where pj.IS_CHILD = 1 and pf.code like '"+data+"%' "
        sql = sql + sql_s
        result = rd.select(sql)
        self.write({"data":result})
        


class ChildWatchChartHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument("id")
        page = self.get_argument("page")
        projectDevInfo = getProjectDevInfo(id)
        self.render("html_add/pmsProCMWatchChart.html",page=page,id=id,projectDevInfo=projectDevInfo)
