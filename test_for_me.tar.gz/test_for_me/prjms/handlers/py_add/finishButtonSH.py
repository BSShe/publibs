import database.readdb as rd


def getFinishRole(id,user_id,stageName):
    show_finish_button = False
    #角色为总监，经理，测试人员显示完成进度按钮
    role_sql = """
        select distinct pms_menu_button.NAME button_role from pms_user
        join pms_user_role on pms_user_role.USER_ID = pms_user.ID
        join pms_role on pms_role.ID = pms_user_role.ROLE_ID
        join pms_role_menu_button on pms_role_menu_button.ROLE_ID = pms_role.ID
        join pms_menu_button on pms_menu_button.ID = pms_role_menu_button.PMS_MENU_BUTTON_ID
        join pms_menu on pms_menu.ID = pms_menu_button.MENU_ID
        where pms_user.id = %s and pms_menu.NAME='项目进度管理' and pms_menu_button.NAME = '确认进度完成(按钮)'
                """ % str(user_id)
    result = rd.select(role_sql)
    if len(result) != 0:
        show_finish_button = True
    else:
        #角色为该项目负责人或此阶段负责人，按钮可见
        sql = """
                select distinct pms_user.id from (select manager_user_id from pms_project where id = %d) pj
                join pms_user on pj.manager_user_id = pms_user.id
                where pms_user.id = %s UNION
                select distinct pms_user.id from (select dev_user_id,pms_project_stage_id from pms_project_dev where pms_project_id = %d) pd
                join pms_user on pms_user.id = pd.dev_user_id
                join pms_project_stage on pms_project_stage.id = pd.pms_project_stage_id
                where pms_user.id = %s and pms_project_stage.NAME = '%s'
                """ % (int(id),str(user_id),int(id),str(user_id),stageName)
        result = rd.select(sql)
        if len(result) != 0:
            show_finish_button = True
    return show_finish_button
