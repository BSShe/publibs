# -*- coding: utf-8 -*-

import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts



class projectDetail2Handler(BaseHandler):
    #页面跳转到详情页
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        pms_sql = "select pms_project_stage.name pms_project_stage_name, pms_user.name pms_user_name,p.p_start_date,p.p_end_date,p.start_date,p.end_date,p.files,p.use_dates,p.is_comp,p.dev_number from (select * from pms_project_dev where pms_project_id = "+id+") p left join pms_project_stage on pms_project_stage.id=p.pms_project_stage_id left join pms_user on pms_user.id = p.dev_user_id order by p.start_date"
        pms_statusList = rd.select(pms_sql)
        sql = "select pms_project.*,pms_project_property.name pms_project_property_name,pms_project_type.name pms_project_type_name,pms_user.name pms_user_name,pms_organizations.name pms_organizations_name,pms_org_type.name pms_org_type_name,pms_status.name pms_status_name,pms_project_stage.name pms_project_stage_name from pms_project left join pms_user on pms_project.manager_user_id = pms_user.id left join pms_project_type on pms_project_type.id = pms_project.pms_pro_type_id left join pms_project_property on pms_project_property.id = pms_project.pms_project_property_id left join pms_organizations on pms_organizations.id = pms_user.org_id left join pms_org_type on pms_org_type.id = pms_organizations.type_id left join pms_status on pms_status.id = pms_organizations.status_id and pms_status.id = pms_user.status_id left join pms_project_dev on pms_project.pms_dev_id = pms_project_dev.id left join pms_project_stage on pms_project_dev.pms_project_stage_id = pms_project_stage.id where pms_project.id ="+id
        data = rd.select(sql)
        check = '演示数据'
        now_dev_sql = 'select * from pms_project_dev ppd left join pms_project_stage pps on pps.id = ppd.pms_project_stage_id  where ppd.id = %s '%data[0]['pms_project_dev_id']
        now_dev = rd.select(now_dev_sql)
        self.render('pmsManager/pms_index_detail5.html',data = data[0],dev_data=pms_statusList,now_dev = now_dev)
