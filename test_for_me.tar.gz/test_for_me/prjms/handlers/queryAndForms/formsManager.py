# -*- coding: utf-8 -*-

import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts

class formsListHandler(BaseHandler):
    #打开报表管理界面
    @tornado.web.authenticated
    def get(self):
        #pms_station = rd.select('select * from pms_organizations ')
        pms_statusList = rd.select('select * from pms_status where code like \'user%\'')
        pms_stationList = rd.select('select * from pms_station')
        pms_orgList = rd.select('select * from pms_organizations')
        self.render('queryAndForms/forms-manager.html', stationList = pms_stationList, statusList = pms_statusList, orgList = pms_orgList)
    #获取列表
    @tornado.web.authenticated
    def post(self):
        no = self.get_argument('no')
        name = self.get_argument('name')
        org_id = self.get_argument('org_id')
        station_id = self.get_argument('station_id')
        status_id = self.get_argument('status_id')
        sql = """select pu.id , pu.no, pu.name, pu.phone_no, pu.st_date, pss.name as status, psn.name as station_name, pos.name as org from pms_user pu
                 left join pms_station psn on psn.id = pu.station_id
                 left join pms_status pss on pss.id = pu.status_id
                 left join pms_organizations pos on pos.id = pu.org_id
                 where 1=1 """
        if no is not None  and  no != "":
            sql += " and pu.no like '%" + no + "%'"
        if name is not None  and  name != "":
            sql += " and pu.name like '%" + name + "%'"
        if status_id is not None  and  status_id != "":
            sql += " and pu.status_id = '" + status_id + "'"
        if station_id is not None  and  station_id != "":
            sql += " and pu.station_id = '" + station_id + "'"
        if org_id is not None  and  org_id != "":
            sql += " and pu.org_id = '" + org_id + "'"

        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']
        sql += " and pu.status_id != '%s'" % status_delete
        sql += " order by pu.id "
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_user,pms_user_count = rd.select_limit_with_count(sql, pageSize, curPage)

        self.write({'total': pms_user_count, 'data': pms_user})

class formsDelHandler(BaseHandler):
    #删除信息
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        sql = "update pms_user set status_id = 'delete' where id = '" + id + "'"
        rd.update(sql)
        self.write({'result': 'true'})

class formsBfUpdateHandler(BaseHandler):
    #修改信息前,回显必要信息
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        sql = "select * from pms_user  where id = '" + id + "'"
        data = rd.select(sql)
        self.write(data[0])

class formsToUpdateHandler(BaseHandler):
    #修改信息
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        rd.updatebyDict('pms_user',requestBy_dict)
        self.write({'result': 'true'})

class formsToAddHandler(BaseHandler):
    #新增信息
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        rd.insertbyDict('pms_user',requestBy_dict)
        self.write({'result': 'true'})

class formsProListHandler(BaseHandler):
    #
    @tornado.web.authenticated
    def get(self):
        self.render('queryAndForms/manage-user-proList.html')
    @tornado.web.authenticated
    def post(self):
        org_id = self.get_argument('org_id')
        sql = """select pu.id, pu.no, pu.name, pu.phone_no, pos.name as org_name, psn.name as station_name, pss.name as status_name 
                from pms_user pu
                join pms_organizations pos on pu.org_id = pos.id
                join pms_station psn on pu.station_id = psn.id
                join pms_status pss on pu.status_id = pss.id
                where pu.org_id = '%s'""" %org_id
        sql += " order by pu.id "
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_user,pms_user_count = rd.select_limit_with_count(sql,pageSize ,curPage)

        self.write({'total': pms_user_count, 'data': pms_user}) 
