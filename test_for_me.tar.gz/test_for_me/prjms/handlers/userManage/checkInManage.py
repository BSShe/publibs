# -*- coding: utf-8 -*-

import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts
import os
import datetime
import time
from urllib.parse import quote
from business_calendar import Calendar,MO, TU, WE, TH, FR, SA, SU 
import logging

class CheckInListHandler(BaseHandler):
    #打开用户考勤管理界面
    @tornado.web.authenticated
    def get(self):
        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']
        pms_orgList = rd.select('select * from pms_organizations where status_id != \'%s\' order by id' %status_delete)
        user_auth = rd.select("""
                                select * from pms_user pu
                                    join pms_user_role pur on pur.user_id = pu.id
                                    join pms_role pr on pr.id = pur.role_id
                                    where pu.id = '%s' and pr.name = '系统管理员'
                                """% self.session['user_id'])
        #如果当前登录用户角色不包含管理员，则只允许看本机构信息
        if not user_auth or len(user_auth) == 0:
            pms_orgList = rd.select('select * from pms_organizations where status_id != \'%s\' and id in (select org_id from pms_user where id = %s) order by id' %(status_delete,self.session['user_id']))
        self.render('userManage/checkIn-manage.html', orgList = pms_orgList)
    #获取用户考勤列表
    @tornado.web.authenticated
    def post(self):
        start_date = self.get_argument('start_date')
        end_date = self.get_argument('end_date')
        org_id = self.get_argument('org_id')
        name = self.get_argument('name')
        no = self.get_argument('no')
        now = time.localtime()
        begin = '%d%02d01' %(now.tm_year, now.tm_mon)#本月初
        end = '%d%02d%02d' %(now.tm_year, now.tm_mon, now.tm_mday)#今天
        if start_date and start_date != '':
            begin = start_date
        if end_date and end_date != '' and end_date <= end:
            end = end_date
        #早于上线时间以上线时间为下限
        if config.ONLINE_DATE > begin:
            begin = config.ONLINE_DATE
        if config.ONLINE_DATE > end:
            end = config.ONLINE_DATE
        logging.info(begin)
        time_quantum = begin + '-' + end
        # 过滤 双休和节假日
        holidaysDict = config.HOLIDAYS
        holidaysList = []
        for k1 in holidaysDict:
            for k2 in holidaysDict[k1]:
                holidaysList.append(k1 + k2)
        cal = Calendar(workdays=[MO, TU, WE, TH, FR, SA, SU],holidays=holidaysList)
        days = cal.busdaycount(datetime.datetime.strptime(begin, '%Y%m%d') - datetime.timedelta(days=1),datetime.datetime.strptime(end, '%Y%m%d'))


        user_auth = rd.select("""
                                select * from pms_user pu
                                    join pms_user_role pur on pur.user_id = pu.id
                                    join pms_role pr on pr.id = pur.role_id
                                    where pu.id = '%s' and pr.name = '系统管理员'
                                """% self.session['user_id'])
        auth_range = ""
        #如果当前登录用户角色不包含管理员，则只允许看本机构信息
        if not user_auth or len(user_auth) == 0:
            auth_range = " where cki_data.user_org_id = (select org_id from pms_user where id = '%s')" %self.session['user_id']
        else:
            if org_id and org_id != "":
                auth_range = " where cki_data.user_org_id = '%s'" %org_id
            else:
                auth_range = " where 1 = 1 "
        no_sql = ""
        if no and no != "":
            no_sql = " and cki_data.user_no = '%s'" %no
        name_sql = ""
        if name and name != "":
            name_sql = " and cki_data.user_name like '%" + name + "%'"
        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']

        sql = """
            select cki_data.* , po.name as org_name from 
            (select max(user_id) as user_id, max(user_no) as user_no, max(user_name) as user_name , max(user_org_id) as user_org_id, to_char(%s - (count(*) - sum(null_count))/2)  as  no_check_in_days ,sum(pspu.shangban_outtime) as sb_error, sum(pspu.xiaban_outtime) as xb_error, '%s' as time_quantum 
                                from 
                                    (
                                        select max(pu.id) as user_id, max(pu.no) as user_no,max(pu.name) as user_name, max(pu.org_id) as user_org_id,count(*) as count ,max(datetime) as datetime ,
                                            case when to_char(max(time),'hh24mi')   < replace(max(pm_end_time),':','')   then 1 else 0 end as xiaban_outtime , 
                                            case when to_char(min(time),'hh24mi')  >= replace(min(pm_start_time),':','')   then 1 else 0  end as shangban_outtime,
                                            case when max(datetime) is null then 1 else 0 end as null_count
                                            from pms_user pu
                                            left join (select * from PMS_SIGNRECODE where  replace(datetime,'-','') >= '%s' and  replace(datetime,'-','') <= '%s' and to_char(time,'hh24mi') >= replace(noon_time,':',''))  ps on pu.id = ps.pms_user_id
                                            where pu.status_id != '%s'
                                            group by ps.datetime, pu.no 
                                        union all
                                        select max(pu.id) as user_id, max(pu.no) as user_no,max(pu.name) as user_name, max(pu.org_id) as user_org_id,count(*) as count ,max(datetime) as datetime ,
                                            case when to_char(max(time),'hh24mi')   < replace(max(am_end_time),':','')  then 1 else 0 end as xiaban_outtime , 
                                            case when to_char(min(time),'hh24mi')  >= replace(min(am_start_time),':','')  then 1 else 0  end as shangban_outtime,
                                            case when max(datetime) is null then 1 else 0 end as null_count
                                            from pms_user pu
                                            left join (select * from PMS_SIGNRECODE where  replace(datetime,'-','') >= '%s' and  replace(datetime,'-','') <= '%s' and to_char(time,'hh24mi') < replace(noon_time,':',''))  ps on pu.id = ps.pms_user_id
                                            where pu.status_id != '%s'
                                            group by ps.datetime, pu.no
                                    ) 
                                pspu group by user_no) cki_data
                                join PMS_ORGANIZATIONS po on po.id = cki_data.user_org_id  %s %s %s  order by cki_data.user_org_id, cki_data.user_no
                """ % (days, time_quantum, begin, end, status_delete, begin, end, status_delete,auth_range,no_sql,name_sql)
        logging.info(sql)
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_checkIn,pms_checkIn_count = rd.select_limit_with_count(sql, pageSize, curPage)
        self.write({'total': pms_checkIn_count, 'data': pms_checkIn})

class CheckInAloneListHandler(BaseHandler):
    #展示 单独员工的 打卡列表
    @tornado.web.authenticated
    def get(self):
        self.render('userManage/aloneCheckIn.html')
    @tornado.web.authenticated
    def post(self):
        user_id = self.get_argument('user_id')
        start_date = self.get_argument('start_date')
        end_date = self.get_argument('end_date')
        now = time.localtime()
        begin = '%d%02d01' %(now.tm_year, now.tm_mon)
        end = '%d%02d%02d' %(now.tm_year, now.tm_mon, now.tm_mday)
        if start_date and start_date != '':
            begin = start_date
        if end_date and end_date != '':
            end = end_date
        #早于上线时间以上线时间为准
        if config.ONLINE_DATE > begin:
            begin = config.ONLINE_DATE
        sql = """
                select  pu.no, pu.name, to_char(time,'hh24:mi:ss') as time, datetime, latitude, longitude from PMS_SIGNRECODE ps
                    join pms_user pu on pu.id = ps.pms_user_id
                    where ps.pms_user_id = '%s'  and  replace(ps.datetime,'-','') >= '%s' and  replace(ps.datetime,'-','') <= '%s'  order by ps.time desc
                """  % (user_id, begin, end)
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_alone_user_check_in,pms_alone_user_check_in_count = rd.select_limit_with_count(sql,pageSize ,curPage)
        for index in range(len(pms_alone_user_check_in)):
            pms_alone_user_check_in[index]['xuhao'] = index + 1
        self.write({'total': pms_alone_user_check_in_count, 'data': pms_alone_user_check_in})


class NCIDListHandler(BaseHandler):
    #展示 单独员工的 未打卡日期列表
    @tornado.web.authenticated
    def get(self):
        self.render('userManage/ncid.html')
    @tornado.web.authenticated
    def post(self):
        user_id = self.get_argument('user_id')
        start_date = self.get_argument('start_date')
        end_date = self.get_argument('end_date')
        now = time.localtime()
        begin = '%d%02d01' %(now.tm_year, now.tm_mon)
        end = '%d%02d%02d' %(now.tm_year, now.tm_mon, now.tm_mday)
        if start_date and start_date != '':
            begin = start_date
        if end_date and end_date != '':
            end = end_date
        #早于上线时间以上线时间为准
        if config.ONLINE_DATE > begin:
            begin = config.ONLINE_DATE
        # 过滤 双休和节假日
        holidaysDict = config.HOLIDAYS
        holidaysList = []
        for k1 in holidaysDict:
            for k2 in holidaysDict[k1]:
                holidaysList.append(k1 + k2)
        holidaysList = str(holidaysList).replace('[','(').replace(']',')')
        workday = []
        sql = """
                select  replace(datetime,'-','') as datetime from PMS_SIGNRECODE ps
                join pms_user pu on pu.id = ps.pms_user_id
                where ps.pms_user_id = '%s'  and  replace(ps.datetime,'-','') >= '%s' and  replace(ps.datetime,'-','') <= '%s' and to_char(ps.time,'hh24mi') < replace(ps.noon_time,':','') 
                intersect 
                select  replace(datetime,'-','') as datetime from PMS_SIGNRECODE ps
                join pms_user pu on pu.id = ps.pms_user_id
                where ps.pms_user_id = '%s'  and  replace(ps.datetime,'-','') >= '%s' and  replace(ps.datetime,'-','') <= '%s' and to_char(ps.time,'hh24mi') >= replace(ps.noon_time,':','') 
                """%(user_id, begin, end,user_id, begin, end)
        workday_date = rd.select(sql)
        for wd in workday_date:
            workday.append(wd['datetime'])
        workday = str(workday).replace('[','(').replace(']',')')
        workday_sql = "replace(dates,'-','') not in %s and " %workday
        if len(workday_date) == 0:
            workday_sql = ""
        half_workday = []
        half_sql1 = """
                select  replace(datetime,'-','') as datetime from PMS_SIGNRECODE ps
                join pms_user pu on pu.id = ps.pms_user_id
                where ps.pms_user_id = '%s'  and  replace(ps.datetime,'-','') >= '%s' and  replace(ps.datetime,'-','') <= '%s' and to_char(ps.time,'hh24mi') < replace(ps.noon_time,':','') 
                minus 
                select  replace(datetime,'-','') as datetime from PMS_SIGNRECODE ps
                join pms_user pu on pu.id = ps.pms_user_id
                where ps.pms_user_id = '%s'  and  replace(ps.datetime,'-','') >= '%s' and  replace(ps.datetime,'-','') <= '%s' and to_char(ps.time,'hh24mi') >= replace(ps.noon_time,':','') 
                """%(user_id, begin, end,user_id, begin, end)
        half_sql2 = """
                select  replace(datetime,'-','') as datetime from PMS_SIGNRECODE ps
                join pms_user pu on pu.id = ps.pms_user_id
                where ps.pms_user_id = '%s'  and  replace(ps.datetime,'-','') >= '%s' and  replace(ps.datetime,'-','') <= '%s' and to_char(ps.time,'hh24mi') >= replace(ps.noon_time,':','') 
                minus 
                select  replace(datetime,'-','') as datetime from PMS_SIGNRECODE ps
                join pms_user pu on pu.id = ps.pms_user_id
                where ps.pms_user_id = '%s'  and  replace(ps.datetime,'-','') >= '%s' and  replace(ps.datetime,'-','') <= '%s' and to_char(ps.time,'hh24mi') < replace(ps.noon_time,':','') 
                """%(user_id, begin, end,user_id, begin, end)
        half_workday_date1 = rd.select(half_sql1) #一天内只上午打卡
        half_workday_date2 = rd.select(half_sql2) #一天内只下午打卡
        for hwd1 in half_workday_date1:
            half_workday.append(hwd1['datetime'])
        for hwd2 in half_workday_date2:
            half_workday.append(hwd2['datetime'])
        half_workday = str(half_workday).replace('[','(').replace(']',')')
        half_workday_sql = "" 
        if len(half_workday_date1) == 0 and len(half_workday_date2) == 0:
            half_workday_sql = " dates "
        else:
            half_workday_sql = "case when replace(dates,'-','') in %s then concat(dates,'(半天未打卡)') else dates end as dates" %half_workday
        sql = """ select rownum as xuhao, %s  from (
                            select  to_char(to_date('%s','YYYYMMDD')+level-1 ,'yyyy-mm-dd')as dates
                                from dual connect by level <= to_date('%s','YYYYMMDD')-to_date('%s','YYYYMMDD')+1 )
                                where  %s  replace(dates,'-','') not in %s order by dates 
              """  % (half_workday_sql,begin, end, begin,workday_sql, holidaysList)
        logging.info(sql)
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_alone_user_check_in,pms_alone_user_check_in_count = rd.select_limit_with_count(sql,pageSize ,curPage)
        self.write({'total': pms_alone_user_check_in_count, 'data': pms_alone_user_check_in})

class SEListHandler(BaseHandler):
    #展示 单独员工的 迟到列表
    @tornado.web.authenticated
    def get(self):
        self.render('userManage/se.html')
    @tornado.web.authenticated
    def post(self):
        user_id = self.get_argument('user_id')
        start_date = self.get_argument('start_date')
        end_date = self.get_argument('end_date')
        now = time.localtime()
        begin = '%d%02d01' %(now.tm_year, now.tm_mon)
        end = '%d%02d%02d' %(now.tm_year, now.tm_mon, now.tm_mday)
        if start_date and start_date != '':
            begin = start_date
        if end_date and end_date != '':
            end = end_date
        #早于上线时间以上线时间为准
        if config.ONLINE_DATE > begin:
            begin = config.ONLINE_DATE
        sql = """
                select rownum as xuhao,r.* from (
                    select case when to_char(min(ps.time),'hh24:mi:ss') >= min(ps.am_start_time)  then to_char(min(time),'hh24:mi:ss')  else 'normal' end as time, datetime  from PMS_SIGNRECODE ps
                    join pms_user pu on pu.id = ps.pms_user_id
                    where ps.pms_user_id = '%s'  and  replace(ps.datetime,'-','') >= '%s' 
                    and  replace(ps.datetime,'-','') <= '%s'  and to_char(ps.time,'hh24mi') < replace(ps.noon_time,':','') group by ps.datetime
                    union all
                    select case when to_char(min(ps.time),'hh24:mi:ss') >= min(ps.pm_start_time)  then to_char(min(time),'hh24:mi:ss')  else 'normal' end as time, datetime  from PMS_SIGNRECODE ps
                    join pms_user pu on pu.id = ps.pms_user_id
                    where ps.pms_user_id = '%s'  and  replace(ps.datetime,'-','') >= '%s' 
                    and  replace(ps.datetime,'-','') <= '%s'  and to_char(ps.time,'hh24mi') >= replace(ps.noon_time,':','') group by ps.datetime
                ) r where time != 'normal' order by r.datetime, r.time
                """  % (user_id, begin, end, user_id, begin, end)
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_alone_user_se,pms_alone_user_se_count = rd.select_limit_with_count(sql,pageSize ,curPage)
        self.write({'total': pms_alone_user_se_count, 'data': pms_alone_user_se})

class XEListHandler(BaseHandler):
    #展示 单独员工的 早退列表
    @tornado.web.authenticated
    def get(self):
        self.render('userManage/xe.html')
    @tornado.web.authenticated
    def post(self):
        user_id = self.get_argument('user_id')
        start_date = self.get_argument('start_date')
        end_date = self.get_argument('end_date')
        now = time.localtime()
        begin = '%d%02d01' %(now.tm_year, now.tm_mon)
        end = '%d%02d%02d' %(now.tm_year, now.tm_mon, now.tm_mday)
        if start_date and start_date != '':
            begin = start_date
        if end_date and end_date != '':
            end = end_date
        #早于上线时间以上线时间为准
        if config.ONLINE_DATE > begin:
            begin = config.ONLINE_DATE
        sql = """
                select rownum as xuhao,r.* from (
                    select case when to_char(max(ps.time),'hh24:mi:ss') < min(ps.am_end_time)  then to_char(min(time),'hh24:mi:ss')  else 'normal' end as time, datetime  from PMS_SIGNRECODE ps
                    join pms_user pu on pu.id = ps.pms_user_id
                    where ps.pms_user_id = '%s'  and  replace(ps.datetime,'-','') >= '%s' 
                    and  replace(ps.datetime,'-','') <= '%s'  and to_char(ps.time,'hh24mi') < replace(ps.noon_time,':','') group by ps.datetime
                    union all
                    select case when to_char(max(ps.time),'hh24:mi:ss') < min(ps.pm_end_time)  then to_char(min(time),'hh24:mi:ss')  else 'normal' end as time, datetime  from PMS_SIGNRECODE ps
                    join pms_user pu on pu.id = ps.pms_user_id
                    where ps.pms_user_id = '%s'  and  replace(ps.datetime,'-','') >= '%s' 
                    and  replace(ps.datetime,'-','') <= '%s'  and to_char(ps.time,'hh24mi') >= replace(ps.noon_time,':','') group by ps.datetime
                ) r where r.time != 'normal' order by r.datetime, r.time
                """  % (user_id, begin, end, user_id, begin, end)
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_alone_user_xe,pms_alone_user_xe_count = rd.select_limit_with_count(sql,pageSize ,curPage)
        self.write({'total': pms_alone_user_xe_count, 'data': pms_alone_user_xe})
class CheckInExportInfoHandler(BaseHandler):
    #人员考勤信息 导出
    @tornado.web.authenticated
    def get(self):
        start_date = self.get_argument('start_date')
        end_date = self.get_argument('end_date')
        now = time.localtime()
        begin = '%d%02d01' %(now.tm_year, now.tm_mon)#本月初
        end = '%d%02d%02d' %(now.tm_year, now.tm_mon, now.tm_mday)#今天
        org_id = self.get_argument('org_id')
        name = self.get_argument('name')
        no = self.get_argument('no')
        if start_date and start_date != '':
            begin = start_date
        if end_date and end_date != '' and end_date <= end:
            end = end_date
        time_quantum = begin + '-' + end
        #早于上线时间以上线时间为下限
        if config.ONLINE_DATE > begin:
            begin = config.ONLINE_DATE
        # 过滤 双休和节假日
        holidaysDict = config.HOLIDAYS
        holidaysList = []
        for k1 in holidaysDict:
            for k2 in holidaysDict[k1]:
                holidaysList.append(k1 + k2)
        cal = Calendar(workdays=[MO, TU, WE, TH, FR],holidays=holidaysList)
        days = cal.busdaycount(datetime.datetime.strptime(begin, '%Y%m%d') - datetime.timedelta(days=1),datetime.datetime.strptime(end, '%Y%m%d'))


        user_auth = rd.select("""
                                select * from pms_user pu
                                    join pms_user_role pur on pur.user_id = pu.id
                                    join pms_role pr on pr.id = pur.role_id
                                    where pu.id = '%s' and pr.name = '系统管理员'
                                """% self.session['user_id'])
        auth_range = ""
        #如果当前登录用户角色不包含管理员，则只允许看本机构信息
        if not user_auth or len(user_auth) == 0:
            auth_range = " where cki_data.user_org_id = (select org_id from pms_user where id = '%s')" %self.session['user_id']
        else:
            if org_id and org_id != "":
                auth_range = " where cki_data.user_org_id = '%s'" %org_id
            else:
                auth_range = " where 1 = 1 "
        no_sql = ""
        if no and no != "":
            no_sql = " and cki_data.user_no = '%s'" %no
        name_sql = ""
        if name and name != "":
            name_sql = " and cki_data.user_name like '%" + name + "%'"
        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']

        sql = """
            select cki_data.* , po.name as org_name from 
            (select max(user_id) as user_id, max(user_no) as user_no, max(user_name) as user_name , max(user_org_id) as user_org_id, to_char(%s - (count(*) - sum(null_count))/2)  as  no_check_in_days ,sum(pspu.shangban_outtime) as sb_error, sum(pspu.xiaban_outtime) as xb_error, '%s' as time_quantum 
                                from 
                                    (
                                        select max(pu.id) as user_id, max(pu.no) as user_no,max(pu.name) as user_name, max(pu.org_id) as user_org_id,count(*) as count ,max(datetime) as datetime ,
                                            case when to_char(max(time),'hh24mi')   < replace(max(pm_end_time),':','')   then 1 else 0 end as xiaban_outtime , 
                                            case when to_char(min(time),'hh24mi')  >= replace(min(pm_start_time),':','')   then 1 else 0  end as shangban_outtime,
                                            case when max(datetime) is null then 1 else 0 end as null_count
                                            from pms_user pu
                                            left join (select * from PMS_SIGNRECODE where  replace(datetime,'-','') >= '%s' and  replace(datetime,'-','') <= '%s' and to_char(time,'hh24mi') >= replace(noon_time,':',''))  ps on pu.id = ps.pms_user_id
                                            where pu.status_id != '%s'
                                            group by ps.datetime, pu.no 
                                        union all
                                        select max(pu.id) as user_id, max(pu.no) as user_no,max(pu.name) as user_name, max(pu.org_id) as user_org_id,count(*) as count ,max(datetime) as datetime ,
                                            case when to_char(max(time),'hh24mi')   < replace(max(am_end_time),':','')  then 1 else 0 end as xiaban_outtime , 
                                            case when to_char(min(time),'hh24mi')  >= replace(min(am_start_time),':','')  then 1 else 0  end as shangban_outtime,
                                            case when max(datetime) is null then 1 else 0 end as null_count
                                            from pms_user pu
                                            left join (select * from PMS_SIGNRECODE where  replace(datetime,'-','') >= '%s' and  replace(datetime,'-','') <= '%s' and to_char(time,'hh24mi') < replace(noon_time,':',''))  ps on pu.id = ps.pms_user_id
                                            where pu.status_id != '%s'
                                            group by ps.datetime, pu.no
                                    ) 
                                pspu group by user_no) cki_data
                                join PMS_ORGANIZATIONS po on po.id = cki_data.user_org_id  %s %s %s  order by cki_data.user_org_id, cki_data.user_no
                """ % (days, time_quantum, begin, end, status_delete, begin, end, status_delete,auth_range,no_sql,name_sql)
        data = rd.select(sql)
        nowtime = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = '人员考勤信息' + nowtime + '.xls'
        self.set_header('Content-Type', 'application/octet-stream')
        self.set_header('Content-Disposition', 'attachment; filename= %s' %quote(filename))
        head = ['人员编号','人员姓名','所属机构','未打卡天数','迟到次数','早退次数','时间段']
        body = ['user_no', 'user_name', 'org_name', 'no_check_in_days', 'sb_error', 'xb_error', 'time_quantum']
        self.write(hts.public_exportInfo(filename, data, head, body))
        self.finish()
