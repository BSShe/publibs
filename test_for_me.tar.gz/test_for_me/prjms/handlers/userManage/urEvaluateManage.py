# -*- coding: utf-8 -*-

import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts
import os
import datetime
from urllib.parse import quote

class UrEvaluateListHandler(BaseHandler):
    #打开人员评价管理界面
    @tornado.web.authenticated
    def get(self):
        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']
        pms_orgList = rd.select('select * from pms_organizations where status_id != \'%s\' order by id' %status_delete)
        user_auth = rd.select("""
                                select * from pms_user pu
                                    join pms_user_role pur on pur.user_id = pu.id
                                    join pms_role pr on pr.id = pur.role_id
                                    where pu.id = '%s' and pr.name = '系统管理员'
                                """% self.session['user_id'])
        #如果当前登录用户角色不包含管理员，则只允许看本机构信息
        if not user_auth or len(user_auth) == 0:
            pms_orgList = rd.select('select * from pms_organizations where status_id != \'%s\' and id in (select org_id from pms_user where id = %s) order by id' %(status_delete,self.session['user_id']))
        #pms_station = rd.select('select * from pms_organizations ')
        self.render('userManage/evaluate-manage.html', orgList = pms_orgList )
    #获取人员评价管理列表
    @tornado.web.authenticated
    def post(self):
        day = str(datetime.date.today()).replace('-','')
        year_month = self.get_argument('year_month')
        org_id = self.get_argument('org_id')
        name = self.get_argument('name')
        no = self.get_argument('no')

        user_auth = rd.select("""
                                select * from pms_user pu
                                    join pms_user_role pur on pur.user_id = pu.id
                                    join pms_role pr on pr.id = pur.role_id
                                    where pu.id = '%s' and pr.name = '系统管理员'
                                """% self.session['user_id'])
        auth_range = ""
        #如果当前登录用户角色不包含管理员，则只允许看本机构信息
        if not user_auth or len(user_auth) == 0:
            auth_range = " and pu.org_id = (select org_id from pms_user where id = '%s')" %self.session['user_id']
        else:
            if org_id and org_id != "":
                auth_range = " and pu.org_id = '%s'" %org_id
        no_sql = ""
        if no and no != "":
            no_sql = " and pu.no = '%s'" %no
        name_sql = ""
        if name and name != "":
            name_sql = " and pu.name like '%" + name + "%'"
        
        sql = """
                select pues.id as id , (100 - pues.check_in_deducted) as check_in_score,(100 - pues.discipline_deducted) as discipline_score, pues.residue_score as residue_score , (pues.year||pues.month) as year_month 
                        ,to_char((select ROUND(sum(residue_score)/count(month),2)  from  pms_user_evaluation_score pues2 where pues2.year = pues.year and pues2.pms_user_id = pues.pms_user_id  group by pues2.pms_user_id,pues2.year)) as year_residue_score,
                         pu.no as no, pu.name as name , pu.phone_no as phone_no ,po.name as org_name, pues.manual_up as manual_up, pues.pms_user_id as pms_user_id 
                from pms_user_evaluation_score pues
                join pms_user  pu on pu.id = pues.pms_user_id
                join PMS_ORGANIZATIONS po on po.id = pu.ORG_ID
                where 1=1  %s %s %s
                """%(auth_range,no_sql,name_sql)
        if year_month and year_month != '':
            sql += " and pues.year = '%s' and month = '%s'" %(year_month[0:4], year_month[4:])
        else:
            sql += " and pues.year = '%s' and month = '%s'" %(day[0:4], day[4:6])
        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']
        sql += " and pu.status_id != '%s'" %status_delete
        sql += "order by po.id,pu.no"
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_user_evaluation_score,pms_user_evaluation_score_count = rd.select_limit_with_count(sql, pageSize, curPage)
        self.write({'total': pms_user_evaluation_score_count, 'data': pms_user_evaluation_score})

class UrEvaluateBfUpdateHandler(BaseHandler):
    #修改信息前,回显必要信息
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        sql = """
                select pues.id as id , (100 - pues.check_in_deducted) as check_in_score,(100 - pues.discipline_deducted) as discipline_score, pues.residue_score as residue_score , (pues.year||pues.month) as year_month 
                        ,to_char((select ROUND(sum(residue_score)/count(month),2)  from  pms_user_evaluation_score pues2 where pues2.year = pues.year and pues2.pms_user_id = pues.pms_user_id  group by pues2.pms_user_id,pues2.year)) as year_residue_score,
                         pu.no as no, pu.name as name , pu.phone_no as phone_no ,po.name as org_name
                from pms_user_evaluation_score pues
                join pms_user  pu on pu.id = pues.pms_user_id
                join PMS_ORGANIZATIONS po on po.id = pu.ORG_ID
                where pues.id = '%s' 
                """ %id
        data = rd.select(sql)
        self.write(data[0])

class UrEvaluateToUpdateHandler(BaseHandler):
    #修改信息
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        requestBy_dict['manual_up'] = 'true'
        rd.updatebyDict('pms_user_evaluation_score',requestBy_dict)
        self.write({'result': 'true'})

class UrEvaluateExportInfoHandler(BaseHandler):
    #人员评价信息 导出
    @tornado.web.authenticated
    def get(self):
        day = str(datetime.date.today()).replace('-','')
        year_month = self.get_argument('year_month')

        user_auth = rd.select("""
                                select * from pms_user pu
                                    join pms_user_role pur on pur.user_id = pu.id
                                    join pms_role pr on pr.id = pur.role_id
                                    where pu.id = '%s' and pr.name = '系统管理员'
                                """% self.session['user_id'])
        auth_range = ""
        #如果当前登录用户角色不包含管理员，则只允许看本机构信息
        if not user_auth or len(user_auth) == 0:
            auth_range = " and pu.org_id = (select org_id from pms_user where id = '%s')" %self.session['user_id']

        sql = """
                select pues.id as id , (100 - pues.check_in_deducted) as check_in_score,(100 - pues.discipline_deducted) as discipline_score, pues.residue_score as residue_score , (pues.year||pues.month) as year_month 
                        ,to_char((select ROUND(sum(residue_score)/count(month),2)  from  pms_user_evaluation_score pues2 where pues2.year = pues.year and pues2.pms_user_id = pues.pms_user_id  group by pues2.pms_user_id,pues2.year)) as year_residue_score,
                         pu.no as no, pu.name as name , pu.phone_no as phone_no ,po.name as org_name, pues.manual_up as manual_up
                from pms_user_evaluation_score pues
                join pms_user  pu on pu.id = pues.pms_user_id
                join PMS_ORGANIZATIONS po on po.id = pu.ORG_ID
                where 1=1  %s 
                """% auth_range
        if year_month and year_month != '':
            sql += " and pues.year = '%s' and month = '%s'" %(year_month[0:4], year_month[4:])
        else:
            sql += " and pues.year = '%s' and month = '%s'" %(day[0:4], day[4:6])
        sql += "order by po.id"
        data = rd.select(sql)
        nowtime = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = '人员评价信息' + nowtime + '.xls'
        self.set_header('Content-Type', 'application/octet-stream')
        self.set_header('Content-Disposition', 'attachment; filename= %s' %quote(filename))
        head = ['编号','姓名','所属机构','联系方式','月考勤得分','月纪律得分','月综合评分','同年综合评分','查询月份']
        body = ['no', 'name', 'org_name', 'phone_no', 'check_in_score', 'discipline_score', 'residue_score', 'year_residue_score', 'year_month']
        self.write(hts.public_exportInfo(filename, data, head, body))
        self.finish()

class UrEvaluateShowChartHandler(BaseHandler):
    #人员评价同年评分图表展示
    @tornado.web.authenticated
    def get(self):
        self.render('userManage/evaluateChart.html' )  
    @tornado.web.authenticated
    def post(self):
        year_month = self.get_argument('year_month')
        pms_user_id = self.get_argument('pms_user_id')
        data = rd.select("select max(residue_score) as residue_score ,month from pms_user_evaluation_score where pms_user_id = '%s'  and year = '%s' group by month order by month" %(pms_user_id,year_month[0:4]))
        self.write({'result': 'true', 'data': data})
        
