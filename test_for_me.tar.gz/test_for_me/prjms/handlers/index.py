# -*- coding: utf-8 -*-
import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config , sessionClass
import json
import datetime
import  handlers.utils  as hts
import logging

class LoginHandler(BaseHandler):
    def get(self):
        if self.session['username']:         
            self.redirect("/")
        else: 
            self.render('login.html',is_show = 'hidden')
    def post(self):
        username = self.get_argument('username')
        password = self.get_argument('password')
        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']
        user_infos = rd.select("""
                                select pu.id , pu.password , pu.st_date,pu.ed_date,ps1.name as user_status, ps2.name as org_staus, pos.st_date as org_st_date from pms_user pu 
                                    join pms_organizations pos on pos.id = pu.org_id
                                    join pms_status ps1 on ps1.id = pu.status_id
                                    join pms_status ps2 on ps2.id = pos.status_id
                                where pu.no = '%s' and pu.status_id != '%s'
                                """ %(username,status_delete))
        if user_infos:
            db_pwd = user_infos[0]['password']
            if db_pwd == hts.encodePasswd(password):
                day = str(datetime.date.today()).replace('-','')
                if user_infos[0]['user_status'] == '停用':
                    self.write({'msg': '当前帐号状态为\'停用\',禁止登入,请联系管理员!', 'result': 'false'})
                elif user_infos[0]['org_staus'] == '停用':
                    self.write({'msg': '当前帐号所属机构状态为\'停用\',禁止登入,请联系管理员!', 'result': 'false'})
                elif day < user_infos[0]['st_date']: 
                    self.write({'msg': '当前帐号入场时间为(%s),时间未到,禁止登入！' %user_infos[0]['st_date'], 'result': 'false'})
                elif user_infos[0]['ed_date'] and day >= user_infos[0]['ed_date']:
                    self.write({'msg': '当前帐号离场时间为(%s),时间已到,禁止登入！' %user_infos[0]['ed_date'], 'result': 'false'})
                elif day < user_infos[0]['org_st_date']: 
                    self.write({'msg': '当前帐号所属机构启动时间为(%s),时间未到,禁止登入！' %user_infos[0]['org_st_date'], 'result': 'false'})
                else:   
                    if db_pwd == hts.encodePasswd(config.INIT_USER_PASSWD):
                        self.write({'msg': 'change_init', 'result': 'false','user_id':user_infos[0]['id']})
                    else:    
                        if config.SESSION_MODE == 0: 
                            self.set_secure_cookie("username", self.get_argument("username"))
                        self.session['user_id'] = user_infos[0]['id']       #将用户名保存到session
                        self.session['username'] = username          #将用户名保存到session
                        self.session['password'] =  password         #将密码保存到session
                        self.redirect("/") 
            else:
                self.write({'msg': '密码错误！', 'result': 'false'})
        else:
            self.write({'msg': '当前用户不存在,请确认帐号输入无误！', 'result': 'false'})

class LoginOutHandler(BaseHandler):
    def post(self):
        if config.SESSION_MODE == 0: 
            self.clear_cookie('username')
        #session = sessionClass.Session(self,0)
        self.session['username'] = None
        self.write({'result':'true','url':'/'})


class IndexHandler(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        username = tornado.escape.xhtml_escape(self.current_user)
        user_infos = rd.select('select * from pms_user where no = \'%s\'' %username)
        menu_infos = rd.select("""select * from pms_menu where url is null and id in (select pm.id from pms_role_menu prm 
                                                                                        join pms_user_role pur on pur.ROLE_ID = prm.ROLE_ID
                                                                                        join pms_menu pm on pm.id = prm.MENU_ID
                                                                                        where pur.USER_ID = '%s' ) order by id 
                                    """ %self.session['user_id'])
        list = []
        sublist = []
        count = 5
        for mi in menu_infos: 
            child = {}
            child['icon'] = mi['icon']
            child['name'] = mi['name']
            child['data'] = rd.select("""select * from pms_menu where pid = \'%s\' and id in (select pm.id from pms_role_menu prm 
                                                                                                  join pms_user_role pur on pur.ROLE_ID = prm.ROLE_ID
                                                                                                  join pms_menu pm on pm.id = prm.MENU_ID
                                                                                                  where pur.USER_ID = '%s' ) order by id 
                                        """ %(mi['id'], user_infos[0]['id']))
            list.append(child)
        mes1 = rd.select("select count(id) ct from pms_risk_mes where status = 0 and GET_MES_USER_ID = %s" % user_infos[0]['id'])
        mes2 = rd.select("select count(id) ct from pms_mes_recode where type = 0 and GET_DATA_USER_ID = %s" % user_infos[0]['id']) 
        print (list)
        self.render('index.html',user = {'name':user_infos[0]['name'],'id':user_infos[0]['id']}, list = list, sublist = sublist, count = count,mesCount = mes1[0]['ct']+mes2[0]['ct'])

class UpPassWdHandler(BaseHandler):
    def get(self):
        self.render('updatePassWd.html')
    def post(self):
        print (self.request.body)
        logging.info(self.request.body)
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        old_password = requestBy_dict.pop('old_password')
        requestBy_dict.pop('again_password')
        
        encode_pd = hts.encodePasswd(old_password)
        the_user = rd.select("select * from pms_user where id = '%s' and password = '%s'" %(requestBy_dict['id'], encode_pd))
        if not the_user:
            self.write({'result':'false', 'msg':'旧密码错误!'})
        else:
            requestBy_dict['password'] = hts.encodePasswd(requestBy_dict['password'])
            rd.updatebyDict('pms_user',requestBy_dict)
            if config.SESSION_MODE == 0: 
                self.clear_cookie('username')
            session = sessionClass.Session(self,0)
            session['username'] = None
            self.write({'result':'true', 'msg':'密码修改成功,请重新登录!'})
            

class PageNotFoundHandler(tornado.web.RequestHandler):
    def get(self):
        return self.write_error(404)
