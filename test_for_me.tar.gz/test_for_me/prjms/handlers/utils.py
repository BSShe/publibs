# -*- coding: utf-8 -*-
"""
@author: Conight
@software: Yinsho
@file: utils.py
@time: 4/23/2018 16:14
@desc:
"""
import datetime
import errno
import json
import os
import signal
from functools import wraps
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor

from handlers.exceptions import ArgMissError
from urllib import parse
import datetime
from urllib.parse import quote
import xlwt
from config import config
import hashlib


class Singleton(object):
    def __new__(cls, *args, **kw):
        if not hasattr(cls, '_instance'):
            orig = super(Singleton, cls)
            cls._instance = orig.__new__(cls, *args, **kw)
        return cls._instance


class ThreadExecutor(ThreadPoolExecutor):
    _instance = None

    def __new__(cls, *args, **kwargs):
        if not getattr(cls, '_instance', None):
            cls._instance = ThreadPoolExecutor(None)
        return cls._instance


class ProcessExecutor(ProcessPoolExecutor):
    _instance = None

    def __new__(cls, *args, **kwargs):
        if not getattr(cls, '_instance', None):
            cls._instance = ProcessPoolExecutor(max_workers=2)
        return cls._instance


class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, datetime.datetime):
            return o.strftime('%Y-%m-%d %H:%M:%S')

        return json.JSONEncoder.default(self, o)


class DateEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, datetime.datetime):
            return o.strftime('%Y-%m-%d')

        return json.JSONEncoder.default(self, o)


def data_util(data):
    if data is None:
        return ' NULL'
    else:
        return ' \'{}\''.format(data)


def update_util(data):
    if data is None:
        return ' NULL'
    else:
        return ' \'{}\''.format(data)


def date_util(data):
    if data:
        return " to_date('{}', 'yyyy-mm-dd')".format(data)
    else:
        return ' NULL'


def datetime_util(data):
    if data:
        return " to_date('{}', 'YYYY-MM-DD HH24:MI:SS')".format(data)
    else:
        return ' NULL'


class TuxTimeoutError(Exception):
    pass


def timeout(seconds=30, error_message=os.strerror(errno.ETIME)):
    def decorator(func):
        def _handle_timeout(signum, frame):
            raise TuxTimeoutError(error_message)

        def wrapper(*args, **kwargs):
            signal.signal(signal.SIGALRM, _handle_timeout)
            signal.alarm(seconds)
            try:
                result = func(*args, **kwargs)
            finally:
                signal.alarm(0)
            return result

        return wraps(func)(wrapper)

    return decorator


def arg_check(data: dict, args: list):
    for arg in args:
        if not data.get(arg):
            raise ArgMissError('参数' + arg + '不存在')


def parse_age_from_id_no(id_no):
    birth_year = id_no[6:10]
    this_year = datetime.date.today().year
    age = this_year - int(birth_year)
    return age


def requestBodyToDict(data):
    str1 = str(data,'utf-8')
    str2 = parse.unquote(str1)
    list1 = str2.split('&')
    dict1 = {}
    for l1 in list1:
        list2 = l1.split('=')
        dict1[list2[0]] = list2[1]
    return dict1

def encodePasswd(password):
    m = hashlib.md5()
    m.update(password.encode('utf-8'))
    password_en = m.hexdigest()

    return password_en

def public_exportInfo(filename, data, head, body):
    nowtime = datetime.datetime.now().strftime('%Y%m%d_%H%M%S') 
    w = xlwt.Workbook()
    ws = w.add_sheet('sheet1')
    count1 = 0
    for hd in head:
        ws.write(0, count1, hd)
        count1 = count1 + 1

    count2 = 1
    for item in data:
        count3 = 0
        for by in body:
            ws.write(count2, count3, item[by])
            count3 = count3 + 1
        count2 = count2 + 1       
    
    filename = config.static_path + "/" + filename
    w.save(filename)
    with open(filename, 'rb') as f:
        while True:
            dt = f.read()
            if not dt:
                break
            os.system("rm %s" %filename)
            return dt

def dateRange(beginDate, endDate):
    dates = []
    dt = datetime.datetime.strptime(beginDate, "%Y-%m-%d")
    date = beginDate[:]
    while date <= endDate:
        dates.append(date)
        dt = dt + datetime.timedelta(1)
        date = dt.strftime("%Y-%m-%d")
    return dates    
