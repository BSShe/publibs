# -*- coding: utf-8 -*-

import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts
import base64
import os
import datetime
from urllib.parse import quote

class ContractListHandler(BaseHandler):
    #打开合同管理界面
    @tornado.web.authenticated
    def get(self):
        #pms_contract_role = rd.select('select * from pms_organizations ')
        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']
        pms_statusList = rd.select("select * from pms_pro_status where type = '3'")
        pms_roleList = rd.select('select * from pms_role where type = \'1\'')
        user_auth = rd.select("""
                                select * from pms_user pu
                                    join pms_user_role pur on pur.user_id = pu.id
                                    join pms_role pr on pr.id = pur.role_id
                                    where pu.id = '%s' and pr.name = '系统管理员'
                                """% self.session['user_id'])
        #if not user_auth:
        #    pms_orgList = rd.select("""select pos.* from pms_organizations pos
        #                                    join pms_org_type pot on pot.id = pos.type_id 
        #                                    where pos.status_id != '%s' and pos.id = (select org_id from pms_user where id = '%s') 
        #                                          and pot.name = '%s'  
        #                            order by pos.id""" %(status_delete,self.session['user_id'],'外包机构'))    
        #else:
        pms_orgList = rd.select("""select pos.code, pos.name  from pms_organizations pos
                                            join pms_org_type pot on pot.id = pos.type_id 
                                            where pos.status_id != '%s' and pot.name = '%s'  
                                    order by pos.id""" %(status_delete, '外包机构'))    
        pms_proList = rd.select("""select pp.code, pp.name  from pms_project pp
                                            join pms_pro_status pps on pp.status = pps.id 
                                            where (pp.manager_user_id = '%s' or pp.org_manager_user_id = '%s') and pps.code != '12'  
                                    order by pp.id desc """ %(self.session['user_id'], self.session['user_id']))    
        self.render('contractManage/manage-contract.html', roleList = pms_roleList, statusList = pms_statusList, orgList = pms_orgList, proList = pms_proList)
    #获取合同列表
    @tornado.web.authenticated
    def post(self):
        code = self.get_argument('code')
        name = self.get_argument('name')
        status_id = self.get_argument('status_id')

        user_auth = rd.select("""
                                select * from pms_user pu
                                    join pms_user_role pur on pur.user_id = pu.id
                                    join pms_role pr on pr.id = pur.role_id
                                    where pu.id = '%s' and pr.name = '系统管理员'
                                """% self.session['user_id'])
        auth_range = ""
        #如果当前登录用户角色不包含管理员，则只允许看本机构信息
        if not user_auth or len(user_auth) == 0:
            auth_range = " and pc.user_id in (select id from pms_user where org_id = (select org_id from pms_user where id = '%s'))" %self.session['user_id']
        sql = """select pcec.id , pc.id as contract_id, pc.code, pc.name, pcec.execute_progress, pps.name as status_name,concat(pu.no,concat('-',pu.name)) as build_user
                 from pms_contract_exe_condtn pcec
                 join pms_contract pc on pc.id = pcec.pms_contract_id
                 join pms_pro_status pps on pps.id = pcec.status_id
                 join pms_user pu on pu.id = pc.user_id
                 where 1=1  %s""" %auth_range
        #sql_status = "select * from pms_status where code = 'delete'"
        #status_delete = rd.select(sql_status)[0]['id']
        #sql += " and pcec.status_id != '%s'" %status_delete
        if code and code != '':
            sql += " and pc.code = '%s'" %code
        if name and name != '':
            sql += " and pc.name like '%" + name + "%'" 
        if status_id and status_id != '':
            sql += " and pcec.status_id = '%s'" %status_id
        sql += " order by pcec.id desc "
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_contract,pms_contract_count = rd.select_limit_with_count(sql, pageSize, curPage)
        self.write({'total': pms_contract_count, 'data': pms_contract})

class ContractDelHandler(BaseHandler):
    #删除合同
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('pms_contract_exe_condtn_id')
        #sql = "select * from pms_contract " 
        #bfDelData = rd.select(sql)
        #if bfDelData and len(bfDelData) > 0:
        if 2 < 1:
            self.write({'result': 'false', 'msg': '与未结束项目存在关联关系，不允许删除！'})
        else:
            sql_status = "select * from pms_status where code = 'delete'"
            status_delete = rd.select(sql_status)[0]['id']
            sql = "update pms_contract_exe_condtn set status_id = '%s' where id = '%s'" %(status_delete, id)
            rd.update(sql)
            self.write({'result': 'true'})


class ContractBfUpdateHandler(BaseHandler):
    #修改合同信息前,回显必要信息
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('contract_id')
        sql = "select * from pms_contract  where id = '" + id + "'"
        data1 = rd.select(sql)
        self.write({'contract':data1[0]})

class ContractToUpdateHandler(BaseHandler):
    #修改合同信息
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        contract_id = requestBy_dict['id']
        rd.updatebyDict('pms_contract',requestBy_dict)
        rd.update("update pms_contract_exe_condtn set status_id = '%s' where pms_contract_id = '%s'" %(requestBy_dict['status_id'],contract_id))
        self.write({'result': 'true'})

class ContractToAddHandler(BaseHandler):
    #新增合同信息
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        requestBy_dict['user_id'] = str(self.session['user_id'])
        sql = "select * from pms_contract where code = '%s'" %requestBy_dict['code']
        sql_data = rd.select(sql)
        if sql_data and len(sql_data) > 0:
            self.write({'result': 'false','msg':'合同编码已存在，不允许新增!'})
        else:
            rd.insertbyDict('pms_contract',requestBy_dict)
            this_contract = rd.selectbyDict('pms_contract',requestBy_dict)
            pcec = {'pms_contract_id':this_contract[0]['id'],'status_id':requestBy_dict['status_id']}
            rd.insertbyDict('pms_contract_exe_condtn',pcec)
            self.write({'result': 'true'})

class ContractStageListHandler(BaseHandler):
    #合同各阶段时间表
    @tornado.web.authenticated
    def get(self):
        self.render('contractManage/manage-contract-stage.html')
    @tornado.web.authenticated
    def post(self):
        contract_id = self.get_argument('contract_id')
        sql = "select * from pms_contract_stage where pms_contract_id = '%s' order by id " %contract_id
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_contract_stage,pms_contract_stage_count = rd.select_limit_with_count(sql,pageSize ,curPage)
        self.write({'total': pms_contract_stage_count, 'data': pms_contract_stage}) 

class ContractItemListHandler(BaseHandler):
    #合同特殊约定事项表
    @tornado.web.authenticated
    def get(self):
        self.render('contractManage/manage-contract-special-item.html')
    @tornado.web.authenticated
    def post(self):
        contract_id = self.get_argument('contract_id')
        sql = "select * from pms_contract_special_item where pms_contract_id = '%s' order by id " %contract_id
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_contract_special_item,pms_contract_special_item_count = rd.select_limit_with_count(sql,pageSize ,curPage)
        for index in range(len(pms_contract_special_item)):
            pms_contract_special_item[index]['xuhao'] = index + 1
        self.write({'total': pms_contract_special_item_count, 'data': pms_contract_special_item}) 

class ContractPayCondtnListHandler(BaseHandler):
    #合同付款情况表
    @tornado.web.authenticated
    def get(self):
        self.render('contractManage/manage-contract-payCondtn.html')
    @tornado.web.authenticated
    def post(self):
        contract_id = self.get_argument('contract_id')
        sql = "select * from pms_contract_pay_condtn where pms_contract_id = '%s' order by id " %contract_id
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_contract_pay_condtn,pms_contract_pay_condtn_count = rd.select_limit_with_count(sql,pageSize ,curPage)
        self.write({'total': pms_contract_pay_condtn_count, 'data': pms_contract_pay_condtn}) 

class ContractFileListHandler(BaseHandler):
    #合同扫描件文档表
    @tornado.web.authenticated
    def get(self):
        self.render('contractManage/manage-contract-file.html')
    @tornado.web.authenticated
    def post(self):
        contract_id = self.get_argument('contract_id')
        sql = "select id, concat(concat(file_name,'.'),file_type) as file_name from pms_contract_file where pms_contract_id = '%s' order by id " %contract_id
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_contract_file,pms_contract_file_count = rd.select_limit_with_count(sql,pageSize ,curPage)
        for index in range(len(pms_contract_file)):
            pms_contract_file[index]['xuhao'] = index + 1
        self.write({'total': pms_contract_file_count, 'data': pms_contract_file}) 

class ContractAddStageHandler(BaseHandler):
    #合同阶段增加
    @tornado.web.authenticated
    def get(self):
        self.render('contractManage/manage-contract-addStage.html')
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        rd.insertbyDict('pms_contract_stage',requestBy_dict)
        self.write({'result': 'true'})

class ContractAddItemHandler(BaseHandler):
    #合同特殊约定事项增加
    @tornado.web.authenticated
    def get(self):
        self.render('contractManage/manage-contract-addItem.html')
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        rd.insertbyDict('pms_contract_special_item',requestBy_dict)
        self.write({'result': 'true'})

class ContractAddPayCondtnHandler(BaseHandler):
    #合同付款情况增加
    @tornado.web.authenticated
    def get(self):
        import logging
        type = self.get_argument('type')
        if type == "1":
            contract_id = self.get_argument('contract_id')
            clt = rd.select("select DISTINCT(pay_type) as pay_type from pms_contract_pay_condtn where pms_contract_id = '%s'" %contract_id)
            payTypeList = ['首付款','阶段性付款','尾付款']
            for c in clt:
                if c['pay_type'] == "首付款":
                    payTypeList.remove("首付款")
                if c['pay_type'] == "尾付款":
                    payTypeList.pop("尾付款")
            self.write({'payTypeList': payTypeList})
        else:
            self.render('contractManage/manage-contract-addPayCondtn.html',payTypeList=[])
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        rd.insertbyDict('pms_contract_pay_condtn',requestBy_dict)
        self.write({'result': 'true'})

class ContractBfAddPayCondtnHandler(BaseHandler):
    #付款情况新增  监听 金额 ，反馈 已付，未付及 比率
    @tornado.web.authenticated
    def post(self):
        contract_id = self.get_argument('contract_id')
        amount = self.get_argument('amount').replace(',','')
        contract_pay_condtn = rd.select("select * from pms_contract_pay_condtn where pms_contract_id = '%s'" %contract_id) 
        contract = rd.select("select * from pms_contract where id = '%s'" %contract_id) 
        payCondtn_paid = 0
        payCondtn_unpaid = 0
        payCondtn_paid_ratio = 0
        for cpc in contract_pay_condtn:
            payCondtn_paid = payCondtn_paid + int(cpc['amount'])
        payCondtn_paid = payCondtn_paid + int(amount)
        if contract and len(contract) > 0:
            payCondtn_unpaid = int(contract[0]['contract_amount']) - payCondtn_paid
            payCondtn_paid_ratio = '%.4f' %(payCondtn_paid/int(contract[0]['contract_amount']))
        self.write({'payCondtn_paid':payCondtn_paid, 'payCondtn_unpaid':payCondtn_unpaid, 'payCondtn_paid_ratio': payCondtn_paid_ratio})

class ContractAddFileHandler(BaseHandler):
    #合同文件增加
    @tornado.web.authenticated
    def get(self):
        self.render('contractManage/manage-contract-addFile.html')
    @tornado.web.authenticated
    def post(self):
        pms_contract_id = self.get_argument('pms_contract_id')
        file_name = self.get_argument('file_name')
        file_metas = self.request.files['file_data']
        dirjoin = os.path.join
        for meta in file_metas:
            name = meta['filename']
            file_type = name.split('.')[1]
            content_type = meta['content_type']
            now_date = datetime.datetime.now()
            nowtime = now_date.strftime('%Y%m%d')   
            hourtime = now_date.strftime("%H%M%S")
            url_file_name = pms_contract_id + '_' + nowtime + hourtime + '.' + name.split('.')[1]    
            path = dirjoin(config.static_path,dirjoin('contractFile',url_file_name))
            with open(path, 'wb') as up:
                up.write(meta['body']) 
            rd.insertbyDict('pms_contract_file', {'pms_contract_id':pms_contract_id,'file_name':file_name,'file_type':file_type,'file_url':path})
        self.write({'result': 'true'})

class ContractDownFileHandler(BaseHandler):
    #下载合同文件
    @tornado.web.authenticated
    def get(self):
        pms_contract_file_id = self.get_argument('pms_contract_file_id')
        sql = "select * from pms_contract_file where id = '%s'" %pms_contract_file_id
        data = rd.select(sql)[0]
        self.set_header('Content-Type', 'application/octet-stream')
        self.set_header('Content-Disposition', 'attachment; filename= %s' %quote( data['file_name'] + '' + '.' + data['file_type'] ))
        with open(data['file_url'], 'rb') as f:
            while True:
                dt = f.read()
                if not dt:
                    break
                self.write(dt)
        self.finish()

class ContractGetSupplierUserHandler(BaseHandler):
    #根据供应商获取其人员列表情况表
    @tornado.web.authenticated
    def post(self):
        org= self.get_argument('org')
        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']
        sql = """select concat(pu.no,concat('-',pu.name)) as supplier_linkman 
                    from pms_user pu 
                    join pms_organizations pos on pos.id = pu.org_id
                    where pos.code = '%s' and pu.status_id != '%s' order by pu.no 
                    """ %(org.split('-')[0],status_delete)
        data = rd.select(sql)
        self.write({'result': 'true', 'data': data}) 
