# -*- coding: utf-8 -*-

import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts
from urllib.parse import quote
import datetime
import logging

class UserListHandler(BaseHandler):
    #打开人员管理界面
    @tornado.web.authenticated
    def get(self):
        #pms_user_role = rd.select('select * from pms_organizations ')
        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']
        pms_statusList = rd.select('select * from pms_status where id != \'%s\' and (code = \'01\' or code = \'02\') order by id' %status_delete)
        role_sql = 'select * from pms_role where type = \'1\''
        pms_orgList = rd.select('select * from pms_organizations where status_id != \'%s\' order by id' %status_delete)

        user_auth = rd.select("""
                                select * from pms_user pu
                                    join pms_user_role pur on pur.user_id = pu.id
                                    join pms_role pr on pr.id = pur.role_id
                                    where pu.id = '%s' and pr.name = '系统管理员'
                                """% self.session['user_id'])
        #如果当前登录用户角色不包含管理员，则只允许看本机构信息
        if not user_auth or len(user_auth) == 0:
            pms_orgList = rd.select('select * from pms_organizations where status_id != \'%s\' and id in (select org_id from pms_user where id = %s) order by id' %(status_delete,self.session['user_id']))
            role_sql = role_sql + 'and name != \'系统管理员\''
            user_auth1 = rd.select("""
                                select * from pms_user pu
                                    join pms_user_role pur on pur.user_id = pu.id
                                    join pms_role pr on pr.id = pur.role_id
                                    where pu.id = '%s' and pr.name = '机构管理员'
                                """% self.session['user_id'])
            if not user_auth1 or len(user_auth1) == 0:
                role_sql = role_sql + ' and name != \'机构管理员\' and name != \'项目总监\' '
            else:
                role_sql = role_sql + 'and name != \'机构管理员\''
        pms_roleList = rd.select(role_sql + 'order by id')
        pms_userEvaluateList = rd.select('select id, replace(name, \'(应扣分值)\', \'\') as name from  pms_user_evaluate where code in (05, 06, 07, 08, 09)')
        all_roleList = rd.select('select * from pms_role where type = \'1\' order by id')
        self.render('paramManage/manage-user.html', auth_roleList = pms_roleList, roleList = all_roleList, statusList = pms_statusList, orgList = pms_orgList, userEvaluateList = pms_userEvaluateList)
    #获取人员列表
    @tornado.web.authenticated
    def post(self):
        no = self.get_argument('no')
        name = self.get_argument('name')
        org_id = self.get_argument('org_id')
        role_id = self.get_argument('role_id')
        status_id = self.get_argument('status_id')
        user_auth = rd.select("""
                                select * from pms_user pu
                                    join pms_user_role pur on pur.user_id = pu.id
                                    join pms_role pr on pr.id = pur.role_id
                                    where pu.id = '%s' and pr.name = '系统管理员'
                                """% self.session['user_id'])
        auth_range = ""
        #如果当前登录用户角色不包含管理员，则只允许看本机构信息
        if not user_auth or len(user_auth) == 0:
            auth_range = "and pu.id in (select id from pms_user where org_id = (select org_id from pms_user where id = %s))" %self.session['user_id']


        sql = """select pu.id , pu.no, pu.name, pu.phone_no, pu.st_date, pu.ed_date, replace(replace(pu.exempt_ck_in,'true','是'),'false','否') as exempt_ck_in, pss.name as status, case when pue.name is not null then replace(pue.name,'(应扣分值)', '')  else '无违纪' end as pms_user_evaluate_name ,pos.name as org,
                 replace((select wm_concat(pr2.name) from pms_user_role pur2 join pms_role pr2 on pr2.id = pur2.role_id where pur2.user_id = pu.id),',','/') as role_name_list 
                 from pms_user pu
                 left join pms_status pss on pss.id = pu.status_id
                 left join pms_organizations pos on pos.id = pu.org_id
                 left join pms_user_evaluate pue on pue.id = pu.pms_user_evaluate_id
                 where 1=1  %s """ %auth_range
        if no is not None  and  no != "":
            sql += " and pu.no like '%" + no + "%'"
        if name is not None  and  name != "":
            sql += " and pu.name like '%" + name + "%'"
        if status_id is not None  and  status_id != "":
            sql += " and pu.status_id = '" + status_id + "'"
        if role_id is not None  and  role_id != "":
            sql += " and  pu.id in (select pur.user_id from  pms_user_role pur join pms_role pr on pr.id = pur.role_id where pr.id = '%s')" %role_id
        if org_id is not None  and  org_id != "":
            sql += " and pu.org_id = '" + org_id + "'"

        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']
        sql += " and pu.status_id != '%s'" %status_delete
        sql += " order by pu.id "
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_user,pms_user_count = rd.select_limit_with_count(sql, pageSize, curPage)
        #根据当前登录人员权限，控制单个人员信息后面的操作按钮是否可见
        role_list = self.get_arguments('ret')
        for index in range(len(pms_user)):
            flag = 'false'
            this_user_role_list = pms_user[index]['role_name_list'].split("/")
            for turl in this_user_role_list:
                if turl in role_list:
                    flag = 'true' 
            pms_user[index]['bt_show_result'] = flag
        self.write({'total': pms_user_count, 'data': pms_user})

class UserDelHandler(BaseHandler):
    #删除人员
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        #sql = "select * from pms_user " 
        #bfDelData = rd.select(sql)
        #if bfDelData and len(bfDelData) > 0:
        if 2 < 1:
            self.write({'result': 'false', 'msg': '与未结束项目存在关联关系，不允许删除！'})
        else:
            sql_status = "select * from pms_status where code = 'delete'"
            status_delete = rd.select(sql_status)[0]['id']
            sql = "update pms_user set status_id = '%s' where id = '%s'" %(status_delete, id)
            rd.update(sql)
            self.write({'result': 'true'})

class UserResetPassWdHandler(BaseHandler):
    #重置人员密码为初始密码
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        init_user_passwd = config.INIT_USER_PASSWD
        encode_pd = hts.encodePasswd(init_user_passwd)
        rd.updatebyDict('pms_user',{'id':id, 'password':encode_pd})
        self.write({'result': 'true', 'msg':'该用户重置密码成功,初始密码为%s' %init_user_passwd})

class UserBfAddOrgIdHandler(BaseHandler):
    #判断机构类型，并反馈对应值
    @tornado.web.authenticated
    def post(self):
        org_id = self.get_argument('org_id')
        sql = """ select pos.code, pot.name from pms_organizations pos
                    join pms_org_type pot on pot.id = pos.type_id
                    where pos.id = '%s'""" %org_id
        bfAddData = rd.select(sql)
        org_type_name = bfAddData[0]['name']
        org_code = bfAddData[0]['code']
        if org_type_name == '外包机构':
            sql = """ select count(*) as count from pms_user where org_id = '%s'""" %org_id
            user_count = rd.select(sql)[0]['count']
            user_count = str(int(user_count) + 1)
            user_no =  ""
            if len(user_count) == 1:
                user_no = org_code + '00' + user_count
            elif len(user_count) == 2:
                user_no = org_code + '0' + user_count
            else:
                user_no = org_code + user_count
            self.write({'result': 'true', 'user_no':user_no})
        else:
            self.write({'result': 'false'})

class UserBfUpdateHandler(BaseHandler):
    #修改人员信息前,回显必要信息
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        sql = "select * from pms_user  where id = '" + id + "'"
        data1 = rd.select(sql)
        sql = "select role_id from pms_user_role where user_id = '%s'" %id
        data2 = rd.select(sql)
        self.write({'user':data1[0],'role_id_list':data2})

class UserToUpdateHandler(BaseHandler):
    #修改人员信息
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        role_id_list = self.get_arguments('role_id_list')
        #判断不能同时担任开发人员和测试人员,以及外包机构人员不能担任系统管理员
        manager_id = rd.select("select * from pms_role where name = '系统管理员'")[0]['id']
        org_type_name = rd.select("select pot.* from pms_organizations pos join pms_org_type pot on pot.id = pos.type_id where pos.id = '%s'" %requestBy_dict['org_id'])[0]['name']
        develer_id = rd.select("select * from pms_role where name = '开发人员'")[0]['id']
        tester_id = rd.select("select * from pms_role where name = '测试人员'")[0]['id']
        if str(develer_id) in role_id_list and str(tester_id) in role_id_list:
            self.write({'result': 'false', 'msg':'不能同时兼任开发人员及测试人员!'})
        elif org_type_name == '外包机构' and str(manager_id) in role_id_list:
            self.write({'result': 'false', 'msg':'外包机构人员不能担任系统管理员!'})
        else: 
            requestBy_dict.pop('role_id_list')
            rd.own_excute("delete pms_user_role where user_id = '%s'" %requestBy_dict['id'])    
            for ril in role_id_list:
                rd.insertbyDict("pms_user_role",{'user_id':requestBy_dict['id'],'role_id':ril})
            rd.updatebyDict('pms_user',requestBy_dict)
            self.write({'result': 'true'})

class UserToAddHandler(BaseHandler):
    #新增人员信息
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        sql = "select * from pms_user where no = '%s'" %requestBy_dict['no']
        sql_data = rd.select(sql)
        if sql_data and len(sql_data) > 0:
            self.write({'result': 'false','msg':'人员编码已存在，不允许新增!'})
        else:
            role_id_list = self.get_arguments('role_id_list')
            #判断不能同时担任开发人员和测试人员,以及外包机构人员不能担任系统管理员
            manager_id = rd.select("select * from pms_role where name = '系统管理员'")[0]['id']
            org_type_name = rd.select("select pot.* from pms_organizations pos join pms_org_type pot on pot.id = pos.type_id where pos.id = '%s'" %requestBy_dict['org_id'])[0]['name']
            develer_id = rd.select("select * from pms_role where name = '开发人员'")[0]['id']
            tester_id = rd.select("select * from pms_role where name = '测试人员'")[0]['id']
            if str(develer_id) in role_id_list and str(tester_id) in role_id_list:
                self.write({'result': 'false', 'msg':'不能同时兼任开发人员及测试人员!'})
            elif org_type_name == '外包机构' and str(manager_id) in role_id_list:
                self.write({'result': 'false', 'msg':'外包机构人员不能担任系统管理员!'})
            else: 
                requestBy_dict.pop('role_id_list')
                if requestBy_dict['ed_date'] == "":
                    requestBy_dict.pop('ed_date')
                if requestBy_dict['pms_user_evaluate_id'] == "":
                    requestBy_dict.pop('pms_user_evaluate_id')
                requestBy_dict['password'] = hts.encodePasswd(config.INIT_USER_PASSWD)
                rd.insertbyDict('pms_user',requestBy_dict)
                this_user = rd.selectbyDict('pms_user',requestBy_dict)[0]
                for ril in role_id_list:
                    rd.insertbyDict("pms_user_role",{'user_id':this_user['id'], 'role_id':ril})
                self.write({'result': 'true'})

class UserExportInfoHandler(BaseHandler):
    #人员管理信息 导出
    @tornado.web.authenticated
    def get(self):
        no = self.get_argument('no')
        name = self.get_argument('name')
        org_id = self.get_argument('org_id')
        role_id = self.get_argument('role_id')
        status_id = self.get_argument('status_id')
        user_auth = rd.select("""
                                select * from pms_user pu
                                    join pms_user_role pur on pur.user_id = pu.id
                                    join pms_role pr on pr.id = pur.role_id
                                    where pu.id = '%s' and pr.name = '系统管理员'
                                """% self.session['user_id'])
        auth_range = ""
        #如果当前登录用户角色不包含管理员，则只允许看本机构信息
        if not user_auth or len(user_auth) == 0:
            auth_range = "and pu.id in (select id from pms_user where org_id = (select org_id from pms_user where id = %s))" %self.session['user_id']


        sql = """select pu.id , pu.no, pu.name, pu.phone_no, pu.st_date, pu.ed_date, replace(replace(pu.exempt_ck_in,'true','是'),'false','否') as exempt_ck_in, pss.name as status, replace(pue.name,'(应扣分值)', '') as pms_user_evaluate_name ,pos.name as org,
                 replace((select wm_concat(pr2.name) from pms_user_role pur2 join pms_role pr2 on pr2.id = pur2.role_id where pur2.user_id = pu.id),',','/') as role_name_list 
                 from pms_user pu
                 left join pms_status pss on pss.id = pu.status_id
                 left join pms_organizations pos on pos.id = pu.org_id
                 left join pms_user_evaluate pue on pue.id = pu.pms_user_evaluate_id
                 where 1=1  %s """ %auth_range
        if no is not None  and  no != "":
            sql += " and pu.no like '%" + no + "%'"
        if name is not None  and  name != "":
            sql += " and pu.name like '%" + name + "%'"
        if status_id is not None  and  status_id != "":
            sql += " and pu.status_id = '" + status_id + "'"
        if role_id is not None  and  role_id != "":
            sql += " and  pu.id in (select pur.user_id from  pms_user_role pur join pms_role pr on pr.id = pur.role_id where pr.id = '%s')" %role_id
        if org_id is not None  and  org_id != "":
            sql += " and pu.org_id = '" + org_id + "'"

        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']
        sql += " and pu.status_id != '%s'" %status_delete
        sql += " order by pu.id "
        data = rd.select(sql)
        nowtime = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = '人员管理信息' + nowtime + '.xls'
        self.set_header('Content-Type', 'application/octet-stream')
        self.set_header('Content-Disposition', 'attachment; filename= %s' %quote(filename))
        head = ['人员编号','姓名','所属机构','角色','手机号','进场时间','离场时间','是否免考勤','本月纪律情况','状态']
        body = ['no', 'name', 'org', 'role_name_list', 'phone_no', 'st_date', 'ed_date', 'exempt_ck_in', 'pms_user_evaluate_name', 'status']
        self.write(hts.public_exportInfo(filename, data, head, body))
        self.finish()

class UserProListHandler(BaseHandler):
    #
    @tornado.web.authenticated
    def get(self):
        self.render('paramManage/manage-user-proList.html')
    @tornado.web.authenticated
    def post(self):
        org_id = self.get_argument('org_id')
        sql = """select pu.id, pu.no, pu.name, pu.phone_no, pos.name as org_name,  pss.name as status_name 
                from pms_user pu
                join pms_organizations pos on pu.org_id = pos.id
                join pms_status pss on pu.status_id = pss.id
                where pu.org_id = '%s'""" %org_id
        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']
        sql += " and pu.status_id != '%s'" %status_delete
        sql += " order by pu.id "
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_user,pms_user_count = rd.select_limit_with_count(sql,pageSize ,curPage)

        self.write({'total': pms_user_count, 'data': pms_user}) 
