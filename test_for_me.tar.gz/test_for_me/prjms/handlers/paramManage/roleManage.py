# -*- coding: utf-8 -*-
import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
from config import config
import json
import  handlers.utils  as hts

class RoleListHandler(BaseHandler):
    #打开系统参数管理-角色界面
    @tornado.web.authenticated
    def get(self):
        sql = "select * from pms_menu where url is null order by id"
        menu1 = rd.select(sql)
        menuAll = []
        for m1 in menu1:
            sql2 = "select * from pms_menu where pid = '%s' order by id" %m1['id']
            menu2 =  rd.select(sql2)
            if menu2 and len(menu2) > 0:
                menu3 = []
                for m2 in menu2:
                    menu_button_list = rd.select("select * from pms_menu_button where menu_id = '%s'" %m2['id'])
                    m2['authList'] = []
                    for mbl in menu_button_list:
                        m2['authList'].append({'id': '%s_%s' %('bt',mbl['id']), 'name': mbl['name']})    
                    menu3.append(m2)
                m1['child'] = menu3
            else:
                menu_button_list = rd.select("select * from pms_menu_button where menu_id = '%s'" %m1['id'])
                m1['child'] = []
                for mbl in menu_button_list:
                    m1['child'].append({'id': '%s_%s' %('bt',mbl['id']), 'name': mbl['name'], 'authList':[]})
            menuAll.append(m1)
        
        # 部门权限信息
        sql = "select * from pms_project_stage order by id"
        stageMenu = rd.select(sql)
        for i in range(len(stageMenu)):
            sql2 = "select * from pms_project_stage_child where PMS_PROJECT_STAGE_ID = "+str( stageMenu[i]['id'])
            stageMenu2 = rd.select(sql2)
            if stageMenu2 and len(stageMenu2) > 0:
                stageMenu[i]['child'] = stageMenu2
                
        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']
        pms_statusList = rd.select('select * from pms_status where id != \'%s\' order by id' %status_delete)
        self.render('paramManage/manage-role.html',menuList = menuAll,stageMenuList = stageMenu, statusList = pms_statusList)
    #获取角色列表
    @tornado.web.authenticated
    def post(self):
        type = self.get_argument('type')#角色类型
        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']
        sql = """select * from  pms_role  psn
                 where 1=1  and status_id != '%s'""" %status_delete
        if type and type != "":
            sql += " and type = %s" %type
        sql += " order by psn.type, psn.id"
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_param_role_list,pms_param_role_list_count = rd.select_limit_with_count(sql, pageSize, curPage)
        self.write({'total': pms_param_role_list_count, 'data': pms_param_role_list})

class RoleDelHandler(BaseHandler):
    #删除角色
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        type = self.get_argument('type')
        sql = ""
        msg = ""
        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']
        if type == '1':
            sql = "select * from pms_user_role where role_id = '%s'" %id
            msg = '与用户表存在关联关系，不允许删除！'
        else:
            sql = "select * from pms_org_role where role_id = '%s'" %id 
            msg = '与机构表存在关联关系，不允许删除！'
        bfDelData = rd.select(sql)
        if bfDelData and len(bfDelData) > 0:
            self.write({'result': 'false', 'msg': msg })
        else:
            sql = "update pms_role set status_id = '%s' where id = '%s'" %(status_delete, id)
            rd.update(sql)
            self.write({'result': 'true', 'msg': '删除成功！'})

class RoleBfUpdateHandler(BaseHandler):
    #修改角色信息前,回显必要信息
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        sql = "select * from pms_role where id = '" + id + "'"
        data = rd.select(sql)
        self.write(data[0])

class RoleToUpdateHandler(BaseHandler):
    #修改角色信息
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        rd.updatebyDict('pms_role',requestBy_dict)
        self.write({'result': 'true'})

class RoleToAddHandler(BaseHandler):
    #新增角色信息
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        rd.insertbyDict('pms_role',requestBy_dict)
        self.write({'result': 'true'})

class RoleGetAuthHandler(BaseHandler):
    #填充权限菜单选中的节点:<获取所有不应选中的节点ID,在前台进行取消选中操作,为了在填充数据的同时,保持jstree的级联特性>
    @tornado.web.authenticated
    def post(self):
        role_id = self.get_argument('role_id')
        sql = """select id as tree_id from pms_menu where id not in (
                                    select menu_id as tree_id from pms_role_menu prm
                                    join pms_menu pm on pm.id = prm.menu_id
                                    where prm.role_id = '%s') 
                """ %role_id
        tree_id_list = rd.select(sql)
        sql = """
                select  id as pms_menu_button_id from pms_menu_button where id not in (
                                    select prmb.pms_menu_button_id from  
                                    pms_role_menu_button prmb 
                                    where prmb.role_id = '%s')
                """ %role_id
        role_menu_button_list = rd.select(sql)
        for rml in role_menu_button_list:
            tree_id_list.append({'tree_id': "bt" + "_" + str(rml['pms_menu_button_id'])})
        self.write({'result': 'true','tree_id_list': tree_id_list})

class RoleGetBranchHandler(BaseHandler):
    #填充部门权限菜单选中的节点:<获取所有不应选中的节点ID,在前台进行取消选中操作,为了在填充数据的同时,保持jstree的级联特性>
    @tornado.web.authenticated
    def post(self):
        role_id = self.get_argument('role_id')
        sql = "select id as stage_child_id from pms_project_stage_child where id not in (select stage_id from pms_role_stage where ROLE_ID = "+str(role_id)+")"
        tree_id_list = rd.select(sql)

        sql = "select id as tree_id from PMS_PROJECT_STAGE where id not in (select ppsc.PMS_PROJECT_STAGE_ID from pms_project_stage_child ppsc left join pms_role_stage prs on prs.STAGE_ID = ppsc.id where prs.ROLE_ID = "+str(role_id)+")"
        role_stage_list = rd.select(sql)
        for rml in tree_id_list:
            role_stage_list.append({'tree_id': "t" + "_" + str(rml['stage_child_id'])})
        self.write({'result': 'true','tree_id_list': role_stage_list})

class RoleToUpdateMenuHandler(BaseHandler):
    #更新权限菜单设置信息
    @tornado.web.authenticated
    def post(self):
        role_id = self.get_argument('id')
        id_list = self.get_arguments('id_list')
        menu_id_list = []
        button_id_list = []
        for il in id_list:
            if il.isdigit():
                menu_id_list.append(il)
            else:
                if "_" in il :
                    button_id_list.append(il)
        #权限内可见菜单
        menu_role_list = []
        for mil in menu_id_list:
            menu_role = {'role_id':role_id,'menu_id':mil}
            menu_role_list.append(menu_role)
        sql = "delete pms_role_menu where role_id = '%s'" %role_id
        rd.own_excute(sql)
        for mrl in menu_role_list:
            rd.insertbyDict('pms_role_menu',mrl)
        #权限内可见菜单中可见按钮列表
        role_menu_button_list = []
        for ail in button_id_list:
            role_menu_button = {'role_id': role_id, 'pms_menu_button_id': ail.split('_')[1]}
            role_menu_button_list.append(role_menu_button)
        sql = "delete pms_role_menu_button where role_id = '%s'" %role_id
        rd.own_excute(sql)
        for rmbl in role_menu_button_list:
            rd.insertbyDict('pms_role_menu_button', rmbl)
        self.write({'result': 'true'})

class RoleToUpdateBranchHandler(BaseHandler):
    #更新部门权限菜单设置信息
    @tornado.web.authenticated
    def post(self):
        role_id = self.get_argument('id')
        id_list = self.get_arguments('id_list')
        stage_id_list = []
        for il in id_list:
            if "_" in il :
                stage_id_list.append(il.split('_')[1])
        #权限内可见菜单
        stage_role_list = []
        for mil in stage_id_list:
            stage_role = {'role_id':role_id,'stage_id':mil}
            stage_role_list.append(stage_role)
        sql = "delete pms_role_stage where role_id = '%s'" %role_id
        rd.own_excute(sql)
        for mrl in stage_role_list:
            rd.insertbyDict('pms_role_stage',mrl)

        self.write({'result': 'true'})


class RolebyAuthGetButtonListHandler(BaseHandler):
    #根据人员角色,获取当前页面不应显示的按钮id
    @tornado.web.authenticated
    def post(self):
        menu_id = self.get_argument('global_menu_id')
        sql = """
                select html_button_id from pms_menu_button 
                    where menu_id = '%s' and id not in (select pmb.id from pms_role_menu_button prmb
                                                           join pms_menu_button pmb on pmb.ID = prmb.PMS_MENU_BUTTON_ID
                                                           where prmb.role_id in (select role_id from pms_user_role where user_id = '%s') and pmb.menu_id = '%s')
                """% (menu_id, self.session['user_id'], menu_id)
        no_show_button_id_list = rd.select(sql)
        self.write({'no_show_button_id_list':no_show_button_id_list})
