# -*- coding: utf-8 -*-

import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
from config import config
import json
import  handlers.utils  as hts

class ParamListHandler(BaseHandler):
    #打开机构管理界面
    @tornado.web.authenticated
    def get(self):
        self.render('paramManage/manage-sysParam.html')
    #获取机构列表
    @tornado.web.authenticated
    def post(self):
        pro_type = self.get_argument('pro_type')
        sql = """select * from pms_param_list ppl
                 where 1=1 """
        if pro_type is not None  and pro_type != "":
            sql += " and ppl.type= '" + pro_type + "'"

        sql += " order by ppl.id "
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_param_list,pms_param_list_count = rd.select_limit_with_count(sql, pageSize, curPage)
        self.write({'total': pms_param_list_count, 'data': pms_param_list})
