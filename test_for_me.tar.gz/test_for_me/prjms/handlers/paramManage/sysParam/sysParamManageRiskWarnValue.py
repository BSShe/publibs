# -*- coding: utf-8 -*-
import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
from config import config
import json
import  handlers.utils  as hts
import datetime

class RiskWarnValueListHandler(BaseHandler):
    #打开系统参数管理-风险预警值参数界面
    @tornado.web.authenticated
    def get(self):
        self.render('paramManage/manage-sysParam-risk-warn-value.html')
    #获取风险预警值参数列表
    @tornado.web.authenticated
    def post(self):
        sql = """select * from  pms_risk_warn_value  ppe
                 where 1=1  """
        sql += " order by ppe.code "
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_risk_warn_value_list,pms_risk_warn_value_list_count = rd.select_limit_with_count(sql, pageSize, curPage)
        self.write({'total': pms_risk_warn_value_list_count, 'data': pms_risk_warn_value_list})


class RiskWarnValueBfUpdateHandler(BaseHandler):
    #修改风险预警值参数信息前,回显必要信息
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        sql = "select * from pms_risk_warn_value where id = '" + id + "'"
        data = rd.select(sql)
        self.write(data[0])

class RiskWarnValueToUpdateHandler(BaseHandler):
    #修改风险预警值参数信息
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        rd.updatebyDict('pms_risk_warn_value',requestBy_dict)
        self.write({'result': 'true'})

class RiskWarnRemindUserHandler(BaseHandler):
    #查询提醒用户 其考勤及工作记录的预警情况
    @tornado.web.authenticated
    def get(self):
        day = str(datetime.date.today()).replace('-','')
        userScore = rd.select("select * from pms_user_evaluation_score where pms_user_id = '%s' and year = '%s' and month = '%s'" %(self.session['user_id'], day[0:4], day[4:6]))[0]
        chi_risk_score = rd.select("select * from pms_risk_warn_value where code = '01'")[0]['score'] #人员月考勤预警值
        discipline_risk_score = rd.select("select * from pms_risk_warn_value where code = '02'")[0]['score'] #人员月纪律预警值
        #month_risk_score = rd.select("select * from pms_risk_warn_value where code = '03'")[0]['score'] #人员月总评分 预警值
        if (100 - int(userScore['check_in_deducted'])) <= int(chi_risk_score):
            risk_remind_record = rd.select("select * from pms_risk_remind_record where part_id = '%s' and year = '%s' and month = '%s' and type = 'check_in'" %(self.session['user_id'], day[0:4], day[4:6]))
            if risk_remind_record:
                self.write({'result': 'true'})
            else:
                self.write({'result': 'false', 'msg':'您的当月考勤分数达到预警值，请注意个人考勤情况!', 'type': 'check_in'})
        elif (100 - int(userScore['discipline_deducted'])) <= int(discipline_risk_score):
            risk_remind_record = rd.select("select * from pms_risk_remind_record where part_id = '%s' and year = '%s' and month = '%s' and type = 'discipline'" %(self.session['user_id'], day[0:4], day[4:6]))
            if risk_remind_record:
                self.write({'result': 'true'})
            else:
                self.write({'result': 'false', 'msg':'您的当月纪律分数达到预警值，请注意个人纪律情况!', 'type': 'discipline'})
        else: 
            #requestBy_dict = hts.requestBodyToDict(self.request.body)
            #rd.updatebyDict('pms_risk_warn_value',requestBy_dict)
            self.write({'result': 'true'})

class RiskWarnRecordRemindHandler(BaseHandler):
    #记录风险提醒,只提醒一次,用户点击弹出框的确定后，记录一条数据,下次不再提醒
    @tornado.web.authenticated
    def get(self):
        day = str(datetime.date.today()).replace('-','')
        rd.insertbyDict('pms_risk_remind_record',{'part_id':self.session['user_id'], 'type':self.get_argument('type'), 'year':day[0:4], 'month':day[4:6]})
        self.write({'result': 'true'})
