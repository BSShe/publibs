# -*- coding: utf-8 -*-
import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
from config import config
import json
import  handlers.utils  as hts

class StatusListHandler(BaseHandler):
    #打开系统参数管理-状态界面
    @tornado.web.authenticated
    def get(self):
        self.render('paramManage/manage-sysParam-status.html')
    #获取状态列表
    @tornado.web.authenticated
    def post(self):
        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']
        sql = """select * from  pms_status  psn
                 where 1=1  """ #and status_id != '%s'""" %status_delete
        sql += " order by psn.code "
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_param_status_list,pms_param_status_list_count = rd.select_limit_with_count(sql, pageSize, curPage)
        self.write({'total': pms_param_status_list_count, 'data': pms_param_status_list})

#class StatusDelHandler(BaseHandler):
#    #删除状态
#    @tornado.web.authenticated
#    def post(self):
#        id = self.get_argument('id')
#        sql_status = "select * from pms_status where code = 'delete'"
#        status_delete = rd.select(sql_status)[0]['id']
#        sql = "select * from pms_user where status_id = '%s'" %id
#        bfDelData = rd.select(sql)
#        if bfDelData and len(bfDelData) > 0:
#            self.write({'result': 'false', 'msg': '与用户表存在关联关系，不允许删除！'})
#        else:
#            sql = "update pms_status set status_id = '%s' where id = '%s'" %(status_delete, id)
#            rd.update(sql)
#            self.write({'result': 'true', 'msg': '删除成功！'})

class StatusBfUpdateHandler(BaseHandler):
    #修改状态信息前,回显必要信息
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        sql = "select * from pms_status where id = '" + id + "'"
        data = rd.select(sql)
        self.write(data[0])

class StatusToUpdateHandler(BaseHandler):
    #修改状态信息
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        rd.updatebyDict('pms_status',requestBy_dict)
        self.write({'result': 'true'})

class StatusToAddHandler(BaseHandler):
    #新增状态信息
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        rd.insertbyDict('pms_status',requestBy_dict)
        self.write({'result': 'true'})
