# -*- coding: utf-8 -*-
import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
from config import config
import json
import  handlers.utils  as hts

class UserEvaluateListHandler(BaseHandler):
    #打开系统参数管理-人员评价参数界面
    @tornado.web.authenticated
    def get(self):
        self.render('paramManage/manage-sysParam-user-evaluate.html')
    #获取人员评价参数列表
    @tornado.web.authenticated
    def post(self):
        sql = """select * from  pms_user_evaluate  pue
                 where 1=1  """
        sql += " order by pue.code "
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_user_evaluate_list,pms_user_evaluate_list_count = rd.select_limit_with_count(sql, pageSize, curPage)
        self.write({'total': pms_user_evaluate_list_count, 'data': pms_user_evaluate_list})


class UserEvaluateBfUpdateHandler(BaseHandler):
    #修改人员评价参数信息前,回显必要信息
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        sql = "select * from pms_user_evaluate where id = '" + id + "'"
        data = rd.select(sql)
        self.write(data[0])

class UserEvaluateToUpdateHandler(BaseHandler):
    #修改人员评价参数信息
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        rd.updatebyDict('pms_user_evaluate',requestBy_dict)
        self.write({'result': 'true'})

