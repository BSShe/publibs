# -*- coding: utf-8 -*-
import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
from config import config
import json
import  handlers.utils  as hts
import os
import datetime
from urllib.parse import quote
import logging

class ProjectStageListHandler(BaseHandler):
    #打开系统参数管理-项目阶段界面
    @tornado.web.authenticated
    def get(self):
        self.render('paramManage/manage-sysParam-project-stage.html')
    #获取项目阶段列表
    @tornado.web.authenticated
    def post(self):
        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']
        sql = """select * from  pms_project_stage  ppt
                 where 1=1  """
        sql += " order by ppt.code "
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_param_station_list,pms_param_station_list_count = rd.select_limit_with_count(sql, pageSize, curPage)
        self.write({'total': pms_param_station_list_count, 'data': pms_param_station_list})


class ProjectStageBfUpdateHandler(BaseHandler):
    #上传阶段文档模版,回显必要信息
    @tornado.web.authenticated
    def post(self):
        project_stage_code = self.get_argument('project_stage_code')
        sql = "select * from pms_project_stage_doc where project_stage_code = '%s'" %project_stage_code
        data = rd.select(sql)
        self.write({'data':data,'code':project_stage_code})

class ProjectStageToUpdateHandler(BaseHandler):
    #上传阶段文档模版
    @tornado.web.authenticated
    def post(self):
        project_stage_doc_id = self.get_argument('project_stage_doc_id')
        file_metas = self.request.files['file_data']
        dirjoin = os.path.join
        for meta in file_metas:
            file_name = meta['filename']
            content_type = meta['content_type']
            now_date = datetime.datetime.now()
            nowtime = now_date.strftime('%Y%m%d')   
            hourtime = now_date.strftime("%H%M%S")
            file_name = project_stage_doc_id + '_' + nowtime + hourtime + '.' + file_name.split('.')[1]    
            path = dirjoin(config.static_path,dirjoin('doc',file_name))
            with open(path, 'wb') as up:
                up.write(meta['body']) 
            sql = "update pms_project_stage_doc set url = '%s' , content_type = '%s'  where id = '%s'" %(path, content_type, project_stage_doc_id)
            rd.update(sql)
        self.write({'result': 'true'})

class ProjectStageDownDocHandler(BaseHandler):
    #下载模版
    @tornado.web.authenticated
    def get(self):
        project_stage_doc_id = self.get_argument('project_stage_doc_id')
        sql = "select * from pms_project_stage_doc where id = '%s'" %project_stage_doc_id
        data = rd.select(sql)[0]
        self.set_header('Content-Type', 'application/octet-stream')
        self.set_header('Content-Disposition', 'attachment; filename= %s' %quote( data['name'] + '_模版' + '.' + data['url'].split('.')[1] )) 
        with open(data['url'], 'rb') as f:
            while True:
                dt = f.read()
                if not dt:
                    break
                self.write(dt)
        self.finish()

class ProjectStageChildHandler(BaseHandler):
    #打开子阶段界面
    @tornado.web.authenticated
    def get(self):
        p_stage_id = self.get_argument('p_stage_id')
        self.render('paramManage/manage-sysParam-project-stage-child.html',p_stage_id=p_stage_id)
    #获取子阶段列表
    @tornado.web.authenticated
    def post(self):
        p_stage_id = self.get_argument('p_stage_id')
        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']
        sql = """select * from  pms_project_stage_child  
                 where 1=1  and pms_project_stage_id = '%s' """ % p_stage_id
        sql += " order by code "
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_param_station_list,pms_param_station_list_count = rd.select_limit_with_count(sql, pageSize, curPage)
        self.write({'total': pms_param_station_list_count, 'data': pms_param_station_list})

class ProjectStageChildBfUpdateHandler(BaseHandler):
    #修改子阶段信息前,回显必要信息
    @tornado.web.authenticated
    def post(self):
        project_stage_child_id = self.get_argument('project_stage_child_id')
        sql = "select * from pms_project_stage_child where id = '%s'" %project_stage_child_id
        data = rd.select(sql)[0]
        self.write(data)

class ProjectStageChildToUpdateHandler(BaseHandler):
    #修改子阶段信息
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        data = {'id':requestBy_dict['id'], 'name': requestBy_dict['child_name'], 'remark': requestBy_dict['child_remark']}
        rd.updatebyDict('pms_project_stage_child',data)
        self.write({'result': 'true'})

class ProjectStageChildToAddHandler(BaseHandler):
    #新增子阶段信息
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        data = {'pms_project_stage_id':requestBy_dict['pms_project_stage_id'], 'code':requestBy_dict['child_code'], 'name': requestBy_dict['child_name'], 'remark': requestBy_dict['child_remark']}
        rd.insertbyDict('pms_project_stage_child',data)
        self.write({'result': 'true'})

class ProjectStageChildToDelHandler(BaseHandler):
    #删除子阶段信息
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        rd.own_excute("delete from pms_project_stage_child where id = '%s'" %id)
        self.write({'result': 'true', 'msg': '删除成功!'})
