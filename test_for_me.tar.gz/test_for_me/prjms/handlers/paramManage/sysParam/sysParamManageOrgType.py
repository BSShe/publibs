# -*- coding: utf-8 -*-
import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
from config import config
import json
import  handlers.utils  as hts

class OrgTypeListHandler(BaseHandler):
    #打开系统参数管理-岗位界面
    @tornado.web.authenticated
    def get(self):
        self.render('paramManage/manage-sysParam-org_type.html')
    #获取岗位列表
    @tornado.web.authenticated
    def post(self):
        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']
        sql = """select * from  pms_org_type  psn
                 where 1=1  """ #and status_id != '%s'""" %status_delete
        sql += " order by psn.id "
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_param_org_type_list,pms_param_org_type_list_count = rd.select_limit_with_count(sql, pageSize, curPage)
        self.write({'total': pms_param_org_type_list_count, 'data': pms_param_org_type_list})

#class OrgTypeDelHandler(BaseHandler):
#    #删除岗位
#    @tornado.web.authenticated
#    def post(self):
#        id = self.get_argument('id')
#        sql_status = "select * from pms_status where code = 'delete'"
#        status_delete = rd.select(sql_status)[0]['id']
#        sql = "select * from pms_user where org_type_id = '%s'" %id
#        bfDelData = rd.select(sql)
#        if bfDelData and len(bfDelData) > 0:
#            self.write({'result': 'false', 'msg': '与用户表存在关联关系，不允许删除！'})
#        else:
#            sql = "update pms_org_type set status_id = '%s' where id = '%s'" %(status_delete, id)
#            rd.update(sql)
#            self.write({'result': 'true', 'msg': '删除成功！'})

class OrgTypeBfUpdateHandler(BaseHandler):
    #修改岗位信息前,回显必要信息
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        sql = "select * from pms_org_type where id = '" + id + "'"
        data = rd.select(sql)
        self.write(data[0])

class OrgTypeToUpdateHandler(BaseHandler):
    #修改岗位信息
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        rd.updatebyDict('pms_org_type',requestBy_dict)
        self.write({'result': 'true'})

class OrgTypeToAddHandler(BaseHandler):
    #新增岗位信息
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        rd.insertbyDict('pms_org_type',requestBy_dict)
        self.write({'result': 'true'})
