# -*- coding: utf-8 -*-
import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
from config import config
import json
import  handlers.utils  as hts

class ProjectEvaluateListHandler(BaseHandler):
    #打开系统参数管理-项目评价参数界面
    @tornado.web.authenticated
    def get(self):
        self.render('paramManage/manage-sysParam-project-evaluate.html')
    #获取项目评价参数列表
    @tornado.web.authenticated
    def post(self):
        sql = """select * from  pms_project_evaluate  ppe
                 where 1=1  """
        sql += " order by ppe.code "
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_project_evaluate_list,pms_project_evaluate_list_count = rd.select_limit_with_count(sql, pageSize, curPage)
        self.write({'total': pms_project_evaluate_list_count, 'data': pms_project_evaluate_list})


class ProjectEvaluateBfUpdateHandler(BaseHandler):
    #修改项目评价参数信息前,回显必要信息
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        sql = "select * from pms_project_evaluate where id = '" + id + "'"
        data = rd.select(sql)
        self.write(data[0])

class ProjectEvaluateToUpdateHandler(BaseHandler):
    #修改项目评价参数信息
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        rd.updatebyDict('pms_project_evaluate',requestBy_dict)
        self.write({'result': 'true'})

