# -*- coding: utf-8 -*-
import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
from config import config
import json
import  handlers.utils  as hts

class ProjectTypeListHandler(BaseHandler):
    #打开系统参数管理-项目类型界面
    @tornado.web.authenticated
    def get(self):
        self.render('paramManage/manage-sysParam-project-type.html')
    #获取项目类型列表
    @tornado.web.authenticated
    def post(self):
        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']
        sql = """select * from  pms_project_type  ppt
                 where 1=1  """
        sql += " order by ppt.code "
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_param_station_list,pms_param_station_list_count = rd.select_limit_with_count(sql, pageSize, curPage)
        self.write({'total': pms_param_station_list_count, 'data': pms_param_station_list})


class ProjectTypeBfUpdateHandler(BaseHandler):
    #修改项目类型信息前,回显必要信息
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        sql = "select * from pms_project_type where id = '" + id + "'"
        data = rd.select(sql)
        self.write(data[0])

class ProjectTypeToUpdateHandler(BaseHandler):
    #修改项目类型信息
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        rd.updatebyDict('pms_project_type',requestBy_dict)
        self.write({'result': 'true'})

class ProjectTypeToAddHandler(BaseHandler):
    #新增项目类型信息
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        rd.insertbyDict('pms_project_type',requestBy_dict)
        self.write({'result': 'true'})
