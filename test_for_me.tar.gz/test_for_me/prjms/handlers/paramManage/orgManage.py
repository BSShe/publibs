# -*- coding: utf-8 -*-

import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config, sessionClass
import json
import  handlers.utils  as hts
import datetime
from urllib.parse import quote

class OrgListHandler(BaseHandler):
    #打开机构管理界面
    @tornado.web.authenticated
    def get(self):
        #pms_station = rd.select('select * from pms_organizations ')
        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']
        pms_statusList = rd.select('select * from pms_status where id != \'%s\' and (code = \'01\' or code = \'02\') order by id' %status_delete)
        pms_orgTypeList = rd.select('select * from pms_org_type where name != \'外包机构\'')
        pms_roleList = rd.select('select * from pms_role where type = \'2\' order by id')
        self.render('paramManage/manage-jigou.html', statusList = pms_statusList, orgTypeList = pms_orgTypeList,roleList = pms_roleList)
    #获取机构列表
    @tornado.web.authenticated
    def post(self):
        code = self.get_argument('code')
        name = self.get_argument('name')
        status_id = self.get_argument('status_id')
        role_id = self.get_argument('role_id')
        type_id = self.get_argument('type_id')

        sql = """select pos.id , pos.code, pos.name, pos.st_date, pss.name as status, pot.name as type, 
                 replace((select wm_concat(pr2.name) from pms_org_role por2 join pms_role pr2 on pr2.id = por2.role_id where por2.org_id = pos.id),',','/') as role_name_list
                 from pms_organizations pos
                 left join pms_status pss on pos.status_id = pss.id
                 left join pms_org_type pot on pot.id = pos.type_id
                 where 1=1 and pot.name != '%s' """ %"外包机构"
        if code is not None  and  code != "":
            sql += " and pos.code like '%" + code + "%'"
        if name is not None  and  name != "":
            sql += " and pos.name like '%" + name + "%'"
        if status_id is not None  and  status_id != "":
            sql += " and pos.status_id = '" + status_id + "'"
        if role_id is not None  and  role_id != "":
            sql += " and  pos.id in (select por.org_id from  pms_org_role por join pms_role pr on pr.id = por.role_id where pr.id = '%s')" %role_id
        if type_id is not None  and  type_id != "":
            sql += " and pos.type_id = '" + type_id + "'"

        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']
        sql += " and pos.status_id != '%s'" % status_delete
        sql += " order by pos.id "
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_user,pms_user_count = rd.select_limit_with_count(sql, pageSize, curPage)
        self.write({'total': pms_user_count, 'data': pms_user})

class OrgDelHandler(BaseHandler):
    #删除机构
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        sql = "select * from pms_user where org_id = '%s'" %id
        bfDelData = rd.select(sql)
        if bfDelData and len(bfDelData) > 0:
            self.write({'result': 'false', 'msg': '与用户表存在关联关系，不允许删除！'})
        else:
            sql_status = "select * from pms_status where code = 'delete'"
            status_delete = rd.select(sql_status)[0]['id']
            sql = "update pms_organizations set status_id = '%s' where id = '%s'" %(status_delete, id)
            rd.update(sql)
            self.write({'result': 'true'})

class OrgBfUpdateHandler(BaseHandler):
    #修改机构信息前,回显必要信息
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        sql = "select * from pms_organizations  where id = '" + id + "'"
        data1 = rd.select(sql)
        sql = "select role_id from pms_org_role where org_id = '%s'" %id 
        data2 = rd.select(sql)
        self.write({'org':data1[0],'role_id_list':data2})

class OrgToUpdateHandler(BaseHandler):
    #修改机构信息
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        role_id_list = self.get_arguments('role_id_list')
        #判断外包机构不能担任管理、需求、测试部门
        manager_id = rd.select("select * from pms_role where name = '管理部门'")[0]['id']
        org_type_id = rd.select("select * from pms_org_type pot where pot.name = '外包机构'")[0]['id']
        need_id = rd.select("select * from pms_role where name = '需求部门'")[0]['id']
        tester_id = rd.select("select * from pms_role where name = '测试部门'")[0]['id']
        if str(org_type_id) == requestBy_dict['type_id'] and (str(manager_id) in role_id_list or str(need_id) in role_id_list or str(tester_id) in role_id_list):
            self.write({'result': 'false', 'msg':'外包机构不能担任管理部门、需求部门、测试部门!'})
        else:
            requestBy_dict.pop('role_id_list')
            rd.own_excute("delete pms_org_role where org_id = '%s'" %requestBy_dict['id'])
            for ril in role_id_list:
                rd.insertbyDict("pms_org_role",{'org_id':requestBy_dict['id'],'role_id':ril})
            rd.updatebyDict('pms_organizations',requestBy_dict)
            self.write({'result': 'true'})

class OrgToAddHandler(BaseHandler):
    #新增机构信息
    @tornado.web.authenticated
    def post(self):
        role_id_list = self.get_arguments('role_id_list')
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        #判断外包机构不能担任管理、需求、测试部门
        manager_id = rd.select("select * from pms_role where name = '管理部门'")[0]['id']
        org_type_id = rd.select("select * from pms_org_type pot where pot.name = '外包机构'")[0]['id']
        need_id = rd.select("select * from pms_role where name = '需求部门'")[0]['id']
        tester_id = rd.select("select * from pms_role where name = '测试部门'")[0]['id']
        if str(org_type_id) == requestBy_dict['type_id'] and (str(manager_id) in role_id_list or str(need_id) in role_id_list or str(tester_id) in role_id_list):
            self.write({'result': 'false', 'msg':'外包机构不能担任管理部门、需求部门、测试部门!'})
        else:
            requestBy_dict.pop('role_id_list')
            org_exist = rd.select("select * from pms_organizations where code = '%s'" %requestBy_dict['code'])
            if org_exist and len(org_exist) > 0:
                self.write({'result': 'false', 'msg':'机构编号已存在,请重新输入!'})
            else:
                rd.insertbyDict('pms_organizations',requestBy_dict)
                this_org = rd.selectbyDict('pms_organizations',requestBy_dict)[0]
                for ril in role_id_list:
                    rd.insertbyDict("pms_org_role",{'org_id':this_org['id'], 'role_id':ril})
                self.write({'result': 'true','org_id':this_org['id']})

class OrgUserListHandler(BaseHandler):
    #
    @tornado.web.authenticated
    def get(self):
        self.render('paramManage/manage-jigou-userList.html')
    @tornado.web.authenticated
    def post(self):
        org_id = self.get_argument('org_id')
        sql = """select pu.id, pu.no, pu.name, pu.phone_no, pos.name as org_name, pss.name as status_name, 
                replace((select wm_concat(pr2.name) from pms_user_role pur2 join pms_role pr2 on pr2.id = pur2.role_id where pur2.user_id = pu.id),',','/') as role_name_list  
                from pms_user pu
                join pms_organizations pos on pu.org_id = pos.id
                join pms_status pss on pu.status_id = pss.id
                where pu.org_id = '%s'""" %org_id
        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']
        sql += " and pu.status_id != '%s'" % status_delete
        sql += " order by pu.id "
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_user,pms_user_count = rd.select_limit_with_count(sql,pageSize ,curPage)

        self.write({'total': pms_user_count, 'data': pms_user}) 

class OrgExportInfoHandler(BaseHandler):
    #机构管理信息 导出
    @tornado.web.authenticated
    def get(self):
        code = self.get_argument('code')
        name = self.get_argument('name')
        status_id = self.get_argument('status_id')
        role_id = self.get_argument('role_id')
        type_id = self.get_argument('type_id')

        sql = """select pos.id , pos.code, pos.name, pos.st_date, pss.name as status, pot.name as type, 
                 replace((select wm_concat(pr2.name) from pms_org_role por2 join pms_role pr2 on pr2.id = por2.role_id where por2.org_id = pos.id),',','/') as role_name_list
                 from pms_organizations pos
                 left join pms_status pss on pos.status_id = pss.id
                 left join pms_org_type pot on pot.id = pos.type_id
                 where 1=1 """
        if code is not None  and  code != "":
            sql += " and pos.code like '%" + code + "%'"
        if name is not None  and  name != "":
            sql += " and pos.name like '%" + name + "%'"
        if status_id is not None  and  status_id != "":
            sql += " and pos.status_id = '" + status_id + "'"
        if role_id is not None  and  role_id != "":
            sql += " and  pos.id in (select por.org_id from  pms_org_role por join pms_role pr on pr.id = por.role_id where pr.id = '%s')" %role_id
        if type_id is not None  and  type_id != "":
            sql += " and pos.type_id = '" + type_id + "'"

        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']
        sql += " and pos.status_id != '%s'" % status_delete
        sql += " order by pos.id "
        data = rd.select(sql)
        nowtime = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = '机构管理信息' + nowtime + '.xls'
        self.set_header('Content-Type', 'application/octet-stream')
        self.set_header('Content-Disposition', 'attachment; filename= %s' %quote(filename))
        head = ['机构号','机构名称','机构类型','机构角色','机构状态','启动日期']
        body = ['code', 'name', 'type', 'role_name_list', 'status', 'st_date']
        self.write(hts.public_exportInfo(filename, data, head, body))
        self.finish()
