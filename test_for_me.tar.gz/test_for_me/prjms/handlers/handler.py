# -*- coding:utf-8 -*-
import json

import tornado.web

from handlers.utils import ThreadExecutor, ProcessExecutor
from database.models import Session as db_Session
#from utils.main_logger import LOGGER
from config import config, sessionClass

class BaseHandler(tornado.web.RequestHandler):
    db_session: db_Session
    thread_executor: ThreadExecutor
    process_executor: ProcessExecutor

    def __init__(self, application, request, **kwargs):
        super().__init__(application, request, **kwargs)
        self.token = None
        self.response = {}
        self.session = sessionClass.Session(self)
        

    def initialize(self):
        self.db_session = db_Session()
        self.thread_executor = ThreadExecutor()
        self.process_executor = ProcessExecutor()

    def data_received(self, chunk):
        pass

    def set_default_headers(self):
        self.set_header('Access-Control-Allow-Origin', '*')
        self.set_header('Access-Control-Allow-Headers', 'x-requested-with')
        self.set_header('Access-Control-Allow-Methods', 'GET, PUT, DELETE, POST')
        # HEADERS!
        self.set_header('Access-Control-Allow-Headers', 'access-control-allow-origin, authorization, content-type')
        self.set_header('Access-Control-Expose-Headers', 'Content-Disposition')

    def options(self, *args, **kwargs):
        self.set_status(204)
        self.finish()

    @property
    def db(self):
        return self.application.db

    @property
    def user(self):
        try:
            return self.token['sub']
        except Exception as e:
            #LOGGER.exception(e)
            self.write({'code': 403})

    def on_finish(self):
        self.db_session.commit()
        self.db_session.close()

    def write_error(self, status_code, **kwargs):
        self.db_session.rollback()
        self.db_session.close()
        self.set_header('Content-Type', 'application/json')
        if self.settings.get("serve_traceback") and "exc_info" in kwargs:
            # in debug mode, try to send a traceback
            # lines = []
            # for line in traceback.format_exception(*kwargs["exc_info"]):
            #     lines.append(line)
            self.finish(json.dumps({
                'code': status_code,
                'message': self._reason,
                # 'traceback': lines,
            }))
        else:
            self.finish(json.dumps({
                'code': status_code,
                'message': self._reason,
            }))
   
    def get_current_user(self):
        self.session['username'] = self.session['username']
        if config.SESSION_MODE == 0: 
            return self.get_secure_cookie('username')
        return self.session['username']
    
