import os

pro_path = "/opt/openoffice4/program/python"
static_path = os.path.abspath(os.path.join(os.getcwd(),('')))


#传入相对地址./static/files开头
#返回转化后文件名
#返回值：1: 0 代表文件不存在 2:文件名,代表转化后的文件名 3: 1 文件名中不能有.
def change_file(file_name):
    names = file_name.split('.')
    if len(names) > 3:
        return 1
    url1 = static_path + names[1]+'.' + names[2]
    url2 = static_path + names[1] +'.html'
    code = "%s %s/handlers/office_change.py %s %s "%(pro_path,static_path,url1,url2)
    print (code)
    if not os.path.isfile(url1):
        return 0
    os.system(code)
    if not os.path.isfile(url2):
        return 0
    file2 ='.' + names[1] +'.html' 
    return file2

#以下为例子
#if __name__== '__main__':
#    #back = change_file('./static/files/for_test.docx')
#    back = change_file('./static/files/21/6_20181112110717.docx')
#    print (back)
