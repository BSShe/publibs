# -*- coding: utf-8 -*-

import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts
import os
import datetime
from urllib.parse import quote

class QualifyListHandler(BaseHandler):
    #打开供应商资质管理界面
    @tornado.web.authenticated
    def get(self):
        #pms_station = rd.select('select * from pms_organizations ')
        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']
        pms_statusList = rd.select('select * from pms_status where id != \'%s\' and (code = \'01\' or code = \'02\') order by id' %status_delete)
        pms_orgTypeList = rd.select('select * from pms_org_type where name = \'外包机构\'')
        pms_roleList = rd.select('select * from pms_role where type = \'2\' order by id')
        self.render('supplierManage/qualify-manage.html', statusList=pms_statusList, roleList=pms_roleList, orgTypeList=pms_orgTypeList)
    #获取供应商资质列表
    @tornado.web.authenticated
    def post(self):
        code = self.get_argument('code')
        name = self.get_argument('name')
        sql = """select 
                        pos.id as org_id, pos.code, pos.name, pos.st_date, pss.name as status, pot.name as type, 
                        replace((select wm_concat(pr2.name) from pms_org_role por2 join pms_role pr2 on pr2.id = por2.role_id where por2.org_id = pos.id),',','/') as role_name_list
                        , psq.*
                 from  pms_organizations pos
                 left join pms_status pss on pos.status_id = pss.id
                 left join pms_org_type pot on pot.id = pos.type_id
                 left join  pms_supplier_qualification psq on pos.id = psq.pms_organizations_id
                 where 1=1  and pot.name = '%s' """ %"外包机构"
        if code is not None  and  code != "":
            sql += " and pos.code = '" + code + "'"
        if name is not None  and  name != "":
            sql += " and pos.name like '%" + name + "%'"

        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']
        sql += " and pos.status_id != '%s'" % status_delete
        sql += " order by pos.id "
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_user,pms_user_count = rd.select_limit_with_count(sql, pageSize, curPage)
        self.write({'total': pms_user_count, 'data': pms_user})

class QualifyBfUpdateHandler(BaseHandler):
    #修改信息前,回显必要信息
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        sql = "select * from pms_supplier_qualification where pms_organizations_id = '%s'" %id 
        if rd.select(sql) and len(rd.select(sql)) > 0:
            sql = """select 
                        pos.id as org_id, pos.code, pos.name, pos.st_date, pos.status_id ,pos.type_id, 
                        psq.*
                     from  pms_organizations pos 
                     left join  pms_supplier_qualification psq on pos.id = psq.pms_organizations_id
                     where psq.pms_organizations_id = '%s' """ %id
            data = rd.select(sql)
            sql_status = "select * from pms_status where code = 'delete'"
            status_delete = rd.select(sql_status)[0]['id']
            sql = """
                    select concat(pu.no,concat('-',pu.name)) as link_man from pms_user  pu where pu.org_id = '%s' and pu.status_id != '%s' order by pu.no
                    """ %(id, status_delete)
            option = rd.select(sql)
            sql = "select role_id from pms_org_role where org_id = '%s'" %id
            data2 = rd.select(sql)
            self.write({'data': data[0],'option': option, 'role_id_list':data2})
        else:
            sql = "select code, name  from pms_organizations where id = '%s'" %id
            data = rd.select(sql)
            sql_status = "select * from pms_status where code = 'delete'"
            status_delete = rd.select(sql_status)[0]['id']
            sql = """
                    select concat(pu.no,concat('-',pu.name)) as link_man from pms_user  pu where pu.org_id = '%s' and pu.status_id != '%s' order by pu.no
                    """ %(id, status_delete)
            option = rd.select(sql)
            sql = "select role_id from pms_org_role where org_id = '%s'" %id
            data2 = rd.select(sql)
            self.write({'data': data[0],'option': option, 'role_id_list':data2})

class QualifyToUpdateHandler(BaseHandler):
    #修改信息
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        requestBy_dict.pop("code")
        requestBy_dict.pop("name")
        id = requestBy_dict.pop("id")
        requestBy_dict['pms_organizations_id'] = id
        sql = "delete from pms_supplier_qualification where pms_organizations_id = '%s'" %id
        rd.own_excute(sql)
        rd.insertbyDict('pms_supplier_qualification',requestBy_dict)
        self.write({'result': 'true'})

class QualifyToAddHandler(BaseHandler):
    #新增信息
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        rd.insertbyDict('',requestBy_dict)
        self.write({'result': 'true'})

class QualifyProListHandler(BaseHandler):
    #此函数用于查询基础的所有项目目录
    @tornado.web.authenticated
    def get(self):
        self.render('supplierManage/estimate-org-userList.html')
    @tornado.web.authenticated
    def post(self):
        pro_id = self.get_argument('pro_id')
        sql = """ select * from pms_project where id=%s order by id""" %pro_id
        


        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_user,pms_user_count = rd.select_limit_with_count(sql,pageSize ,curPage)
        
        self.write({'total': pms_user_count, 'data': pms_user}) 

class QualifyFileListHandler(BaseHandler):
    #合同扫描件文档表
    @tornado.web.authenticated
    def get(self):
        self.render('supplierManage/qualify-file.html')
    @tornado.web.authenticated
    def post(self):
        organizations_id = self.get_argument('org_id')
        sql = "select id, concat(concat(file_name,'.'),file_type) as file_name from pms_supplier_file where pms_organizations_id = '%s' order by id " %organizations_id
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_supplier_file,pms_supplier_file_count = rd.select_limit_with_count(sql,pageSize ,curPage)
        for index in range(len(pms_supplier_file)):
            pms_supplier_file[index]['xuhao'] = index + 1
        self.write({'total': pms_supplier_file_count, 'data': pms_supplier_file})

class QualifyAddFileHandler(BaseHandler):
    #合同文件增加
    @tornado.web.authenticated
    def get(self):
        self.render('supplierManage/qualify-addFile.html')
    @tornado.web.authenticated
    def post(self):
        pms_organizations_id = self.get_argument('pms_org_id')
        file_name = self.get_argument('file_name')
        file_metas = self.request.files['file_data']
        dirjoin = os.path.join
        for meta in file_metas:
            name = meta['filename']
            file_type = name.split('.')[1]
            content_type = meta['content_type']
            now_date = datetime.datetime.now()
            nowtime = now_date.strftime('%Y%m%d')
            hourtime = now_date.strftime("%H%M%S")
            url_file_name = pms_organizations_id + '_' + nowtime + hourtime + '.' + name.split('.')[1]
            path = dirjoin(config.static_path,dirjoin('supplierFile',url_file_name))
            with open(path, 'wb') as up:
                up.write(meta['body'])
            rd.insertbyDict('pms_supplier_file', {'pms_organizations_id':pms_organizations_id,'file_name':file_name,'file_type':file_type,'file_url':path})
        self.write({'result': 'true'})

class QualifyDownFileHandler(BaseHandler):
    #下载合同文件
    @tornado.web.authenticated
    def get(self):
        pms_supplier_file_id = self.get_argument('pms_supplier_file_id')
        sql = "select * from pms_supplier_file where id = '%s'" %pms_supplier_file_id
        data = rd.select(sql)[0]
        self.set_header('Content-Type', 'application/octet-stream')
        self.set_header('Content-Disposition', 'attachment; filename= %s' %quote( data['file_name'] + '' + '.' + data['file_type'] ))
        with open(data['file_url'], 'rb') as f:
            while True:
                dt = f.read()
                if not dt:
                    break
                self.write(dt)
        self.finish()


class QualifyExportInfoHandler(BaseHandler): 
    #供应商资质信息 导出
    @tornado.web.authenticated
    def get(self):
        code = self.get_argument('code')
        name = self.get_argument('name')
        sql = """select 
                 pos.id as org_id, pos.code, pos.name, pos.st_date, pss.name as status, pot.name as type, 
                 replace((select wm_concat(pr2.name) from pms_org_role por2 join pms_role pr2 on pr2.id = por2.role_id where por2.org_id = pos.id),',','/') as role_name_list
                 , psq.*
                 from  pms_organizations pos
                 left join pms_status pss on pos.status_id = pss.id
                 left join pms_org_type pot on pot.id = pos.type_id
                 left join  pms_supplier_qualification psq on pos.id = psq.pms_organizations_id
                 where 1=1  and pot.name = '%s' """ %"外包机构"
        if code is not None  and  code != "":
            sql += " and pos.code = '" + code + "'"
        if name is not None  and  name != "":
            sql += " and pos.name like '%" + name + "%'"

        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']
        sql += " and pos.status_id != '%s'" % status_delete
        sql += " order by pos.id "
        data = rd.select(sql)
        nowtime = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = '供应商资质信息' + nowtime + '.xls'
        self.set_header('Content-Type', 'application/octet-stream')
        self.set_header('Content-Disposition', 'attachment; filename= %s' %quote(filename))
        head = ['编号','企业名称','机构类型','机构角色','机构状态','启动日期','注册地址','成立时间','法人代表','注册资本','销售联系人','联系电话','邮箱','技术联系人','联系电话','邮箱']
        body = ['code', 'name', 'type', 'role_name_list', 'status', 'st_date', 'place','build_date','corp_rep','reg_cap','sale_contact','sale_contact_phone','sale_contact_email','tech_contact','tech_contact_phone','tech_contact_email']
        self.write(hts.public_exportInfo(filename, data, head, body))
        self.finish()

class QualifyGetUserPhoneHandler(BaseHandler): 
    #根据主要联系人员 获取其联系方式
    @tornado.web.authenticated
    def post(self):
        user = self.get_argument('user')
        data = rd.select("select * from pms_user where no = '%s' and name = '%s'" %(user.split("-")[0], user.split("-")[1]))[0]
        print (data)
        self.write({'result': 'true', 'data': data})
