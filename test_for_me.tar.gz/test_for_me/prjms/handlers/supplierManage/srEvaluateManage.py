# -*- coding: utf-8 -*-

import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts
import os
import datetime
from urllib.parse import quote

class SrEvaluateListHandler(BaseHandler):
    #打开供应商评价管理界面
    @tornado.web.authenticated
    def get(self):
        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']
        #pms_orgList = rd.select('select * from pms_organizations where status_id != \'%s\' order by id' %status_delete)
        #user_auth = rd.select("""
        #                        select * from pms_user pu
        #                            join pms_user_role pur on pur.user_id = pu.id
        #                            join pms_role pr on pr.id = pur.role_id
        #                            where pu.id = '%s' and pr.name = '系统管理员'
        #                        """% self.session['user_id'])
        ##如果当前登录用户角色不包含管理员，则只允许看本机构信息
        #if not user_auth or len(user_auth) == 0:
        #    pms_orgList = rd.select('select * from pms_organizations where status_id != \'%s\' and id in (select org_id from pms_user where id = %s) order by id' %(status_delete,self.session['user_id']))
        #pms_station = rd.select('select * from pms_organizations ')
        self.render('supplierManage/evaluate-manage.html' )#, orgList = pms_orgList )
    #获取供应商评价管理列表
    @tornado.web.authenticated
    def post(self):
        name = self.get_argument('name')
        code = self.get_argument('code')

        auth_range = ""
        #user_auth = rd.select("""
        #                        select * from pms_user pu
        #                            join pms_user_role pur on pur.user_id = pu.id
        #                            join pms_role pr on pr.id = pur.role_id
        #                            where pu.id = '%s' and pr.name = '系统管理员'
        #                        """% self.session['user_id'])
        #auth_range = ""
        ##如果当前登录用户角色不包含管理员，则只允许看本机构信息
        #if not user_auth or len(user_auth) == 0:
        #    auth_range = " and pu.org_id = (select org_id from pms_user where id = '%s')" %self.session['user_id']
        #else:
        #    if org_id and org_id != "":
        #        auth_range = " and pu.org_id = '%s'" %org_id
        code_sql = ""
        if code and code != "":
            code_sql = " and pos.code = '%s'" %code
        name_sql = ""
        if name and name != "":
            name_sql = " and pos.name like '%" + name + "%'"
        
        sql = """
                select pos.id as org_id, pos.code, pos.name,pses.* 
                from pms_supplier_eva_score pses
                join PMS_ORGANIZATIONS pos on pos.id = pses.pms_organizations_id
                where 1=1  %s %s %s
                """%(auth_range,code_sql,name_sql)
        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']
        sql += " and pos.status_id != '%s'" %status_delete
        sql += "order by pos.id"
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_supplier_eva_score,pms_supplier_eva_score_count = rd.select_limit_with_count(sql, pageSize, curPage)
        self.write({'total': pms_supplier_eva_score_count, 'data': pms_supplier_eva_score})

class SrEvaluateBfUpdateHandler(BaseHandler):
    #修改信息前,回显必要信息
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        sql = """
                select  pos.code, pos.name,pses.*
                from pms_supplier_eva_score pses
                join PMS_ORGANIZATIONS pos on pos.id = pses.pms_organizations_id
                where pos.id = '%s' 
                """ %id
        data = rd.select(sql)
        self.write(data[0])

class SrEvaluateToUpdateHandler(BaseHandler):
    #修改信息
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        rd.updatebyDict('pms_supplier_eva_score',requestBy_dict)
        self.write({'result': 'true'})

class SrEvaluateExportInfoHandler(BaseHandler):
    #供应商评价信息 导出
    @tornado.web.authenticated
    def get(self):
        name = self.get_argument('name')
        code = self.get_argument('code')

        auth_range = ""
        code_sql = ""
        if code and code != "":
            code_sql = " and pos.code = '%s'" %code
        name_sql = ""
        if name and name != "":
            name_sql = " and pos.name like '%" + name + "%'"

        sql = """
                select pos.id as org_id, pos.code, pos.name,pses.* 
                from pms_supplier_eva_score pses
                join PMS_ORGANIZATIONS pos on pos.id = pses.pms_organizations_id
                where 1=1  %s %s %s
                """%(auth_range,code_sql,name_sql)
        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']
        sql += " and pos.status_id != '%s'" %status_delete
        sql += "order by pos.id"
        data = data = rd.select(sql)
        nowtime = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = '供应商评价信息' + nowtime + '.xls'
        self.set_header('Content-Type', 'application/octet-stream')
        self.set_header('Content-Disposition', 'attachment; filename= %s' %quote(filename))
        head = ['编号','供应商名称','人员评价平均分','项目质量平均分','系统评分','管理员评分']
        body = ['code', 'name', 'user_avg_score', 'project_avg_score', 'residue_score', 'handscore']
        self.write(hts.public_exportInfo(filename, data, head, body))
        self.finish()

