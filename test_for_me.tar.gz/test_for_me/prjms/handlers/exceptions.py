class ArgMissError(Exception):
    """参数丢失错误，主要是xml报文字段检查"""
    pass


class EndSignal(Exception):
    """常用结束信号，用于替代多层函数的return"""
    pass
