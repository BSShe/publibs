# -*- coding: utf-8 -*-

import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config,wx_config
import json
import datetime
import  handlers.utils  as hts
import traceback
from math import radians,cos,sin,asin,sqrt

class signlogin(BaseHandler):
    def post(self):
        print (self.request.body)
        account = self.get_argument('account')
        password = self.get_argument('password')
        if account is None or account =='':
            print ('uninputaccount')
            self.write({'success':False,'msg':'请输入帐号'})
            return 
        if password is None or account =='':
            print ('uninputpassword')
            self.write({'success':False,'msg':'请输入密码'})
            return
        user_infos = rd.select("select * from pms_user where no = '%s'" %account)
        if user_infos:
            db_pwd = user_infos[0]['password']
            if db_pwd == hts.encodePasswd(password):
                print (self.get_argument("account"))
                self.set_secure_cookie("account",self.get_argument("account"))
                self.write({'success':True,'msg':'登录成功','msg2':account})
            else:
                self.write({'success':False,'msg': '密码错误！'})
        else:
            self.write({'success':False,'msg':'用户不存在！'})


class signcode(BaseHandler):
    def post(self):
        #请求传入username信息，获取签到记录
        print (self.request.body)
        account = self.get_argument('account')
        date = self.get_argument('date')
        print (date)
        if date is None:
            sql = "select * from pms_signrecode where pms_user_id in (select id from pms_user where no = '%s')" %account
            print (sql)
            sign_code = rd.select(sql)
        else :
            sql = "select * from pms_signrecode where pms_user_id in (select id from pms_user where no = '%s') and datetime='%s'" %(account,date)
            print (sql)
            sign_code = rd.select(sql)
        print (sign_code)
        for i in sign_code:
            i['time'] = i['time'].strftime('%Y-%m-%d %H:%M:%S')
        if sign_code:
            self.write({'success':True,'msg':sign_code})
        else:
            self.write({'success':False,'msg':'无签到数据'})

class sign(BaseHandler):
    def post(self):
        #设置一个参数作为在规定时间内的签到次数，如果不满足该 条件则不允许签到
        try:
            '''
        set_time = wx_config['time']
        set_num = wx_config['num']
        now = datetime.datetime.now().strftime('%Y%m%d')
        account = self.get_secure_cookie('account')
        old_time = now - set_time
        re.select('select * from pms_signcode where pms_user_id in (select id from pms_user where no = %s ) and time < %s and time > %s',account,now,old_time)
            ''' 
        #在前台获取当前位置传递到后台，规定的经纬度设置一个参数作为参考条件
            now_date = datetime.datetime.now().strftime('%Y-%m-%d')
            now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            account = self.get_argument('account')
            
            set_jd = wx_config.wx_config['jd']
            set_wd = wx_config.wx_config['wd']
            print (self.request.body)
            now_jd = self.get_argument('longitude')
            now_wd = self.get_argument('latitue')
        #此处计算经纬度相对位置
            print ('%s,%s,%s,%s'%(set_jd,set_wd,now_jd,now_wd))
            num = math_num(set_jd,set_wd,now_jd,now_wd)
            print (num)
            if num >=100:
                self.write({'success':False,'msg':'距离超过100m'})
                return 
        #添加签到记录到签到记录表中，并跳转到签到成功页面，签到成功页面可以查看签到记录
            sql = "insert into pms_signrecode (id,time,pms_user_id,latitude,longitude,datetime,am_start_time,am_end_time,noon_time,pm_start_time,pm_end_time) values(seq_pms_signrecode.nextval,to_date('%s','yyyy-mm-dd HH24:MI:SS'),(select id from pms_user where no = '%s'),'%s','%s','%s',(select value from pms_time where code = '01'),(select value from pms_time where code = '02'),(select value from pms_time where code = '03'),(select value from pms_time where code = '04'),(select value from pms_time where code = '05'))"%(now,account,now_jd,now_wd,now_date)
            print (sql)
            res =  rd.insert(sql)
        except :
            print (traceback.print_exc())
            self.write({'success':False,'msg':'签到失败'})
        else:
            self.write({'success':True,'msg':'签到成功'})


def math_num(set_jd,set_wd,now_jd,now_wd):
    lon1,lat1,lon2,lat2= map(radians,[float(set_jd),float(set_wd),float(now_jd),float(now_wd)])
    dlon = lon2-lon1
    print (dlon)
    dlat = lat2-lat1
    print (dlat)
    a = sin(dlat/2)**2 + cos(lat1)*cos(lat2)*sin(dlon/2)**2
    c = 2 * asin(sqrt(a))
    print (c)
    r = 6371
    num = c * r 
    return num

