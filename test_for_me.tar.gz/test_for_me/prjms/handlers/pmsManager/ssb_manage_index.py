import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts
from handlers.pmsManager.ssb_pmsProjectSelect import getProjectListSql,getPro_ingListSql
from handlers.pmsManager.ssb_project_msg_detail import getMsgListSql

class getIndexHandler(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        userno = tornado.escape.xhtml_escape(self.current_user)
        user_infos = rd.select('select * from pms_user where no = \'%s\'' %userno)
        id = user_infos[0]["id"]
        org = user_infos[0]["org_id"]
        pid = self.get_argument('id')
        
        msgListSql = getMsgListSql(id)
        msgList = rd.select_limit_with_count(msgListSql,5 ,1)[0]

        sql = "select c.id as pid,c.name as pname,a.id,a.title,to_char(a.WORK_DATE,'yyyy-mm-dd hh24:mi:ss') as wdate,b.name as send_user,b.id as userid from pms_work_day_mes a left join pms_user b on a.PMS_USER_ID = b.id left join pms_project c on c.id = a.PMS_PROJECT_ID where b.id = "+str(id)+" order by a.WORK_DATE desc"
        logList = rd.select_limit_with_count(sql,5 ,1)[0]

        pro_ingListSql = getPro_ingListSql(id,'All') + " order by pp.id desc"
        pro_ingList = rd.select_limit_with_count(pro_ingListSql, 5, 1)[0]

        projectListSql = getProjectListSql(id,org,'All') + " order by pp.id desc"
        projectList = rd.select_limit_with_count(projectListSql, 5, 1)[0] 


        total = {}
        sql = 'select count(pms_project.id) pro_count,sum(pms_contract.CONTRACT_AMOUNT) money_count from pms_project left join pms_contract on pms_contract.code = pms_project.HT_CODE'
        result = rd.select(sql)
        total["pro_count"] = result[0]["pro_count"]
        total["money_count"] = result[0]["money_count"]
        sql = "select name from pms_organizations"
        result = rd.select(sql)
        total["outsourcer"] = result
        sql = "select name from pms_org_type"
        result = rd.select(sql)
        total["organizationNature"] = result
        sql = "select name from pms_project_type"
        result = rd.select(sql)
        total["projectType"] = result
        sql = "select name from pms_project_property"
        result = rd.select(sql)
        total["projectNature"] = result

        self.render('pmsManager/ssb_manage_index2.html',id = pid, msgList = msgList,projectList = projectList,info = total,logList = logList,pro_ingList = pro_ingList)
