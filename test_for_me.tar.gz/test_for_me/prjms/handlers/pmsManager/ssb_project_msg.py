import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts

class getUserIdHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        userno = tornado.escape.xhtml_escape(self.current_user)
        user_infos = rd.select('select * from pms_user where no = \'%s\'' %userno)
        id = user_infos[0]["id"]
        username = user_infos[0]["name"]
        self.write({'userId':id,'username':username});
