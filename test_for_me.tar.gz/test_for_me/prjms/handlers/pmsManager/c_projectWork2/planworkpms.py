# -*- coding: utf-8 -*-

import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts

class PlanWorkDetailHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        project_id = self.get_argument('project_id')
        sql = """
              select * from project_plan where 
              """
        return 
