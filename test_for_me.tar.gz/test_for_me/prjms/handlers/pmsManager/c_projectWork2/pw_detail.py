# -*- coding: utf-8 -*-

import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts
from datetime import datetime
import time


def page_data(id):
    plan_sql = """select * from pms_project_dev where pms_project_id = %s"""%id
    project = """select * from pms_project where id = %s"""%id
    all_plan_sql = """select * from pms_project_stage"""
    plan = rd.select(plan_sql)
    for i in plan:
        if i['dev_user_id'] is None:
            i['dev_user_name'] = None
        else:
            plan_sql = """select * from pms_user where id = %s"""%i['dev_user_id']
            planuser = rd.select(plan_sql)
            i['dev_user_name'] = planuser[0]['name']
    if len(plan) > 0  :
        if plan[0]['dev_user_id'] is None:
            plan_user = None
        else:
            plan_user = """select * from pms_user where id = %s"""%plan[0]['dev_user_id']
            plan_user = rd.select(plan_user)
            plan_user = plan_user[0]['name']
    else:
            plan_user = None
    all_plan= rd.select(all_plan_sql)
    project = rd.select(project)
    return (plan,plan_user,all_plan,project)


#此功能是项目计划安排
class projectPlanDetailHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        plan_sql = """select * from pms_project_dev where pms_project_id = %s"""%id
        project = """select * from pms_project where id = %s"""%id
        all_plan_sql = """select * from pms_project_stage"""
        plan = rd.select(plan_sql)
        for i in plan:
            if i['dev_user_id'] is None:
                i['dev_user_name'] = None
            else:
                plan_sql = """select * from pms_user where id = %s"""%i['dev_user_id']
                planuser = rd.select(plan_sql)
                i['dev_user_name'] = planuser[0]['name']
        if len(plan) > 0  :
            if plan[0]['dev_user_id'] is None:
                plan_user = None
            else:
                print (plan[0]['dev_user_id'])
                plan_user = """select * from pms_user where id = %s"""%plan[0]['dev_user_id']
                plan_user = rd.select(plan_user) 
                plan_user = plan_user[0]['name']
        else:
                plan_user = None
        all_plan= rd.select(all_plan_sql)
        project = rd.select(project)
        print (plan)
        stage = rd.select("select * from pms_project_stage")
        manage_user = rd.select('select * from pms_user where id in (select user_id from pms_user_role )')
        self.render('pmsManager/pms_work_index_detail.html',plan=plan,all_plan=all_plan,
                                                           pms_id = id,
                                                           pms_stage=stage,manage_user = manage_user,
                                                           project_name=project[0]['name'],plan_user=plan_user)


class projectProPlanDataHandler(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        self.render('pmsManager/project_pro_plan.html')
    @tornado.web.authenticated
    def post(self):
        org_id = self.get_argument('org_id')
        sql = """
              select  di.id from pms_differ di 
              join pms_user pu 
              join pms_organizations pos on pu.org_id = pos.id
              where pu.org_id = '%s'
              """%org_id
        
        pageSize = int(self.get_argument('limit'))
        curPage = int(self.get_argument('page'))
        pms_user_pms_user_cout = rd.select_limit_with_count(sql,pageSize,curPage)
        self.write({'total':pms_user_count,'data':pms_user})


class projectProPlanDetailHandler(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        self.render('pmsManager/pms_pro_plan_detail.html')
    @tornado.web.authenticated
    def post(self):
        pro_id = self.get_argument('pro_id')
        user_id = self.get_argument('user_id')
        property_sql = """select * from pms_project_property""" 
        plan_sql = """select * from pms_project_dev where pms_project_id = %s"""%pro_id
        #此处将值传递回前台
        pro_data = rd.select(property_sql)
        plan_data = rd.select(plan_sql)
        self.write({'plan_data':plan_data,'pro_data':pro_data})

#此处进行项目周期内的内容更新
class pmsUpdate(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        sql = "update pms_project_dev set pms_project_id = '%s' , pms_project_stage_id = '%s' , dev_user_id = '%s' , p_end_date=to_date('%s','yyyy-mm-dd ') , start_date =  to_date('%s','yyyy-mm-dd')  where id = %s"%(requestBy_dict['pms_project_id'],requestBy_dict['pms_project_stage_id'],requestBy_dict['dev_user_id'],requestBy_dict['p_end_date'],requestBy_dict['start_date'],requestBy_dict['id'])
        rd.update(sql)
        print (sql)
        id = self.get_argument('pms_project_id')#此处需要获取项目id
        (plan,plan_user,all_plan,project)=page_data(id)
        self.render('pmsManager/pms_work_index_detail_tmp.html',plan=plan,
                                                           all_plan=all_plan,
                                                           project_name=project[0]['name'],
                                                           plan_user=plan_user)        

#此处进行回调更新按钮的展示数据
class pmsUpdateBack(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        pro_dev_id = self.get_argument('pro_dev_id')
        sql ="select * from pms_project_dev where id =%s"%pro_dev_id
        data = rd.select(sql)
        mes = {}
        print (data)
        mes['id'] = data[0]['pms_project_id']
        mes['pms_dev_user_id'] = data[0]['dev_user_id']
        mes['pms_project_stage_id'] = data[0]['pms_project_stage_id']
        if data[0]['p_end_date'] is not None:
            mes['p_end_date'] = datetime.strftime(data[0]['p_end_date'],'%Y-%m-%d')
        else:
            mes['p_end_date'] = 'null'
        if data[0]['start_date'] is not None:
            mes['start_date'] = datetime.strftime(data[0]['start_date'],'%Y-%m-%d')
        else:
            mes['start_date'] = 'null'
        self.write({'data':mes})



#项目周期的添加
#添加项目周期时需要安排对应的项目周期负责人员
class pmsAddWork(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('pms_project_id')
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        del requestBy_dict['id']
        a = requestBy_dict
        sql = """insert into  pms_project_dev   (id, pms_project_id, pms_project_stage_id, dev_user_id, p_end_date, start_date)   values(seq_pms_project_dev.nextval, '%s', '%s', '%s',to_date('%s','yyyy-mm-dd'),to_date('%s','yyyy-mm-dd'))"""%(a['pms_project_id'],a['pms_project_stage_id'],a['dev_user_id'],a['p_end_date'],a['start_date'])
        rd.insert(sql)
        (plan,plan_user,all_plan,project)=page_data(id)
        self.render('pmsManager/pms_work_index_detail_tmp.html',plan=plan,
                                                           all_plan=all_plan,
                                                           project_name=project[0]['name'],
                                                           plan_user=plan_user)        

#项目周期的删除
class pmsDelete(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        pro_dev_id = self.get_argument('id')
        id = self.get_argument('pms_project_id')
        sql = 'delete  pms_project_dev where id = %s'%pro_dev_id
        rd.own_excute(sql)
        (plan,plan_user,all_plan,project)=page_data(id)
        self.render('pmsManager/pms_work_index_detail_tmp.html',plan=plan,
                                                           all_plan=all_plan,
                                                           project_name=project[0]['name'],
                                                           plan_user=plan_user)

#此处进行调整项目的周期
class pmsChangeProjectPlanHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        pro_id = self.get_argument('id')
        pro = self.get_argument('pro')
        #此处将对应的项目计划数据覆盖对应的项目
        sql = """select code from pms_project_stage where id in (select pms_project_stage_id from pms_project_dev where pms_project_id = %s)"""%pro_id
        data = rd.select(sql) 
        #把pro拆成数组
        #查询全部的阶段类型,如果已有的阶段跟选择的阶段不同，则取出相同的阶段。其他不同的阶段以选择的阶段为准。
        pro_arr = pro.split(',')
        data_tmp = data
        new_pro = []
        print (pro_arr)
        print (data_tmp)
        #此处需要进行调试
        for i in pro_arr:
            if i == "" :
                pro_arr.remove(i)
        pro_tmp = pro_arr
        print (data_tmp)
        print (pro_tmp)     
        for i in data:
            for j in pro_arr:
                print (i)
                print (j)
                if j == i['code']:
                    data_tmp.remove(i)
                    pro_tmp.remove(j)
                    break
        #已经获取相同的阶段，不同的阶段分别取前面的与后面的。
        print (data_tmp)
        print (pro_tmp)
        for k in pro_tmp:
            sql_i = """insert into pms_project_dev (id,pms_project_id,pms_project_stage_id,is_comp) values (seq_pms_project_dev.nextval,%s,(select id from pms_project_stage where code = '%s'),0) """%(pro_id,k)
            rd.insert(sql_i)
        for i in data_tmp:
            sql_d = """delete from pms_project_dev where (pms_project_id =%s) and (pms_project_stage_id = (select id from pms_project_stage where code = '%s'))"""%(pro_id,i['code'])          
            rd.insert(sql_d)

        plan_sql = """select * from pms_project_dev where pms_project_id = %s"""%pro_id
        project = """select * from pms_project where id = %s"""%pro_id
        all_plan_sql = """select * from pms_project_stage"""
        all_plan= rd.select(all_plan_sql)
        plan = rd.select(plan_sql)
        print (plan)
        if len(plan) > 0  :
            if plan[0]['dev_user_id'] is None:
                plan_user = None
            else:
                print (plan[0]['dev_user_id'])
                plan_user = """select * from pms_user where id = %s"""%plan[0]['dev_user_id']
                plan_user = rd.select(plan_user)
                plan_user = plan_user[0]['name']
        else:
                plan_user = None
        project = rd.select(project)
        stage = rd.select("select * from pms_project_stage")
        manage_user = rd.select('select * from pms_user where id in (select user_id from pms_user_role where role_id in (2,3,5,6,21))')
        self.render('pmsManager/pms_work_index_detail_tmp.html',plan=plan,all_plan=all_plan,pms_id = pro_id,project_name=project[0]['name'],
                                                           pms_stage=stage,manage_user = manage_user,
                                                           plan_user=plan_user)

