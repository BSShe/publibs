import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts

#项目消息
class manageMessageListHandler(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        userno = tornado.escape.xhtml_escape(self.current_user)
        user_infos = rd.select('select * from pms_user where no = \'%s\'' %userno)
        id = user_infos[0]["id"]

        page = self.get_argument("page",1)
        userList = rd.select("select distinct(pmr.SEND_DATA_USER_ID) as id,pu.name from PMS_MES_RECODE pmr left join pms_user pu on pmr.SEND_DATA_USER_ID = pu.id where pmr.GET_DATA_USER_ID ="+str(id))
        stageList = rd.select("select id,name from pms_project_stage")

        self.render("pmsManager/ssb_pms_plan_msg.html",page = page,userList = userList,stageList = stageList)
    #未读消息状态变更数据更新
    def post(self):
        id = self.get_argument('id')
        username = self.get_argument('username')
        updateMsgStatus(username,id)
        self.write({'status':'success'})

class setManyMsgStatusHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        data = json.loads(self.get_argument('data'))
        for i in data:
            username = i.split('-')[1]
            id = data[i]
            print(username,id)
            updateMsgStatus(username,id)
        self.write({'status':'success'})

#获取消息列表
class projectMsgProListHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        userno = tornado.escape.xhtml_escape(self.current_user)
        user_infos = rd.select('select * from pms_user where no = \'%s\'' %userno)
        id = user_infos[0]["id"]

        pname = self.get_argument("pname")
        pcode = self.get_argument("pcode")
        userId = self.get_argument("userId")
        sendTime = self.get_argument("sendTime")
        ptype = self.get_argument("ptype")
        pstage = self.get_argument("pstage")
        pstatus = self.get_argument("pstatus",0)

        msgListSql = getMsgListSql(id)
        if pname != None and pname != "":
            msgListSql += " and pname like '%"+str(pname)+"%'"
        if pcode != None and pcode != "":
            msgListSql += " and pcode like '%"+str(pcode)+"%'"
        if userId != None and userId != "":
            msgListSql += " and send_user = '"+str(userId)+"'"
        if sendTime != None and sendTime != "":
            msgListSql += " and substr(msgdate,0,10) = '"+str(sendTime)+"'"
        if ptype != None and ptype != "":
            msgListSql += " and mes_type = '"+str(ptype)+"'"
        if pstage != None and pstage != "":
            msgListSql += " and sname = '"+str(pstage)+"'"
        if pstatus != None and pstatus != "":
            msgListSql += " and type = "+str(pstatus)

        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_pro,pms_pro_count = rd.select_limit_with_count(msgListSql,pageSize ,curPage)

        self.write({'total': pms_pro_count, 'data': pms_pro, 'userId':id,'userno':userno})

def updateMsgStatus(username,id):
    if ('系统' == str(username)):
        print("------更新预警消息，id：")
        print(id)
        rd.update("update PMS_RISK_MES set status = 1,read_time = sysdate where id ="+str(id))
    else:
        print("------更新阶段消息，id：")
        print(id)
        rd.update("update PMS_MES_RECODE set type = 1 where id ="+str(id))

def getMsgListSql(id):
    sql = "select * from (select pmr.id as id,pp.id as pid,pp.code as pcode,pp.name as pname,pu.name as send_user,to_char(SEND_DATE,'yyyy-mm-dd HH24:mi:ss') as msgDate,pmr.mes,pmr.SEND_DATA_USER_ID as sendId,pps.id as sid,pps.name as sname,pmr.TYPE,'阶段消息' as mes_type from PMS_MES_RECODE pmr left join pms_project pp on pp.id = pmr.PROJECT_ID left join pms_project_stage pps on pps.ID = pmr.PROJECT_PRO_ID left join pms_user pu on pmr.SEND_DATA_USER_ID = pu.id where GET_DATA_USER_ID ="+str(id)+" union select prm.id as id,pp.id as pid,pp.code as pcode,pp.name as pname,'系统' as send_user,to_char(time,'yyyy-mm-dd HH24:mi:ss') as msgDate,prm.mes,-1 as sendId,pps.id as sid,nvl(pps.name,'项目消息') as sname,prm.STATUS as type,'预警消息' as mes_type from PMS_RISK_MES prm left join pms_project pp on pp.id = prm.PROJECT_ID left join pms_project_dev ppd on ppd.id = prm.DEV_ID left join pms_project_stage pps on pps.ID = ppd.PMS_PROJECT_STAGE_ID where GET_MES_USER_ID ="+str(id)+" order by type asc, msgDate desc) A where pid is not null"
    return sql
