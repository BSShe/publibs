# -*- coding: utf-8 -*-

import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts

class projectPlanListHandler(BaseHandler):
    #打开项目计划列表
    #展示对应的项目，选择项目的内容对应的计划与安排。
    #项目安排期间不再项目团队显示内容，
    #安排之后在团队内显示对应的阶段与控制，并在项目安排期间将项目的工作任务与内容安排进去
    #设置项目计划并将项目计划显示在对应的界面上
    #调整项目评价
    @tornado.web.authenticated
    def get(self):
        page = self.get_argument("page",1)
        work_id = self.get_argument("work_id",0)
        print("--------work_id:",work_id)
        pms_statusList = rd.select('select * from pms_pro_status where type = 1')
        pms_orgList = rd.select('select * from pms_organizations')
        pms_ptryList = rd.select('select * from pms_project_property')
        pms_htList = rd.select('select * from pms_project_type') 
        pms_manaUserList = rd.select('select * from pms_user')#此处需要加入查询条件管理员
        pms_ptyList = rd.select('select * from pms_project_type')
        pms_pmsPro = rd.select('select * from pms_project_stage')
        pms_supp = rd.select('select * from pms_user')
        url = 'pmsManager/pms_plan_index.html'    
        user_id = self.session['user_id']
        user_sql = '''select * from pms_role where id in (select role_id from pms_user_role where user_id = %s)'''%user_id
        data = rd.select(user_sql)
        #权限配置返回值(1：系统管理者权限 2：项目总监权限  3：项目经理权限 4：普通人员权限)
        for i in data:
            if i['name'] == '机构管理员' or i['name']=='项目总监' or i['name']=='系统管理员' or i['name'] =='项目经理':
                url = 'pmsManager/pms_plan_index_2.html'
        self.render( url,
                     page = page,
                     work_id = work_id,
                     statusList = pms_statusList,
                     orgList = pms_orgList,manaUserList = pms_manaUserList,
                     ptyList = pms_ptyList,ptryList = pms_ptryList,
                     htList = pms_htList,pms_pmsPro = pms_pmsPro,suppList = pms_supp
        )
   
    #获取项目计划功能列表
    @tornado.web.authenticated
    def post(self):
        name = self.get_argument('search_name')
        project_name =self.get_argument('search_pro_name')
        project_code = self.get_argument('search_project_code')
        org_id = self.get_argument('search_org_id')
        status_id = self.get_argument('search_status_id')
        work_id = self.get_argument('work_id',0)
        user_id = self.session['user_id']
        #项目人员权限获取，根据不同的权限获取不同的项目数据
        #思路：权限获取后，根据人员身份的不同，只有跟项目有关的人员才能看到对应的项目列表，分别时pms_dev_user表中存在的和pms_project和pms_project_dev中存在再查询条件中增加对应的功能
        #普通用户能看到的：自己进行工作的项目阶段。也就是在pms_dev_user表中存在的项目阶段，通过user_id去查询
        #无关人员则必须是总监和系统管理员才可以看对应的项目列表
        role_sql = """select pr.name name,pu.name pu_name from pms_role pr left join pms_user_role pur on pr.id = pur.role_id left join pms_user pu on pu.id = pur.user_id where pu.id = %s """%user_id
        user_roles = rd.select(role_sql)
        sql_s1 = 'and (ppd.id in (select ppdc.pms_project_dev_id dev_id from pms_project_dev_child_user ppdcu left join pms_project_dev_child ppdc on ppdc.id = ppdcu.dev_child_id  where ppdcu.user_id = %s) or ppd.dev_user_id = %s '%(user_id,user_id)
        sql_s = ''
        is_all = 0
        for i in user_roles:
            if i['name'] == "项目经理":
                sql_s += 'or pj.org_manager_user_id = %s or pj.manager_user_id = %s '%(user_id,user_id)
                break
        for i in user_roles:
            if i['name'] == '项目总监' or i['name'] == '机构管理员':
                sql_s += 'or (pj.pms_org_id =(select org_id from pms_user where id = %s) or pj.pms_supp_id = (select org_id from pms_user where id = %s)) '%(user_id,user_id)
                break
        for i in user_roles:
            if i['name'] == "系统管理员" :
                sql_s = ''
                is_all = 1
                break        
        if str(work_id) == '0':
            sql = """select pj.pms_dev_id,pj.id,pj.code,pj.name,pj.p_start_date,pj.p_end_date,pj.pms_dangous_level,pu.name as pms_project_dev_user,pps.name as pms_project_stage_name,pps.code as pms_project_stage_code , pj.status as status        from pms_project pj        left join pms_project_dev ppd on ppd.id = pj.pms_dev_id        left join pms_user pu on pu.id = ppd.dev_user_id  left join pms_project pp on pp.id = ppd.pms_project_id      left join pms_project_stage pps on pps.id = ppd.pms_project_stage_id where (pj.is_child != 1 or pj.is_child is null ) and (pj.status !=5 and pj.status !=14) """
            if is_all == 0:
                sql += sql_s1
        else:
            if is_all == 0:
                sql = "select distinct(pj.id),pj.pms_dev_id,pj.code,pj.name,pj.p_start_date,pj.p_end_date,pj.pms_dangous_level,pu.name as pms_project_dev_user,pps.name as pms_project_stage_name,pps.code as pms_project_stage_code , pj.status as status        from pms_project pj        left join pms_project_dev ppd on ppd.id = pj.pms_dev_id        left join pms_user pu on pu.id = ppd.dev_user_id  left join pms_project pp on pp.id = ppd.pms_project_id      left join pms_project_stage pps on pps.id = ppd.pms_project_stage_id left join pms_project_dev ppd2 on ppd2.pms_project_id = pj.id where (pj.is_child != 1 or pj.is_child is null ) and (ppd2.id in (select ppdc.pms_project_dev_id dev_id from pms_project_dev_child_user ppdcu left join pms_project_dev_child ppdc on ppdc.id = ppdcu.dev_child_id  where ppdcu.user_id = %s) or ppd2.dev_user_id = %s "%(user_id,user_id)
            else:
                sql = "select distinct(pj.id),pj.pms_dev_id,pj.code,pj.name,pj.p_start_date,pj.p_end_date,pj.pms_dangous_level,pu.name as pms_project_dev_user,pps.name as pms_project_stage_name,pps.code as pms_project_stage_code , pj.status as status        from pms_project pj        left join pms_project_dev ppd on ppd.id = pj.pms_dev_id        left join pms_user pu on pu.id = ppd.dev_user_id  left join pms_project pp on pp.id = ppd.pms_project_id      left join pms_project_stage pps on pps.id = ppd.pms_project_stage_id left join pms_project_dev ppd2 on ppd2.pms_project_id = pj.id where (pj.is_child != 1 or pj.is_child is null )"
        if sql_s != "":
            sql += sql_s
        if is_all == 0:
            sql += ')'
        #此处需要加入更多的查询条件
        if name is not None  and  name != "":
            sql += " and pu.name like '%" + name + "%'"
        if project_name is not None  and  project_name != "":
            sql += " and pj.name like '%" + project_name + "%'"
        if project_code is not None and project_code != "":
            sql += " and pj.code = '%s'"%project_code
        if org_id is not None and org_id != '':
            sql += " and pj.pms_org_id = %s"%org_id
        if status_id is not None and status_id !='':
            sql += " and pj.status = '%s'"%status_id
        sql += " order by pj.id desc"
        #sql_status = "select * from pms_status where code = 'delete'"
        #status_delete = rd.select(sql_status)[0]['id']
        #sql += " and pj.status != '%s'" % status_delete
        #sql += " order by pj.id "
        sql_x = """select pps.code,pp.id,ppd.id dev_id from pms_project_stage pps left join pms_project_dev ppd on ppd.PMS_PROJECT_STAGE_ID = pps.id left join pms_project pp on pp.id = ppd.pms_project_id order by pps.code"""
        all_dev = rd.select(sql_x)
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_user,pms_user_count = rd.select_limit_with_count(sql, pageSize, curPage)
        for i in pms_user:
            i['stages'] = []
            i['dev_id'] = []
            for j in all_dev:
                if j['id'] == i['id']:
                    i['stages'].append(j['code'])
                    i['dev_id'].append(j['dev_id'])
                if j['dev_id'] == i['pms_dev_id']:
                    break
        print ('sql:%s'%sql)
        print('pms_user:%s'%pms_user)
        self.write({'total': pms_user_count, 'data': pms_user})
   
class projectPlanDelHandler(BaseHandler):
    #删除项目计划
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        sql = "update pms_user set status_id = 'delete' where id = '" + id + "'"
        rd.update(sql)
        self.write({'result': 'true'})



class projectPlanUpdateHandler(BaseHandler):
    #修改信息前,回显必要信息
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        sql = "select * from pms_user  where id = '" + id + "'"
        data = rd.select(sql)
        self.write(data[0])

class projectPlanToUpdateHandler(BaseHandler):
    #修改信息
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        rd.updatebyDict('pms_user',requestBy_dict)
        self.write({'result': 'true'})


class projectPlanAddPlanHandler(BaseHandler):
    #制定项目进度计划与工作任务量
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        #获取计划安排表之后展现新的计划
        pms_project = rd.select('select * from pms_project')
        self.write({'result':'data'})  
        return 

class projectNewHandler(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        
        self.write({'result':'true'})
    def post(self):
        pass

class projectPlanToAddHandler(BaseHandler):
    #分配项目阶段与人员
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        #将项目周期单独拿出来，需要创建对应的项目阶段，然后加入对应的项目列表
        result = rd.insertbyDict('pms_project',requestBy_dict)
        pro = create_pms_project_stage(requestBy_dict) 
        update_pms_project(requestBy_dict,pro)
        self.write({'result': 'true'})

def update_pms_project(requestBy_dict,pro):
    code = requestBy_dict.get('code')
    pro_stage = rd.select("select * from pms_project_dev where pms_project_stage_id in (select id from pms_project_stage where code ='01') and pms_project_id= %s"%(pro[0]['id']))
    sql = """update pms_project set pms_dev_id = %s,t_start_date = to_date('%s','yyyy-mm-dd HH24:MI:ss') where id = %s """%(pro_stage[0]['id'],pro_stage[0]['start_date'],pro[0]['id'])
    rd.update(sql)
    return

def create_pms_project_stage(requestBy_dict):
    code = requestBy_dict.get('code')
    pro = rd.select('select * from pms_project where code = '+code)
    stage = rd.select("select * from pms_project_stage where code = '01'")
    sql ="""insert into pms_project_dev (id,pms_project_id,dev_user_id,pms_project_stage_id,p_start_date,p_end_date,start_date,is_comp) values(seq_pms_project_dev.nextval,%s,%s,%s,to_date('%s','yyyy-mm-dd'),to_date('%s','yyyy-mm-dd'),to_date('%s','yyyy-mm-dd'),'%s')"""%(pro[0]['id'],pro[0]['manager_user_id'],stage[0]['id'],pro[0]['p_start_date'],pro[0]['p_end_date'],pro[0]['p_start_date'],'0')
    rd.insert(sql)
    sql2 ="""insert into pms_project_dev_user (id,dev_id,user_id) values(seq_pms_project_dev.nextval,%s,%s)"""%(pro[0]['id'],pro[0]['manager_user_id'])
    rd.insert(sql)
    return pro

class projectPlanProListHandler(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        self.render('supplierManager/estimate-org-userList.html')
    @tornado.web.authenticated
    def post(self):
        org_id = self.get_argument('org_id')
        sql = """select pu.id, pu.no, pu.name, pu.phone_no, pos.name as org_name, pss.name as status_name 
                from pms_user pu
                join pms_organizations pos on pu.org_id = pos.id
                join pms_status pss on pu.status_id = pss.id
                where pu.org_id = '%s'""" %org_id
        sql += " order by pu.id "
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_user,pms_user_count = rd.select_limit_with_count(sql,pageSize ,curPage)
        
        self.write({'total': pms_user_count, 'data': pms_user}) 
