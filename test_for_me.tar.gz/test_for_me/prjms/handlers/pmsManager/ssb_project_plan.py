# -*- coding: utf-8 -*-
#import tornado.web
#import database.readdb as rd
#from handlers.handler import BaseHandler
#import tornado.template as template
#from config import config
#import json
#import  handlers.utils  as hts
#
#
#
#class ProjectPreparationHandler(BaseHandler):
#    #页面跳转到详情页
#    @tornado.web.authenticated
#    def post(self):
#        id = self.get_argument('id')
#        sql = 'select * from pms_project where id ='+id
#        data = rd.select(sql)
#        self.render('pmsManager/ssb_pms_plan_index_detail.html',data=data,)




import tornado.web
import database.readdb as rd
from database.models import db_Session
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts
from handlers.pmsManager.projectChild import dev_child_roles
from handlers.py_add.onlineUser import userList
from handlers.py_add.projectStageFinish import finishProjectStage

#人员分配userList
class getChildBranchPersonHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        userno = tornado.escape.xhtml_escape(self.current_user)
        user_infos = rd.select('select * from pms_user where no = \'%s\'' %userno)
        org = user_infos[0]["org_id"]
        pid = self.get_argument('pid')
        cstage = rd.select("select c.id,c.NAME as cname,c.PMS_PROJECT_STAGE_ID as sid ,d.NAME as sname from pms_project_dev a left join PMS_PROJECT_DEV_CHILD b on a.id = b.PMS_PROJECT_DEV_ID left join pms_project_stage_child c on b.PMS_PROJECT_STAGE_CHILD_ID = c.ID left join pms_project_stage d on c.PMS_PROJECT_STAGE_ID = d.ID where a.PMS_PROJECT_ID = "+str(pid)+" and c.id is not null order by c.ID asc")

        proBranchList = getAllProBranch(pid)
        for i in range(len(cstage)):
            userList = []
            orgLi = []
            branchList = rd.select("select po.id from pms_role_stage prs left join pms_role pr on prs.ROLE_ID = pr.id left join pms_org_role por on por.ROLE_ID = pr.ID left join PMS_ORGANIZATIONS po on por.ORG_ID = po.ID where prs.stage_id ="+str(cstage[i]['id']))
            for j in branchList:
                if j['id'] in proBranchList:
                    orgLi.append(j['id'])
                    continue
            print(orgLi)
            for j in orgLi:
                if j != None:
                    userLi = rd.select("select pu.id,pu.name from pms_user pu left join pms_user_role pur on pur.user_id = pu.id left join pms_role pr on pur.role_id = pr.id where org_id = "+str(j)+" and pr.name <> '项目总监' and pr.name <> '系统管理员' and pr.name <> '机构管理员'")
                    userList = userList + userLi
            print(userList)
            is_userLi2 = rd.select("select * from PMS_ORGANIZATIONS po left join pms_org_type pot on po.TYPE_ID = pot.id where pot.NAME = '外包机构' and po.id ="+str(org))
            if (len(is_userLi2)):
                userLi2 = rd.select("select distinct(pu.id),pu.name from pms_user pu left join pms_user_role pur on pu.id = pur.USER_ID left join pms_role pr on pur.ROLE_ID = pr.ID where pu.org_id = "+str(org)+"and pr.name <> '项目总监' and pr.name <> '系统管理员' and pr.name <> '机构管理员'")
                userList = userList + userLi2
            print(userList)
            cstage[i]['userList'] = userList
        name = rd.select("select id,name,no,phone_no from PMS_USER ")
        self.write({'cstage_userList':cstage,'name1':name})

#首页数据初始化
class getProjectPreDataHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        userno = tornado.escape.xhtml_escape(self.current_user)
        user_infos = rd.select('select * from pms_user where no = \'%s\'' %userno)
        userid = user_infos[0]["id"]
        id = self.get_argument("id")
        dev_id = self.get_argument("dev_id")        

        resList = rd.select("select psdm.TYPE,po.name,psdm.con from pms_stage_doc_main psdm left join PMS_ORGANIZATIONS po on psdm.TITLE = po.id left join PMS_PROJECT_STAGE pps on pps.code = psdm.PMS_PROJECT_STAGE_CODE where pps.name = '项目准备' and psdm.type = 1 and psdm.PMS_PROJECT_ID ="+str(id))
        devList = rd.select("select psdm.TYPE,po.name,psdm.con from pms_stage_doc_main psdm left join PMS_ORGANIZATIONS po on psdm.TITLE = po.id left join PMS_PROJECT_STAGE pps on pps.code = psdm.PMS_PROJECT_STAGE_CODE where pps.name = '项目准备' and psdm.type = 2 and psdm.PMS_PROJECT_ID ="+str(id))
        worksDay = rd.select("select PMS_PROJECT_STAGE_ID as sid, WORKSDAY from pms_project_dev where PMS_PROJECT_ID ="+str(id))
        devMList = rd.select("select a.DEV_USER_ID as id,b.name as name,a.PMS_PROJECT_STAGE_ID as sid from pms_project_dev a left join pms_user b on a.DEV_USER_ID = b.id where PMS_PROJECT_ID ="+str(id))
        couList = rd.select("select sid,count(userId) cou from (select distinct(a.PMS_PROJECT_STAGE_ID) as sid, c.USER_ID as userId from pms_project_dev a left join pms_project_dev_child b on b.PMS_PROJECT_DEV_ID = a.id left join pms_project_dev_child_user c on c.DEV_CHILD_ID = b.id where PMS_PROJECT_ID = "+str(id)+") A group by sid")
        allManList = rd.select("select a.PMS_PROJECT_STAGE_ID as sid,d.ID as cid,c.USER_ID as userid,e.name from pms_project_dev a left join pms_project_dev_child b on b.PMS_PROJECT_DEV_ID = a.id left join pms_project_dev_child_user c on c.DEV_CHILD_ID = b.id left join PMS_PROJECT_STAGE_CHILD d on b.PMS_PROJECT_STAGE_CHILD_ID = d.ID left join pms_user e on c.user_id = e.id where PMS_PROJECT_ID ="+str(id))

        is_write_1 = dev_child_roles(userid,dev_id,id)[0]
        writeList = []
        for i in is_write_1:
            is_write_2 = rd.select("select b.CODE from pms_project_dev_child a left join pms_project_stage_child b on a.PMS_PROJECT_STAGE_CHILD_ID = b.ID where a.id ="+str(i))
            writeList.append(is_write_2[0]['code'])
        writeList.sort()

        for i in range(len(resList)):
            if '03' in writeList:
                resList[i]['write'] = 1
            else:
                resList[i]['write'] = 0

        for i in range(len(devList)):
            if '04' in writeList:
                devList[i]['write'] = 1
            else:
                devList[i]['write'] = 0
        for i in range(len(worksDay)):
            worksDay[i]['type'] = 3
            if worksDay[i]['worksday'] == None:
                worksDay[i]['worksday'] = ""
        for i in range(len(devMList)):
            devMList[i]['type'] = 4
        for i in range(len(couList)):
            couList[i]['type'] = 5
        for i in range(len(allManList)):
            allManList[i]['type'] = 6
        resList = resList + devList + worksDay + devMList + couList + allManList
        resList = json.dumps(resList)
        self.write(resList)

#项目准备
class projectPreparationHandler(BaseHandler):
    #页面跳转到详情页
    @tornado.web.authenticated
    def post(self):
        id = self.session['user_id']
        sql = """select * from pms_user where id = %s""" % id
        user_infos = rd.select(sql)
        org = user_infos[0]["org_id"]
        username = user_infos[0]["name"]
        proId = self.get_argument('id')
        page = self.get_argument('page')
        type = self.get_argument('type')

        did = self.get_argument('dev_id')
        sid = rd.select("select id from pms_project_stage where name = '项目准备'")
        projectName = rd.select("select name from pms_project where id = "+str(proId))
        suId = rd.select("select pms_supp_id as id from pms_project where id = "+str(proId))

        status1 = rd.select("select ppd.is_comp statu from pms_project_dev ppd left join pms_project_stage pps on ppd.PMS_PROJECT_STAGE_ID = pps.ID where pps.NAME = '项目准备' and ppd.PMS_PROJECT_ID ="+ str(proId))
        statu = 1
        if (len(status1)):
            statu = status1[0]['statu']

        manageroleId = rd.select("select id from pms_role where NAME = '项目经理'")
        roleId = rd.select("select role_id from pms_user_role where USER_ID ="+str(id))
        manageId = rd.select("select MANAGER_USER_ID from pms_project where id ="+str(proId))
        prorgId = rd.select("select pms_org_id as orgid from pms_project where id ="+str(proId))
        allStageChild = rd.select("select c.id,c.NAME as cname,c.PMS_PROJECT_STAGE_ID as sid ,d.NAME as sname from pms_project_dev a left join PMS_PROJECT_DEV_CHILD b on a.id = b.PMS_PROJECT_DEV_ID left join pms_project_stage_child c on b.PMS_PROJECT_STAGE_CHILD_ID = c.ID left join pms_project_stage d on c.PMS_PROJECT_STAGE_ID = d.ID where a.PMS_PROJECT_ID = "+str(proId)+" and c.id is not null order by c.ID asc")

        s_stageListsql="select ppst.ID,ppst.NAME from  pms_project_stage ppst left join pms_project_dev ppd on ppst.id = ppd.PMS_PROJECT_STAGE_ID where ppd.PMS_PROJECT_ID ="+str(proId)+"order by ppst.ID asc"
        s_stageList = rd.select(s_stageListsql)
        print("--------------ssb")
        print(s_stageList)
        stage = s_stageList
        orgListSql = "select id,name from pms_organizations"

        proBranchList = getAllProBranch(proId)
        userList = []
        for i in proBranchList:
            print(i)
            userLi2 = rd.select("select distinct(pu.id),pu.name from pms_user pu left join pms_user_role pur on pu.id = pur.USER_ID left join pms_role pr on pur.ROLE_ID = pr.ID where pr.name <> '机构管理员' and pr.name <> '项目总监' and pr.name <> '系统管理员' and pu.org_id ="+str(i))
            userList = userList + userLi2
            
        is_userLi2 = rd.select("select * from PMS_ORGANIZATIONS po left join pms_org_type pot on po.TYPE_ID = pot.id where pot.NAME = '外机构' and po.id ="+str(org))
        if (len(is_userLi2)):
            userLi2 = rd.select("select distinct(pu.id),pu.name from pms_user pu left join pms_user_role pur on pu.id = pur.USER_ID left join pms_role pr on pur.ROLE_ID = pr.ID where pu.org_id = "+str(org)+"and pr.name <> '项目总监' and pr.name <> '系统管理员' and pr.name <> '机构管理员'")
            userList = userList + userLi2

        orgList = rd.select(orgListSql)
        #manageUserList = rd.select(manageUserListSql)
       
        print("----------13 power----------")
        print(dev_child_roles(id,did,proId)) 
        is_write = []
        is_read = []
        is_write_1 = dev_child_roles(id,did,proId)[0]
        is_read_1 = dev_child_roles(id,did,proId)[1]
        is_to_end = dev_child_roles(id,did,proId)[2]
        for i in is_write_1:
            is_write_2 = rd.select("select b.CODE from pms_project_dev_child a left join pms_project_stage_child b on a.PMS_PROJECT_STAGE_CHILD_ID = b.ID where a.id ="+str(i))
            is_write.append(is_write_2[0]['code'])
        for i in is_read_1:
            is_read_2 = rd.select("select b.CODE from pms_project_dev_child a left join pms_project_stage_child b on a.PMS_PROJECT_STAGE_CHILD_ID = b.ID where a.id ="+str(i))
            is_read.append(is_read_2[0]['code'])
        is_write.sort()
        is_read.sort()
        #测试使用
        #is_write = ['01','02','03','04'] 

        self.render('pmsManager/ssb_pms_plan_index_detail.html',
            is_write = is_write,
            is_read = is_read,
            is_to_end = is_to_end,
            dev_id = did,
            did = sid[0]['id'],
            proId = proId,
            page = page,
            type = type,
            projectName = projectName[0]['name'],
          #  status = status,
            username=username,
         #   manageUserList = manageUserList,
            userList=userList,
            s_stageList=s_stageList,
            orgList=orgList,
            statu = statu,
            allStageChild = allStageChild
        )

class projectPreDataHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        id = self.session['user_id']
        projectId = self.get_argument("projectId")
        checkTime = self.get_argument("checkTime")
        dev_id = self.get_argument('dev_id')
        test = finishProjectStage(projectId,'项目准备',id,json.loads(checkTime),dev_id)
        self.write(test)

class timeAndDevMCommitHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        data = json.loads(self.get_argument('data'))
        print("--------------更新阶段管理与时间-------------")
        print(data)
        projectId = data['projectId']
        for i in data:
            if 'time' in i:
                if data[i] != '':
                    rd.update("update pms_project_dev set worksday = "+str(data[i])+" where PMS_PROJECT_ID = "+str(projectId)+" and PMS_PROJECT_STAGE_ID ="+str(i.split('time')[0]))
            elif 'devM' in i:
                if data[i] != '':
                    rd.update("update pms_project_dev set dev_user_id = "+str(data[i])+" where PMS_PROJECT_ID = "+str(projectId)+" and PMS_PROJECT_STAGE_ID ="+str(i.split('devM')[0]))
                
        statu = "success"
        self.write(statu)

class devChildUserCommitHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        data = json.loads(self.get_argument('data'))
        print("--------------更新子任务人员情况-------------")
        print(data)
        for i in data:
            if 'projectId' in i:
                projectId = data[i].split('-')[0]
                sid = data[i].split('-')[1]
                break

        allManList = rd.select("select a.PMS_PROJECT_STAGE_ID as sid,b.id as cid,d.ID as scid,c.USER_ID as userid,e.name from pms_project_dev a left join pms_project_dev_child b on b.PMS_PROJECT_DEV_ID = a.id left join pms_project_dev_child_user c on c.DEV_CHILD_ID = b.id left join PMS_PROJECT_STAGE_CHILD d on b.PMS_PROJECT_STAGE_CHILD_ID = d.ID left join pms_user e on c.user_id = e.id where a.PMS_PROJECT_STAGE_ID ="+str(sid)+"and e.id is not null")
        for i in allManList:
            flag = 1
            for j in data:
                if 'projectId' in j:
                    continue
                else:
                    if str(i['sid']) == str(j.split('-')[0]) and str(i['scid']) == str(data[j].split('-')[0]) and str(i['userid']) == str(data[j].split('-')[1]) and j.split("-")[2] == "0":
                        flag = 0
                        break
            if flag == 1:#delete
                delete("delete from pms_project_dev_child_user where DEV_CHILD_ID = "+str(i['cid'])+" and USER_ID = "+str(i['userid']))
                print("userid:")
                print(i['userid'])
                print("----del")
                
                
        for i in data:
            if 'projectId' in i:
                continue
            else:
                if i.split("-")[2] == "1":
                    userId = data[i].split('-')[1]
                    scId = data[i].split('-')[0]
                    devId = rd.select("select id from pms_project_dev where PMS_PROJECT_ID = "+str(projectId)+" and PMS_PROJECT_STAGE_ID = "+str(i.split('-')[0]))
                    devId = devId[0]['id']
                    devCId = rd.select("select a.id from pms_project_dev_child a where a.PMS_PROJECT_DEV_ID = "+str(devId)+" and a.PMS_PROJECT_STAGE_CHILD_ID ="+str(scId))
                    devCId = devCId[0]['id']
                    print("userid:")
                    print(userId)
                    print("---insert")
                    sql = """insert into PMS_PROJECT_DEV_CHILD_USER(id,DEV_CHILD_ID,user_id,power) values(seq_PMS_PROJECT_DEV_CHILD_USER.nextval,%s,%s,%s)"""%(devCId,userId,1)
                    rd.insert(sql)

        statu = "success"
        self.write(statu)

class resAndDevCommitHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        data = json.loads(self.get_argument('data'))
        print("--------------更新设备与资源情况-------------")
        print(data)

        type = ""        
        projectId = data['projectId']
        for i in data:
            if 'res' in i:
                type = "res"
                break
            elif 'dev' in i:
                type = "dev"
                break

        stageCode = rd.select("select code from pms_project_stage where name = '项目准备'")
        stype = -1
        if type == "res":
            stype = 1;
        elif type == "dev":    
            stype = 2
        
        if stype != -1:
            allRes = rd.select("select id,PMS_PROJECT_ID,PMS_PROJECT_STAGE_CODE,TYPE,CON,TITLE from PMS_STAGE_DOC_MAIN where type = "+ str(stype) +" and PMS_PROJECT_STAGE_CODE = "+str(stageCode[0]['code']))

            for i in allRes:
                flag = 0
                for j in data:
                    if 'projectId' in j:
                        continue
                    else:
                        orgzaid = rd.select("select id from PMS_ORGANIZATIONS where name = '"+str(j.split(type)[1])+"'")
                        if (str(i['title'])==str(orgzaid[0]['id']) and str(i['con']) == str(data[j])):
                            flag = 1
                            data.pop(j)
                            print("data remove:")
                            print(i['con'])
                            break
                if flag == 0:
                    delete("delete from PMS_STAGE_DOC_MAIN where id = "+str(i['id']))
                    print("database delete:")
                    print(i['con'])
            for i in data:
                if 'projectId' in i:
                    continue
                else:
                    orgzaid = rd.select("select id from PMS_ORGANIZATIONS where name = '"+str(i.split(type)[1])+"'")
                    sql = """insert into PMS_STAGE_DOC_MAIN(id,PMS_PROJECT_ID,PMS_PROJECT_STAGE_CODE,TYPE,CON,TITLE) values(seq_PMS_STAGE_DOC_MAIN.nextval,%s,%s,%s,'%s','%s')"""%(projectId,stageCode[0]['code'],stype,data[i],orgzaid[0]['id'])
                    rd.insert(sql)

        statu = "success"
        self.write(statu)

class getAllManHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        pid = self.get_argument('pid')        
        userId = self.get_argument("userId")
        userNo = self.get_argument("userno")
        orgName = self.get_argument("orgId")
        
        sql = "select pu.id as userid,pu.no as userno,pu.name as username,pu.phone_no,po.id as org_id,po.name as org_name,pot.id as org_type_id,pot.NAME as org_type from (select ppdcu.USER_ID as id from pms_project_dev ppd left join pms_project_dev_child ppdc on ppdc.PMS_PROJECT_DEV_ID = ppd.id left join pms_project_dev_child_user ppdcu on ppdcu.DEV_CHILD_ID = ppdc.ID where ppd.PMS_PROJECT_ID = "+str(pid)+" union select DEV_USER_ID as id from pms_project_dev where PMS_PROJECT_ID = "+str(pid)+" union select MANAGER_USER_ID as id from pms_project where id = "+str(pid)+" union select ORG_MANAGER_USER_ID as id from pms_project where id = "+str(pid)+" union select DEP_MANAGER_USER_ID as id from pms_project where id = "+str(pid)+" union select REQ_MANAGER_USER_ID as id from pms_project where id = "+str(pid)+" union select TEC_MANAGER_USER_ID as id from pms_project where id = "+str(pid)+" union select TES_MANAGER_USER_ID as id from pms_project where id = "+str(pid)+") A left join pms_user pu on A.id = pu.id left join PMS_ORGANIZATIONS po on po.id = pu.ORG_ID left join pms_org_type pot on pot.id = po.TYPE_ID where pu.id is not null"
        count = len(rd.select(sql))
        if userId != None and userId != "":
            sql += (" and pu.id ="+str(userId))
        if userNo != None and userNo != "":
            sql += (" and pu.no like '%"+str(userNo)+"%'")
        if orgName != None and orgName != "":
            sql += (" and po.name ='"+str(orgName)+"'")
        sql += " order by pu.id asc"
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_pro,pms_pro_count = rd.select_limit_with_count(sql,pageSize ,curPage)

        self.write({'total': pms_pro_count, 'data': pms_pro,'count':count});

def getAllProBranch(pid):
    proBranchList = []
    li = rd.select("select DEP_ORG_ID as id from pms_project where id ="+str(pid))
    if li[0]['id'] not in proBranchList and li[0]['id'] != None:
        proBranchList.append(li[0]['id'])
    li = rd.select("select REQ_ORG_ID as id from pms_project where id ="+str(pid))
    if li[0]['id'] not in proBranchList and li[0]['id'] != None:
        proBranchList.append(li[0]['id'])
    li = rd.select("select TEC_ORG_ID as id from pms_project where id ="+str(pid))
    if li[0]['id'] not in proBranchList and li[0]['id'] != None:
        proBranchList.append(li[0]['id'])
    li = rd.select("select TES_ORG_ID as id from pms_project where id ="+str(pid))
    if li[0]['id'] not in proBranchList and li[0]['id'] != None:
        proBranchList.append(li[0]['id'])
    return proBranchList

def getAllProPersonInfo(pid):
    sql = "select pu.id as userid,pu.no as userno,pu.name as username,pu.phone_no,po.id as org_id,po.name as org_name,pot.id as org_type_id,pot.NAME as org_type,pr.id as branch_id,pr.name as branch_name from (select ppdcu.USER_ID as id from pms_project_dev ppd left join pms_project_dev_child ppdc on ppdc.PMS_PROJECT_DEV_ID = ppd.id left join pms_project_dev_child_user ppdcu on ppdcu.DEV_CHILD_ID = ppdc.ID where ppd.PMS_PROJECT_ID = "+str(pid)+" union select DEV_USER_ID as id from pms_project_dev where PMS_PROJECT_ID = "+str(pid)+" union select MANAGER_USER_ID as id from pms_project where id = "+str(pid)+" union select ORG_MANAGER_USER_ID as id from pms_project where id = "+str(pid)+" union select DEP_MANAGER_USER_ID as id from pms_project where id = "+str(pid)+" union select REQ_MANAGER_USER_ID as id from pms_project where id = "+str(pid)+" union select TEC_MANAGER_USER_ID as id from pms_project where id = "+str(pid)+" union select TES_MANAGER_USER_ID as id from pms_project where id = "+str(pid)+") A left join pms_user pu on A.id = pu.id left join PMS_ORGANIZATIONS po on po.id = pu.ORG_ID left join pms_org_type pot on pot.id = po.TYPE_ID left join pms_org_role por on por.ORG_ID = po.id left join pms_role pr on pr.ID = por.ROLE_ID where pu.id is not null"
    personList = rd.select(sql)
    return (len(personList),personList)

def delete(sql):
    db_session = db_Session()
    try:
        db_session.execute(sql)
        db_session.commit()
        db_session.close()
    except Exception as e:
            logging.error(e)
            db_session.rollback()
