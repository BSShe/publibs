# -*- coding: utf-8 -*-

import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts
from datetime import datetime
import time
import webbrowser
import xlrd,xlwt
import os
import operator
from handlers.pmsManager.utils import export


class ProjectWorkDtIndexHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        project_id = self.get_argument('id')
        type = self.get_argument('type')
        page = self.get_argument('page',1)
        sql = """
            select pps.id,pps.code,pps.name from pms_project_stage pps
        where code not in (
            select pps.code from pms_project_dev ppd
            join pms_project_stage pps on pps.id = ppd.pms_project_stage_id
            where ppd.pms_project_id = %s UNION
            select pps.code from pms_project_stage pps
                where pps.code <= (select pps.code from pms_project pj
                                join pms_project_dev ppd on ppd.id = pj.pms_dev_id
                                join pms_project_stage pps on pps.id = ppd.pms_project_stage_id
                                where pj.id = %s))
                 order by pps.code
                """ % (project_id,project_id)
        can_add_stage = rd.select(sql)
        sql = """
                select pps.code,ppd.id,pj.name pj_name,pps.name stage_name,pu.name manage_user,ppd.p_start_date,ppd.p_end_date,
            ppd.end_date,decode(is_comp,1,use_dates,null) use_dates,
            decode(is_comp,1,'已完成','未完成') is_comp,ppd.start_date,pp.pms_dev_id 
            from pms_project_dev ppd
            left join pms_project_stage pps on pps.id = ppd.pms_project_stage_id
            left join pms_project pj on pj.id = ppd.pms_project_id
            left join pms_project pp on pp.pms_dev_id = ppd.id
            left join pms_user pu on pu.id = ppd.dev_user_id
            where pj.id = %s order by pps.code
                """ % project_id
        result = rd.select(sql)
        status = rd.select("select pps.name from pms_project pj left join pms_pro_status pps \
                        on pps.id = pj.status where pj.id = %s" % project_id)[0]['name']
        self.render('pmsManager/pms_work_index_detail.html',dev_info = result,showType = type,id = project_id\
                        ,can_add_stage = can_add_stage,status = status,page = page
                        )

class ProjectWorkDtInfoHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        dev_id = self.get_argument('dev_id')
        sql = """select ppd.id dev_id,pps.name stage_name,pu.name manage_name,to_char(ppd.p_start_date,'yyyy-mm-dd') p_start_date,to_char(ppd.p_end_date,'yyyy-mm-dd') p_end_date from pms_project_dev ppd
left join pms_user pu on pu.id = ppd.dev_user_id
left join pms_project_stage pps on pps.id = ppd.pms_project_stage_id
where ppd.id = %s""" % dev_id
        result = rd.select(sql)[0]
        self.write(result)

#文件导入功能
class ProjectWorkImport(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        fileName=self.get_argument("fileName")
        #项目id
        id=self.get_argument("id")
        #文件保存路径及名字
        filePath='./static/files/'+fileName
        inner=self.request.files.get("file",None)
        #读取已读文件并将读取的文件的数据进行录入
        try:
            with open(filePath,'wb') as g:
                for meta in inner:
                    g.write(meta["body"])
            if '.xls' in fileName:
                wb = xlrd.open_workbook(filePath)
                print (wb.sheet_names())
                sh = wb.sheet_by_index(0)
                #sh = wb.sheet_by_name(u'sheet1')
                for rownum in range(sh.nrows):
                    print (sh.row_values(rownum))
                print (sh.col_values(3))
                print (sh.col_values(4))
                print (sh.col_values(1))
                col3 = sh.col_values(3)
                col4 = sh.col_values(4)
                col1 = sh.col_values(1)
                col0 = sh.col_values(0)
                sql = """
                        select pps.name stage_name,pj.name pj_name from pms_project_dev ppd
                        left join pms_project_stage pps on ppd.PMS_PROJECT_STAGE_ID = pps.id
                        left join pms_project pj on pj.id = ppd.PMS_PROJECT_ID
                        where ppd.PMS_PROJECT_ID = %s order by pps.code
                        """ % id
                dev_info = rd.select(sql)
                for i in range(len(col0)):
                    if i == 0:
                        continue
                    else:
                        if col0[i] != dev_info[0]['pj_name']:
                            self.write({'success':2,'msg':'导入失败，项目名与本项目不符'})
                            return
                if len(dev_info) > (len(col1)-1):
                    self.write({'success':2,'msg':'导入失败，导入时不允许删除阶段'})
                    return
                for i in range(len(dev_info)):
                    if dev_info[i]['stage_name'] not in col1:
                        self.write({'success':2,'msg':'导入失败，导入时不允许删除阶段'})
                        return
                stages = rd.select("select * from pms_project_stage pps order by pps.code")
                left,right = 0,len(col1)-1
                for i in range(len(stages)):
                    if left == right:
                        break
                    else:
                        if stages[i]['name'] == col1[left+1]:
                            left = left +1
                if left != right:
                    self.write({'success':2,'msg':'导入失败，阶段顺序错误'})
                    return
                for i in range(len(col3)):
                    if i == 0:
                        continue
                    else:
                        if not isinstance(col3[i],str):
                            #col3[i] = str(col3[i])
                            #col3[i] = col3[i][:col3[i].rindex('.')]
                            self.write({'success':2,'msg':'导入失败，日期格式应为yyyymmdd的文本'})
                            return
                        if col3[i].find('-') != -1 or col3[i].find('/') != -1:
                            self.write({'success':2,'msg':'导入失败，日期格式应为yyyymmdd的文本'})
                            return
                for i in range(len(col4)):
                    if i == 0:
                        continue
                    else:
                        if not isinstance(col4[i],str):
                            #col4[i] = str(col4[i])
                            #col4[i] = col4[i][:col4[i].rindex('.')]
                            self.write({'success':2,'msg':'导入失败，日期格式应为yyyymmdd的文本'})
                            return
                        if col4[i].find('-') != -1 or col4[i].find('/') != -1:
                            self.write({'success':2,'msg':'导入失败，日期格式应为yyyymmdd的文本'})
                            return
                sql = """
                        select * from (
                            select pps.name,to_char(ppd.p_start_date,'yyyymmdd') p_start_date,pps.code from pms_project_dev ppd
                            left join pms_project_stage pps on ppd.PMS_PROJECT_STAGE_ID = pps.id
                            where ppd.PMS_PROJECT_ID = %s and ppd.is_comp =1 
                            union
                            select pps.name,to_char(ppd.p_start_date,'yyyymmdd') p_start_date,pps.code from pms_project pj 
                            left join pms_project_dev ppd on ppd.id = pj.pms_dev_id
                            left join pms_project_stage pps on pps.id = ppd.pms_project_stage_id
                            where pj.id = %s) order by code
                        """ % (id,id)
                result = rd.select(sql)
                for i in range(len(result)):
                    if result[i]['name'] != col1[i+1] or result[i]['p_start_date'] != col3[i+1]:
                        self.write({'success':2,'msg':'导入失败，不允许修改已完成或当前正在进行阶段的预计开始时间'})
                        return
                for i in range(len(col4)-1):
                    if i == 0 or col4[i] == "":
                        continue
                    else:
                        for j in range(i+1,len(col4)):
                            if col4[j] != "" and operator.gt(col4[i],col4[j]) == True:
                                self.write({'success':2,'msg':'导入失败，存在阶段预计结束大于其后面阶段的预计结束时间或小于其前面阶段的预计结束时间'})
                                return
                for inx,val in enumerate(col1):
                    p_start_date = ''
                    p_end_date = ''
                    if inx == 0:
                        continue
                    if col3[inx] and col3[inx] != '':
                        p_start_date = col3[inx][:4] +'-'+col3[inx][4:6] +'-'+col3[inx][6:8]
                    if col4[inx] and col4[inx] != '':
                        p_end_date = col4[inx][:4] +'-'+col4[inx][4:6] +'-'+col4[inx][6:8]
                    if col0[inx] and col0[inx] != '':
                        pro_name = col0[inx]
                    if col1[inx] and col1[inx] != '':
                        dev_name = col1[inx]
                    data =  rd.select("select * from pms_project_dev ppd left join pms_project_stage pps on pps.id = ppd.pms_project_stage_id left join pms_project pp on ppd.pms_project_id = pp.id  where pps.name = '%s' and pp.name = '%s'"%(dev_name,pro_name))
                    if len(data) == 0:
                        #此数据不存在则插入此数据
                        stage = rd.select("select * from pms_project_stage where name = '%s'"%(dev_name))
                        if len(stage) == 0:
                            print('error')
                            continue
                        else:
                            #此处补全
                            project = rd.select("select * from pms_project where name = '%s'"%pro_name)
                            user_id = project[0]['manager_user_id']
                            project_id = project[0]['id']
                            stage_id = stage[0]['id']
                            rd.insert("insert into pms_project_dev (id,dev_user_id,pms_project_id,is_comp,pms_project_stage_id,p_start_date,p_end_date) values (seq_pms_project_dev.nextval,%s,%s,0,%s,to_date('%s','yyyy-mm-dd'),to_date('%s','yyyy-mm-dd'))"%(user_id,project_id,stage_id,p_start_date,p_end_date))
                    else:
                        #更新此数据
                        stage = rd.select("select * from pms_project_stage where name = '%s'"%(dev_name))
                        if len(stage) == 0:
                            continue
                        else:
                            #数据补全
                            project = rd.select("select * from pms_project where name = '%s'"%pro_name)
                            user_id = project[0]['manager_user_id']
                            project_id = project[0]['id']
                            stage_id = stage[0]['id']                        
                            rd.update("update pms_project_dev set p_start_date = to_date('%s','yyyy-mm-dd'),p_end_date = to_date('%s','yyyy-mm-dd') where pms_project_id = %s and pms_project_stage_id =%s"%(p_start_date,p_end_date,project_id,stage_id))
            else:
                print ('文件类型异常')
                self.write({'success':'0'})
        except:
            self.write({'success':'0'})
        finally:
            os.remove(filePath)
        self.write({'success':'1'})
        

#导入模版下载
#此处需要根据数据库查询结果，进行写入对应的数据，返回写入结果的模版然后根据录入的数据进行导入
class ProjectWorkDownload(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        fileName=self.get_argument("fileName")
        self.set_header("Content-Type","application/octet-stream")
        project_id = self.get_argument('id')
        sql = """
            select pps.id,pps.code,pps.name from pms_project_stage pps
        where code not in (
            select pps.code from pms_project_dev ppd
            join pms_project_stage pps on pps.id = ppd.pms_project_stage_id
            where ppd.pms_project_id = %s UNION
            select pps.code from pms_project_stage pps
                where pps.code <= (select pps.code from pms_project pj
                                join pms_project_dev ppd on ppd.id = pj.pms_dev_id
                                join pms_project_stage pps on pps.id = ppd.pms_project_stage_id
                                where pj.id = %s))
                 order by pps.code
                """ % (project_id,project_id)
        can_add_stage = rd.select(sql)
        sql = """
                select pps.code,ppd.id,pj.name pj_name,pps.name stage_name,pu.name manage_user,
            to_char(ppd.p_start_date,'yyyymmdd') p_start_date,to_char(ppd.p_end_date,'yyyymmdd') p_end_date,
            to_char(ppd.end_date,'yyyymmdd') end_date,decode(is_comp,1,use_dates,null) use_dates,
            decode(is_comp,1,'已完成','未完成') is_comp,to_char(ppd.start_date,'yyyymmdd') start_date,pp.pms_dev_id 
            from pms_project_dev ppd
            left join pms_project_stage pps on pps.id = ppd.pms_project_stage_id
            left join pms_project pj on pj.id = ppd.pms_project_id
            left join pms_project pp on pp.pms_dev_id = ppd.id
            left join pms_user pu on pu.id = ppd.dev_user_id
            where pj.id = %s order by pps.code
                """ % project_id
        result = rd.select(sql)
        status = rd.select("select pps.name from pms_project pj left join pms_pro_status pps \
                        on pps.id = pj.status where pj.id = %s" % project_id)[0]['name']
        #此处将数据写入
        #调用export函数
        #fileds = [(u'项目名',),(u'项目进度名',),(u'进度主要负责人',),(u'预计开始日期',),(u'预计结束日期',),(u'实际开始日期',),(u'实际结束日期',)] 
        #body = []
        #for i in range(len(result)):
        #    text = (result[i]['pj_name'],result[i]['stage_name'],result[i]['manage_user'],result[i]['p_start_date'],result[i]['p_end_date'],result[i]['start_date'],result[i]['end_date'],)
        #    body.append(text)
        #filePath='./static/files/'+fileName
        #filePath = export(body,fileds,'./static/files/')
        #buff=1024*1024*2
        #with open(filePath,"rb") as f:
        #    while 1:
        #        block=f.read(buff)
        #        if not block:
        #            break
        #        self.write(block)
        head = ['项目名','项目进度名','进度主要负责人','预计开始日期','预计结束日期']
        body = ['pj_name','stage_name','manage_user','p_start_date','p_end_date']
        fileName = fileName + time.strftime("%Y%m%d%H%M%S",time.localtime(time.time())) + '.xls'
        downloadName='attachment;filename='+fileName
        downloadName=downloadName.encode()
        self.set_header("Content-Disposition",downloadName)
        print(fileName)
        self.write(hts.public_exportInfo(fileName, result, head, body))
        self.finish()


class ProjectWorkDtUpdate(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        user_id = self.session['user_id']
        username = self.session['username']
        dev_id = self.get_argument('dev_id')
        p_start_date = self.get_argument('p_start_date')
        p_end_date = self.get_argument('p_end_date')
        refreshReason  = self.get_argument('refreshReason')
        sql = """
            select pps.code,ppd.PMS_PROJECT_ID,pps.name from pms_project_dev ppd 
            left join pms_project_stage pps on pps.id = ppd.pms_project_stage_id
            where ppd.id = %s
                """ % dev_id
        result = rd.select(sql)
        code = result[0]['code']
        pj_id = result[0]['pms_project_id']
        name = result[0]['name']
        status = check_all_time(pj_id,code,p_start_date,p_end_date)
        if status['status'] == 0:
            self.write(status)
            return
        sql = "update pms_project_dev set p_start_date = to_date('%s','yyyy-mm-dd HH24:mi:ss'),p_end_date = to_date('%s','yyyy-mm-dd HH24:mi:ss') where id = %s" % (p_start_date,p_end_date,dev_id)
        rd.update(sql)
        if refreshReason is not None and refreshReason != "":
            change = '设置' + name + '阶段'
            if p_start_date is not None and p_start_date != "":
                change = change + ' 预计开始时间为：' + p_start_date
            else:
                change = change + ' 预计开始时间为空'
            if p_end_date is not None and p_end_date != "":
                change = change + '，预计结束时间为：' + p_end_date
            else:
                change = change + '，预计结束时间为空'
            sql = """
                insert into pms_plan_change_mes values(seq_pms_plan_change_mes.nextval,%s,sysdate,'%s','%s',%s)
                    """ % (user_id,change,refreshReason,pj_id)
            rd.insert(sql)
        self.write({'status':1})

class ProjectWorkDtAddStage(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        user_id = self.session['user_id']
        id = self.get_argument('id')
        stage_id = self.get_argument('stage_id')
        p_start_date = self.get_argument('p_start_date')
        p_end_date = self.get_argument('p_end_date')
        addReason = self.get_argument('addReason')
        sql = """
            select code,name from pms_project_stage where id = %s
                """ % stage_id
        result = rd.select(sql)
        code = result[0]['code']
        name = result[0]['name']
        status = check_all_time(id,code,p_start_date,p_end_date)
        if status['status'] == 0:
            self.write(status)
            return
        sql = """
            insert into  pms_project_dev   (id, pms_project_id, pms_project_stage_id, p_start_date, p_end_date,is_comp)   values(seq_pms_project_dev.nextval,%s , %s, to_date('%s','yyyy-mm-dd'), to_date('%s','yyyy-mm-dd'),0) 
            """ % (id,stage_id,p_start_date,p_end_date)
        rd.insert(sql)
        if addReason is not None and addReason != "":
            change = '新增' + name + '阶段'
            if p_start_date is not None and p_start_date != "":
                change = change + ' 预计开始时间为：' + p_start_date
            else:
                change = change + ' 预计开始时间为空'
            if p_end_date is not None and p_end_date != "":
                change = change + '，预计结束时间为：' + p_end_date
            else:
                change = change + '，预计结束时间为空'
            sql = """
                insert into pms_plan_change_mes values(seq_pms_plan_change_mes.nextval,%s,sysdate,'%s','%s',%s)
                    """ % (user_id,change,addReason,id)
            rd.insert(sql)
        self.write({'status':1})


class ProjectWorkDtDelDev(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        user_id = self.session['user_id']
        dev_id = self.get_argument('dev_id')
        deleteReason = self.get_argument('deleteReason')
        result = rd.select("select pps.name,ppd.pms_project_id from pms_project_dev ppd left join pms_project_stage pps \
            on pps.id = ppd.pms_project_stage_id where ppd.id = %s"%dev_id)
        name = result[0]['name']
        pj_id = result[0]['pms_project_id']
        sql = """
            delete from pms_project_dev_child_user ppdcu
        where ppdcu.id in (
        select ppdcu.id from pms_project_dev_child_user ppdcu
        left join pms_project_dev_child ppdc on ppdc.id = ppdcu.DEV_CHILD_ID
        where ppdc.pms_project_dev_id = %s)
                """ % dev_id
        rd.own_excute(sql)
        rd.own_excute("delete from pms_project_dev_child where pms_project_dev_id = %s"%dev_id)
        rd.own_excute("delete from pms_project_dev_user where dev_id = %s"%dev_id)
        rd.own_excute("delete from pms_project_dev where id = %s"%dev_id)
        if deleteReason is not None and deleteReason != "":
            change = '删除' + name + '阶段'
            sql = """
                insert into pms_plan_change_mes values(seq_pms_plan_change_mes.nextval,%s,sysdate,'%s','%s',%s)
                    """ % (user_id,change,deleteReason,pj_id)
            rd.insert(sql)
        self.write({'status':1})


class ProjectStatusChange(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        sql = """
           select count(ppd.id) ct from pms_project_dev ppd
        where ppd.pms_project_id = %s and (p_end_date is  null or p_start_date is null)
                """ % id
        result = rd.select(sql)
        if result[0]['ct'] != 0:
            self.write({'status':0,'msg':'存在阶段未计划时间，请为所有阶段分配好时间再启动项目'})
            return
        else:
            sql = """
                update pms_project set status = (
            select id from pms_pro_status pps where pps.name = '已开始' and type = '1') where id = %s 
                    """ % id
            rd.update(sql)
            self.write({'status':1})


def check_all_time(pj_id,code,p_start_date,p_end_date):
    status = {'status':1} 
    if p_end_date is not None and p_end_date != "":
        sql = """
                select count(distinct ppd.id) ct from pms_project_dev ppd
            left join pms_project_stage pps on pps.id = ppd.pms_project_stage_id
            where ppd.pms_project_id = %s and ((pps.code < '%s' and ppd.p_end_date > to_date('%s','yyyy-mm-dd'))
            or (pps.code > '%s' and ppd.p_end_date < to_date('%s','yyyy-mm-dd')))
                """ % (pj_id,code,p_end_date,code,p_end_date)
        result = rd.select(sql)
        if result[0]['ct'] != 0:
            status['status'] = 0
            status['msg'] = '计划结束时间小于其前面阶段的预计结束时间或大于其后面阶段的预计结束时间'
    return status


class GetChangeInfosHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        sql = """
                select pu.name user_name,ppcm.change,ppcm.mes,to_char(ppcm.time,'yyyy-mm-dd HH24:mi:ss') time from pms_plan_change_mes ppcm
            left join pms_user pu on pu.id = ppcm.USER_ID
            where ppcm.project_id = %s order by ppcm.time desc
                """ % id
        result = rd.select(sql)
        self.write(json.dumps(result))
