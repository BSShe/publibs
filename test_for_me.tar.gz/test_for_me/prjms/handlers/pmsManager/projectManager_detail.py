# -*- coding: utf-8 -*-

import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts



class projectDetail2Handler(BaseHandler):
    #页面跳转到详情页
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        page = self.get_argument('page')
        pms_sql = "select pu.name as duser,pps.name,ppd.P_START_DATE,ppd.P_END_DATE,ppd.START_DATE,ppd.END_DATE,ppd.DEV_NUMBER,ppd.WORKSDAY,ppd.IS_COMP from pms_project_dev ppd left join pms_user pu on ppd.DEV_USER_ID = pu.id left join pms_project_stage pps on ppd.PMS_PROJECT_STAGE_ID = pps.id where ppd.PMS_PROJECT_ID ="+str(id)
        devStatus = rd.select(pms_sql)
        sql = "select pms_project.code as code1,pms_project.name as name1,pc.name as ht_name,pms_project.pms_number,pms_project.P_START_DATE,pms_project.P_END_DATE,pms_project.T_START_DATE,pms_project.T_END_DATE,prp1.name as risk_level,e.name as sup_name,a.name as name2,prp2.name as name9,c.name as name7, pms_project_type.name pms_project_type_name,pms_project_property.name pms_project_property_name,pms_user.name pms_user_name,b.name as name3,d.name as name4,pms_org_type.name pms_org_type_name,f.name as name8 from pms_project left join pms_user on pms_project.manager_user_id = pms_user.id left join pms_project_type on pms_project_type.id = pms_project.pms_pro_type_id left join pms_project_property on pms_project_property.id = pms_project.pms_project_property_id left join pms_organizations a on a.id = pms_project.PMS_ORG_ID left join pms_organizations b on b.id = pms_user.org_id left join pms_organizations e on e.id = pms_project.PMS_SUPP_ID left join pms_org_type on pms_org_type.id = b.type_id left join pms_status d on d.id = b.status_id and d.id = pms_user.status_id left join pms_project_dev on pms_project.pms_dev_id = pms_project_dev.id left join pms_project_stage on pms_project_dev.pms_project_stage_id = pms_project_stage.id left join pms_contract pc on pms_project.ht_code = pc.code left join pms_risk_param prp1 on pms_project.PMS_DANGOUS_LEVEL = prp1.id left join pms_pro_status c on c.id = pms_project.status left join pms_user f on f.id = pms_project.org_manager_user_id left join pms_risk_param prp2 on pms_project.pms_level = prp2.id where pms_project.id ="+str(id)
        data = rd.select(sql)
        print(data)
        dev = rd.select("select pps.name from pms_project pp left join pms_project_dev ppd on pp.PMS_DEV_ID = ppd.id left join pms_project_stage pps on ppd.PMS_PROJECT_STAGE_ID = pps.ID where pp.id ="+str(id)+"order by pps.id asc")
        check = '项目详情'
        self.render('pmsManager/pms_index_detail2.html',check = check,page = page,data = data,dev_data = devStatus,dev = dev[0]['name'])
