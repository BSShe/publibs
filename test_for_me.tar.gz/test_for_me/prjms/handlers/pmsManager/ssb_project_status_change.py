import tornado.web
import database.readdb as rd
from database.models import db_Session
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts
from handlers.py_add.projectStageFinish import makeComment

class stopTheProjectHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        user_id = self.session['user_id']
        pid = self.get_argument("pid")
        stopReason = self.get_argument('stopReason')
        rd.update("update pms_project set status = (select id from pms_pro_status where name = '已关闭' and type = 1) where id = "+pid+" or father = "+pid)
        sql = """
                insert into pms_plan_change_mes values(seq_pms_plan_change_mes.nextval,%s,sysdate,'%s','%s',%s)
                    """ % (user_id,'关闭项目',stopReason,pid)
        rd.insert(sql)
        sql = """select is_child,father from pms_project where id = %s""" % pid
        pro = rd.select(sql)
        if pro[0]['is_child'] == 1:
            sql = """
               select count(pj.id) ct from pms_project pj left join pms_pro_status pps on pps.id = pj.status where (pps.name != '已完成' and 
                pps.name != '已关闭' or pps.name is null) and pj.father = %s
                    """ % pro[0]['father']
            unfinish_child = rd.select(sql)
            if unfinish_child[0]['ct'] == 0:
                sql = """select count(ppd.id) ct from pms_project_dev ppd where ppd.pms_project_id = %s and ppd.is_comp = 0""" % pro[0]['father']
                father_dev = rd.select(sql)
                if father_dev[0]['ct'] == 0: #父项目的阶段全部完成
                    sql = """update pms_project set t_end_date = to_char(sysdate,'yyyy-mm-dd HH:mi:ss'),status = (select id from pms_pro_status where name = '已完成' and type = 1) where pms_project.id = %s""" % pro[0]['father']
                    rd.update(sql)
                    makeComment(pro[0]['father'])
        status = 'success'
        self.write(status)


class getStopProjectInfo(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        sql = """
                select pu.name user_name,ppcm.mes,to_char(ppcm.time,'yyyy-mm-dd HH24:mi:ss') time from pms_plan_change_mes ppcm
            left join pms_user pu on pu.id = ppcm.USER_ID
            where ppcm.project_id = %s and ppcm.change = '%s' order by ppcm.time desc
                """ % (id,'关闭项目')
        result = rd.select(sql)
        self.write(json.dumps(result))
