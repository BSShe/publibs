import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts
#系统查询和项目工作报告数据填充
class getPmsProjectSelectHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        userno = tornado.escape.xhtml_escape(self.current_user)
        user_infos = rd.select('select * from pms_user where no = \'%s\'' %userno)
        org = user_infos[0]["org_id"]

        pno = self.get_argument("projectNo","")
        pname = self.get_argument("projectId")
        supId = self.get_argument("supId")
        orgId = self.get_argument("orgId")
        userId = self.get_argument("userId")
        orguserId = self.get_argument("orguserId")
        contractCode = self.get_argument("contractCode","")
        status = self.get_argument("statusId")

        user_id = self.session['user_id']
        sql = getProjectListSql(user_id,org,'All') 
        
        if pno != None and pno != "":
            sql += ("and pp.code like '%"+str(pno)+"%'")
        if pname != None and pname != "":
            sql += ("and pp.name like '%"+str(pname)+"%'")
        if supId != None and supId != "":
            sql += ("and pp.PMS_SUPP_ID ="+str(supId))
        if orgId != None and orgId != "":
            sql += ("and pp.PMS_ORG_ID ="+str(orgId))
        if userId != None and userId != "":
            sql += (" and pp.MANAGER_USER_ID in ("+str(userId)+")")
        if orguserId != None and orguserId != "":
            sql += (" and pp.ORG_MANAGER_USER_ID in ("+str(orguserId)+")")
        if contractCode != None and contractCode != "":
            sql += ("and pp.ht_code ='"+str(contractCode)+"'")
        if status != None and status != "":
            sql += ("and pp.status ="+str(status))
        
        sql += " order by pp.id desc"

        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_pro,pms_pro_count = rd.select_limit_with_count(sql,pageSize ,curPage)

        self.write({'total': pms_pro_count, 'data': pms_pro});

#type指管理员是否能看见全部项目   "All"表示系统管理员能看所有项目
def getProjectListSql(user_id,org,type):
    role_sql = """select pr.name name,pu.name pu_name from pms_role pr left join pms_user_role pur on pr.id = pur.role_id left join pms_user pu on pu.id = pur.user_id where pu.id = %s """%user_id
    user_roles = rd.select(role_sql)

    sql = "select distinct(pp.id) as pid,pp.code as pcode,pp.name as pname,u2.name as puser,u3.name as org_user,pps.name as sname,ppst.name as statusname,psdc2.name as PMS_LEVEL,psdc.name as danger_level,pc.name as ht_name,po1.name as org_name,po2.name as sup_name from pms_project pp left join pms_project_dev ppd on ppd.PMS_PROJECT_ID = pp.id left join pms_project_dev_child ppdc on ppdc.PMS_PROJECT_DEV_ID = ppd.id left join pms_project_dev_child_user ppdcu on ppdcu.DEV_CHILD_ID = ppdc.ID left join pms_pro_status ppst on pp.STATUS = ppst.ID left join pms_project_dev ppd2 on pp.PMS_DEV_ID = ppd2.id left join pms_project_stage pps on pps.ID = ppd2.PMS_PROJECT_STAGE_ID left join pms_user pu on pu.id = ppd2.DEV_USER_ID left join pms_user u2 on u2.id = pp.MANAGER_USER_ID left join pms_user u3 on u3.id = pp.ORG_MANAGER_USER_ID left join pms_risk_param psdc on pp.PMS_DANGOUS_LEVEL = psdc.id left join pms_risk_param psdc2 on pp.PMS_LEVEL = psdc2.id left join PMS_CONTRACT pc on pp.ht_code = pc.code left join PMS_ORGANIZATIONS po1 on pp.PMS_ORG_ID = po1.id left join PMS_ORGANIZATIONS po2 on pp.PMS_SUPP_ID = po2.id where (pp.MANAGER_USER_ID = "+str(user_id)+" or pp.ORG_MANAGER_USER_ID = "+str(user_id)+" or ppd.DEV_USER_ID = "+str(user_id)+" or ppdcu.USER_ID = "+str(user_id)+") and pp.id is not null "
    for i in user_roles:
        if i['name'] == '项目总监' or i['name'] == '机构管理员':
            sql = "select pp.id as pid,pp.code as pcode,pp.name as pname,pu.name as puser,pps.name as sname,ppst.name as statusname,psdc2.name as PMS_LEVEL,psdc.name as danger_level,pc.name as ht_name,po1.name as org_name,pu2.name as org_user,po2.name as sup_name from pms_project pp left join pms_user pu on pp.MANAGER_USER_ID = pu.id left join pms_project_dev ppd on pp.PMS_DEV_ID = ppd.id left join pms_project_stage pps on ppd.PMS_PROJECT_STAGE_ID = pps.id left join pms_pro_status ppst on pp.STATUS = ppst.ID left join pms_risk_param psdc on pp.PMS_DANGOUS_LEVEL = psdc.id left join pms_risk_param psdc2 on pp.PMS_LEVEL = psdc2.id left join PMS_CONTRACT pc on pp.ht_code = pc.code left join PMS_ORGANIZATIONS po1 on pp.PMS_ORG_ID = po1.id left join PMS_ORGANIZATIONS po2 on pp.PMS_SUPP_ID = po2.id left join pms_user pu2 on pu2.id = pp.ORG_MANAGER_USER_ID where (pp.PMS_ORG_ID = "+str(org)+" or pp.PMS_SUPP_ID = "+str(org)+") "
            break
        if i['name'] == '系统管理员' and type == 'All':
            sql = "select pp.id as pid,pp.code as pcode,pp.name as pname,pu.name as puser,pps.name as sname,ppst.name as statusname,psdc2.name as PMS_LEVEL,psdc.name as danger_level,pc.name as ht_name,po1.name as org_name,pu2.name as org_user,po2.name as sup_name from pms_project pp left join pms_user pu on pp.MANAGER_USER_ID = pu.id left join pms_project_dev ppd on pp.PMS_DEV_ID = ppd.id left join pms_project_stage pps on ppd.PMS_PROJECT_STAGE_ID = pps.id left join pms_pro_status ppst on pp.STATUS = ppst.ID left join pms_risk_param psdc on pp.PMS_DANGOUS_LEVEL = psdc.id left join pms_risk_param psdc2 on pp.PMS_LEVEL = psdc2.id left join PMS_CONTRACT pc on pp.ht_code = pc.code left join PMS_ORGANIZATIONS po1 on pp.PMS_ORG_ID = po1.id left join PMS_ORGANIZATIONS po2 on pp.PMS_SUPP_ID = po2.id left join pms_user pu2 on pu2.id = pp.ORG_MANAGER_USER_ID where pp.id is not null "
            break
    return sql

def getPro_ingListSql(user_id,type):
    role_sql = """select pr.name name,pu.name pu_name from pms_role pr left join pms_user_role pur on pr.id = pur.role_id left join pms_user pu on pu.id = pur.user_id where pu.id = %s """%user_id
    user_roles = rd.select(role_sql)
    sql = "select pp.name as pname,to_char(ppd.start_date,'yyyy-mm-dd hh24:mi:ss') as start_date,to_char(ppd.p_end_date,'yyyy-mm-dd hh24:mi:ss') as p_end_date,pps.name as sname from pms_project pp left join pms_project_dev ppd on pp.PMS_DEV_ID = ppd.id left join pms_project_stage pps on pps.id = ppd.PMS_PROJECT_STAGE_ID where (pp.is_child != 1 or pp.is_child is null ) and (pp.status !=5 and pp.status !=14)"
    is_all = 0
    if type == 'All':
        for i in user_roles:
            if i['name'] == '系统管理员':
                is_all = 1
                break
    if is_all == 0:
        sql += " and (ppd.id in (select ppdc.PMS_PROJECT_DEV_ID from pms_project_dev_child ppdc left join pms_project_dev_child_user ppdcu on ppdc.id = ppdcu.DEV_CHILD_ID where ppdcu.USER_ID = %s) or ppd.DEV_USER_ID = %s or pp.MANAGER_USER_ID = %s or pp.ORG_MANAGER_USER_ID = %s"%(user_id,user_id,user_id,user_id)
        for i in user_roles:
            if i['name'] == '项目总监' or i['name'] == '机构管理员':
                sql += ' or (pp.pms_org_id =(select org_id from pms_user where id = %s) or pp.pms_supp_id = (select org_id from pms_user where id = %s)) '%(user_id,user_id)
                break
        sql += ')'
    return sql
