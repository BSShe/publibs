import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts
#项目日志提交
class manageLogHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        userno = tornado.escape.xhtml_escape(self.current_user)
        user_infos = rd.select('select * from pms_user where no = \'%s\'' %userno)
        id = user_infos[0]["id"]
        logData = json.loads(self.get_argument('data'))
        logData['userId'] = id
        test = "success"
        print("-----------logData：-----------")
        print(logData)
        sql = """insert into PMS_WORK_DAY_MES values(seq_PMS_WORK_DAY_MES.nextval,'%s',sysdate,%s,%s,'%s')"""%(logData['text'],logData['userId'],logData['projectId'],logData['title'])
        rd.insert(sql)
        self.write(test)
#获取日志
class getLogDetailsForWatchHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        sql = "select a.con,to_char(a.WORK_DATE,'yyyy-mm-dd HH24:mi:ss') as wdate,a.title from pms_work_day_mes a where ID ="+str(id)
        logs = rd.select(sql)
        self.write({'data':logs[0]})

class logPageHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        proId = self.get_argument('proId')
        sql = "select a.con,to_char(a.WORK_DATE,'yyyy-mm-dd HH24:mi:ss') as wdate,b.name as send_user,b.id as userid from pms_work_day_mes a left join pms_user b on a.PMS_USER_ID = b.id where PMS_PROJECT_ID ="+str(proId)+"order by a.work_date desc"
        logs = json.dumps(rd.select(sql))
        self.write(logs)
#日志主页跳转
class getmanageWorkLogListHandler(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        userno = tornado.escape.xhtml_escape(self.current_user)
        user_infos = rd.select('select * from pms_user where no = \'%s\'' %userno)
        org = user_infos[0]["org_id"]
        userId = user_infos[0]["id"]
        page = self.get_argument("page",1)

        #pms_station = rd.select('select * from pms_organizations ')
        pms_statusList = rd.select('select * from pms_pro_status where type = 1')
        orgList = rd.select("select po.* from PMS_ORGANIZATIONS po left join PMS_ORG_TYPE pot on po.TYPE_ID = pot.ID where pot.NAME <> '外包机'")
        supList=rd.select("select po.* from PMS_ORGANIZATIONS po left join PMS_ORG_TYPE pot on po.TYPE_ID = pot.ID where pot.NAME = '外包机构'")
        userList = rd.select("select * from PMS_user")
        orguserList = rd.select("select pu.* from PMS_user pu left join PMS_ORGANIZATIONS po on pu.org_id = po.id left join PMS_ORG_TYPE pot on po.TYPE_ID = pot.ID where pot.NAME <> '外包机构'")

        self.render('pmsManager/ssb_pms_plan_work_log.html',
            page = page,
            userId = userId,
            supList = supList,
            orgList = orgList,
            userList = userList,
            orguserList = orguserList,
            statusList = pms_statusList)
#日志详细界面跳转与数据填充    
class getLogDetailsHandler(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        userno = tornado.escape.xhtml_escape(self.current_user)
        user_infos = rd.select('select * from pms_user where no = \'%s\'' %userno)
        userId = user_infos[0]["id"]
        pid = self.get_argument("pid")
        page = self.get_argument("page")
        if getRole(userId)==0:
            userList = rd.select("select distinct(b.id),b.name from pms_work_day_mes a left join pms_user b on a.PMS_USER_ID = b.id where PMS_PROJECT_ID ="+str(pid))
        else:
            userList = rd.select("select id,name from pms_user where id =" +str(userId))
        self.render("pmsManager/ssb_pms_plan_log.html",pid = pid,userList = userList,page = page)

    @tornado.web.authenticated
    def post(self):
        userno = tornado.escape.xhtml_escape(self.current_user)
        user_infos = rd.select('select * from pms_user where no = \'%s\'' %userno)
        user_id = user_infos[0]["id"]

        proId = self.get_argument('pid')
        userId = self.get_argument('userId')
        logDate = self.get_argument('logDate')
        logTitle = self.get_argument('logTitle')

        if getRole(user_id)==0:
            sql = "select c.name as pname,a.id,a.title,to_char(a.WORK_DATE,'yyyy-mm-dd HH24:mi:ss') as wdate,b.name as send_user,b.id as userid from pms_work_day_mes a left join pms_user b on a.PMS_USER_ID = b.id left join pms_project c on c.id = a.PMS_PROJECT_ID where a.PMS_PROJECT_ID ="+str(proId)
        else:
            sql = "select c.name as pname,a.id,a.title,to_char(a.WORK_DATE,'yyyy-mm-dd HH24:mi:ss') as wdate,b.name as send_user,b.id as userid from pms_work_day_mes a left join pms_user b on a.PMS_USER_ID = b.id left join pms_project c on c.id = a.PMS_PROJECT_ID where a.PMS_PROJECT_ID ="+str(proId)+" and b.id = "+str(user_id) 

        if userId != None and userId != "":
            sql += (" and b.id = "+str(userId))
        if logDate != None and logDate != "":
            sql += (" and substr(a.WORK_DATE,0,10) = to_date('"+str(logDate)+"','yyyy-mm-dd')")
        if logTitle != None and logTitle != "":
            sql += (" and a.title like '%"+str(logTitle)+"%'")

        sql += " order by a.work_date desc"
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_pro,pms_pro_count = rd.select_limit_with_count(sql,pageSize ,curPage)

        self.write({'total': pms_pro_count, 'data': pms_pro});

def getRole(userId):
    role_sql = """select pr.name name,pu.name pu_name from pms_role pr left join pms_user_role pur on pr.id = pur.role_id left join pms_user pu on pu.id = pur.user_id where pu.id = %s """%userId
    user_roles = rd.select(role_sql)    
    for i in user_roles:
        if i['name'] == "项目经理" or i['name'] == '项目总监' or i['name'] == '机构管理员' or i['name'] == '系统管理员':    
            return 0
        return 1 
