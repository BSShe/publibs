# -*- coding: utf-8 -*-

import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts
import os
import time
from handlers.py_add.onlineUser import userList
from handlers.py_add.projectStageFinish import finishProjectStage
from handlers.py_add.fileOperation import upload,downlaodFile,checkTemplate,downloadTemplate,deleteFile
from handlers.open import change_file

class projectChildFaildHandler(BaseHandler):
    #打开开发实现界面
    @tornado.web.authenticated
    def post(self):
        #在界面出寻找对应的子阶段与文件上传按钮是否由存在权限，如果有权限则返回存在的按钮
        id=self.get_argument("id")
        page = self.get_argument("page")
        type = self.get_argument("type")
        user_id = self.session['user_id']
        dev_id = self.get_argument('dev_id')
        all_dev_child = rd.select("select ppsc.name,ppsc.code,ppdc.id dev_child_id,pps.code stage_code,pps.name stage_name from pms_project_stage_child ppsc left join pms_project_stage pps on ppsc.pms_project_stage_id = pps.id inner join pms_project_dev_child ppdc on ppdc.pms_project_stage_child_id = ppsc.id where ppdc.PMS_PROJECT_DEV_ID = %s"%dev_id)
        print ('all_dev_child:')
        print (all_dev_child)
        #此处进行操作权限判定
        (dev_child_role_edit,dev_child_role_watch,is_finsh_role)  = dev_child_roles(user_id,dev_id,id)
        #将得到的结果进行过滤掉对应的查看权限 
        child_data = []
        for i in all_dev_child:
            if i['dev_child_id'] in dev_child_role_watch:
                child_data.append(i)
        print ('dev_child:')
        print (child_data)         
        for i in child_data:
            dev_child_id = i['dev_child_id']
            data = rd.select("select message3 from pms_project_dev_report where to_char(message1) = '%s'"%dev_child_id)
            if len(data) >0:
                i['data'] = data[0]['message3']
            else:
                i['data'] = ''
        sql = """
                select ppsd.PROJECT_STAGE_CODE,ppsd.code,ppsd.name from pms_project_dev ppd
                join pms_project_stage pps on pps.id = ppd.PMS_PROJECT_STAGE_ID
                join pms_project_stage_doc ppsd on ppsd.project_stage_code = pps.code
                where ppd.id = %s
                """ % dev_id
        #sql = """
        #        select ppsd.PROJECT_STAGE_CODE,ppsd.code,ppsd.name from pms_project_stage_file ppsf join 
        #        pms_project_stage_doc ppsd on ppsd.ID = ppsf.STAGE_DOC_ID where ppsf.DEV_ID = %s order by ppsd.code
        #        """ % dev_id
        files_page =rd.select(sql)
        for i in range(len(files_page)):
            sql = "select * from pms_file_upload where dev_id = "+dev_id+"and PMS_PROJECT_STAGE_CODE ="+str(files_page[i]['project_stage_code'])+"and code ="+str(files_page[i]['code'])+" order by id desc"
            result = rd.select(sql)
            files_page[i]['files'] = result
        print('child_data:')
        print (child_data)
        self.render("pmsManager/html_add/pms_template.html",dev_id = dev_id,child_data = child_data,id=id,page=page,type = type,
                                                          files_page=files_page,dev_child_role_edit=dev_child_role_edit,
                                                          dev_child_role_watch =dev_child_role_watch,is_finsh_role=is_finsh_role
                                                           )


#权限判断函数
#返回值：dev_child_role_edit 该用户在当前进度可以操作的所有子任务id
#返回值：dev_child_role_watch该用户再当前进度可以查看的所有子任务id
#返回值：is_finsh_role 该用户是否允许结束当前进度的权限 0 为允许 1为不允许
#参数：user_id用户id,dev_id项目进度编号,id项目编号
def dev_child_roles(user_id,dev_id,id):
    project_data = rd.select('select * from pms_project where id = %s'%id)
    result_edit = rd.select("select ppdc.id from pms_project_dev_child_user ppdcu left join pms_project_dev_child ppdc on ppdc.id = ppdcu.dev_child_id left join pms_project_dev ppd on ppdc.pms_project_dev_id = ppd.id left join pms_project pp on pp.pms_dev_id = ppd.id  where ppdc.pms_project_dev_id = %s and ppdcu.user_id = %s  "%(dev_id,user_id))
    dev_child_role_edit = []
    is_finsh_role = 1
    for i in result_edit:
        dev_child_role_edit.append(i['id'])
    #如果用户是系统管理员或者该项目的管理员或者该进度的负责人则都可以查看该进度的全部子任务
    project_result= rd.select("select * from pms_project where id =%s"%id)
    roles = rd.select("select code from pms_user_role pur left join pms_role pr on pur.role_id = pr.id where pur.user_id = %s  "%user_id)
    all_dev_child = rd.select('select id from pms_project_dev_child where pms_project_dev_id = %s'%dev_id)
    dev_result = rd.select('select dev_user_id,is_comp from pms_project_dev where id = %s'%dev_id)
    dev_child_role_watch = []
    for i in roles:
        print ('pms_dev_id:%s'%project_result[0]['pms_dev_id'])
        print ('dev_id:%s'%dev_id)
        if str(dev_result[0]['dev_user_id'])==str(user_id) and str(project_result[0]['pms_dev_id']) == str(dev_id) and project_result[0]['status'] !=5 and dev_result[0]['is_comp'] !=1 :
            is_finsh_role = 0
            print ('is_finsh_role:%s'%is_finsh_role)
        if i['code'] =='01' or i['code']=='03' or project_result[0]['org_manager_user_id']==user_id or project_result[0]['manager_user_id'] == user_id or dev_result[0]['dev_user_id'] == user_id:
            print ('all_dev_child:%s'%all_dev_child)
            for j in all_dev_child:
                if j['id'] not in dev_child_role_watch:
                    dev_child_role_watch.append(j['id'])
    #如果用户不是以上关系户,则用户能查看的仅仅是自己能操作的所有子任务的id
    if len(dev_child_role_watch) == 0 :
        dev_child_role_watch = dev_child_role_edit 
    return (dev_child_role_edit,dev_child_role_watch,is_finsh_role)



class projectChildFieldFileUploadHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        fileInfo=upload(self)
        self.write(fileInfo)


class projectChildFieldFileDownloadHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        downlaodFile(self)

class ProjectChildCheckTemplateHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        checkTemplate(self)

class ProjectChildTemplateDownloadHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        downloadTemplate(self)



class ProjectChildFaildSubmitHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        dev_child_id = self.get_argument("dev_child_id")
        dev_id = self.get_argument('dev_id')
        data = self.get_argument("data")
        type = self.get_argument('type')
        old = rd.select("select * from pms_project_dev_report where dev_id = %s and to_char(message1) = '%s' and to_char(message2) = '%s'"%(dev_id,dev_child_id,type))
        if len(old) > 0 :
            sql = "update pms_project_dev_report set message3= ('%s') where dev_id = %s and to_char(message1) = '%s' and to_char(message2) = '%s' "%(data,dev_id,dev_child_id,type)
            rd.update(sql)
        else:        
            sql = "insert into pms_project_dev_report (id,dev_id,message1,message2,message3) values (seq_pms_project_dev_report.nextval,%s,'%s','%s','%s')"%(dev_id,dev_child_id,type,data)
            rd.insert(sql)
        self.write({'success':'true','msg':'提交成功!'})




class ProjectFinishDevelopHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        dev_id = self.get_argument("dev_id")
        checkTime = self.get_argument("checkTime")
        stage_name = rd.select('select name from pms_project_dev ppd left join pms_project_stage pps on ppd.pms_project_stage_id = pps.id where ppd.id = %s'%dev_id)[0]['name']
        id = rd.select('select pms_project_id from pms_project_dev where id = %s '%dev_id)[0]['pms_project_id']
        user_id = self.session['user_id']
        status = finishProjectStage(id,stage_name,user_id,json.loads(checkTime),dev_id)
        self.write(status)

class ProjectDeleteFileHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        deleteFile(self)

class ProjectPreviewFileHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        url = self.get_argument('url')
        is_ok = change_file(url)
        if is_ok == 0 or is_ok == 1:
            url = "error.html"
        else:
            url = "../"+is_ok
        print(url)
        self.render(url)

class CheckPlanTimeHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        dev_id = self.get_argument('dev_id')
        sql = """
            select ppd.p_start_date,ppd.p_end_date from pms_project_dev ppd
            where ppd.id = %s
                """ % dev_id
        result = rd.select(sql)
        status = []
        if result[0]['p_start_date'] is None:
            status.append('p_start_date')
        if result[0]['p_end_date'] is None:
            status.append('p_end_date')
        self.write(json.dumps(status))
