import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts

class projectCommesHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        pid = self.get_argument('pid')
        sql = "select pp.name as proname,pu.name as username,to_char(ppc.WORK_DATE,'yyyy-mm-dd HH24:MI:SS') as workdate,ppc.con as con from pms_project_commes ppc left join pms_user pu on ppc.PMS_USER_ID = pu.id left join pms_project pp on ppc.PMS_PROJECT_ID = pp.id where ppc.PMS_PROJECT_ID ="+str(pid)+'order by ppc.WORK_DATE desc'
        commes = rd.select(sql)
        commes = json.dumps(commes)
        self.write(commes)

class saveProjectCommesHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        pid = self.get_argument('pid')
        uid = self.get_argument('uid')
        con = self.get_argument('con')
        sql = """insert into pms_project_commes(id,CON,WORK_DATE,PMS_PROJECT_ID,PMS_USER_ID) values(seq_pms_project_commes.nextval,'%s',sysdate,%s,%s)"""%(con,pid,uid)
        rd.insert(sql)
        success = {'status':"success"}
        self.write(success)

