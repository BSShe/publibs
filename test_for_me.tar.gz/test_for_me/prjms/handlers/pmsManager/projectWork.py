# -*- coding: utf-8 -*-

import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts

class projectWorkListHandler(BaseHandler):
    #打开项目计划功能列表
    #展示对应的项目，选择项目的内容对应的计划与安排。
    #项目安排期间不再项目团队显示内容，
    #安排之后在团队内显示对应的阶段与控制，并在项目安排期间将项目的工作任务与内容安排进去
    #设置项目计划并将项目计划显示在对应的界面上
    @tornado.web.authenticated
    def get(self):
        pms_statusList = rd.select('select * from pms_pro_status where type = 1')
        pms_orgList = rd.select('select * from pms_organizations')
        pms_ptryList = rd.select('select * from pms_project_property')
        pms_htList = rd.select('select * from pms_project_type') 
        pms_manaUserList = rd.select('select * from pms_user')#此处需要加入查询条件管理员
        pms_ptyList = rd.select('select * from pms_project_type')
        pms_pmsPro = rd.select('select * from pms_project_stage')
        
        self.render('pmsManager/pms_work_index.html',
                     statusList = pms_statusList,
                     orgList = pms_orgList,manaUserList = pms_manaUserList,
                     ptyList = pms_ptyList,ptryList = pms_ptryList,
                     htList = pms_htList,pmPro = pms_pmsPro
        )
   
    #获取项目计划功能列表
    @tornado.web.authenticated
    def post(self):
        name = self.get_argument('search_name')
        project_name =self.get_argument('search_pro_name')
        project_code = self.get_argument('search_project_code')
        org_id = self.get_argument('search_org_id')
        status_id = self.get_argument('search_status_id')
        sql = """
        select pj.id,pj.code,pj.name,pj.p_start_date,pj.p_end_date,pj.pms_level,pj.pms_dangous_level,pu.name as pms_project_dev_user,pps.name as pms_project_stage_name, pj.status as status        from pms_project pj        left join pms_project_dev ppd on ppd.id = pj.pms_dev_id        left join pms_user pu on pu.id = ppd.dev_user_id        left join pms_project_stage pps on pps.id = ppd.pms_project_stage_id where (pj.is_child != 1 or pj.is_child is null)
              """
        
        #此处需要加入更多的查询条件
        if name is not None  and  name != "":
            sql += " and pu.name like '%" + name + "%'"
        
        #sql_status = "select * from pms_status where code = 'delete'"
        #status_delete = rd.select(sql_status)[0]['id']
        #sql += " and pj.status != '%s'" % status_delete
        #sql += " order by pj.id "
        sql = " select * from pms_project pj left join pms_project_dev ppd on ppd.id = pj.pms_dev_id where (pj.is_child != 1 or pj.is_child is null)"
        sql2 = " select count(*) from pms_project pj left join pms_project_dev ppd on ppd.id = pj.pms_dev_id where (pj.is_child != 1 or pj.is_child is null)"
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_user,pms_user_count = rd.select_limit_with_count(sql, pageSize, curPage)
        self.write({'total': pms_user_count, 'data': pms_user})


def plansetting():
    return 


class datapage(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        self.writ({'':''})
class projectDelHandler(BaseHandler):
    #删除项目计划
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        sql = "update pms_user set status_id = 'delete' where id = '" + id + "'"
        rd.update(sql)
        self.write({'result': 'true'})

class projectBfUpdateHandler(BaseHandler):
    #修改信息前,回显必要信息
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        sql = "select * from pms_user  where id = '" + id + "'"
        data = rd.select(sql)
        self.write(data[0])

class projectToUpdateHandler(BaseHandler):
    #修改信息
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        rd.updatebyDict('pms_user',requestBy_dict)
        self.write({'result': 'true'})

class projectToAddHandler(BaseHandler):
    #新增data
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        #将项目周期单独拿出来，需要创建对应的项目阶段，然后加入对应的项目列表
        result = rd.insertbyDict('pms_project',requestBy_dict)
        pro = create_pms_project_stage(requestBy_dict) 
        update_pms_project(requestBy_dict,pro)
        self.write({'result': 'true'})

def update_pms_project(requestBy_dict,pro):
    code = requestBy_dict.get('code')
    pro_stage = rd.select("select * from pms_project_dev where pms_project_stage_id in (select id from pms_project_stage where code ='01') and pms_project_id= %s"%(pro[0]['id']))
    sql = """update pms_project set pms_dev_id = %s,t_start_date = to_date('%s','yyyy-mm-dd HH24:MI:ss') where id = %s """%(pro_stage[0]['id'],pro_stage[0]['start_date'],pro[0]['id'])
    rd.update(sql)
    return


def create_pms_project_stage(requestBy_dict):
    code = requestBy_dict.get('code')
    pro = rd.select('select * from pms_project where code = '+code)
    stage = rd.select("select * from pms_project_stage where code = '01'")
    sql ="""insert into pms_project_dev (id,pms_project_id,dev_user_id,pms_project_stage_id,p_start_date,p_end_date,start_date,is_comp) values(seq_pms_project_dev.nextval,%s,%s,%s,to_date('%s','yyyy-mm-dd'),to_date('%s','yyyy-mm-dd'),to_date('%s','yyyy-mm-dd'),'%s')"""%(pro[0]['id'],pro[0]['manager_user_id'],stage[0]['id'],pro[0]['p_start_date'],pro[0]['p_end_date'],pro[0]['p_start_date'],'0')
    rd.insert(sql)
    sql2 ="""insert into pms_project_dev_user (id,dev_id,user_id) values(seq_pms_project_dev.nextval,%s,%s)"""%(pro[0]['id'],pro[0]['manager_user_id'])
    rd.insert(sql)
    return pro

class projectProListHandler(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        self.render('supplierManager/estimate-org-userList.html')
    @tornado.web.authenticated
    def post(self):
        org_id = self.get_argument('org_id')
        sql = """select pu.id, pu.no, pu.name, pu.phone_no, pos.name as org_name, pss.name as status_name 
                from pms_user pu
                join pms_organizations pos on pu.org_id = pos.id
                join pms_status pss on pu.status_id = pss.id
                where pu.org_id = '%s'""" %org_id
        sql += " order by pu.id "
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_user,pms_user_count = rd.select_limit_with_count(sql,pageSize ,curPage)
        self.write({'total': pms_user_count, 'data': pms_user}) 

class projectPlanDetailHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        plan_sql = """select * from pms_project_plan where plan_code = %s"""%id
        all_plan_sql = """select * from pms_project_stage"""
        plan = rd.select(plan_sql)
        all_plan= rd.select(all_plan_sql)
        print (all_plan)
        self.render('pmsManager/pms_work_index_detail.html',plan=plan,all_plan=all_plan,pms_id = id)


class projectProPlanDataHandler(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        self.render('pmsManager/end-of-date.html')
    @tornado.web.authenticated
    def post(self):
        org_id = self.get_argument('org_id')
        sql = """
              select  di.id from pms_differ di 
              join pms_user pu 
              join pms_organizations pos on pu.org_id = pos.id
              where pu.org_id = '%s'
              """%org_id
        pageSize = int(self.get_argument('limit'))
        curPage = int(self.get_argument('page'))
        pms_user_pms_user_cout = rd.select_limit_with_count(sql,pageSize,curPage)
        self.write({'total':pms_user_count,'data':pms_user})


class projectProPlanDetailHandler(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        self.render('pmsManager/pms_pro_plan_detail.html')
    @tornado.web.authenticated
    def post(self):
        pro_id = self.get_argument('pro_id')
        user_id = self.get_argument('user_id')
        property_sql = """select * from pms_project_property""" 
        plan_sql = """select * from pms_project_dev where pms_project_id = %s"""%pro_id
        #此处将值传递回前台
        pro_data = rd.select(property_sql)
        plan_data = rd.select(plan_sql)
        self.write({'plan_data':plan_data,'pro_data':pro_data})

class projectProPlanDetailSettingHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        pro_id = self.get_argument('pro_id')
        user_id = self.get_argument('user_id')
        pro_detail_id = self.get_argument('pro_detail_id')
        sql = """
              select * from pms_project_dev where pms_project_id = %s
              """%pro_detail_id
         
