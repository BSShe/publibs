# -*- coding: utf-8 -*-

import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts
import time
from datetime import datetime,timedelta

#自动评分函数
#传入已完成的dev编号
def comment_audit(dev_id):
    dev = rd.select("select * from pms_project_dev where id = %s"%dev_id)
    code = 100
    if len(dev)> 0 :
        if dev[0]['is_comp'] == 1 :
            end_date = dev[0]['end_date']
            p_end_date = dev[0]['p_end_date']
            role_date = end_date - p_end_date 
            print ('end_date:%s'%end_date)
            print ('p_end_date:%s'%p_end_date)
            print ('role_date:%s'%role_date)
            p_start_date = dev[0]['p_start_date']
            print ('p_start_date:%s'%p_start_date)
            p_con_date = p_end_date - p_start_date
            print ('p_con_date:%s'%p_con_date)
            con_date = end_date - p_start_date
            print ('con_date:%s'%con_date)
            p_con_day = (str(p_con_date).split('day'))[0]
            print ('p_con_day:%s'%p_con_day)
            con_day = (str(con_date).split('day'))[0]
            print ('con_day:%s'%con_day)
            days = (str(role_date).split('day'))[0]
            print('days:%s'%days) 
            #此处进行存入评价数据
            if len(str(role_date).split('day')) > 1 : 
                code_more =  (((float(p_con_day)/float(con_day))-1)*100)
                num_25 = rd.select("select * from pms_project_evaluate where code ='12' ")[0]['score']
                num_10 = rd.select("select * from pms_project_evaluate where code ='11' ")[0]['score']
                if code_more >= 25:
                    code = 100 - int(num_25)
                elif code_more >= 10:
                    code = 100 - int(num_10)
            else:
                code = 100
            type = rd.select('select pps.code from pms_project_dev ppd left join pms_project_stage pps on ppd.pms_project_stage_id = pps.id where ppd.id = %s'%dev_id)[0]['code']
            sql = "insert into pms_project_dev_comment (id,pms_project_dev_id,code,type) values (seq_pms_project_dev_comment.nextval,%s,%s,'%s')"%(dev_id,code,type)
            rd.insert(sql)
    return

#返回项目总评分
#参数
#project_id:项目编号
#返回值
#code:项目总进度评分
#pro_mes_code:项目质量总平均评分
#pro_code:项目总评分
def comment_sub(project_id):
    project = rd.select('select * from pms_project where id = %s'%project_id)[0]
    all_comment = rd.select('select * from pms_project_dev_comment ppdc left join pms_project_dev ppd on ppd.id =ppdc.pms_project_dev_id  where ppd.pms_project_id = %s '%project_id)
    code = 0
    #查询出所有的阶段权重函数，做一个评分占比然后根据对应的阶段评分与占比来进行计算出进度总评分
    all_num = 0
    for i in all_comment:
        print ('type:%s'%i['type'])
        score = rd.select("select * from pms_project_evaluate where code='%s'"%i['type'] )[0]['score']
        all_num+=float(score)
    #查询出所有的阶段权重与质量权重，做一个评分占比然后根据对应的评分占比计算总评分
    for i in all_comment:
        score = rd.select("select * from pms_project_evaluate where code='%s'"%i['type'] )[0]['score']
        if i['mes_code']:
            code += float(i['mes_code']) *(float(score)/all_num)
        else:
            code +=float(i['code'])*(float(score)/all_num)
    all_pro_comment = rd.select("select * from pms_project_comment_detail where pms_project_id = %s"%project_id)
    all_pro_num = 0
    pro_mes_code = 0
    for i in all_pro_comment :
        score = rd.select("select * from pms_project_evaluate where code='%s'"%i['type'] )[0]['score']
        all_pro_num += float(score)
    for i in all_pro_comment:
        score = rd.select("select * from pms_project_evaluate where code='%s'"%i['type'] )[0]['score']
        pro_mes_code +=float(i['code'])*(float(score)/all_pro_num)
    #算总评分
    sub_num =  all_pro_num + all_num   
    pro_code = 0
    for i in all_comment:
        score = rd.select("select * from pms_project_evaluate where code='%s'"%i['type'] )[0]['score']
        if i['mes_code']:
            pro_code += float(i['mes_code']) *(float(score)/sub_num)
        else:
            score = rd.select("select * from pms_project_evaluate where code='%s'"%i['type'] )[0]['score']
            pro_code += float(i['code']) *(float(score)/sub_num)
    for i in all_pro_comment :
        score = rd.select("select * from pms_project_evaluate where code='%s'"%i['type'] )[0]['score']
        if i['code']:
            pro_code +=float(i['code'])*(float(score)/sub_num)
    return (code,pro_code,pro_mes_code)

#手动评价函数
#参数
#type:评价类型编号，请对应到评价类型表的code
#project_id:项目编号
#score:评分
#discus:说明
#user_id:用户编号
def comment_edit(type,project_id,user_id,score,discus):
    rd.insert("insert into pms_project_detail (id,pms_project_id,comment_user_id,code_id,discu,type) values(seq_pms_project_detail.nextval,%s,%s,%s,%s)"%(project_id,user_id,score,discus,type))
    return true 



class projectCommentListHandler(BaseHandler):
    #打开项目管理评论功能列表
    @tornado.web.authenticated
    def get(self):
        page = self.get_argument("page",1)
        pms_statusList = rd.select('select * from pms_pro_status where type = 1')
        pms_orgList = rd.select('select * from pms_organizations')
        self.render('pmsManager/pms_index_comment.html',
                     statusList = pms_statusList,
                     orgList = pms_orgList,
                     page = page
        )
   
    #获取项目管理评价功能列表
    @tornado.web.authenticated
    def post(self):
        name = self.get_argument('search_name')
        project_name =self.get_argument('search_pro_name')
        project_code = self.get_argument('search_project_code')
        org_id = self.get_argument('search_org_id')
        status_id = self.get_argument('search_status_id')
        
        #此处展示评价数据
        sql = """select pj.id as id,pj.code,pj.name,pu.name as pms_project_user,ppst.name as statusname from pms_project pj left join pms_project_comment ppc on ppc.pms_project_id = pj.id left join pms_user pu on pu.id = pj.manager_user_id left join pms_pro_status ppst on ppst.id = pj.status where ppst.name = '已完成' and (pj.is_child != 1 or pj.is_child is null)"""
        #此处需要加入更多的查询条件
        if name is not None  and  name != "":
            sql += " and pu.name like '%" + name + "%'"
        if project_name is not None  and  project_name != "":
            sql += " and pj.name like '%" + project_name + "%'"
        if project_code is not None and project_code != "":
            sql += " and pj.code = '%s'"%project_code
        if org_id is not None and org_id != '':
            sql += " and pj.pms_org_id = %s"%org_id
        if status_id is not None and status_id !='':
            sql += " and pj.status = '%s'"%status_id

        print(sql)
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_user,pms_user_count = rd.select_limit_with_count(sql, pageSize, curPage)
        print (pms_user)
        for i in pms_user:
            (code,pro_code,pro_mes_code) = comment_sub(i['id'])
            i['mes_code'] = code#阶段总评分
            i['pro_code'] = pro_code#总评分
            i['pro_mes_code'] = pro_mes_code#质量总评分
        self.write({'total': pms_user_count, 'data': pms_user})
   

class projectCommentBfUpdateHandler(BaseHandler):
    #修改信息前,回显必要信息
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        sql = "select * from pms_user  where id = '" + id + "'"
        data = rd.select(sql)
        self.write(data[0])

class projectCommentToAddHandler(BaseHandler):
    #新增评价
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('pms_project_id')
        userId = self.get_argument('comment_user_id') 
        discu = self.get_argument('discu')
        code = self.get_argument('code')
        type = self.get_argument('type')
        comment_type = ['01-项目方案评价','02-项目文档评价','03-项目上线评价','04-项目运行质量评价']
        for i in comment_type:
            if type in i:
                type = i.split("-")[0]
                break

        sql = "select * from pms_project_comment_detail where pms_project_id ="+str(id)+" and type = '"+str(type)+"'"
        is_Have = rd.select(sql)
        if len(is_Have):
            sql = """update pms_project_comment_detail set comment_user_id = %s,discu = '%s',code = %s where id = %s"""%(userId,discu,code,is_Have[0]['id'])
            rd.update(sql)
        else:
            sql = """insert into  pms_project_comment_detail   (id, comment_user_id, pms_project_id, code, type, discu)   values(seq_pms_project_comment_detail.nextval, %s, %s, %s, '%s','%s')"""%(userId,id,code,type,discu)
            rd.insert(sql)

        sql = "select a.PMS_PROJECT_ID as pid,a.type,a.DISCU,a.CODE,b.name as username from PMS_PROJECT_COMMENT_DETAIL a left join pms_user b on a.COMMENT_USER_ID = b.id where PMS_PROJECT_ID ="+str(id)
        result = rd.select(sql)
        for i in range(len(result)):
            for j in comment_type:
                if result[i]['type'] == j.split("-")[0]:
                    result[i]['name2'] = j.split("-")[1]
                    break
            
        result = json.dumps(result)
        self.write(result)



class projectCommentToUpdateHandler(BaseHandler):
    #更新评价操作
    @tornado.web.authenticated
    def post(self):
        pcid = self.get_argument('pcid')
        code = self.get_argument('code')
        rd.update("update pms_project_dev_comment set mes_code = "+str(code)+" where id = "+str(pcid))
        self.write({'result':'true'})


class projectCommentUpdateMessage(BaseHandler):
    #返回对应的信息
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('pms_project_dev_comment_id')
        data = rd.select("select * from pms_project_dev_comment where id =%s"%id)
        self.write({'result':'true','data':data})

class projectCommentProListHandler(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        self.render('supplierManager/estimate-org-userList.html')
    @tornado.web.authenticated
    def post(self):
        org_id = self.get_argument('org_id')
        sql = """select pu.id, pu.no, pu.name, pu.phone_no, pos.name as org_name, pss.name as status_name 
                from pms_user pu
                join pms_organizations pos on pu.org_id = pos.id
                join pms_status pss on pu.status_id = pss.id
                where pu.org_id = '%s'""" %org_id
        sql += " order by pu.id "
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_user,pms_user_count = rd.select_limit_with_count(sql,pageSize ,curPage)
        
        self.write({'total': pms_user_count, 'data': pms_user}) 


class projectCommentHandler(BaseHandler):
    #页面跳转到质量评价详情页
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        user_id = self.session['user_id']
        page = self.get_argument("page",1)
        type = self.get_argument('type')
        url = ''
        if type == '1':
            url = 'pmsManager/pms_index_comment_detail.html'
            comment_sql = "select ppe.NAME,ppcd.type,ppcd.code,ppcd.discu,pu.name user_name,ppcd.id from pms_project_comment_detail ppcd left join pms_project pp on pp.id = ppcd.pms_project_id left join pms_user pu on pu.id = ppcd.comment_user_id left join pms_project_evaluate ppe on ppcd.type = ppe.CODE where pp.id = %s "%id
            comment_detail = rd.select(comment_sql)
            comment_type = ['01-项目方案评价','02-项目文档评价','03-项目上线评价','04-项目运行质量评价']
            for i in range(len(comment_detail)):
                for j in comment_type:
                    if comment_detail[i]['type'] in j:
                        comment_detail[i]['name'] = j.split("-")[1]
                        comment_type.remove(j)
                        break
                    
            self.render(url,comment_detail = comment_detail,comment_type=comment_type,project_id=id,userId = user_id,page = page)
        elif type == '2':
            url = 'pmsManager/pms_index_comment2_detail.html'
            comment_sql = "select ppdc.id as pcid,pps.name stage_name,pu.name user_name,ppd.p_start_date,ppd.p_end_date,ppd.start_date,ppd.end_date,ppdc.CODE,ppdc.mes_code from pms_project_dev_comment ppdc left join pms_project_dev ppd on ppdc.pms_project_dev_id =ppd.id left join pms_project pp on ppd.pms_project_id = pp.id left join pms_project_stage pps on ppd.pms_project_stage_id = pps.id left join pms_user pu on pu.id = ppd.dev_user_id where pp.id = %s "%id
            comment = rd.select(comment_sql)
            self.render(url,comment = comment,project_id=id,userId = user_id,page = page)

