# -*- coding: utf-8 -*-

import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts

class estimateListHandler(BaseHandler):
    #打开供应商评价管理界面
    @tornado.web.authenticated
    def get(self):
        #pms_station = rd.select('select * from pms_organizations ')
        pms_statusList = rd.select('select * from pms_status where code like \'org%\'')
        pms_orgList = rd.select('select * from pms_org_type')
        self.render('supplierManager/estimate-manager.html', statusList = pms_statusList, orgTypeList = pms_orgList)
    #获取列表
    @tornado.web.authenticated
    def post(self):
        code = self.get_argument('code')
        name = self.get_argument('name')
        status_id = self.get_argument('status_id')
        type_id = self.get_argument('type_id')
        sql = """select pos.id , pos.code, pos.name, pos.st_date, pss.name as status, pot.name as type from pms_organizations pos
                 left join pms_status pss on pos.status_id = pss.id
                 left join pms_org_type pot on pot.id = pos.type_id
                 where 1=1 """
        if code is not None  and  code != "":
            sql += " and pos.code like '%" + code + "%'"
        if name is not None  and  name != "":
            sql += " and pos.name like '%" + name + "%'"
        if status_id is not None  and  status_id != "":
            sql += " and pos.status_id = '" + status_id + "'"
        if type_id is not None  and  type_id != "":
            sql += " and pos.type_id = '" + type_id + "'"

        sql_status = "select * from pms_status where code = 'delete'"
        status_delete = rd.select(sql_status)[0]['id']
        sql += " and pos.status_id != '%s'" % status_delete
        sql += " order by pos.id "
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_user,pms_user_count = rd.select_limit_with_count(sql, pageSize, curPage)

        self.write({'total': pms_user_count, 'data': pms_user})

class estimateDelHandler(BaseHandler):
    #删除信息
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        sql = "update pms_organizations set status_id = 'delete' where id = '" + id + "'"
        rd.update(sql)
        self.write({'result': 'true'})

class estimateBfUpdateHandler(BaseHandler):
    #修改信息前,回显必要信息
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        sql = "select * from pms_organizations  where id = '" + id + "'"
        data = rd.select(sql)
        self.write(data[0])

class estimateToUpdateHandler(BaseHandler):
    #修改信息
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        rd.updatebyDict('pms_organizations',requestBy_dict)
        self.write({'result': 'true'})

class estimateToAddHandler(BaseHandler):
    #新增信息
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        rd.insertbyDict('pms_organizations',requestBy_dict)
        self.write({'result': 'true'})

class estimateUserListHandler(BaseHandler):
    #
    @tornado.web.authenticated
    def get(self):
        self.render('supplierManager/estimate-org-userList.html')
    @tornado.web.authenticated
    def post(self):
        org_id = self.get_argument('org_id')
        sql = """select pu.id, pu.no, pu.name, pu.phone_no, pos.name as org_name, psn.name as station_name, pss.name as status_name 
                from pms_user pu
                join pms_organizations pos on pu.org_id = pos.id
                join pms_station psn on pu.station_id = psn.id
                join pms_status pss on pu.status_id = pss.id
                where pu.org_id = '%s'""" %org_id
        sql += " order by pu.id "
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_user,pms_user_count = rd.select_limit_with_count(sql,pageSize ,curPage)

        self.write({'total': pms_user_count, 'data': pms_user}) 
