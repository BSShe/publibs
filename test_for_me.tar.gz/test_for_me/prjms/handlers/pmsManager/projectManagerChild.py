# -*- coding: utf-8 -*-

import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts

class projectChildListHandler(BaseHandler):
    #打开子项目计划列表
    @tornado.web.authenticated
    def get(self):
        pms_statusList = rd.select('select * from pms_status where code like \'user%\'')
        pms_orgList = rd.select('select * from pms_organizations')
        pms_ptryList = rd.select('select * from pms_project_property')
        pms_htList = rd.select('select * from pms_project_type') 
        pms_manaUserList = rd.select('select * from pms_user')#此处需要加入查询条件管理员
        pms_ptyList = rd.select('select * from pms_project_type')
        pms_pmsPro = rd.select('select * from pms_project_stage')
        pms_supp = rd.select('select * from pms_user')
        
        self.render('pmsManager/pms_plan_index.html',
                     statusList = pms_statusList,
                     orgList = pms_orgList,manaUserList = pms_manaUserList,
                     ptyList = pms_ptyList,ptryList = pms_ptryList,
                     htList = pms_htList,pmPro = pms_pmsPro,suppList = pms_supp
        )
   
    #获取子项目计划功能列表
    @tornado.web.authenticated
    def post(self):
        name = self.get_argument('search_name')
        project_name =self.get_argument('search_pro_name')
        project_code = self.get_argument('search_project_code')
        org_id = self.get_argument('search_org_id')
        status_id = self.get_argument('search_status_id')
        sql = """
        select pl.id,pj.code, from pms_project_plan
        select pj.id,pj.code,pj.name,pj.p_start_date,pj.p_end_date,pj.pms_level,pj.pms_dangous_level,pu.name as pms_project_dev_user,pps.name as pms_project_stage_name, pj.status as status        from pms_project pj        left join pms_project_dev ppd on ppd.id = pj.pms_dev_id        left join pms_user pu on pu.id = ppd.dev_user_id        left join pms_project_stage pps on pps.id = ppd.pms_project_stage_id where 1=1
              """
        #此处需要加入更多的查询条件
        if name is not None  and  name != "":
            sql += " and pu.name like '%" + name + "%'"

        #sql_status = "select * from pms_status where code = 'delete'"
        #status_delete = rd.select(sql_status)[0]['id']
        #sql += " and pj.status != '%s'" % status_delete
        #sql += " order by pj.id "


        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_user,pms_user_count = rd.select_limit_with_count(sql, pageSize, curPage)
        self.write({'total': pms_user_count, 'data': pms_user})


   
class projectChildDelHandler(BaseHandler):
    #删除项目计划
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        sql = "update pms_user set status_id = 'delete' where id = '" + id + "'"
        rd.update(sql)
        self.write({'result': 'true'})

class projectChildUpdateHandler(BaseHandler):
    #修改信息前,回显必要信息
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        sql = "select * from pms_user  where id = '" + id + "'"
        data = rd.select(sql)
        self.write(data[0])

class projectChildToUpdateHandler(BaseHandler):
    #修改信息
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        rd.updatebyDict('pms_user',requestBy_dict)
        self.write({'result': 'true'})

class projectChildAddHandler(BaseHandler):
    #制定项目进度计划与工作任务量
    @tornado.web.authenticated
    def post(self):
        pass

class projectChildToAddHandler(BaseHandler):
    #分配项目阶段与人员
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        #将项目周期单独拿出来，需要创建对应的项目阶段，然后加入对应的项目列表
        result = rd.insertbyDict('pms_project',requestBy_dict)
        pro = create_pms_project_stage(requestBy_dict) 
        update_pms_project(requestBy_dict,pro)
        self.write({'result': 'true'})

def update_pms_project(requestBy_dict,pro):
    code = requestBy_dict.get('code')
    pro_stage = rd.select("select * from pms_project_dev where pms_project_stage_id in (select id from pms_project_stage where code ='01') and pms_project_id= %s"%(pro[0]['id']))
    sql = """update pms_project set pms_dev_id = %s,t_start_date = to_date('%s','yyyy-mm-dd HH24:MI:ss') where id = %s """%(pro_stage[0]['id'],pro_stage[0]['start_date'],pro[0]['id'])
    rd.update(sql)
    return

def create_pms_project_stage(requestBy_dict):
    code = requestBy_dict.get('code')
    pro = rd.select('select * from pms_project where code = '+code)
    stage = rd.select("select * from pms_project_stage where code = '01'")
    sql ="""insert into pms_project_dev (id,pms_project_id,dev_user_id,pms_project_stage_id,p_start_date,p_end_date,start_date,is_comp) values(seq_pms_project_dev.nextval,%s,%s,%s,to_date('%s','yyyy-mm-dd'),to_date('%s','yyyy-mm-dd'),to_date('%s','yyyy-mm-dd'),'%s')"""%(pro[0]['id'],pro[0]['manager_user_id'],stage[0]['id'],pro[0]['p_start_date'],pro[0]['p_end_date'],pro[0]['p_start_date'],'0')
    rd.insert(sql)
    sql2 ="""insert into pms_project_dev_user (id,dev_id,user_id) values(seq_pms_project_dev.nextval,%s,%s)"""%(pro[0]['id'],pro[0]['manager_user_id'])
    rd.insert(sql)
    return pro

class projectChildProListHandler(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        self.render('supplierManager/estimate-org-userList.html')
    @tornado.web.authenticated
    def post(self):
         
        org_id = self.get_argument('org_id')
        sql = """select pu.id, pu.no, pu.name, pu.phone_no, pos.name as org_name, pss.name as status_name 
                from pms_user pu
                join pms_organizations pos on pu.org_id = pos.id
                join pms_status pss on pu.status_id = pss.id
                where pu.org_id = '%s'""" %org_id
        sql += " order by pu.id "
        
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_user,pms_user_count = rd.select_limit_with_count(sql,pageSize ,curPage)

        self.write({'total': pms_user_count, 'data': pms_user}) 
