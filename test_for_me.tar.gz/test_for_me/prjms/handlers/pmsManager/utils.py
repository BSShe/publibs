import json
import time
import datetime
import xlwt

#results:查询结果以[('','',''),('','','')]格式传入
#fileds:column[(u'发票号码',),(u'原始本金',),(u'活期余额',),(u'定期余额',),(u'定期利息',),(u'活期利息',),(u'开始日期',),(u'结束日期',)]类似
#outputpath:传出地址
#table_ch_name:文件名
#导出export函数
#返回值：文件写入的地址
def export(results,fields,outputpath,table_ch_name=u'无',tradition=['20171025','20171025']):
    workbook = xlwt.Workbook()
    if len(results)>65000:
        num = (len(results)/65000)+2
        for i in range(1,num) :
            sheet = workbook.add_sheet('sheet'+str(i),cell_overwrite_ok = False)
            sheet.write(0,len(fields)/2,table_ch_name)
            for field in range(0,len(fields)):
                code = fields[field][0]
                sheet.write(2,field,code)
            row = 1
            col = 0
            if len(results)/(i*65000)>0:
                start = (i-1)*65000
                end = i*65000
            else :
                start = (i-1)*65000
                end = len(results)
            for row in range(1,end+1-start):
                for col in range(0,len(fields)):
                    sheet.write(row+2,col,u'%s'%results[row-1+start][col])
    else:
        sheet = workbook.add_sheet('sheet',cell_overwrite_ok = False)
        sheet.write(0,len(fields)/2,table_ch_name)
        for field in range(0,len(fields)):
            code = fields[field][0]
            sheet.write(2,field,code)
        row = 1
        col = 0
        for row in range(1,len(results)+1):
            for col in range(0,len(fields)):
                sheet.write(row+2,col,u'%s'%results[row-1][col])
    outputpath = outputpath+table_ch_name+get_serach_time()+'.xls'
    workbook.save(outputpath)
    return (outputpath)
