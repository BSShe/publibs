# -*- coding: utf-8 -*-

import tornado.web
import database.readdb as rd
from handlers.handler import BaseHandler
import tornado.template as template
from config import config
import json
import  handlers.utils  as hts

class projectListHandler(BaseHandler):
    #打开项目管理功能列表
    @tornado.web.authenticated
    def get(self):
        user_id = self.session['user_id']
        page = self.get_argument('page',1)
        pms_statusList = rd.select('select * from pms_pro_status where type = 1')
        pms_orgList = rd.select('select * from pms_organizations')
        pms_ptryList = rd.select('select * from pms_project_property')
        pms_htList = rd.select('select * from pms_contract') 
        pms_riskList = rd.select("select id,name,doc from pms_risk_param where type = '风险等级' order by code")
        pms_manaUserList = rd.select('select pu.id,pu.name from pms_user pu inner join PMS_USER_ROLE pur on  pu.id = pur.user_id where pur.role_id = 3')#此处需要加入查询条件管理员
        pms_ptyList = rd.select('select * from pms_project_type')
        pms_pmsPro = rd.select("select * from pms_project_stage where code != '01' ")
        pms_pj_priority = rd.select("select id,name,doc from pms_risk_param where type = '项目优先等级' order by code")
        pms_org_role = rd.select('select * from pms_org_role')
        pms_role = rd.select('select * from pms_role')
        create_project_role = checkCreateRole(user_id,'项目综合管理','创建项目(按钮)')
        create_child_role = checkCreateRole(user_id,'项目综合管理','创建子项目(按钮)')
        close_project_role = checkCreateRole(user_id,'项目综合管理','关闭项目(按钮)')
        work_plan_role = checkCreateRole(user_id,'项目综合管理','项目计划制定(按钮)')
        work_plan_imp_role = checkCreateRole(user_id,'项目综合管理','项目计划变更(按钮)')
        for i in pms_pmsPro:
            i['child'] = rd.select("select * from pms_project_stage_child where pms_project_stage_id =%s"%i['id'])            
        #供应商查询
        pms_supp = rd.select('select po.id,po.name from PMS_SUPPLIER_QUALIFICATION psq left join pms_organizations po on po.id = psq.pms_organizations_id')
        self.render('pmsManager/pms_index.html',
                     page = page,
                     statusList = pms_statusList,
                     orgList = pms_orgList,manaUserList = pms_manaUserList,
                     ptyList = pms_ptyList,ptryList = pms_ptryList,
                     pj_priority = pms_pj_priority,
                     org_role = pms_org_role,role = pms_role,
                     create_project_role = create_project_role,
                     create_child_role = create_child_role,
                     close_project_role = close_project_role,
                     work_plan_role = work_plan_role,
                     work_plan_imp_role = work_plan_imp_role,
                     htList = pms_htList,pmsPro = pms_pmsPro,suppList = pms_supp,riskList = pms_riskList
        )
   
    #获取子项目管理功能列表
    @tornado.web.authenticated
    def post(self):
        name = self.get_argument('search_name')
        project_name =self.get_argument('search_pro_name')
        project_code = self.get_argument('search_project_code')
        org_id = self.get_argument('search_org_id')
        status_id = self.get_argument('search_status_id')
        user_id = self.session['user_id']
        role_sql = """select pr.name name,pu.name pu_name from pms_role pr left join pms_user_role pur on pr.id = pur.role_id left join pms_user pu on pu.id = pur.user_id where pu.id = %s """%user_id
        user_roles = rd.select(role_sql)
        sql_s = 'or ppd.id in (select ppdc.pms_project_dev_id dev_id from pms_project_dev_child_user ppdcu left join pms_project_dev_child ppdc on ppdc.id = ppdcu.dev_child_id  where ppdcu.user_id = %s) '%user_id
        for i in user_roles:
            if i['name'] == "项目经理":
                sql_s += 'or (pp.org_manager_user_id = %s or pp.manager_user_id = %s) '%(user_id,user_id)
                break
        for i in user_roles:
            if i['name'] == '项目总监' or i['name'] == '机构管理员':
                sql_s = 'or (pj.pms_org_id = (select org_id from pms_user where id = %s) or pj.pms_supp_id = (select org_id from pms_user where id = %s) ) '%(user_id,user_id)
                break
        for i in user_roles:
            if i['name'] == "系统管理员" :
                sql_s = ''
                break
        sql = """select ppt.name type_name,ppst.name as statusname,pj.id,pj.code,pj.name,pj.p_start_date,pj.p_end_date,psdm2.name as pms_level,psdm.name as pms_dangous_level,pu.name as pms_project_dev_user,pps.name as pms_project_stage_name, pj.status as status        from pms_project pj        left join pms_project_dev ppd on ppd.id = pj.pms_dev_id        left join pms_user pu on pu.id = ppd.dev_user_id   left join pms_project pp on pp.id = ppd.pms_project_id     left join pms_project_stage pps on pps.id = ppd.pms_project_stage_id left join pms_pro_status ppst on pj.status = ppst.id left join pms_project_type ppt on ppt.id = pj.pms_pro_type_id left join pms_risk_param psdm on pj.pms_dangous_level = psdm.id left join pms_risk_param psdm2 on pj.pms_level = psdm2.id where (pj.IS_CHILD != 1 or pj.IS_CHILD is null)"""
        sql_s = sql_s.strip('or')
        if sql_s != "":
            sql += ' and ('+sql_s+')'
        #此处需要加入更多的查询条件
        if name is not None  and  name != "":
            sql += " and pu.name like '%" + name + "%'"
        if project_name is not None  and  project_name != "":
            sql += " and pj.name like '%" + project_name + "%'"
        if project_code is not None and project_code != "":
            sql += " and pj.code = '%s'"%project_code
        if org_id is not None and org_id != '':
            sql += " and pj.pms_org_id = %s"%org_id
        if status_id is not None and status_id !='':
            sql += " and pj.status = '%s'"%status_id
        sql += " order by pj.id desc"
        #sql_status = "select * from pms_status where code = 'delete'"
        #status_delete = rd.select(sql_status)[0]['id']
        #sql += " and pj.status != '%s'" % status_delete
        #sql += " order by pj.id "
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_user,pms_user_count = rd.select_limit_with_count(sql, pageSize, curPage)
        self.write({'total': pms_user_count, 'data': pms_user})

class projectGetSuppManager(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        org_id = self.get_argument('org_id')
        data = rd.select('select * from pms_user where org_id = %s'%org_id)
        self.write({'data':data})

   
class projectDelHandler(BaseHandler):
    #删除项目数据
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        sql = "update pms_user set status_id = 'delete' where id = '" + id + "'"
        rd.update(sql)
        self.write({'result': 'true'})

class projectBfUpdateHandler(BaseHandler):
    #修改信息前,回显必要信息
    @tornado.web.authenticated
    def post(self):
        id = self.get_argument('id')
        sql = "select * from pms_user  where id = '" + id + "'"
        data = rd.select(sql)
        self.write(data[0])

class proformrule(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        account = self.get_argument('account')

class projectToUpdateHandler(BaseHandler):
    #修改信息
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        rd.updatebyDict('pms_user',requestBy_dict)
        self.write({'result': 'true'})

class projectToAddHandler(BaseHandler):
    #新增信息
    @tornado.web.authenticated
    def post(self):
        requestBy_dict = hts.requestBodyToDict(self.request.body)
        print (self.get_arguments('pro_id[]'))
        pro_ids = self.get_arguments('pro_id[]')
        #将项目周期单独拿出来，需要创建对应的项目阶段，然后加入对应的项目列表
        pms_old = rd.select("select * from pms_project where code = '%s'"%requestBy_dict['code'])
        if len(pms_old)>0:
            self.write({'result':'false','msg':'项目编号重复了'})
            return
        pms_old = rd.select("select * from pms_project where code = '%s'"%requestBy_dict['name'])
        if len(pms_old)>0:
            self.write({'result':'false','msg':'项目名重复了'})
            return
        del requestBy_dict['pro_id[]']
        print(requestBy_dict)
        if(requestBy_dict.get('father',None) is not None):
            requestBy_dict['is_child'] = 1
        result = rd.insertbyDict('pms_project',requestBy_dict)
        pro = create_pms_project_stage(requestBy_dict,pro_ids) 
        update_pms_project(requestBy_dict,pro)
        self.write({'result': 'true'})

def update_pms_project(requestBy_dict,pro):
    code = requestBy_dict.get('code')
    pro_stage = rd.select("select * from pms_project_dev where pms_project_stage_id in (select id from pms_project_stage where code ='01') and pms_project_id= %s"%(pro[0]['id']))
    sql = """update pms_project set pms_dev_id = %s,t_start_date = to_date('%s','yyyy-mm-dd HH24:MI:ss') where id = %s """%(pro_stage[0]['id'],pro_stage[0]['start_date'],pro[0]['id'])
    rd.update(sql)
    return


#创建项目阶段
def create_pms_project_stage(requestBy_dict,pro_ids):
    code = requestBy_dict.get('code')
    dev_ids = []
    dev_child_ids = []
    flag = 0
    for i in pro_ids:
        if i == '#':
            flag=1
            continue
        if flag == 0:
            dev_ids.append(i)
        else :
            k = i.split('_')
            dev_child_ids.append(k[1])
    print ('dev_ids:%s'%dev_ids)
    print ('dev_child_ids:%s'%dev_child_ids)
    pro = rd.select("select * from pms_project where code = '%s'"%code)
    print(pro)
    stage = rd.select("select * from pms_project_stage where code = '01'")
    print(stage)
    sql ="""insert into pms_project_dev (id,pms_project_id,dev_user_id,pms_project_stage_id,p_start_date,start_date,is_comp) values(seq_pms_project_dev.nextval,%s,%s,%s,to_date('%s','yyyy-mm-dd'),to_date('%s','yyyy-mm-dd'),'%s')"""%(pro[0]['id'],pro[0]['manager_user_id'],stage[0]['id'],pro[0]['p_start_date'],pro[0]['p_start_date'],'0')
    print (sql)
    rd.insert(sql)
    #添加项目任务
    for i in ['01','02','03','04']:
        dev_id = rd.select("select ppd.id,ppsc.id ppsc_id from pms_project_stage_child  ppsc left join pms_project_dev ppd on ppd.PMS_PROJECT_STAGE_ID = ppsc.pms_project_stage_id where ppd.pms_project_id = %s and ppsc.code = '%s' "%(pro[0]['id'],i))
        sql3 = "insert into pms_project_dev_child (id,pms_project_stage_child_id,pms_project_dev_id) values(seq_pms_project_dev_child.nextval,%s,%s)"%(dev_id[0]['ppsc_id'],dev_id[0]['id'])
        rd.insert(sql3)
    for i in dev_ids:
        if (i!=''):
            stage_code = rd.select("select * from pms_project_stage where id = %s"%i)
            sql3 = """insert into pms_project_dev (id,pms_project_id,dev_user_id,pms_project_stage_id,is_comp,dev_number) values(seq_pms_project_dev.nextval,%s,%s,%s,%s,'%s') """%(pro[0]['id'],pro[0]['manager_user_id'],i,'0',stage_code[0]['code'])
            rd.insert(sql3)
            dev_id = rd.select('select * from pms_project_dev where pms_project_stage_id = %s'%i)[0]['id']
            #添加阶段对应文件上传任务
            sql3 = "insert into pms_project_stage_file (id,dev_id,stage_doc_id) values (seq_pms_project_stage_file.nextval,%s,(select ppd.id from pms_project_stage_doc ppsc inner join pms_project_stage pps on ppsc.PROJECT_STAGE_CODE = pps.CODE inner join pms_project_dev ppd on ppd.pms_project_stage_id = pps.id where ppd.id = %s))"%(dev_id,dev_id)
            #rd.insert(sql3)
    for i in dev_child_ids:
        if (i!=''):
            #添加项目子任务
            this_dev_id = rd.select("select ppd.id from pms_project_stage_child  ppsc left join pms_project_dev ppd on ppd.PMS_PROJECT_STAGE_ID = ppsc.pms_project_stage_id where ppd.pms_project_id = %s and ppsc.id = %s "%(pro[0]['id'],i))
            if len(this_dev_id) > 0 :
                sql3 = "insert into pms_project_dev_child (id,pms_project_stage_child_id,pms_project_dev_id) values(seq_pms_project_dev_child.nextval,%s,%s)"%(i,this_dev_id[0]['id'])
                rd.insert(sql3)
                #根据已有的项目子任务添加对应的文件上传sql
    #添加初始化的两个初始任务绑定对应的项目管理员
    rd.insert("insert into pms_project_dev_child_user (id,dev_child_id,user_id,power) values(seq_pms_project_dev_child_user.nextval,(select ppdc.id from pms_project_dev_child  ppdc left join pms_project_stage_child ppsc on ppsc.id=ppdc.pms_project_stage_child_id left join pms_project_dev ppd on ppd.id = ppdc.pms_project_dev_id left join pms_project pp on pp.id = ppd.pms_project_id where ppsc.name ='项目立项' and pp.id = %s),(select manager_user_id from pms_project where id = %s),1)"%(pro[0]['id'],pro[0]['id']) )
    rd.insert("insert into pms_project_dev_child_user (id,dev_child_id,user_id,power) values(seq_pms_project_dev_child_user.nextval,(select ppdc.id from pms_project_dev_child  ppdc left join pms_project_stage_child ppsc on ppsc.id=ppdc.pms_project_stage_child_id left join pms_project_dev ppd on ppd.id = ppdc.pms_project_dev_id left join pms_project pp on pp.id = ppd.pms_project_id  where ppsc.name ='项目立项' and pp.id =%s),(select org_manager_user_id from pms_project where id = %s),1)"%(pro[0]['id'],pro[0]['id']))
    rd.insert("insert into pms_project_dev_child_user (id,dev_child_id,user_id,power) values(seq_pms_project_dev_child_user.nextval,(select ppdc.id from pms_project_dev_child  ppdc left join pms_project_stage_child ppsc on ppsc.id=ppdc.pms_project_stage_child_id left join pms_project_dev ppd on ppd.id = ppdc.pms_project_dev_id left join pms_project pp on pp.id = ppd.pms_project_id  where ppsc.name ='项目启动' and pp.id = %s),(select org_manager_user_id from pms_project where id = %s),1)"%(pro[0]['id'],pro[0]['id']))
    rd.insert("insert into pms_project_dev_child_user (id,dev_child_id,user_id,power) values(seq_pms_project_dev_child_user.nextval,(select ppdc.id from pms_project_dev_child  ppdc left join pms_project_stage_child ppsc on ppsc.id=ppdc.pms_project_stage_child_id left join pms_project_dev ppd on ppd.id = ppdc.pms_project_dev_id left join pms_project pp on pp.id = ppd.pms_project_id where ppsc.name ='项目启动' and pp.id = %s),(select manager_user_id from pms_project where id = %s),1)"%(pro[0]['id'],pro[0]['id']))
    select_dev_id =rd.select("select * from pms_project_dev where pms_project_id = %s"%pro[0]['id'])
    sql2 ="""insert into pms_project_dev_user (id,dev_id,user_id) values(seq_pms_project_dev.nextval,%s,%s)"""%(select_dev_id[0]['id'],pro[0]['manager_user_id'])
    rd.insert(sql2)
    return pro

class projectProListHandler(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        self.render('supplierManager/estimate-org-userList.html')
    @tornado.web.authenticated
    def post(self):
        org_id = self.get_argument('org_id')
        sql = """select pu.id, pu.no, pu.name, pu.phone_no, pos.name as org_name, pss.name as status_name 
                from pms_user pu
                join pms_organizations pos on pu.org_id = pos.id
                join pms_status pss on pu.status_id = pss.id
                where pu.org_id = '%s'""" %org_id
        sql += " order by pu.id "
        pageSize = int(self.get_argument('limit'))#一页放多少条数据
        curPage = int(self.get_argument('page'))#当前第几页
        pms_user,pms_user_count = rd.select_limit_with_count(sql,pageSize ,curPage)
        
        self.write({'total': pms_user_count, 'data': pms_user}) 



def checkCreateRole(user_id,menu_name,button_name):
    sql = """
                select distinct pms_menu_button.NAME button_role from pms_user
        join pms_user_role on pms_user_role.USER_ID = pms_user.ID
        join pms_role on pms_role.ID = pms_user_role.ROLE_ID
        join pms_role_menu_button on pms_role_menu_button.ROLE_ID = pms_role.ID
        join pms_menu_button on pms_menu_button.ID = pms_role_menu_button.PMS_MENU_BUTTON_ID
        join pms_menu on pms_menu.ID = pms_menu_button.MENU_ID
        where pms_user.id = %s and pms_menu.NAME='%s' and pms_menu_button.NAME = '%s'
                """ % (user_id,menu_name,button_name)
    result = rd.select(sql)
    if len(result) == 0:
        return 0
    else:
        return 1


class ShowNextInfoHandler(BaseHandler):
    @tornado.web.authenticated
    def post(self):
        org_id = self.get_argument('org_id')
        sql = """
            select distinct pu.id,pu.name from pms_user pu
            left join pms_user_role pur on pur.USER_ID = pu.id
            left join pms_role pr on pr.ID = pur.ROLE_ID
            where pu.org_id = %s and pr.name = '项目经理'
                """ % org_id
        users = rd.select(sql)
        info = {'users':users}
        self.write(json.dumps(info))
       
