#!/bin/sh
#-----请在下方引号内填入你的SVN帐号密码-------#
svn_username="liuchuang"
svn_password="1iuchuang123"
#-----填写完成后请去除下方注释(###)----------#
svn up alembic/versions/ --username $svn_username   --password $svn_password
time=`date "+%Y%m%d_%H%M%S"`
versionResult=`alembic revision --autogenerate -m \'$time\'`
cut1=${versionResult##*/}
versionNo=${cut1%%_*}
result=`alembic upgrade $versionNo`
up_file_py=$versionNo"_"$time".py"
svn add alembic/versions/$up_file_py  
svn ci alembic/versions/$up_file_py  -m \''模型更新 alembic 版本控制提交'\'  --username $svn_username   --password $svn_password
echo "==========模型更新完成============"
