

insert into  pms_menu (id,name,url,pid) values(seq_pms_menu.nextval,'供应商管理','','');
insert into  pms_menu (id, name,url,pid) values(seq_pms_menu.nextval,'人员管理','','');
insert into  pms_menu (id,name,url,pid) values(seq_pms_menu.nextval,'项目管理','','');
insert into  pms_menu (id,name,url,pid) values(seq_pms_menu.nextval,'合同管理','','');
insert into  pms_menu (id,name,url,pid) values(seq_pms_menu.nextval,'查询与报表管理','','');
insert into  pms_menu (id,name,url,pid) values(seq_pms_menu.nextval,'参数管理','','');
insert into  pms_menu (id,name,url,pid) values(seq_pms_menu.nextval,'人员管理','/paramManage/manageUserList',(select id from pms_menu where name = '参数管理'));
insert into  pms_menu (id,name,url,pid) values(seq_pms_menu.nextval,'机构管理','/paramManage/manageOrgList',(select id from pms_menu where name = '参数管理'));
insert into  pms_menu (id,name,url,pid) values(seq_pms_menu.nextval,'系统参数管理','/paramManage/manageParamList',(select id from pms_menu where name = '参数管理'));
insert into  pms_menu (id,name,url,pid) values(seq_pms_menu.nextval,'角色权限管理','/paramManage/manageRoleList',(select id from pms_menu where name = '参数管理'));
insert into  pms_menu (id,name,url,pid) values(seq_pms_menu.nextval,'一般项目合同管理','/contractManage/manageContractList',(select id from pms_menu where name = '合同管理'));
insert into  pms_menu (id,name,url,pid) values(seq_pms_menu.nextval,'供应商资质管理','/supplierManage/manageQualifyList',(select id from pms_menu where name = '供应商管理'));
insert into  pms_menu (id,name,url,pid) values(seq_pms_menu.nextval,'供应商评价管理','/supplierManage/manageEstimateList',(select id from pms_menu where name = '供应商管理'));
insert into  pms_menu (id,name,url,pid) values(seq_pms_menu.nextval,'人员信息管理','/paramManage/manageUserList',(select id from pms_menu where name = '人员管理' and url is null));
insert into  pms_menu (id,name,url,pid) values(seq_pms_menu.nextval,'人员评价管理','/userManage/userEvaluateList',(select id from pms_menu where name = '人员管理' and url is null));
insert into  pms_menu (id,name,url,pid) values(seq_pms_menu.nextval,'人员考勤管理','/userManage/userCheckInList',(select id from pms_menu where name = '人员管理' and url is null));


insert into pms_status (id,code,name) values(seq_pms_status.nextval,'01','正常');
insert into pms_status (id,code,name) values(seq_pms_status.nextval,'02','停用');
insert into pms_status (id,code,name) values(seq_pms_status.nextval,'delete','于本系统中标为删除状态');


insert into  pms_role (id,code,name,type,STATUS_ID) values(seq_pms_role.nextval,'03','项目总监','1',(select id from pms_status where name = '正常'));
insert into  pms_role (id,code,name,type,STATUS_ID) values(seq_pms_role.nextval,'04','项目经理','1',(select id from pms_status where name = '正常'));
insert into  pms_role (id,code,name,type,STATUS_ID) values(seq_pms_role.nextval,'01','系统管理员','1',(select id from pms_status where name = '正常'));
insert into  pms_role (id,code,name,type,STATUS_ID) values(seq_pms_role.nextval,'02','机构管理员','1',(select id from pms_status where name = '正常'));
insert into  pms_role (id,code,name,type,STATUS_ID) values(seq_pms_role.nextval,'05','开发人员','1',(select id from pms_status where name = '正常'));
insert into  pms_role (id,code,name,type,STATUS_ID) values(seq_pms_role.nextval,'06','测试人员','1',(select id from pms_status where name = '正常'));
insert into  pms_role (id,code,name,type,STATUS_ID) values(seq_pms_role.nextval,'01','管理部门','2',(select id from pms_status where name = '正常'));
insert into  pms_role (id,code,name,type,STATUS_ID) values(seq_pms_role.nextval,'02','需求部门','2',(select id from pms_status where name = '正常'));
insert into  pms_role (id,code,name,type,STATUS_ID) values(seq_pms_role.nextval,'03','研发部门','2',(select id from pms_status where name = '正常'));
insert into  pms_role (id,code,name,type,STATUS_ID) values(seq_pms_role.nextval,'04','测试部门','2',(select id from pms_status where name = '正常'));
insert into  pms_role (id,code,name,type,STATUS_ID) values(seq_pms_role.nextval,'05','技术支持部门','2',(select id from pms_status where name = '正常'));


insert into pms_user_evaluate  (id,code,name,score) values(seq_pms_user_evaluate.nextval,'01','当月迟到或早退一次(应扣分值)','10');
insert into pms_user_evaluate  (id,code,name,score) values(seq_pms_user_evaluate.nextval,'02','当月迟到或早退两次(应扣分值)','30');
insert into pms_user_evaluate  (id,code,name,score) values(seq_pms_user_evaluate.nextval,'03','当月迟到或早退三次(应扣分值)','50');
insert into pms_user_evaluate  (id,code,name,score) values(seq_pms_user_evaluate.nextval,'04','当月迟到或早退三次以上(应扣分值)，或无故旷工','100');
insert into pms_user_evaluate  (id,code,name,score) values(seq_pms_user_evaluate.nextval,'05','上班时玩手机、打游戏一次(应扣分值)','10');
insert into pms_user_evaluate  (id,code,name,score) values(seq_pms_user_evaluate.nextval,'06','上班时玩手机、打游戏两次(应扣分值)','30');
insert into pms_user_evaluate  (id,code,name,score) values(seq_pms_user_evaluate.nextval,'07','上班时玩手机、打游戏三次(应扣分值)','50');
insert into pms_user_evaluate  (id,code,name,score) values(seq_pms_user_evaluate.nextval,'08','上班时玩手机、打游戏三次以上(应扣分值)','100');
insert into pms_user_evaluate  (id,code,name,score) values(seq_pms_user_evaluate.nextval,'09','泄露资料,偷窃(应扣分值)','100');
insert into pms_user_evaluate  (id,code,name,score) values(seq_pms_user_evaluate.nextval,'10','考勤评价占人员评价权重(比值)','0.5');
insert into pms_user_evaluate  (id,code,name,score) values(seq_pms_user_evaluate.nextval,'11','纪律评价占人员评价权重(比值)','0.5');

insert into  pms_org_type (id,code,name) values(seq_pms_org_type.nextval,'分行内设机构');
insert into  pms_org_type (id,code,name) values(seq_pms_org_type.nextval,'一级支行');
insert into  pms_org_type (id,code,name) values(seq_pms_org_type.nextval,'外包机构');
insert into  pms_org_type (id,code,name) values(seq_pms_org_type.nextval,'总行内设机构');

insert into  pms_param_list (id,name,map_addr,type) values(seq_pms_param_list.nextval,'机构类型信息', '/paramManage/manageParamList-org_typeList','1');
insert into  pms_param_list (id,name,map_addr,type) values(seq_pms_param_list.nextval,'状态信息', '/paramManage/manageParamList-statusList','1');
insert into  pms_param_list (id,name,map_addr,type) values(seq_pms_param_list.nextval,'相关时间设置', '/paramManage/manageParamList-timeList','1');
insert into  pms_param_list (id,name,map_addr,type) values(seq_pms_param_list.nextval,'项目类型', '/paramManage/manageParamList-project_typeList','2');
insert into  pms_param_list (id,name,map_addr,type) values(seq_pms_param_list.nextval,'项目性质', '/paramManage/manageParamList-project_propertyList','2');
insert into  pms_param_list (id,name,map_addr,type) values(seq_pms_param_list.nextval,'项目阶段', '/paramManage/manageParamList-project_stageList','2');
insert into  pms_param_list (id,name,map_addr,type) values(seq_pms_param_list.nextval,'人员评价参数设定', '/paramManage/manageParamList-user_evaluateList','3');
insert into  pms_param_list (id,name,map_addr,type) values(seq_pms_param_list.nextval,'项目评价参数设定', '/paramManage/manageParamList-project_evaluateList','3');
insert into  pms_param_list (id,name,map_addr,type) values(seq_pms_param_list.nextval,'供应商评价参数设定', '/paramManage/manageParamList-supplier_evaluateList','3');
insert into  pms_param_list (id,name,map_addr,type) values(seq_pms_param_list.nextval,'风险预警值设定', '/paramManage/manageParamList-riskWarnValueList','3');


#####----------------------------##############################################################
insert into  pms_organizations (id,code,name,status_id,st_date,type_id) values(seq_pms_organizations.nextval,'0002','运营管理部','2','20180929','8');

insert into pms_org_role (id, org_id,role_id) values(seq_pms_user_role.nextval,'2','4');

insert into  pms_user (id,no, name,password,phone_no,ORG_ID,status_id,st_date) values(seq_pms_user.nextval,'SHYS002','微信测试用户2','111111','18312341111','2','2','20180930');

insert into pms_user_role (id, user_id,role_id) values(seq_pms_user_role.nextval,'2','4');

#####----------------------------##############################################################

insert into pms_risk_warn_value  (id,code,name,score) values(seq_pms_risk_warn_value.nextval,'01','考勤月评价预警值','60');
insert into pms_risk_warn_value  (id,code,name,score) values(seq_pms_risk_warn_value.nextval,'02','工作纪律月评价预警值','60');
insert into pms_risk_warn_value  (id,code,name,score) values(seq_pms_risk_warn_value.nextval,'03','人员月评价预警值','60');
insert into pms_risk_warn_value  (id,code,name,score) values(seq_pms_risk_warn_value.nextval,'04','项目阶段预警值','60');
insert into pms_risk_warn_value  (id,code,name,score) values(seq_pms_risk_warn_value.nextval,'05','项目总体进度预警值','60');
insert into pms_risk_warn_value  (id,code,name,score) values(seq_pms_risk_warn_value.nextval,'06','项目方案评价预警值','60');
insert into pms_risk_warn_value  (id,code,name,score) values(seq_pms_risk_warn_value.nextval,'07','项目文档评价预警值','60');
insert into pms_risk_warn_value  (id,code,name,score) values(seq_pms_risk_warn_value.nextval,'08','项目上线评价预警值','60');
insert into pms_risk_warn_value  (id,code,name,score) values(seq_pms_risk_warn_value.nextval,'09','项目运行评价预警值','60');
insert into pms_risk_warn_value  (id,code,name,score) values(seq_pms_risk_warn_value.nextval,'10','项目质量总体评价预警值','60');
insert into pms_risk_warn_value  (id,code,name,score) values(seq_pms_risk_warn_value.nextval,'11','供应商评价预警值','60');


insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '供应商资质管理'),'文件列表-查看详情(按钮)','showFileListBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '供应商资质管理'),'上传资质文件(按钮)','showAddFileBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '供应商资质管理'),'修改(按钮)','updateBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '供应商资质管理'),'导出(按钮)','exportBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '供应商资质管理'),'新增供应商(按钮)','addBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '人员信息管理'),'新增人员(按钮)','addUserBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '人员信息管理'),'修改(按钮)','updateUserBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '人员信息管理'),'删除(按钮)','deleteUserBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '人员信息管理'),'重置密码(按钮)','resetUserPdBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '人员信息管理'),'导出(按钮)','exportBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '人员评价管理'),'修改(按钮)','updateBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '人员评价管理'),'导出(按钮)','exportBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '人员评价管理'),'查看图表(按钮)','showChartBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '人员考勤管理'),'打卡详情-查看详情(按钮)','showAloneUserListBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '人员考勤管理'),'导出(按钮)','exportBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '一般项目合同管理'),'新增合同(按钮)','addContractBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '一般项目合同管理'),'查看阶段详情(按钮)','showStageListBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '一般项目合同管理'),'查看特别约定事项(按钮)','showItemListBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '一般项目合同管理'),'付款情况-查看详情(按钮)','showPayCondtnListBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '一般项目合同管理'),'文档情况-查看详情(按钮)','showFileListBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '一般项目合同管理'),'添加阶段(按钮)','showAddStageBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '一般项目合同管理'),'添加特殊约定事项(按钮)','showAddItemBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '一般项目合同管理'),'添加付款信息(按钮)','showAddPayCondtnBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '一般项目合同管理'),'上传合同文件(按钮)','showAddFileBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '一般项目合同管理'),'修改合同要素(按钮)','updateContractBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '人员管理' and url is not null),'新增人员(按钮)','addUserBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '人员管理' and url is not null),'修改(按钮)','updateUserBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '人员管理' and url is not null),'删除(按钮)','deleteUserBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '人员管理' and url is not null),'导出(按钮)','exportBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '机构管理' ),'新增机构(按钮)','addOrgBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '机构管理' ),'查看人员(按钮)','showOrgUserBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '机构管理' ),'修改(按钮)','updateOrgBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '机构管理' ),'删除(按钮)','deleteOrgBtId');
insert into pms_menu_button (id, menu_id, name, HTML_BUTTON_ID) values(seq_pms_menu_button.nextval,(select id from pms_menu where name = '机构管理' ),'导出(按钮)','exportBtId');


insert into pms_project_property (id,code,name,remark) values(seq_pms_project_property.nextval, '01','银行自行项目','银行自行项目');
insert into pms_project_property (id,code,name,remark) values(seq_pms_project_property.nextval, '02','外包项目','外包项目');
insert into pms_project_property (id,code,name,remark) values(seq_pms_project_property.nextval, '03','混合项目','指银行与外商供应商合作开发的项目');


insert into pms_project_type (id,code,name,remark) values(seq_pms_project_type.nextval, '01','软件开发项目','软件开发项目');
insert into pms_project_type (id,code,name,remark) values(seq_pms_project_type.nextval, '02','设备采购项目','设备采购项目');
insert into pms_project_type (id,code,name,remark) values(seq_pms_project_type.nextval, '03','系统维护项目','系统维护项目');
insert into pms_project_type (id,code,name,remark) values(seq_pms_project_type.nextval, '04','人月服务项目','人月服务项目');
insert into pms_project_type (id,code,name,remark) values(seq_pms_project_type.nextval, '05','混合型项目','指可能同时包含多个项目类型的项目，如同时包括设备采购、软件开发、系统维护的项目');

insert into pms_project_stage (id,code,name,remark) values(seq_pms_project_stage.nextval, '01','项目准备','包括项目立项、项目启动、项目资源、网络与设备；提供相应阶段文档包括：项目立项单、项目组人员名单、设备清单等；');
insert into pms_project_stage (id,code,name,remark) values(seq_pms_project_stage.nextval, '02','需求确定','包括需求分析、需求确定；提供阶段文档为需求说明书；');
insert into pms_project_stage (id,code,name,remark) values(seq_pms_project_stage.nextval, '03','方案设计','包括项目概要设计、系统架构设计、接口规划、数据库设计等；提供项目阶段文档为设计说明书；');
insert into pms_project_stage (id,code,name,remark) values(seq_pms_project_stage.nextval, '04','开发实现','包括程序设计、单元测试；提供阶段文档为测试通知书；');
insert into pms_project_stage (id,code,name,remark) values(seq_pms_project_stage.nextval, '05','项目测试','包括环境准备、业务测试；提供阶段文档为测试报告；');
insert into pms_project_stage (id,code,name,remark) values(seq_pms_project_stage.nextval, '06','上线准备','包括上线审批、代码整理；提供阶段文档为上线审批单');
insert into pms_project_stage (id,code,name,remark) values(seq_pms_project_stage.nextval, '07','上线','生产环境进行上线部署；提供阶段文档为上线手册；');
insert into pms_project_stage (id,code,name,remark) values(seq_pms_project_stage.nextval, '08','上线验证','生产对上线项目进行验证；提供阶段文档为验证报告；');
insert into pms_project_stage (id,code,name,remark) values(seq_pms_project_stage.nextval, '09','项目验收','对已上线项目进行项目验收；提供阶段文档为验收报告、用户手册（操作手册）');
insert into pms_project_stage (id,code,name,remark) values(seq_pms_project_stage.nextval, '10','项目维护','项目后续维护；提供阶段文档为项目维护报告。');


insert into pms_project_stage_doc (id,PROJECT_STAGE_CODE,CODE,NAME,URL) values(seq_pms_project_stage_doc.nextval,'01','01','项目立项单','');
insert into pms_project_stage_doc (id,PROJECT_STAGE_CODE,CODE,NAME,URL) values(seq_pms_project_stage_doc.nextval,'01','02','项目组人员名单','');
insert into pms_project_stage_doc (id,PROJECT_STAGE_CODE,CODE,NAME,URL) values(seq_pms_project_stage_doc.nextval,'01','03','设备清单','');
insert into pms_project_stage_doc (id,PROJECT_STAGE_CODE,CODE,NAME,URL) values(seq_pms_project_stage_doc.nextval,'02','01','需求说明书','');
insert into pms_project_stage_doc (id,PROJECT_STAGE_CODE,CODE,NAME,URL) values(seq_pms_project_stage_doc.nextval,'03','01','设计说明书','');
insert into pms_project_stage_doc (id,PROJECT_STAGE_CODE,CODE,NAME,URL) values(seq_pms_project_stage_doc.nextval,'04','01','测试通知书','');
insert into pms_project_stage_doc (id,PROJECT_STAGE_CODE,CODE,NAME,URL) values(seq_pms_project_stage_doc.nextval,'05','01','测试报告','');
insert into pms_project_stage_doc (id,PROJECT_STAGE_CODE,CODE,NAME,URL) values(seq_pms_project_stage_doc.nextval,'06','01','上线审批单','');
insert into pms_project_stage_doc (id,PROJECT_STAGE_CODE,CODE,NAME,URL) values(seq_pms_project_stage_doc.nextval,'07','01','上线手册','');
insert into pms_project_stage_doc (id,PROJECT_STAGE_CODE,CODE,NAME,URL) values(seq_pms_project_stage_doc.nextval,'08','01','验证报告','');
insert into pms_project_stage_doc (id,PROJECT_STAGE_CODE,CODE,NAME,URL) values(seq_pms_project_stage_doc.nextval,'09','01','验收报告','');
insert into pms_project_stage_doc (id,PROJECT_STAGE_CODE,CODE,NAME,URL) values(seq_pms_project_stage_doc.nextval,'09','02','用户手册（操作手册）','');
insert into pms_project_stage_doc (id,PROJECT_STAGE_CODE,CODE,NAME,URL) values(seq_pms_project_stage_doc.nextval,'10','01','项目维护报告','');


insert into pms_project_evaluate  (id,code,name,score) values(pms_project_evaluate.nextval,'01','项目准备权重(比值)','0.1');
insert into pms_project_evaluate  (id,code,name,score) values(pms_project_evaluate.nextval,'02','需求确定权重(比值)','0.1');
insert into pms_project_evaluate  (id,code,name,score) values(pms_project_evaluate.nextval,'03','方案设计权重(比值)','0.1');
insert into pms_project_evaluate  (id,code,name,score) values(pms_project_evaluate.nextval,'04','开发实现权重(比值)','0.1');
insert into pms_project_evaluate  (id,code,name,score) values(pms_project_evaluate.nextval,'05','项目测试权重(比值)','0.1');
insert into pms_project_evaluate  (id,code,name,score) values(pms_project_evaluate.nextval,'06','上线准备权重(比值)','0.1');
insert into pms_project_evaluate  (id,code,name,score) values(pms_project_evaluate.nextval,'07','上线权重(比值)','0.1');
insert into pms_project_evaluate  (id,code,name,score) values(pms_project_evaluate.nextval,'08','上线验证权重(比值)','0.1');
insert into pms_project_evaluate  (id,code,name,score) values(pms_project_evaluate.nextval,'09','项目验收权重(比值)','0.1');
insert into pms_project_evaluate  (id,code,name,score) values(pms_project_evaluate.nextval,'10','项目维护权重(比值)','0.1');
insert into pms_project_evaluate  (id,code,name,score) values(seq_pms_user_evaluate.nextval,'11','超过计划周期10%(应扣分值)','10');
insert into pms_project_evaluate  (id,code,name,score) values(seq_pms_user_evaluate.nextval,'12','超过计划周期25%(应扣分值)','30');
insert into pms_project_evaluate  (id,code,name,score) values(seq_pms_user_evaluate.nextval,'13','项目方案评价权重(比值)','0.25');
insert into pms_project_evaluate  (id,code,name,score) values(seq_pms_user_evaluate.nextval,'14','项目文档质量权重(比值)','0.25');
insert into pms_project_evaluate  (id,code,name,score) values(seq_pms_user_evaluate.nextval,'15','项目上线质量权重(比值)','0.25');
insert into pms_project_evaluate  (id,code,name,score) values(seq_pms_user_evaluate.nextval,'16','项目运行质量权重(比值)','0.25');

insert into pms_supplier_evaluate  (id,code,name,score) values(pms_supplier_evaluate.nextval,'01','供应商人员评价权重(比值)','0.5');
insert into pms_supplier_evaluate  (id,code,name,score) values(pms_supplier_evaluate.nextval,'02','供应商项目评价权重(比值)','0.5');

insert into PMS_PRO_STATUS (id,code,name,TYPE) values(seq_pms_pro_status.nextval,'01','已立项','1');
insert into PMS_PRO_STATUS (id,code,name,TYPE) values(seq_pms_pro_status.nextval,'02','已开始','1');
insert into PMS_PRO_STATUS (id,code,name,TYPE) values(seq_pms_pro_status.nextval,'03','进行中','1');
insert into PMS_PRO_STATUS (id,code,name,TYPE) values(seq_pms_pro_status.nextval,'04','已完成','1');
insert into PMS_PRO_STATUS (id,code,name,TYPE) values(seq_pms_pro_status.nextval,'05','已开始','2');
insert into PMS_PRO_STATUS (id,code,name,TYPE) values(seq_pms_pro_status.nextval,'06','进行中','2');
insert into PMS_PRO_STATUS (id,code,name,TYPE) values(seq_pms_pro_status.nextval,'07','已完成','2');
insert into PMS_PRO_STATUS (id,code,name,TYPE) values(seq_pms_pro_status.nextval,'08','开始','3');
insert into PMS_PRO_STATUS (id,code,name,TYPE) values(seq_pms_pro_status.nextval,'09','进行中','3');
insert into PMS_PRO_STATUS (id,code,name,TYPE) values(seq_pms_pro_status.nextval,'10','已完成','3');
insert into PMS_PRO_STATUS (id,code,name,TYPE) values(seq_pms_pro_status.nextval,'11','已暂停','3');
insert into PMS_PRO_STATUS (id,code,name,TYPE) values(seq_pms_pro_status.nextval,'12','已取消','3');


insert into pms_time (id, code, name, value) values(seq_pms_time.nextval,'01','上午上班时间','08:30');
insert into pms_time (id, code, name, value) values(seq_pms_time.nextval,'02','上午下班时间','11:30');
insert into pms_time (id, code, name, value) values(seq_pms_time.nextval,'03','午分时刻','12:00');
insert into pms_time (id, code, name, value) values(seq_pms_time.nextval,'04','下午上班时间','13:00');
insert into pms_time (id, code, name, value) values(seq_pms_time.nextval,'05','下午下班时间','17:00');


insert into pms_project_stage_child (id,PMS_PROJECT_STAGE_ID,code,name,remark) values(seq_pms_project_stage_child.nextval, (select id from pms_project_stage where code = 01),'01','项目立项','所属父阶段为[项目准备]');
insert into pms_project_stage_child (id,PMS_PROJECT_STAGE_ID,code,name,remark) values(seq_pms_project_stage_child.nextval, (select id from pms_project_stage where code = 01),'02','项目启动','所属父阶段为[项目准备]');
insert into pms_project_stage_child (id,PMS_PROJECT_STAGE_ID,code,name,remark) values(seq_pms_project_stage_child.nextval, (select id from pms_project_stage where code = 01),'03','项目资源','所属父阶段为[项目准备]');
insert into pms_project_stage_child (id,PMS_PROJECT_STAGE_ID,code,name,remark) values(seq_pms_project_stage_child.nextval, (select id from pms_project_stage where code = 01),'04','网络与设备','所属父阶段为[项目准备]');
insert into pms_project_stage_child (id,PMS_PROJECT_STAGE_ID,code,name,remark) values(seq_pms_project_stage_child.nextval, (select id from pms_project_stage where code = 02),'01','需求分析','所属父阶段为[需求确定]');
insert into pms_project_stage_child (id,PMS_PROJECT_STAGE_ID,code,name,remark) values(seq_pms_project_stage_child.nextval, (select id from pms_project_stage where code = 02),'02','需求确定','所属父阶段为[需求确定]');
insert into pms_project_stage_child (id,PMS_PROJECT_STAGE_ID,code,name,remark) values(seq_pms_project_stage_child.nextval, (select id from pms_project_stage where code = 03),'01','项目概要设计','所属父阶段为[方案设计]');
insert into pms_project_stage_child (id,PMS_PROJECT_STAGE_ID,code,name,remark) values(seq_pms_project_stage_child.nextval, (select id from pms_project_stage where code = 03),'02','系统架构设计','所属父阶段为[方案设计]');
insert into pms_project_stage_child (id,PMS_PROJECT_STAGE_ID,code,name,remark) values(seq_pms_project_stage_child.nextval, (select id from pms_project_stage where code = 03),'03','接口规划','所属父阶段为[方案设计]');
insert into pms_project_stage_child (id,PMS_PROJECT_STAGE_ID,code,name,remark) values(seq_pms_project_stage_child.nextval, (select id from pms_project_stage where code = 03),'04','数据库设计','所属父阶段为[方案设计]');
insert into pms_project_stage_child (id,PMS_PROJECT_STAGE_ID,code,name,remark) values(seq_pms_project_stage_child.nextval, (select id from pms_project_stage where code = 04),'01','程序设计','所属父阶段为[开发实现]');
insert into pms_project_stage_child (id,PMS_PROJECT_STAGE_ID,code,name,remark) values(seq_pms_project_stage_child.nextval, (select id from pms_project_stage where code = 04),'02','单元测试','所属父阶段为[开发实现]');
insert into pms_project_stage_child (id,PMS_PROJECT_STAGE_ID,code,name,remark) values(seq_pms_project_stage_child.nextval, (select id from pms_project_stage where code = 05),'01','环境准备','所属父阶段为[项目测试]');
insert into pms_project_stage_child (id,PMS_PROJECT_STAGE_ID,code,name,remark) values(seq_pms_project_stage_child.nextval, (select id from pms_project_stage where code = 05),'02','业务测试','所属父阶段为[项目测试]');
insert into pms_project_stage_child (id,PMS_PROJECT_STAGE_ID,code,name,remark) values(seq_pms_project_stage_child.nextval, (select id from pms_project_stage where code = 06),'01','上线审批','所属父阶段为[上线准备]');
insert into pms_project_stage_child (id,PMS_PROJECT_STAGE_ID,code,name,remark) values(seq_pms_project_stage_child.nextval, (select id from pms_project_stage where code = 06),'02','代码整理','所属父阶段为[上线准备]');
insert into pms_project_stage_child (id,PMS_PROJECT_STAGE_ID,code,name,remark) values(seq_pms_project_stage_child.nextval, (select id from pms_project_stage where code = 07),'01','生产环境进行上线部署','所属父阶段为[上线]');
insert into pms_project_stage_child (id,PMS_PROJECT_STAGE_ID,code,name,remark) values(seq_pms_project_stage_child.nextval, (select id from pms_project_stage where code = 08),'01','生产对上线项目进行验证','所属父阶段为[上线验证]');
insert into pms_project_stage_child (id,PMS_PROJECT_STAGE_ID,code,name,remark) values(seq_pms_project_stage_child.nextval, (select id from pms_project_stage where code = 09),'01','对已上线项目进行项目验收','所属父阶段为[项目验收]');
insert into pms_project_stage_child (id,PMS_PROJECT_STAGE_ID,code,name,remark) values(seq_pms_project_stage_child.nextval, (select id from pms_project_stage where code = 10),'01','项目后续维护','所属父阶段为[项目维护]');











































