# -*- coding: utf-8 -*-

import os
os.environ['NLS_LANG'] = 'SIMPLIFIED CHINESE_CHINA.AL32UTF8'
from database.models import db_Session
import logging
from database.models import engine
#from  database.dbconnect  import *
def select(sql):
    db_session = db_Session()
    lines = db_session.execute(sql)
    lines = [dict(zip(row.keys(), row)) for row in lines]
    db_session.close()
    return lines
def selectbyDict(tableName, dict1):
    db_session = db_Session()
    dict_len = len(dict1)
    start = 1
    sql1 = " select * from  " + tableName + " where "
    sql2 = ""
    for key in dict1:
        sql2 += key + " = '" + dict1[key] + "' "
        if start == dict_len:
            break
        start += 1
        sql2 += "and "

    sql = sql1 + sql2 
    lines = db_session.execute(sql)
    lines = [dict(zip(row.keys(), row)) for row in lines]
    db_session.close()
    return lines
        

def select_limit_with_count( search_sql, pageSize, curPage):
    start = pageSize * curPage - pageSize + 1
    end = pageSize * curPage
    db_session = db_Session()
    SQL_LIMIT = '''
        select *
        from (
           select
             rownum as rn,
             temp_a.*
           from ( 
                  %s
                ) temp_a
              ) temp_b
        where temp_b.rn between %d and %d
    ''' % (search_sql, start, end)
    SQL_COUNT = '''select count(0) from (%s)''' % search_sql
    count = db_session.execute(SQL_COUNT).first()[0]
    res = db_session.execute(SQL_LIMIT)
    data = [dict(zip(row.keys(), row)) for row in res]
    db_session.close()
    return data, count

def insert(sql):
    db_session = db_Session()
    try:
        db_session.execute(sql)
        db_session.commit()
        db_session.close()
    except Exception as e:
            logging.error(e)
            db_session.rollback()

def update(sql):
    db_session = db_Session()
    try:
        db_session.execute(sql)
        db_session.commit()
        db_session.close()
    except Exception as e:
        logging.error(e)
        db_session.rollback()

def updatebyDict(tableName, dict1):
    db_session = db_Session()
    try:
        id = dict1.pop('id')
        dict_len = len(dict1)
        start = 1
        sql1 = " update " + tableName + " set "
        sql2 = ""
        for key in dict1:
            sql2 += key + " = '" + dict1[key] + "' "
            if start == dict_len:
                break
            start += 1
            sql2 += ", "
            
        sql = sql1 + sql2 + " where id = '%s'" %id 
        print (sql)
        db_session.execute(sql)
        db_session.commit()
        db_session.close()
    except Exception as e:
            logging.error(e)
            db_session.rollback()

def insertbyDict(tableName, dict1):
    db_session = db_Session()
    try:
        dict_len = len(dict1)
        start = 1
        sql1 = " insert into  %s  "  %tableName 
        sql2 = ""
        sql3 = ""
        for key in dict1:
            sql2 += key
            sql3 += "'%s'" %dict1[key]
            if start == dict_len:
                break
            start += 1
            sql2 += ", "
            sql3 += ", "
        sql2 = " (id, %s) " %sql2
        sql3 = "  values(seq_%s.nextval, %s) " %(tableName, sql3)
            
        sql = sql1 + sql2 + sql3
        db_session.execute(sql)
        db_session.commit()
        db_session.close()
    except Exception as e:
            logging.error(e)
            db_session.rollback()

def own_excute(sql):
    db_session = db_Session()
    try:
        db_session.execute(sql)
        db_session.commit()
        db_session.close()
    except Exception as e:
        logging.error(e)
        db_session.rollback()

def call_proc(pro_name,params):
    connection = engine.raw_connection()
    try:
        cursor = connection.cursor()
        cursor.callproc(pro_name,params)
        connection.commit()
        connection.close()
    except Exception as e:
        print(e)
        connection.rollback()

