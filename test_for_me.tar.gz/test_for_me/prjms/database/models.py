# -*- coding: utf-8 -*-
import os

from sqlalchemy import *
#from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import *
import sys
sys.path.append('../')
from config import config
import datetime


os.environ['NLS_LANG'] = 'AMERICAN_AMERICA.AL32UTF8'
engine = create_engine('oracle://{}:{}@{}/{}'.format(config.DATABASE_USER, config.DATABASE_PASS,
                                                     config.DATABASE_HOST, config.DATABASE_NAME),
                       pool_size=300, max_overflow=300)

#Base = declarative_base(engine)
db_Session = sessionmaker(bind=engine)
metadata = MetaData(engine)

now = datetime.datetime.now().strftime('%Y%m%d')


"""==================建表模型=========================="""
#菜单表
pms_menu = Table('pms_menu', metadata,
    Column('id', BigInteger,Sequence('seq_pms_menu') , primary_key = True),
    Column('name', String(64), nullable = False),
    Column('url', String(128)),
    Column('icon',String(64)),
    Column('pid', String(8))
)

#状态表
pms_status = Table('pms_status', metadata,
    Column('id', BigInteger,Sequence('seq_pms_status'), primary_key = True),
    Column('code', String(32), nullable = False),
    Column('name', String(64), nullable = False)
)

#角色表
pms_role = Table('pms_role', metadata,
    Column('id', BigInteger,Sequence('seq_pms_role'), primary_key = True),
    Column('code', String(64), nullable = True),
    Column('name', String(64), nullable = False),
    Column('type', BigInteger, nullable = False, doc = '1. 人员角色     2  机构角色'), 
    Column('status_id', BigInteger, ForeignKey('pms_status.id'), nullable = False)  
)

#人员评价参照分值表
pms_user_evaluate = Table('pms_user_evaluate', metadata,
    Column('id', BigInteger,Sequence('seq_pms_user_evaluate'), primary_key = True),
    Column('code', String(4), nullable = False ,doc = ''),
    Column('name', String(128), nullable = False),
    Column('score', String(4), nullable = False)
)

#机构类型表
pms_org_type = Table('pms_org_type', metadata,
    Column('id', BigInteger,Sequence('seq_pms_org_type'), primary_key = True),
    Column('name', String(64), nullable = False)
)

#参数列表总表
pms_param_list = Table('pms_param_list', metadata,
    Column('id', BigInteger,Sequence('seq_pms_param_list'), primary_key = True),
    Column('name', String(32), nullable = False ),
    Column('map_addr', String(256), nullable = False),
    Column('type', String(1), nullable = False, doc = '1 基本参数类   ， 2 项目管理类  ，3  评价模型类 ')
)

#机构表
pms_organizations = Table('pms_organizations', metadata,
    Column('id', BigInteger,Sequence('seq_pms_organizations'), primary_key = True),
    Column('code', String(16), nullable = False ),
    Column('name', String(128), nullable = False),
    Column('status_id', BigInteger, ForeignKey('pms_status.id'), nullable = False), #pms_status 表 id
    Column('st_date', String(8),  nullable = False),
    Column('type_id', BigInteger, ForeignKey('pms_org_type.id'), nullable = False), #pms_org_type 表的id
)

#机构角色关系表
pms_org_role = Table('pms_org_role', metadata,
    Column('id', BigInteger,Sequence('seq_pms_org_role'), primary_key = True),
    Column('org_id', BigInteger, ForeignKey('pms_organizations.id'), nullable = False),
    Column('role_id', BigInteger, ForeignKey('pms_role.id'), nullable = False)
)

#系统用户表
pms_user = Table('pms_user', metadata,
    Column('id', BigInteger,Sequence('seq_pms_user'), primary_key = True),
    Column('no', String(16), nullable = False),
    Column('name', String(40), nullable = False),
    Column('password', String(512), nullable = False),
    Column('phone_no', String(11), nullable = False),
    Column('org_id', BigInteger, ForeignKey('pms_organizations.id'), nullable = False), # pms_organizations 表 id
    Column('status_id', BigInteger, ForeignKey('pms_status.id'), nullable = False), # pms_status 表 id
    Column('st_date', String(8),  nullable = False ), #进场时间
    Column('ed_date', String(8),  nullable = True ),  #离场时间
    Column('exempt_ck_in', String(8), server_default='false'  ),  #是否免考勤   true 无需考勤   false 需要考勤
    Column('self_sign',String(128)),
    Column('pms_user_evaluate_id',BigInteger,ForeignKey('pms_user_evaluate.id')) #纪律情况id 
)

#人员角色关系表
pms_user_role = Table('pms_user_role', metadata,
    Column('id', BigInteger,Sequence('seq_pms_user_role'), primary_key = True),
    Column('user_id', BigInteger, ForeignKey('pms_user.id'), nullable = False),
    Column('role_id', BigInteger, ForeignKey('pms_role.id'), nullable = False)
)


#风险预警值设定表
pms_risk_warn_value= Table('pms_risk_warn_value', metadata,
    Column('id', BigInteger,Sequence('seq_pms_risk_warn_value'), primary_key = True),
    Column('code', String(4), nullable = False ,doc = ''),
    Column('name', String(128), nullable = False),
    Column('score', String(4), nullable = False)
)

#角色菜单权限表
pms_role_menu = Table('pms_role_menu', metadata,
    Column('id', BigInteger,Sequence('seq_pms_role_menu'), primary_key = True),
    Column('role_id', BigInteger,ForeignKey('pms_role.id')),
    Column('menu_id', BigInteger,ForeignKey('pms_menu.id')),
)

#菜单按钮表
pms_menu_button = Table('pms_menu_button', metadata,
    Column('id', BigInteger,Sequence('seq_pms_menu_button'), primary_key = True),
    Column('menu_id', BigInteger,ForeignKey('pms_menu.id')),
    Column('name', String(64)), #按钮名称
    Column('html_button_id', String(128)), #按钮 html页面中对应控件id
)

#角色按钮权限表
pms_role_menu_button = Table('pms_role_menu_button', metadata,
    Column('id', BigInteger,Sequence('seq_pms_role_menu_button'), primary_key = True),
    Column('role_id', BigInteger,ForeignKey('pms_role.id')),
    Column('pms_menu_button_id', BigInteger,ForeignKey('pms_menu_button.id')),
)

#项目性质表
pms_project_property  = Table('pms_project_property', metadata,
    Column('id', BigInteger,Sequence('seq_pms_project_property'), primary_key = True),
    Column('code', String(32), nullable = False ,doc = ''),
    Column('name', String(64), nullable = False),
    Column('remark', String(256), nullable = False)
)
#项目类型表
pms_project_type = Table('pms_project_type', metadata,
    Column('id', BigInteger,Sequence('seq_pms_project_type'), primary_key = True),
    Column('code', String(32), nullable = False ,doc = ''),
    Column('name', String(64), nullable = False),
    Column('remark', String(256), nullable = False)
)

#项目阶段表
pms_project_stage = Table('pms_project_stage', metadata,
    Column('id', BigInteger,Sequence('seq_pms_project_stage'), primary_key = True),
    Column('code', String(32), nullable = False ,doc = ''),
    Column('name', String(64), nullable = False),
    Column('remark', String(256), nullable = False)
)

#项目阶段文档表
pms_project_stage_doc = Table('pms_project_stage_doc', metadata,
    Column('id', BigInteger,Sequence('seq_pms_project_stage_doc'), primary_key = True),
    Column('project_stage_code', String(8), nullable = False ,doc = 'pms_project_stage.code'),
    Column('code', String(32), nullable = False),
    Column('name', String(64), nullable = False),
    Column('url', String(512), nullable = True),
    Column('content_type', String(512), nullable = True)
)

#项目阶段表_子项表
pms_project_stage_child = Table('pms_project_stage_child', metadata,
    Column('id', BigInteger,Sequence('seq_pms_project_stage_child'), primary_key = True),
    Column('pms_project_stage_id', BigInteger,ForeignKey('pms_project_stage.id'), doc='父表pms_project_stage id'),
    Column('code', String(32), nullable = False),
    Column('name', String(64), nullable = False),
    Column('remark', String(256), nullable = True)
)

#项目评价参照分值表
pms_project_evaluate = Table('pms_project_evaluate', metadata,
    Column('id', BigInteger,Sequence('seq_pms_project_evaluate'), primary_key = True),
    Column('code', String(4), nullable = False ,doc = ''),
    Column('name', String(128), nullable = False),
    Column('score', String(4), nullable = False)
)

#供应商参照评价表
pms_supplier_evaluate = Table('pms_supplier_evaluate', metadata,
    Column('id', BigInteger,Sequence('seq_pms_supplier_evaluate'), primary_key = True),
    Column('code', String(4), nullable = False ,doc = ''),
    Column('name', String(128), nullable = False),
    Column('score', String(4), nullable = False)
)

#项目合同相关状态表
pms_pro_status = Table('pms_pro_status', metadata,
    Column('id', BigInteger,Sequence('seq_pms_pro_status'), primary_key = True),
    Column('code', String(32), nullable = False),
    Column('name', String(64), nullable = False),
    Column('type', String(64), nullable = False) # 1 项目总体状态   2  阶段任务状态   3  合同状态
)

#合同基础登记表
pms_contract = Table('pms_contract', metadata,
    Column('id', BigInteger,Sequence('seq_pms_contract'), primary_key = True),
    Column('code', String(64), nullable = False), #合同编号
    Column('name', String(256), nullable = False), #合同名称
    Column('project_name', String(256), nullable = False), #项目名称
    Column('supplier_name', String(256), nullable = False), #供应商名称
    Column('contract_amount', String(256), nullable = False), #合同金额
    Column('supplier_linkman', String(256), nullable = False), #供应商联系人
    Column('execution_period', String(256), nullable = False), #实施期限
    Column('start_date', String(256), nullable = False), #合同生效时间
    Column('status_id', BigInteger,ForeignKey('pms_pro_status.id'), nullable = False), #合同状态
    Column('user_id', BigInteger,ForeignKey('pms_user.id'), nullable = False) #合同登记者
)

#合同其他事项-阶段时间记录表
pms_contract_stage = Table('pms_contract_stage', metadata,
    Column('id', BigInteger,Sequence('seq_pms_contract_stage'), primary_key = True),
    Column('pms_contract_id',BigInteger,ForeignKey('pms_contract.id'), nullable = False),
    Column('name', String(128), nullable = False), #合同阶段名字
    Column('start_date', String(16), nullable = False), #开始时间
    Column('end_date', String(16), nullable = False) #结束时间
)

#合同其他事项-特别约定事项
pms_contract_special_item = Table('pms_contract_special_item', metadata,
    Column('id', BigInteger,Sequence('seq_pms_contract_special_item'), primary_key = True),
    Column('pms_contract_id',BigInteger,ForeignKey('pms_contract.id'), nullable = False),
    Column('remark', String(512), nullable = False) #合同特殊约定事项
)

#合同执行情况表
pms_contract_exe_condtn = Table('pms_contract_exe_condtn', metadata,
    Column('id', BigInteger,Sequence('seq_pms_contract_exe_condtn'), primary_key = True),
    Column('pms_contract_id',BigInteger,ForeignKey('pms_contract.id'), nullable = False),
    Column('execute_progress', String(128), nullable = True), #合同阶段
    Column('status_id', BigInteger,ForeignKey('pms_pro_status.id'), nullable = False) #合同状态
)

#合同付款情况表
pms_contract_pay_condtn = Table('pms_contract_pay_condtn', metadata,
    Column('id', BigInteger,Sequence('seq_pms_contract_pay_condtn'), primary_key = True),
    Column('pms_contract_id',BigInteger,ForeignKey('pms_contract.id'), nullable = False),
    Column('pay_date', String(128), nullable = False), #付款时间
    Column('amount', String(128), nullable = False), #金额
    Column('pay_type', String(32), nullable = False), #付款性质
    Column('remark', String(128), nullable = False), #备注说明
    Column('paid', String(128), nullable = False), #已付金额
    Column('unpaid', String(128), nullable = False), #未付金额
    Column('paid_ratio', String(128), nullable = False) #已付款比例
)

#合同文件上传表
pms_contract_file = Table('pms_contract_file', metadata,
    Column('id', BigInteger,Sequence('seq_pms_contract_file'), primary_key = True),
    Column('pms_contract_id',BigInteger,ForeignKey('pms_contract.id'), nullable = False),
    Column('file_name', String(128), nullable = False),
    Column('file_type', String(16), nullable = False),
    Column('file_url', String(512), nullable = False) #文件地址
)

#供应商资质信息表
pms_supplier_qualification = Table('pms_supplier_qualification', metadata,
    Column('id', BigInteger,Sequence('seq_pms_supplier_qualification'), primary_key = True),
    Column('pms_organizations_id',BigInteger,ForeignKey('pms_organizations.id'), nullable = False),
    Column('place', String(128), nullable = False),
    Column('build_date', String(16), nullable = False),
    Column('corp_rep', String(128), nullable = False),
    Column('reg_cap', String(32), nullable = True),
    Column('sale_contact', String(64), nullable = False),
    Column('sale_contact_phone', String(16), nullable = False),
    Column('sale_contact_email', String(128), nullable = True),
    Column('tech_contact', String(64), nullable = False),
    Column('tech_contact_phone', String(16), nullable = False),
    Column('tech_contact_email', String(128), nullable = True) 
)

#供应商资文件上传表
pms_supplier_file = Table('pms_supplier_file', metadata,
    Column('id', BigInteger,Sequence('seq_pms_supplier_file'), primary_key = True),
    Column('pms_organizations_id',BigInteger,ForeignKey('pms_organizations.id'), nullable = False),
    Column('file_name', String(128), nullable = False),
    Column('file_type', String(16), nullable = False),
    Column('file_url', String(512), nullable = False) #文件地址
)

#系统时间设置表
pms_time = Table('pms_time', metadata,
    Column('id', BigInteger,Sequence('seq_pms_time'), primary_key = True),
    Column('code', String(32), nullable = False),
    Column('name', String(64), nullable = False),
    Column('value', String(64), nullable = False) 
)

#人员评价汇总表
pms_user_evaluation_score = Table('pms_user_evaluation_score',metadata,
    Column('id',BigInteger,Sequence('seq_pms_user_evaluation_score') , primary_key = True),
    Column('year',String(8)),
    Column('month',String(8)),
    Column('pms_user_id', BigInteger, ForeignKey('pms_user.id'), nullable = False),
    Column('check_in_deducted',String(64)),#考勤扣分
    Column('discipline_deducted',String(64)),#纪律扣分
    Column('residue_score',String(64)),#总评分数
    Column('manual_up',String(64)) # true 手工修改过    false  未手工修改 ,若手工修改过此月分数,则自动计算分数时跳过此用户
)

#供应商评价汇总表
pms_supplier_eva_score = Table('pms_supplier_eva_score',metadata,
    Column('id',BigInteger,Sequence('seq_pms_supplier_eva_score') , primary_key = True),
    Column('pms_organizations_id', BigInteger, ForeignKey('pms_organizations.id'), nullable = False),
    Column('user_avg_score',String(64)),#人员平均分
    Column('project_avg_score',String(64)),#项目平均分
    Column('residue_score',String(64)),#总评分数
    Column('handscore',String(64))#手工评分 
)

#预警提醒记录表
pms_risk_remind_record = Table('pms_risk_remind_record', metadata,
    Column('id', BigInteger,Sequence('seq_pms_risk_remind_record'), primary_key = True),
    Column('part_id', String(32), nullable = False),
    Column('year', String(16), nullable = False),
    Column('month', String(16), nullable = False),
    Column('type', String(64), nullable = False) 
)

################----------------------------------------------------------------sguo------------------

#签到记录表
pms_signrecode = Table('pms_signrecode',metadata,
    Column('id',BigInteger,Sequence('seq_pms_signrecode') , primary_key = True),
    Column('time',DateTime,nullable=False),
    Column('datetime',String(64)),
    Column('am_start_time',String(64)),
    Column('am_end_time',String(64)),
    Column('noon_time',String(64)),
    Column('pm_start_time',String(64)),
    Column('pm_end_time',String(64)),
    Column('pms_user_id', BigInteger, ForeignKey('pms_user.id'), nullable = False),
    Column('latitude',String(64)),
    Column('longitude',String(64)),
)


#项目表
pms_project = Table('pms_project',metadata,
    Column('id',BigInteger,Sequence('seq_pms_project'),primary_key = True),
    Column('code',String(64)),#项目编号
    Column('name',String(64)),#项目名称
    Column('ht_code',String(64)),#合同外键
    Column('manager_user_id',BigInteger,ForeignKey('pms_user.id'),nullable = False),#项目管理人id
    Column('pms_dev_id',BigInteger),#项目完成进度
    Column('pms_number',BigInteger),#预计工作量
    Column('p_start_date',String(64)),#项目预计开始日期
    Column('p_end_date',String(64)),#项目预计结束日期
    Column('t_start_date',String(64)),#项目开始日期
    Column('t_end_date',String(64)),#项目结束日期
    Column('pms_project_property_id',BigInteger,ForeignKey('pms_project_property.id')),#项目性质
    Column('pms_pro_type_id',BigInteger,ForeignKey('pms_project_type.id')),#项目类型
    Column('pms_dangous_level',BigInteger),#风险等级
    Column('pms_supp_id',BigInteger),#供应商外键
    Column('org_manager_user_id',BigInteger,ForeignKey('pms_user.id')),#行方项目管理人
    Column('pms_org_id',BigInteger),#所属机构外键
    Column('req_org_id',BigInteger),#需求机构
    Column('req_manager_user_id',BigInteger),#需求机构联系人
    Column('tec_org_id',BigInteger),#技术支持机构
    Column('tec_manager_user_id',BigInteger),#技术支持机构联系人
    Column('dep_org_id',BigInteger),#研发部门
    Column('dep_manager_user_id',BigInteger),#研发部门联系人
    Column('tes_org_id',BigInteger),#测试部门
    Column('tes_manager_user_id',BigInteger),#测试部门联系人
    Column('pms_level',BigInteger), #优先级
    Column('is_child',BigInteger),#0不为子项目，1 为子项目
    Column('father',BigInteger),#此字段内容为父项目的id
    Column('status',BigInteger)#状态

)
#项目完成进度表
pms_project_dev = Table('pms_project_dev',metadata,
    Column('id',BigInteger,Sequence('seq_pms_project_dev'),primary_key = True),
    Column('pms_project_id',BigInteger),#项目id
    Column('dev_user_id',BigInteger,ForeignKey('pms_user.id')),#项目进度主要负责人员
    Column('pms_project_stage_id',BigInteger,ForeignKey('pms_project_stage.id')),#项目进度名
    Column('p_start_date',Date),#进度预计开始日期
    Column('p_end_date',Date),#进度预计结束日期
    Column('start_date',Date),#进度开始日期
    Column('end_date',Date),#进度结束日期
    Column('dev_number',String(64)),#进度评分
    Column('files',String(256)),#上传文件目录
    Column('use_dates',BigInteger),#已耗费的时间
    Column('worksday',BigInteger),
    Column('is_comp',Boolean)#是否已经完成
)

#项目子任务-用户关系表
pms_project_dev_child_user = Table('pms_project_dev_child_user',metadata,
    Column('id',BigInteger,Sequence('seq_pms_project_dev_child_user'),primary_key = True),
    Column('dev_child_id',BigInteger,ForeignKey('pms_project_dev_child.id')),
    Column('user_id',BigInteger,ForeignKey('pms_user.id')),
    Column('power',BigInteger)#查询修改权限 0-不可编辑，1-可编辑，默认为0
)
#项目子任务表

pms_project_dev_child = Table('pms_project_dev_child',metadata,
    Column('id',BigInteger,Sequence('seq_pms_project_dev_child'),primary_key = True),
    Column('pms_project_stage_child_id',ForeignKey('pms_project_stage_child.id')),
    Column('pms_project_dev_id',ForeignKey('pms_project_dev.id')),
)



#项目进度报告表
pms_project_dev_report = Table('pms_project_dev_report',metadata,
    Column('id',BigInteger,Sequence('seq_pms_project_dev_report'),primary_key = True),
    Column('dev_id',BigInteger,ForeignKey('pms_project_dev.id')),#项目阶段
    Column('message1',Text),#进度内的子任务名
    Column('message2',Text),#以下皆为子任务内容
    Column('message3',Text),
    Column('message4',Text),
    Column('message5',Text),
    Column('message6',Text),

)

#项目阶段周期表
pms_project_dev_comment = Table('pms_project_dev_comment',metadata,
    Column('id',BigInteger,Sequence('seq_pms_project_dev_comment'),primary_key = True),
    Column('pms_project_dev_id',BigInteger,ForeignKey('pms_project_dev.id')),
    Column('code',BigInteger),#阶段周期自动计算评分
    Column('mes_code',BigInteger),#阶段进度评分
    Column('code_user',BigInteger),#阶段评分人
    Column('type',String(64)),
)


#项目评价表
pms_project_comment = Table('pms_project_comment',metadata,
    Column('id',BigInteger,Sequence('seq_pms_project_comment'),primary_key = True),
    Column('pms_project_id',BigInteger),
    Column('comment_user_id',BigInteger),#项目评价人id
    Column('comment_cycle_all',BigInteger),#周期评分
    Column('comment_quality_all',BigInteger),#质量评分
    Column('code',BigInteger),#项目整体计算得出评分
    Column('discu',String(64)),#项目评分说明
    Column('code_user',BigInteger),#项目评价人修改后评分
    Column('status',String(64)),#项目评分状态
)

#项目评价质量表
pms_project_comment_detail = Table('pms_project_comment_detail',metadata,
    Column('id',BigInteger,Sequence('seq_pms_project_comment_detail'),primary_key = True),
    Column('pms_project_id',BigInteger),
    Column('type',String(64)),
    Column('comment_user_id',BigInteger),#项目评价人id
    Column('code',BigInteger),#质量评分
    Column('discu',String(64)),#项目评分说明
)

#项目进度关联用户表
pms_project_dev_user = Table('pms_project_dev_user',metadata,
    Column('id',BigInteger,Sequence('seq_pms_project_dev_user'),primary_key = True),
    Column('dev_id',BigInteger,ForeignKey('pms_project_dev.id')),
    Column('user_id',BigInteger,ForeignKey('pms_user.id')),
    Column('worksday',BigInteger),
    Column('number',BigInteger),
    Column('date',Date),
)

#项目工作计划表
pms_project_plan = Table('pms_project_plan',metadata,
    Column('id',BigInteger,Sequence('seq_pms_project_plan'),primary_key = True),
    Column('plan_code',BigInteger),
    Column('pms_project_dev_id',BigInteger,ForeignKey('pms_project_dev.id')),
    Column('date',BigInteger),
    Column('code',BigInteger),
    
)
#子项目表
pms_child_project = Table('pms_child_project',metadata,
    Column('id',BigInteger,Sequence('seq_pms_child_project'),primary_key = True),
    Column('code',String(64)),#项目编号
    Column('name',String(64)),#项目名称
    Column('f_id',BigInteger,ForeignKey('pms_project.id')),#父项目id
    Column('manager_user_id',BigInteger,ForeignKey('pms_user.id'),nullable = False),#项目管理人id
    Column('pms_dev_id',BigInteger),#项目完成进度
    Column('pms_number',BigInteger),#预计工作量
    Column('p_start_date',String(64)),#项目预计开始日期
    Column('p_end_date',String(64)),#项目预计结束日期
    Column('t_start_date',String(64)),#项目开始日期
    Column('t_end_date',String(64)),#项目结束日期
    Column('pms_project_property_id',BigInteger,ForeignKey('pms_project_property.id')),#项目性质
    Column('pms_pro_type_id',BigInteger,ForeignKey('pms_project_type.id')),#项目类型
    Column('pms_dangous_level',BigInteger),#风险等级
    Column('pms_supp_id',BigInteger),#供应商外键
    Column('pms_org_id',BigInteger),#所属机构外键
    Column('pms_level',BigInteger), #优先级
    Column('status',BigInteger)#状态
)
#子项目完成进度表
pms_child_project_plan = Table('pms_child_project_plan',metadata,
    Column('id',BigInteger,Sequence('seq_pms_child_plan'),primary_key = True),
    Column('plan_work',String(512)),
    Column('plan_number',BigInteger),
    Column('manage_user',BigInteger,ForeignKey('pms_user.id'))
)

#工作日志汇报
pms_work_day_mes = Table('pms_work_day_mes',metadata,
    Column('id',BigInteger,Sequence('seq_pms_work_day_mes'),primary_key = True),
    Column('title',String(128)),
    Column('con',String(1024)),
    Column('work_date',Date),
    Column('pms_user_id',BigInteger,ForeignKey('pms_user.id')),
    Column('pms_project_id',BigInteger,ForeignKey('pms_project.id'))
)
#子项目进度关联用户表
pms_child_project_dev_user = Table('pms_child_project_dev_user',metadata,
    Column('id',BigInteger,Sequence('seq_pms_child_project_dev_user')),
    Column('pms_user_id',BigInteger,ForeignKey('pms_user.id')),#子项目负责人编号
    Column('pms_child_project_plan_id',BigInteger,ForeignKey('pms_child_project_plan.id')),#子项目编号
    Column('complate',String(32)),#是否已完成
    Column('worksday',BigInteger),#工作时间
    Column('number',BigInteger),#进度评分
    Column('comp_date',Date),#进度完成日期
)

#工作交互消息记录表
#此表用于记录员工之间的互发消息交互
pms_send_mes_data = Table('pms_send_mes_data',metadata,
    Column('id',BigInteger,Sequence('seq_pms_send_mes_data')),
    Column('mes',String(1024)),#信息内容
    Column('type',BigInteger),# 0 为新消息  1为旧消息
    Column('send_date',Date),#消息发送时间
    Column('get_data_user_id',BigInteger),#消息接收的人员编号
    Column('send_data_user_id',BigInteger),#消息发送的人员编号
)


#项目进度变动与操作消息记录表
pms_mes_recode = Table('pms_mes_recode',metadata,
    Column('id',BigInteger,Sequence('seq_pms_mes_recode')),
    Column('project_id',BigInteger),#消息对应的项目编号
    Column('project_pro_id',BigInteger),#消息对应的项目阶段编号
    Column('type',BigInteger),# 0 为新消息  1为旧消息
    Column('mes',String(1024)),#信息内容
    Column('send_date',Date),#消息发送时间
    Column('get_data_user_id',BigInteger),#消息接收的人员编号
    Column('send_data_user_id',BigInteger),#消息发送的人员编号
)


#ssb部门菜单权限表
pms_role_stage = Table('pms_role_stage', metadata,
    Column('id', BigInteger,Sequence('seq_pms_role_stage'), primary_key = True),
    Column('role_id', BigInteger),
    Column('stage_id', BigInteger)
)

#ssb项目资源表
pms_dev_and_res = Table('pms_dev_and_res',metadata,
    Column('id', BigInteger,Sequence('seq_pms_dev_and_res'), primary_key = True),
    Column('project_id',BigInteger),
    Column('sup_id',BigInteger),
    Column('con',String(1024)),
    Column('type',String(64))
)
#ssb风险等级表
pms_risk_param = Table('pms_risk_param',metadata,
    Column('id', BigInteger,Sequence('seq_pms_risk_param'), primary_key = True),
    Column('code',String(32)),
    Column('name',String(32)),
    Column('doc',String(1024)),
    Column('type',String(64))
)

#ssb项目评论表
pms_project_commes = Table('pms_project_commes',metadata,
    Column('id',BigInteger,Sequence('seq_pms_project_commes'),primary_key = True),
    Column('con',String(1024)),
    Column('work_date',Date),
    Column('pms_user_id',BigInteger,ForeignKey('pms_user.id')),
    Column('pms_project_id',BigInteger,ForeignKey('pms_project.id'))
)

#文件上传记录表
pms_file_upload = Table('pms_file_upload',metadata,
    Column('id', BigInteger,Sequence('seq_pms_file_upload'),primary_key = True),
    Column('dev_id',BigInteger,nullable = False,doc='pms_project_dev.id'),
    Column('pms_project_stage_code',BigInteger,nullable = False,doc='pms_project_stage_doc.project_stage_code'),
    Column('code', BigInteger, nullable = False,doc='pms_project_stage_doc.code'),
    Column('url', String(512)),
    Column('real_name',String(512))
)

#项目阶段概要
pms_satge_doc_main = Table('pms_stage_doc_main', metadata,
    Column('id', BigInteger,Sequence('seq_pms_stage_doc_main'),primary_key = True),
    Column('pms_project_id',BigInteger),
    Column('pms_project_stage_code',BigInteger),
    Column('type',BigInteger),
    Column('text',Text),
    Column('title',String(256)),
    Column('con',String(256))
)
#记录私聊消息
pms_private_chat = Table('pms_private_chat', metadata,
    Column('id', BigInteger,Sequence('seq_pms_private_chat'),primary_key = True),
    Column('mes',String(2048)),
    Column('type',BigInteger),
    Column('timestamp',BigInteger),
    Column('send_mes_user_id',BigInteger),
    Column('get_mes_user_id',BigInteger)
)
#群聊消息记录
pms_group_chat = Table('pms_group_chat',metadata,
    Column('id',BigInteger,Sequence('seq_pms_group_chat'),primary_key = True),
    Column('mes',String(2048)),
    Column('timestamp',BigInteger),
    Column('send_mes_user_id',BigInteger),
    Column('pms_project_id', BigInteger)
)
#记录各个进度的文档有哪些
pms_project_stage_file = Table('pms_project_stage_file',metadata,
    Column('id',BigInteger,Sequence('seq_pms_project_stage_file'),primary_key = True),
    Column('dev_id',BigInteger,doc="pms_project_dev.id"),
    Column('stage_doc_id',BigInteger,doc="pms_project_stage_doc.id")
)
#风险消息记录表
pms_risk_mes = Table('pms_risk_mes',metadata,
    Column('id',BigInteger,Sequence('seq_pms_risk_mes'),primary_key = True),
    Column('project_id',BigInteger,doc='pms_project.id'),
    Column('dev_id',BigInteger,doc='pms_project_dev.id'),
    Column('get_mes_user_id',BigInteger,doc='pms_user.id'),
    Column('mes',String(512)),
    Column('time',Date),
    Column('read_time',Date),
    Column('status',BigInteger) # 0为未读，1为已读
)
#计划变更记录
pms_plan_change_mes = Table('pms_plan_change_mes',metadata,
    Column('id',BigInteger,Sequence('seq_pms_plan_change_mes'),primary_key = True),
    Column('user_id',BigInteger,doc = 'pms_user.id'),
    Column('project_id',BigInteger,doc = 'pms_project.id'),
    Column('time',Date),
    Column('change',String(1024)),  #操作记录
    Column('mes',String(1024))   #变更原因
)
metadata.create_all(engine)
